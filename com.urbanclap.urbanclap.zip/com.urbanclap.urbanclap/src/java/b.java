/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
public class b {
    public static /* synthetic */ int a(boolean bl) {
        if (bl) {
            return 1231;
        }
        return 1237;
    }
}

