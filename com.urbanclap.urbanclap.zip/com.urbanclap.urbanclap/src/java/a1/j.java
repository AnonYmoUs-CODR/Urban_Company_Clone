/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Void
 *  org.json.JSONArray
 */
package a1;

import a1.f;
import a1.g;
import org.json.JSONArray;

public class j
implements f<Void, g<JSONArray>> {
}

