/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package a1;

import a1.g;

public class h<TResult> {
    public final g<TResult> a = new g();

    public g<TResult> a() {
        return this.a;
    }

    public void b() {
        if (this.e()) {
            return;
        }
        throw new IllegalStateException("Cannot cancel a completed task.");
    }

    public void c(Exception exception) {
        if (this.f(exception)) {
            return;
        }
        throw new IllegalStateException("Cannot set the error on a completed task.");
    }

    public void d(TResult TResult) {
        if (this.g(TResult)) {
            return;
        }
        throw new IllegalStateException("Cannot set the result of a completed task.");
    }

    public boolean e() {
        return this.a.y();
    }

    public boolean f(Exception exception) {
        return this.a.z(exception);
    }

    public boolean g(TResult TResult) {
        return this.a.A(TResult);
    }
}

