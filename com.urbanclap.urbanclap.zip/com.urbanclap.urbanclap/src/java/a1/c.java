/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 */
package a1;

import android.content.Intent;
import android.os.Bundle;

public final class c {
    public static Bundle a(Intent intent) {
        return intent.getBundleExtra("al_applink_data");
    }

    public static Bundle b(Intent intent) {
        Bundle bundle = c.a(intent);
        if (bundle == null) {
            return null;
        }
        return bundle.getBundle("extras");
    }
}

