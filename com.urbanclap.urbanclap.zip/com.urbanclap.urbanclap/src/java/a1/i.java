/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  bolts.UnobservedTaskException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Throwable
 */
package a1;

import a1.g;
import bolts.UnobservedTaskException;

public class i {
    public g<?> a;

    public i(g<?> g2) {
        this.a = g2;
    }

    public void a() {
        this.a = null;
    }

    public void finalize() {
        block5 : {
            g<?> g2 = this.a;
            if (g2 == null) break block5;
            g.h h2 = g.r();
            if (h2 == null) break block5;
            h2.a(g2, new UnobservedTaskException((Throwable)g2.p()));
        }
        return;
        finally {
            super.finalize();
        }
    }
}

