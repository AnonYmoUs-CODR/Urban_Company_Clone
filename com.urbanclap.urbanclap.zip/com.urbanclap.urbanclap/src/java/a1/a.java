/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package a1;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class a {
    public static final a b;
    public static final int c;
    public static final int d;
    public static final int e;
    public final Executor a = new b(null);

    public static {
        int n;
        b = new a();
        c = n = Runtime.getRuntime().availableProcessors();
        d = n + 1;
        e = 1 + n * 2;
    }

    @SuppressLint(value={"NewApi"})
    public static void a(ThreadPoolExecutor threadPoolExecutor, boolean bl) {
        if (Build.VERSION.SDK_INT >= 9) {
            threadPoolExecutor.allowCoreThreadTimeOut(bl);
        }
    }

    public static ExecutorService b() {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(d, e, 1L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue());
        a.a(threadPoolExecutor, true);
        return threadPoolExecutor;
    }

    public static Executor c() {
        return a.b.a;
    }

    public static class b
    implements Executor {
        public b() {
        }

        public /* synthetic */ b(a a2) {
            this();
        }

        public void execute(Runnable runnable) {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }

}

