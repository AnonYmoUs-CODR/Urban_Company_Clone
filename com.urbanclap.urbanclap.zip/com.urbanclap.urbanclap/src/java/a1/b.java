/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.List
 */
package a1;

import android.net.Uri;
import java.util.Collections;
import java.util.List;

public class b {
    public List<a> a;

    public b(Uri uri, List<a> list, Uri uri2) {
        if (list == null) {
            list = Collections.emptyList();
        }
        this.a = list;
    }

    public static class a {
        public a(String string, String string2, Uri uri, String string3) {
        }
    }

}

