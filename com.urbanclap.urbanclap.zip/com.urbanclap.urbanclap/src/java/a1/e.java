/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a1;

public class e {
    public boolean a() {
        throw null;
    }
}

