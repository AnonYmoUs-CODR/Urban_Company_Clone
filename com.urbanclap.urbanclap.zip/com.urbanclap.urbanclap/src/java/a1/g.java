/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a1.g$a
 *  a1.g$b
 *  a1.g$c
 *  a1.g$e$a
 *  a1.g$g
 *  bolts.ExecutorException
 *  bolts.UnobservedTaskException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.Callable
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 */
package a1;

import a1.g;
import a1.i;
import bolts.ExecutorException;
import bolts.UnobservedTaskException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

/*
 * Exception performing whole class analysis.
 */
public class g<TResult> {
    public static final ExecutorService i;
    public static final Executor j;
    public static final Executor k;
    public static volatile h l;
    public static g<?> m;
    public static g<Boolean> n;
    public static g<Boolean> o;
    public static g<?> p;
    public final Object a;
    public boolean b;
    public boolean c;
    public TResult d;
    public Exception e;
    public boolean f;
    public i g;
    public List<a1.f<TResult, Void>> h;

    public static {
        i = a1.d.a();
        j = a1.d.b();
        k = a1.a.c();
        m = new g<Object>(null);
        n = new g<Boolean>(Boolean.TRUE);
        o = new g<Boolean>(Boolean.FALSE);
        p = new g<TResult>(true);
    }

    public g() {
        this.a = new Object();
        this.h = new ArrayList();
    }

    public g(TResult TResult) {
        this.a = new Object();
        this.h = new ArrayList();
        this.A(TResult);
    }

    public g(boolean bl) {
        this.a = new Object();
        this.h = new ArrayList();
        if (bl) {
            this.y();
            return;
        }
        this.A(null);
    }

    public static /* synthetic */ void a(a1.h h2, a1.f f2, g g2, Executor executor, a1.e e2) {
        g.g(h2, f2, g2, executor, e2);
    }

    public static /* synthetic */ void b(a1.h h2, a1.f f2, g g2, Executor executor, a1.e e2) {
        g.f(h2, f2, g2, executor, e2);
    }

    public static <TResult> g<TResult> c(Callable<TResult> callable, Executor executor) {
        return g.d(callable, executor, null);
    }

    public static <TResult> g<TResult> d(final Callable<TResult> callable, Executor executor, a1.e e2) {
        final a1.h h2 = new a1.h();
        try {
            executor.execute(new Runnable(e2){
                public final /* synthetic */ a1.e a;

                public void run() {
                    a1.e e2 = this.a;
                    if (e2 == null) {
                        try {
                            h2.d(callable.call());
                            return;
                        }
                        catch (Exception exception) {
                            h2.c(exception);
                            return;
                        }
                        catch (CancellationException cancellationException) {
                            h2.b();
                            return;
                        }
                    }
                    e2.a();
                    throw null;
                }
            });
        }
        catch (Exception exception) {
            h2.c((Exception)new ExecutorException(exception));
        }
        return h2.a();
    }

    public static <TResult> g<TResult> e() {
        return p;
    }

    public static <TContinuationResult, TResult> void f(final a1.h<TContinuationResult> h2, final a1.f<TResult, g<TContinuationResult>> f2, final g<TResult> g2, Executor executor, a1.e e2) {
        try {
            executor.execute(new Runnable(e2){
                public final /* synthetic */ a1.e a;

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    a1.e e2 = this.a;
                    if (e2 != null) {
                        e2.a();
                        throw null;
                    }
                    try {
                        g g22 = (g)f2.then(g2);
                        if (g22 == null) {
                            h2.d(null);
                            return;
                        }
                        g22.h(new a(this));
                        return;
                    }
                    catch (Exception exception) {
                        h2.c(exception);
                        return;
                    }
                    catch (CancellationException cancellationException) {
                        h2.b();
                        return;
                    }
                }
            });
            return;
        }
        catch (Exception exception) {
            h2.c((Exception)new ExecutorException(exception));
            return;
        }
    }

    public static <TContinuationResult, TResult> void g(final a1.h<TContinuationResult> h2, final a1.f<TResult, TContinuationResult> f2, final g<TResult> g2, Executor executor, a1.e e2) {
        try {
            executor.execute(new Runnable(e2){
                public final /* synthetic */ a1.e a;

                public void run() {
                    a1.e e2 = this.a;
                    if (e2 == null) {
                        try {
                            Object TContinuationResult = f2.then(g2);
                            h2.d(TContinuationResult);
                            return;
                        }
                        catch (Exception exception) {
                            h2.c(exception);
                            return;
                        }
                        catch (CancellationException cancellationException) {
                            h2.b();
                            return;
                        }
                    }
                    e2.a();
                    throw null;
                }
            });
            return;
        }
        catch (Exception exception) {
            h2.c((Exception)new ExecutorException(exception));
            return;
        }
    }

    public static <TResult> g<TResult> m() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static <TResult> g<TResult> n(Exception exception) {
        a1.h h2 = new a1.h();
        h2.c(exception);
        return h2.a();
    }

    public static <TResult> g<TResult> o(TResult TResult) {
        if (TResult == null) {
            return m;
        }
        if (TResult instanceof Boolean) {
            if (((Boolean)TResult).booleanValue()) {
                return n;
            }
            return o;
        }
        a1.h<TResult> h2 = new a1.h<TResult>();
        h2.d(TResult);
        return h2.a();
    }

    public static h r() {
        return l;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean A(TResult TResult) {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.b) {
                return false;
            }
            this.b = true;
            this.d = TResult;
            this.a.notifyAll();
            this.x();
            return true;
        }
    }

    public <TContinuationResult> g<TContinuationResult> h(a1.f<TResult, TContinuationResult> f2) {
        return this.i(f2, j, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public <TContinuationResult> g<TContinuationResult> i(a1.f<TResult, TContinuationResult> f2, Executor executor, a1.e e2) {
        Object object;
        a1.h h2 = new a1.h();
        Object object2 = object = this.a;
        // MONITORENTER : object2
        boolean bl = this.t();
        if (!bl) {
            List<a1.f<TResult, Void>> list = this.h;
            a a2 = new a(this, h2, f2, executor, e2);
            list.add((Object)a2);
        }
        // MONITOREXIT : object2
        if (!bl) return h2.a();
        g.g(h2, f2, this, executor, e2);
        return h2.a();
    }

    public <TContinuationResult> g<TContinuationResult> j(a1.f<TResult, g<TContinuationResult>> f2) {
        return this.l(f2, j, null);
    }

    public <TContinuationResult> g<TContinuationResult> k(a1.f<TResult, g<TContinuationResult>> f2, Executor executor) {
        return this.l(f2, executor, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public <TContinuationResult> g<TContinuationResult> l(a1.f<TResult, g<TContinuationResult>> f2, Executor executor, a1.e e2) {
        Object object;
        a1.h h2 = new a1.h();
        Object object2 = object = this.a;
        // MONITORENTER : object2
        boolean bl = this.t();
        if (!bl) {
            List<a1.f<TResult, Void>> list = this.h;
            b b2 = new b(this, h2, f2, executor, e2);
            list.add((Object)b2);
        }
        // MONITOREXIT : object2
        if (!bl) return h2.a();
        g.f(h2, f2, this, executor, e2);
        return h2.a();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Exception p() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.e == null) return this.e;
            this.f = true;
            i i2 = this.g;
            if (i2 == null) return this.e;
            i2.a();
            this.g = null;
            return this.e;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public TResult q() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            TResult TResult = this.d;
            return TResult;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean s() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            return this.c;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean t() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            return this.b;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean u() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.p() == null) return false;
            return true;
        }
    }

    public <TContinuationResult> g<TContinuationResult> v(a1.f<TResult, TContinuationResult> f2) {
        return this.w(f2, j, null);
    }

    public <TContinuationResult> g<TContinuationResult> w(a1.f<TResult, TContinuationResult> f2, Executor executor, a1.e e2) {
        return this.k((a1.f<TResult, g<TContinuationResult>>)new c(this, e2, f2), executor);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void x() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            Iterator iterator = this.h.iterator();
            do {
                if (!iterator.hasNext()) {
                    this.h = null;
                    return;
                }
                a1.f f2 = (a1.f)iterator.next();
                try {
                    f2.then(this);
                }
                catch (Exception exception) {
                    throw new RuntimeException((Throwable)exception);
                }
                catch (RuntimeException runtimeException) {
                    throw runtimeException;
                }
            } while (true);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean y() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.b) {
                return false;
            }
            this.b = true;
            this.c = true;
            this.a.notifyAll();
            this.x();
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean z(Exception exception) {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.b) {
                return false;
            }
            this.b = true;
            this.e = exception;
            this.f = false;
            this.a.notifyAll();
            this.x();
            if (!this.f && g.r() != null) {
                this.g = new i(this);
            }
            return true;
        }
    }

    public static interface h {
        public void a(g<?> var1, UnobservedTaskException var2);
    }

}

