/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a1;

import a1.g;

public interface f<TTaskResult, TContinuationResult> {
    public TContinuationResult then(g<TTaskResult> var1);
}

