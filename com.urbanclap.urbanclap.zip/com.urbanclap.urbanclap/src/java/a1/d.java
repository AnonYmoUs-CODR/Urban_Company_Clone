/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.ThreadLocal
 *  java.util.Locale
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ScheduledExecutorService
 */
package a1;

import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public final class d {
    public static final d d = new d();
    public final ExecutorService a;
    public final ScheduledExecutorService b;
    public final Executor c;

    public d() {
        ExecutorService executorService = !d.c() ? Executors.newCachedThreadPool() : a1.a.b();
        this.a = executorService;
        this.b = Executors.newSingleThreadScheduledExecutor();
        this.c = new b(null);
    }

    public static ExecutorService a() {
        return d.d.a;
    }

    public static Executor b() {
        return d.d.c;
    }

    public static boolean c() {
        String string = System.getProperty((String)"java.runtime.name");
        if (string == null) {
            return false;
        }
        return string.toLowerCase(Locale.US).contains((CharSequence)"android");
    }

    public static class b
    implements Executor {
        public ThreadLocal<Integer> a = new ThreadLocal();

        public b() {
        }

        public /* synthetic */ b(a a2) {
            this();
        }

        public final int a() {
            int n;
            Integer n2 = (Integer)this.a.get();
            if (n2 == null) {
                n2 = 0;
            }
            if ((n = -1 + n2) == 0) {
                this.a.remove();
                return n;
            }
            this.a.set((Object)n);
            return n;
        }

        public final int b() {
            Integer n = (Integer)this.a.get();
            if (n == null) {
                n = 0;
            }
            int n2 = 1 + n;
            this.a.set((Object)n2);
            return n2;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        public void execute(Runnable var1_1) {
            if (this.b() > 15) ** GOTO lbl5
            try {
                var1_1.run();
                return;
lbl5: // 1 sources:
                d.a().execute(var1_1);
                return;
            }
            finally {
                this.a();
            }
        }
    }

}

