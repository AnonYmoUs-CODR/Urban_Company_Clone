/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 */
public class c {
    public static /* synthetic */ int a(double d2) {
        long l = Double.doubleToLongBits((double)d2);
        return (int)(l ^ l >>> 32);
    }
}

