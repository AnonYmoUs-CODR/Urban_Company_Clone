/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.MotionEvent
 *  android.view.ViewGroup
 *  androidx.annotation.Nullable
 *  com.facebook.react.ReactRootView
 *  com.facebook.react.bridge.BaseJavaModule
 *  com.facebook.react.bridge.JSApplicationIllegalArgumentException
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.ReadableType
 *  com.facebook.react.common.MapBuilder
 *  com.facebook.react.module.annotations.ReactModule
 *  com.facebook.react.uimanager.PixelUtil
 *  com.facebook.react.uimanager.UIBlock
 *  com.facebook.react.uimanager.UIManagerModule
 *  com.facebook.react.uimanager.events.Event
 *  com.facebook.react.uimanager.events.EventDispatcher
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$a
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$b
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$c
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$d
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$e
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$f
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$g
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$h
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$i
 *  com.swmansion.gesturehandler.react.RNGestureHandlerModule$j
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  t1.q.a.b
 *  t1.q.a.i
 *  t1.q.a.p.a
 *  t1.q.a.p.b
 *  t1.q.a.p.c
 *  t1.q.a.p.d
 *  t1.q.a.p.f
 *  t1.q.a.p.g
 *  t1.q.a.p.i
 */
package com.swmansion.gesturehandler.react;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import com.facebook.react.ReactRootView;
import com.facebook.react.bridge.BaseJavaModule;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableType;
import com.facebook.react.common.MapBuilder;
import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.uimanager.PixelUtil;
import com.facebook.react.uimanager.UIBlock;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.EventDispatcher;
import com.swmansion.gesturehandler.react.RNGestureHandlerModule;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 * Exception performing whole class analysis.
 */
@ReactModule(name="RNGestureHandlerModule")
public class RNGestureHandlerModule
extends ReactContextBaseJavaModule {
    private static final String KEY_DIRECTION = "direction";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_HIT_SLOP = "hitSlop";
    private static final String KEY_HIT_SLOP_BOTTOM = "bottom";
    private static final String KEY_HIT_SLOP_HEIGHT = "height";
    private static final String KEY_HIT_SLOP_HORIZONTAL = "horizontal";
    private static final String KEY_HIT_SLOP_LEFT = "left";
    private static final String KEY_HIT_SLOP_RIGHT = "right";
    private static final String KEY_HIT_SLOP_TOP = "top";
    private static final String KEY_HIT_SLOP_VERTICAL = "vertical";
    private static final String KEY_HIT_SLOP_WIDTH = "width";
    private static final String KEY_LONG_PRESS_MAX_DIST = "maxDist";
    private static final String KEY_LONG_PRESS_MIN_DURATION_MS = "minDurationMs";
    private static final String KEY_NATIVE_VIEW_DISALLOW_INTERRUPTION = "disallowInterruption";
    private static final String KEY_NATIVE_VIEW_SHOULD_ACTIVATE_ON_START = "shouldActivateOnStart";
    private static final String KEY_NUMBER_OF_POINTERS = "numberOfPointers";
    private static final String KEY_PAN_ACTIVE_OFFSET_X_END = "activeOffsetXEnd";
    private static final String KEY_PAN_ACTIVE_OFFSET_X_START = "activeOffsetXStart";
    private static final String KEY_PAN_ACTIVE_OFFSET_Y_END = "activeOffsetYEnd";
    private static final String KEY_PAN_ACTIVE_OFFSET_Y_START = "activeOffsetYStart";
    private static final String KEY_PAN_AVG_TOUCHES = "avgTouches";
    private static final String KEY_PAN_FAIL_OFFSET_RANGE_X_END = "failOffsetXEnd";
    private static final String KEY_PAN_FAIL_OFFSET_RANGE_X_START = "failOffsetXStart";
    private static final String KEY_PAN_FAIL_OFFSET_RANGE_Y_END = "failOffsetYEnd";
    private static final String KEY_PAN_FAIL_OFFSET_RANGE_Y_START = "failOffsetYStart";
    private static final String KEY_PAN_MAX_POINTERS = "maxPointers";
    private static final String KEY_PAN_MIN_DIST = "minDist";
    private static final String KEY_PAN_MIN_POINTERS = "minPointers";
    private static final String KEY_PAN_MIN_VELOCITY = "minVelocity";
    private static final String KEY_PAN_MIN_VELOCITY_X = "minVelocityX";
    private static final String KEY_PAN_MIN_VELOCITY_Y = "minVelocityY";
    private static final String KEY_SHOULD_CANCEL_WHEN_OUTSIDE = "shouldCancelWhenOutside";
    private static final String KEY_TAP_MAX_DELAY_MS = "maxDelayMs";
    private static final String KEY_TAP_MAX_DELTA_X = "maxDeltaX";
    private static final String KEY_TAP_MAX_DELTA_Y = "maxDeltaY";
    private static final String KEY_TAP_MAX_DIST = "maxDist";
    private static final String KEY_TAP_MAX_DURATION_MS = "maxDurationMs";
    private static final String KEY_TAP_MIN_POINTERS = "minPointers";
    private static final String KEY_TAP_NUMBER_OF_TAPS = "numberOfTaps";
    public static final String MODULE_NAME = "RNGestureHandlerModule";
    private List<Integer> mEnqueuedRootViewInit;
    private t1.q.a.i mEventListener;
    private d[] mHandlerFactories;
    private t1.q.a.p.d mInteractionManager;
    private final t1.q.a.p.f mRegistry;
    private List<t1.q.a.p.g> mRoots;

    public RNGestureHandlerModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.mEventListener = new a(this);
        d[] arrd = new d[]{new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */, new /* Unavailable Anonymous Inner Class!! */};
        this.mHandlerFactories = arrd;
        this.mRegistry = new t1.q.a.p.f();
        this.mInteractionManager = new t1.q.a.p.d();
        this.mRoots = new ArrayList();
        this.mEnqueuedRootViewInit = new ArrayList();
    }

    public static /* synthetic */ void access$000(t1.q.a.b b2, ReadableMap readableMap) {
        RNGestureHandlerModule.handleHitSlopProperty(b2, readableMap);
    }

    public static /* synthetic */ List access$1100(RNGestureHandlerModule rNGestureHandlerModule) {
        return rNGestureHandlerModule.mEnqueuedRootViewInit;
    }

    public static /* synthetic */ void access$200(RNGestureHandlerModule rNGestureHandlerModule, t1.q.a.b b2, MotionEvent motionEvent) {
        rNGestureHandlerModule.onTouchEvent(b2, motionEvent);
    }

    public static /* synthetic */ void access$300(RNGestureHandlerModule rNGestureHandlerModule, t1.q.a.b b2, int n2, int n3) {
        rNGestureHandlerModule.onStateChange(b2, n2, n3);
    }

    @Nullable
    private d findFactoryForHandler(t1.q.a.b b2) {
        d[] arrd;
        for (int i2 = 0; i2 < (arrd = this.mHandlerFactories).length; ++i2) {
            d d2 = arrd[i2];
            if (!d2.e().equals((Object)b2.getClass())) continue;
            return d2;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    private t1.q.a.p.g findRootHelperForViewAncestor(int n2) {
        List<t1.q.a.p.g> list;
        int n3 = ((UIManagerModule)this.getReactApplicationContext().getNativeModule(UIManagerModule.class)).resolveRootTagFromReactTag(n2);
        if (n3 < 1) {
            return null;
        }
        List<t1.q.a.p.g> list2 = list = this.mRoots;
        synchronized (list2) {
            int n4 = 0;
            while (n4 < this.mRoots.size()) {
                t1.q.a.p.g g2 = (t1.q.a.p.g)this.mRoots.get(n4);
                ViewGroup viewGroup = g2.f();
                if (viewGroup instanceof ReactRootView && ((ReactRootView)viewGroup).getRootViewTag() == n3) {
                    return g2;
                }
                ++n4;
            }
            return null;
        }
    }

    private static void handleHitSlopProperty(t1.q.a.b b2, ReadableMap readableMap) {
        float f2;
        float f3;
        float f4;
        float f5;
        if (readableMap.getType(KEY_HIT_SLOP) == ReadableType.Number) {
            float f6 = PixelUtil.toPixelFromDIP((double)readableMap.getDouble(KEY_HIT_SLOP));
            b2.J(f6, f6, f6, f6, Float.NaN, Float.NaN);
            return;
        }
        ReadableMap readableMap2 = readableMap.getMap(KEY_HIT_SLOP);
        if (readableMap2.hasKey(KEY_HIT_SLOP_HORIZONTAL)) {
            f2 = f4 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_HORIZONTAL));
        } else {
            f4 = Float.NaN;
            f2 = Float.NaN;
        }
        if (readableMap2.hasKey(KEY_HIT_SLOP_VERTICAL)) {
            f3 = f5 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_VERTICAL));
        } else {
            f5 = Float.NaN;
            f3 = Float.NaN;
        }
        if (readableMap2.hasKey(KEY_HIT_SLOP_LEFT)) {
            f4 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_LEFT));
        }
        float f7 = f4;
        if (readableMap2.hasKey(KEY_HIT_SLOP_TOP)) {
            f5 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_TOP));
        }
        float f8 = f5;
        if (readableMap2.hasKey(KEY_HIT_SLOP_RIGHT)) {
            f2 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_RIGHT));
        }
        float f9 = f2;
        if (readableMap2.hasKey(KEY_HIT_SLOP_BOTTOM)) {
            f3 = PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_BOTTOM));
        }
        float f10 = f3;
        float f11 = readableMap2.hasKey(KEY_HIT_SLOP_WIDTH) ? PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_WIDTH)) : Float.NaN;
        float f12 = readableMap2.hasKey(KEY_HIT_SLOP_HEIGHT) ? PixelUtil.toPixelFromDIP((double)readableMap2.getDouble(KEY_HIT_SLOP_HEIGHT)) : Float.NaN;
        b2.J(f7, f8, f9, f10, f11, f12);
    }

    private void onStateChange(t1.q.a.b b2, int n2, int n3) {
        if (b2.q() < 0) {
            return;
        }
        d d2 = this.findFactoryForHandler(b2);
        ((UIManagerModule)this.getReactApplicationContext().getNativeModule(UIManagerModule.class)).getEventDispatcher().dispatchEvent((Event)t1.q.a.p.i.b((t1.q.a.b)b2, (int)n2, (int)n3, (t1.q.a.p.c)d2));
    }

    private void onTouchEvent(t1.q.a.b b2, MotionEvent motionEvent) {
        if (b2.q() < 0) {
            return;
        }
        if (b2.p() == 4) {
            d d2 = this.findFactoryForHandler(b2);
            ((UIManagerModule)this.getReactApplicationContext().getNativeModule(UIManagerModule.class)).getEventDispatcher().dispatchEvent((Event)t1.q.a.p.b.b((t1.q.a.b)b2, (t1.q.a.p.c)d2));
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void tryInitializeHandlerForReactRootView(int n2) {
        List<t1.q.a.p.g> list;
        UIManagerModule uIManagerModule = (UIManagerModule)this.getReactApplicationContext().getNativeModule(UIManagerModule.class);
        int n3 = uIManagerModule.resolveRootTagFromReactTag(n2);
        if (n3 < 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could find root view for a given ancestor with tag ");
            stringBuilder.append(n2);
            throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
        }
        List<t1.q.a.p.g> list2 = list = this.mRoots;
        synchronized (list2) {
            int n4 = 0;
            do {
                if (n4 < this.mRoots.size()) {
                    ViewGroup viewGroup = ((t1.q.a.p.g)this.mRoots.get(n4)).f();
                    if (viewGroup instanceof ReactRootView && ((ReactRootView)viewGroup).getRootViewTag() == n3) {
                        return;
                    }
                } else {
                    List<Integer> list3;
                    // MONITOREXIT [4, 6, 10] lbl18 : w: MONITOREXIT : var14_5
                    List<Integer> list4 = list3 = this.mEnqueuedRootViewInit;
                    synchronized (list4) {
                        if (this.mEnqueuedRootViewInit.contains((Object)n3)) {
                            return;
                        }
                        this.mEnqueuedRootViewInit.add((Object)n3);
                    }
                    uIManagerModule.addUIBlock((UIBlock)new b(this, n3));
                    return;
                }
                ++n4;
            } while (true);
        }
    }

    @ReactMethod
    public void attachGestureHandler(int n2, int n3) {
        this.tryInitializeHandlerForReactRootView(n3);
        if (this.mRegistry.b(n2, n3)) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Handler with tag ");
        stringBuilder.append(n2);
        stringBuilder.append(" does not exists");
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    @ReactMethod
    public void createGestureHandler(String string, int n2, ReadableMap readableMap) {
        d[] arrd;
        for (int i2 = 0; i2 < (arrd = this.mHandlerFactories).length; ++i2) {
            d d2 = arrd[i2];
            if (!d2.d().equals((Object)string)) continue;
            t1.q.a.b b2 = d2.c((Context)this.getReactApplicationContext());
            b2.N(n2);
            b2.L(this.mEventListener);
            this.mRegistry.h(b2);
            this.mInteractionManager.e(b2, readableMap);
            d2.b(b2, readableMap);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid handler name ");
        stringBuilder.append(string);
        throw new JSApplicationIllegalArgumentException(stringBuilder.toString());
    }

    @ReactMethod
    public void dropGestureHandler(int n2) {
        this.mInteractionManager.g(n2);
        this.mRegistry.e(n2);
    }

    @Nullable
    public Map getConstants() {
        Integer n2 = 0;
        Integer n3 = 2;
        Integer n4 = 4;
        Integer n5 = 3;
        Integer n6 = 1;
        return MapBuilder.of((Object)"State", (Object)MapBuilder.of((Object)"UNDETERMINED", (Object)n2, (Object)"BEGAN", (Object)n3, (Object)"ACTIVE", (Object)n4, (Object)"CANCELLED", (Object)n5, (Object)"FAILED", (Object)n6, (Object)"END", (Object)5), (Object)"Direction", (Object)MapBuilder.of((Object)"RIGHT", (Object)n6, (Object)"LEFT", (Object)n3, (Object)"UP", (Object)n4, (Object)"DOWN", (Object)8));
    }

    public String getName() {
        return MODULE_NAME;
    }

    public t1.q.a.p.f getRegistry() {
        return this.mRegistry;
    }

    @ReactMethod
    public void handleClearJSResponder() {
    }

    @ReactMethod
    public void handleSetJSResponder(int n2, boolean bl) {
        t1.q.a.p.g g2;
        if (this.mRegistry != null && (g2 = this.findRootHelperForViewAncestor(n2)) != null) {
            g2.g(n2, bl);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onCatalystInstanceDestroy() {
        List<t1.q.a.p.g> list;
        this.mRegistry.d();
        this.mInteractionManager.h();
        List<t1.q.a.p.g> list2 = list = this.mRoots;
        synchronized (list2) {
            int n2;
            do {
                if (this.mRoots.isEmpty()) {
                    // MONITOREXIT [2, 3, 5] lbl7 : w: MONITOREXIT : var6_2
                    BaseJavaModule.super.onCatalystInstanceDestroy();
                    return;
                }
                n2 = this.mRoots.size();
                t1.q.a.p.g g2 = (t1.q.a.p.g)this.mRoots.get(0);
                ViewGroup viewGroup = g2.f();
                if (viewGroup instanceof t1.q.a.p.a) {
                    ((t1.q.a.p.a)viewGroup).b();
                    continue;
                }
                g2.i();
            } while (this.mRoots.size() < n2);
            throw new IllegalStateException("Expected root helper to get unregistered while tearing down");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void registerRootHelper(t1.q.a.p.g g2) {
        List<t1.q.a.p.g> list;
        List<t1.q.a.p.g> list2 = list = this.mRoots;
        synchronized (list2) {
            if (!this.mRoots.contains((Object)g2)) {
                this.mRoots.add((Object)g2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Root helper");
            stringBuilder.append((Object)g2);
            stringBuilder.append(" already registered");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void unregisterRootHelper(t1.q.a.p.g g2) {
        List<t1.q.a.p.g> list;
        List<t1.q.a.p.g> list2 = list = this.mRoots;
        synchronized (list2) {
            this.mRoots.remove((Object)g2);
            return;
        }
    }

    @ReactMethod
    public void updateGestureHandler(int n2, ReadableMap readableMap) {
        d d2;
        t1.q.a.b b2 = this.mRegistry.f(n2);
        if (b2 != null && (d2 = this.findFactoryForHandler(b2)) != null) {
            this.mInteractionManager.g(n2);
            this.mInteractionManager.e(b2, readableMap);
            d2.b(b2, readableMap);
        }
    }
}

