/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.facebook.react.bridge.BaseJavaModule
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.NativeModule
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.module.annotations.ReactModule
 *  com.facebook.react.uimanager.UIBlock
 *  com.facebook.react.uimanager.UIManagerModule
 *  com.facebook.react.uimanager.UIManagerModuleListener
 *  com.swmansion.reanimated.ReanimatedModule$a
 *  com.swmansion.reanimated.ReanimatedModule$b
 *  com.swmansion.reanimated.ReanimatedModule$c
 *  com.swmansion.reanimated.ReanimatedModule$d
 *  com.swmansion.reanimated.ReanimatedModule$e
 *  com.swmansion.reanimated.ReanimatedModule$f
 *  com.swmansion.reanimated.ReanimatedModule$g
 *  com.swmansion.reanimated.ReanimatedModule$h
 *  com.swmansion.reanimated.ReanimatedModule$i
 *  com.swmansion.reanimated.ReanimatedModule$j
 *  com.swmansion.reanimated.ReanimatedModule$k
 *  com.swmansion.reanimated.ReanimatedModule$l
 *  com.swmansion.reanimated.ReanimatedModule$m
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Set
 *  t1.q.b.c
 *  t1.q.b.i.c
 */
package com.swmansion.reanimated;

import com.facebook.react.bridge.BaseJavaModule;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.uimanager.UIBlock;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.UIManagerModuleListener;
import com.swmansion.reanimated.ReanimatedModule;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@ReactModule(name="ReanimatedModule")
public class ReanimatedModule
extends ReactContextBaseJavaModule
implements LifecycleEventListener,
UIManagerModuleListener {
    public static final String NAME = "ReanimatedModule";
    private t1.q.b.c mNodesManager;
    private ArrayList<m> mOperations = new ArrayList();
    private t1.q.b.i.c mTransitionManager;
    private UIManagerModule mUIManager;

    public ReanimatedModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    @ReactMethod
    public void animateNextTransition(int n2, ReadableMap readableMap) {
        this.mTransitionManager.a(n2, readableMap);
    }

    @ReactMethod
    public void attachEvent(int n2, String string, int n3) {
        this.mOperations.add((Object)new k(this, n2, string, n3));
    }

    @ReactMethod
    public void configureProps(ReadableArray readableArray, ReadableArray readableArray2) {
        int n2 = readableArray.size();
        HashSet hashSet = new HashSet(n2);
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            hashSet.add((Object)readableArray.getString(i2));
        }
        int n4 = readableArray2.size();
        HashSet hashSet2 = new HashSet(n4);
        while (n3 < n4) {
            hashSet2.add((Object)readableArray2.getString(n3));
            ++n3;
        }
        this.mOperations.add((Object)new a(this, (Set)hashSet, (Set)hashSet2));
    }

    @ReactMethod
    public void connectNodeToView(int n2, int n3) {
        this.mOperations.add((Object)new i(this, n2, n3));
    }

    @ReactMethod
    public void connectNodes(int n2, int n3) {
        this.mOperations.add((Object)new g(this, n2, n3));
    }

    @ReactMethod
    public void createNode(int n2, ReadableMap readableMap) {
        this.mOperations.add((Object)new e(this, n2, readableMap));
    }

    @ReactMethod
    public void detachEvent(int n2, String string, int n3) {
        this.mOperations.add((Object)new l(this, n2, string, n3));
    }

    @ReactMethod
    public void disconnectNodeFromView(int n2, int n3) {
        this.mOperations.add((Object)new j(this, n2, n3));
    }

    @ReactMethod
    public void disconnectNodes(int n2, int n3) {
        this.mOperations.add((Object)new h(this, n2, n3));
    }

    @ReactMethod
    public void dropNode(int n2) {
        this.mOperations.add((Object)new f(this, n2));
    }

    public String getName() {
        return NAME;
    }

    public t1.q.b.c getNodesManager() {
        if (this.mNodesManager == null) {
            this.mNodesManager = new t1.q.b.c((ReactContext)this.getReactApplicationContext());
        }
        return this.mNodesManager;
    }

    @ReactMethod
    public void getValue(int n2, Callback callback) {
        this.mOperations.add((Object)new b(this, n2, callback));
    }

    public void initialize() {
        ReactApplicationContext reactApplicationContext = this.getReactApplicationContext();
        UIManagerModule uIManagerModule = (UIManagerModule)reactApplicationContext.getNativeModule(UIManagerModule.class);
        reactApplicationContext.addLifecycleEventListener((LifecycleEventListener)this);
        uIManagerModule.addUIManagerListener((UIManagerModuleListener)this);
        this.mTransitionManager = new t1.q.b.i.c(uIManagerModule);
        this.mUIManager = uIManagerModule;
    }

    public void onCatalystInstanceDestroy() {
        BaseJavaModule.super.onCatalystInstanceDestroy();
        t1.q.b.c c2 = this.mNodesManager;
        if (c2 != null) {
            c2.y();
        }
    }

    public void onHostDestroy() {
    }

    public void onHostPause() {
        t1.q.b.c c2 = this.mNodesManager;
        if (c2 != null) {
            c2.z();
        }
    }

    public void onHostResume() {
        t1.q.b.c c2 = this.mNodesManager;
        if (c2 != null) {
            c2.A();
        }
    }

    @ReactMethod
    public void setValue(int n2, Double d2) {
        this.mOperations.add((Object)new c(this, n2, d2));
    }

    public void willDispatchViewUpdates(UIManagerModule uIManagerModule) {
        if (this.mOperations.isEmpty()) {
            return;
        }
        ArrayList<m> arrayList = this.mOperations;
        this.mOperations = new ArrayList();
        uIManagerModule.addUIBlock((UIBlock)new d(this, arrayList));
    }
}

