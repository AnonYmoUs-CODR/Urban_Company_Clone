/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzby
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlm
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlr
 *  com.google.mlkit.vision.barcode.internal.zzi
 *  com.google.mlkit.vision.common.InputImage
 *  java.lang.Object
 */
package com.google.mlkit.vision.barcode.internal;

import com.google.android.gms.internal.mlkit_vision_barcode.zzby;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlm;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlr;
import com.google.mlkit.vision.barcode.internal.zzi;
import com.google.mlkit.vision.common.InputImage;

public final class zzh
implements zzlm {
    public final /* synthetic */ zzi a;
    public final /* synthetic */ long b;
    public final /* synthetic */ zzjb c;
    public final /* synthetic */ zzby d;
    public final /* synthetic */ zzby e;
    public final /* synthetic */ InputImage f;

    public /* synthetic */ zzh(zzi zzi2, long l, zzjb zzjb2, zzby zzby2, zzby zzby3, InputImage inputImage) {
        this.a = zzi2;
        this.b = l;
        this.c = zzjb2;
        this.d = zzby2;
        this.e = zzby3;
        this.f = inputImage;
    }

    public final zzlr zza() {
        return this.a.j(this.b, this.c, this.d, this.e, this.f);
    }
}

