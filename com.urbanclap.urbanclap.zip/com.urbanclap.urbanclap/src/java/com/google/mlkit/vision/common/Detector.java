/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.LifecycleObserver
 *  java.io.Closeable
 *  java.lang.Object
 */
package com.google.mlkit.vision.common;

import androidx.lifecycle.LifecycleObserver;
import java.io.Closeable;

public interface Detector<DetectionResultT>
extends Closeable,
LifecycleObserver {
}

