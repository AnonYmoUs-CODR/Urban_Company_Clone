/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.Detector
 *  com.google.mlkit.vision.text.Text
 *  java.lang.Object
 */
package com.google.mlkit.vision.text;

import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.Detector;
import com.google.mlkit.vision.text.Text;

public interface TextRecognizer
extends Detector<Text> {
    @NonNull
    public Task<Text> a(@RecentlyNonNull InputImage var1);

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public void close();
}

