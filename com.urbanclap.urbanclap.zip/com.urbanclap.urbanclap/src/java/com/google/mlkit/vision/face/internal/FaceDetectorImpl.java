/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.internal.mlkit_vision_face.zzie
 *  com.google.android.gms.internal.mlkit_vision_face.zzit
 *  com.google.android.gms.internal.mlkit_vision_face.zziv
 *  com.google.android.gms.internal.mlkit_vision_face.zzjh
 *  com.google.android.gms.internal.mlkit_vision_face.zzji
 *  com.google.android.gms.internal.mlkit_vision_face.zzla
 *  com.google.android.gms.internal.mlkit_vision_face.zzld
 *  com.google.android.gms.internal.mlkit_vision_face.zzll
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.common.sdkinternal.ExecutorSelector
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.MobileVisionBase
 *  com.google.mlkit.vision.face.Face
 *  com.google.mlkit.vision.face.FaceDetectorOptions
 *  com.google.mlkit.vision.face.FaceDetectorOptions$Builder
 *  com.google.mlkit.vision.face.internal.zzc
 *  com.google.mlkit.vision.face.internal.zzh
 *  com.google.mlkit.vision.face.internal.zzj
 *  java.lang.String
 *  java.util.List
 *  java.util.concurrent.Executor
 */
package com.google.mlkit.vision.face.internal;

import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.internal.mlkit_vision_face.zzie;
import com.google.android.gms.internal.mlkit_vision_face.zzit;
import com.google.android.gms.internal.mlkit_vision_face.zziv;
import com.google.android.gms.internal.mlkit_vision_face.zzjh;
import com.google.android.gms.internal.mlkit_vision_face.zzji;
import com.google.android.gms.internal.mlkit_vision_face.zzla;
import com.google.android.gms.internal.mlkit_vision_face.zzld;
import com.google.android.gms.internal.mlkit_vision_face.zzll;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.sdkinternal.ExecutorSelector;
import com.google.mlkit.common.sdkinternal.MLTask;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.MobileVisionBase;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.internal.zzc;
import com.google.mlkit.vision.face.internal.zzh;
import com.google.mlkit.vision.face.internal.zzj;
import java.util.List;
import java.util.concurrent.Executor;

public class FaceDetectorImpl
extends MobileVisionBase<List<Face>>
implements FaceDetector {
    public static {
        new FaceDetectorOptions.Builder().a();
    }

    public /* synthetic */ FaceDetectorImpl(zzh zzh2, ExecutorSelector executorSelector, FaceDetectorOptions faceDetectorOptions, zzc zzc2) {
        Executor executor = executorSelector.a(faceDetectorOptions.f());
        zzla zzla2 = zzll.zzb((String)zzj.b());
        super((MLTask)zzh2, executor);
        zziv zziv2 = new zziv();
        zzjh zzjh2 = new zzjh();
        zzjh2.zze(zzj.a((FaceDetectorOptions)faceDetectorOptions));
        zziv2.zzf(zzjh2.zzi());
        zzla2.zzd(zzld.zze((zziv)zziv2, (int)1), zzit.zzc);
    }

    @NonNull
    @Override
    public final Task<List<Face>> a(@RecentlyNonNull InputImage inputImage) {
        return super.b(inputImage);
    }
}

