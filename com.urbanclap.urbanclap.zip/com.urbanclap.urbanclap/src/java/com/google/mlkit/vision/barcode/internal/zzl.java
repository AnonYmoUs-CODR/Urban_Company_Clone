/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.graphics.Rect
 *  androidx.annotation.Nullable
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzmp
 *  com.google.mlkit.vision.barcode.internal.zzk
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.vision.barcode.internal;

import android.graphics.Point;
import android.graphics.Rect;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.mlkit_vision_barcode.zzmp;
import com.google.mlkit.vision.barcode.internal.zzk;

public final class zzl
implements zzk {
    public final zzmp a;

    public zzl(zzmp zzmp2) {
        this.a = zzmp2;
    }

    public final int zza() {
        return this.a.zza();
    }

    public final int zzb() {
        return this.a.zzb();
    }

    @Nullable
    public final Rect zzc() {
        Point[] arrpoint = this.a.zzo();
        if (arrpoint == null) {
            return null;
        }
        int n = arrpoint.length;
        int n2 = Integer.MIN_VALUE;
        int n3 = Integer.MIN_VALUE;
        int n4 = Integer.MAX_VALUE;
        int n5 = Integer.MAX_VALUE;
        for (int i = 0; i < n; ++i) {
            Point point = arrpoint[i];
            n4 = Math.min((int)n4, (int)point.x);
            n2 = Math.max((int)n2, (int)point.x);
            n5 = Math.min((int)n5, (int)point.y);
            n3 = Math.max((int)n3, (int)point.y);
        }
        return new Rect(n4, n5, n2, n3);
    }

    @Nullable
    public final String zzm() {
        return this.a.zzl();
    }

    @Nullable
    public final String zzn() {
        return this.a.zzm();
    }
}

