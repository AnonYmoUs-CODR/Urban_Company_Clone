/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.media.Image
 *  android.media.Image$Plane
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.os.SystemClock
 *  android.util.Log
 *  androidx.annotation.Nullable
 *  androidx.annotation.VisibleForTesting
 *  androidx.annotation.WorkerThread
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.dynamic.IObjectWrapper
 *  com.google.android.gms.dynamic.ObjectWrapper
 *  com.google.android.gms.dynamite.DynamiteModule
 *  com.google.android.gms.dynamite.DynamiteModule$LoadingException
 *  com.google.android.gms.dynamite.DynamiteModule$VersionPolicy
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlo
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzmp
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzmr
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzmz
 *  com.google.android.gms.internal.mlkit_vision_barcode.zznb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzni
 *  com.google.mlkit.common.MlKitException
 *  com.google.mlkit.common.sdkinternal.OptionalModuleUtils
 *  com.google.mlkit.vision.barcode.Barcode
 *  com.google.mlkit.vision.barcode.BarcodeScannerOptions
 *  com.google.mlkit.vision.barcode.internal.zzb
 *  com.google.mlkit.vision.barcode.internal.zzj
 *  com.google.mlkit.vision.barcode.internal.zzk
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.CommonConvertUtils
 *  com.google.mlkit.vision.common.internal.ImageUtils
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.google.mlkit.vision.barcode.internal;

import android.content.Context;
import android.media.Image;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlo;
import com.google.android.gms.internal.mlkit_vision_barcode.zzmp;
import com.google.android.gms.internal.mlkit_vision_barcode.zzmr;
import com.google.android.gms.internal.mlkit_vision_barcode.zzmz;
import com.google.android.gms.internal.mlkit_vision_barcode.zznb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzni;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.common.sdkinternal.OptionalModuleUtils;
import com.google.mlkit.vision.barcode.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.internal.zzb;
import com.google.mlkit.vision.barcode.internal.zzj;
import com.google.mlkit.vision.barcode.internal.zzk;
import com.google.mlkit.vision.barcode.internal.zzl;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.CommonConvertUtils;
import com.google.mlkit.vision.common.internal.ImageUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class zzm
implements zzj {
    public boolean a;
    public boolean b;
    public boolean c;
    public final Context d;
    public final BarcodeScannerOptions e;
    public final zzlo f;
    @Nullable
    public zzmz g;

    public zzm(Context context, BarcodeScannerOptions barcodeScannerOptions, zzlo zzlo2) {
        this.d = context;
        this.e = barcodeScannerOptions;
        this.f = zzlo2;
    }

    public static boolean b(Context context) {
        return DynamiteModule.getLocalVersion((Context)context, (String)"com.google.mlkit.dynamite.barcode") > 0;
    }

    @WorkerThread
    public final List<Barcode> a(InputImage inputImage) {
        List list;
        if (this.g == null) {
            this.zzc();
        }
        zzmz zzmz2 = (zzmz)Preconditions.checkNotNull((Object)this.g);
        if (!this.a) {
            try {
                zzmz2.zze();
                this.a = true;
            }
            catch (RemoteException remoteException) {
                throw new MlKitException("Failed to init barcode scanner.", 13, (Throwable)remoteException);
            }
        }
        int n = inputImage.k();
        if (inputImage.f() == 35 && Build.VERSION.SDK_INT >= 19) {
            n = ((Image.Plane[])Preconditions.checkNotNull((Object)inputImage.i()))[0].getRowStride();
        }
        int n2 = n;
        zzni zzni2 = new zzni(inputImage.f(), n2, inputImage.g(), CommonConvertUtils.a((int)inputImage.j()), SystemClock.elapsedRealtime());
        IObjectWrapper iObjectWrapper = ImageUtils.b().a(inputImage);
        try {
            list = zzmz2.zzd(iObjectWrapper, zzni2);
        }
        catch (RemoteException remoteException) {
            throw new MlKitException("Failed to run barcode scanner.", 13, (Throwable)remoteException);
        }
        ArrayList arrayList = new ArrayList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)new Barcode((zzk)new zzl((zzmp)iterator.next())));
        }
        return arrayList;
    }

    @VisibleForTesting
    public final zzmz c(DynamiteModule.VersionPolicy versionPolicy, String string, String string2) {
        return zznb.zza((IBinder)DynamiteModule.load((Context)this.d, (DynamiteModule.VersionPolicy)versionPolicy, (String)string).instantiate(string2)).zzd(ObjectWrapper.wrap((Object)this.d), new zzmr(this.e.a()));
    }

    @WorkerThread
    public final void zzb() {
        zzmz zzmz2 = this.g;
        if (zzmz2 != null) {
            try {
                zzmz2.zzf();
            }
            catch (RemoteException remoteException) {
                Log.e((String)"DecoupledBarcodeScanner", (String)"Failed to release barcode scanner.", (Throwable)remoteException);
            }
            this.g = null;
            this.a = false;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @WorkerThread
    public final boolean zzc() {
        if (this.g != null) {
            return this.b;
        }
        if (zzm.b(this.d)) {
            this.b = true;
            try {
                this.g = this.c(DynamiteModule.PREFER_LOCAL, "com.google.mlkit.dynamite.barcode", "com.google.mlkit.vision.barcode.bundled.internal.ThickBarcodeScannerCreator");
            }
            catch (RemoteException remoteException) {
                throw new MlKitException("Failed to create thick barcode scanner.", 13, (Throwable)remoteException);
            }
            catch (DynamiteModule.LoadingException loadingException) {
                throw new MlKitException("Failed to load the bundled barcode module.", 13, (Throwable)loadingException);
            }
        } else {
            this.b = false;
            this.g = this.c(DynamiteModule.PREFER_REMOTE, "com.google.android.gms.vision.barcode", "com.google.android.gms.vision.barcode.mlkit.BarcodeScannerCreator");
        }
        zzb.e((zzlo)this.f, (zzjb)zzjb.zza);
        return this.b;
        catch (RemoteException remoteException) {
            zzb.e((zzlo)this.f, (zzjb)zzjb.zzC);
            throw new MlKitException("Failed to create thin barcode scanner.", 13, (Throwable)remoteException);
        }
        catch (DynamiteModule.LoadingException loadingException) {
            if (!this.c) {
                OptionalModuleUtils.a((Context)this.d, (String)"barcode");
                this.c = true;
            }
            zzb.e((zzlo)this.f, (zzjb)zzjb.zzB);
            throw new MlKitException("Waiting for the barcode module to be downloaded. Please wait.", 14);
        }
    }
}

