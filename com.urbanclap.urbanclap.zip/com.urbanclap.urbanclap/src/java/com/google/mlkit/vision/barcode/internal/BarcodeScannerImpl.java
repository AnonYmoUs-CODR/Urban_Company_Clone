/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.VisibleForTesting
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjc
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzje
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjq
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjr
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlo
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlr
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.vision.barcode.Barcode
 *  com.google.mlkit.vision.barcode.BarcodeScannerOptions
 *  com.google.mlkit.vision.barcode.BarcodeScannerOptions$Builder
 *  com.google.mlkit.vision.barcode.internal.zzb
 *  com.google.mlkit.vision.barcode.internal.zzi
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.MobileVisionBase
 *  java.util.List
 *  java.util.concurrent.Executor
 */
package com.google.mlkit.vision.barcode.internal;

import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjc;
import com.google.android.gms.internal.mlkit_vision_barcode.zzje;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjq;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjr;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlo;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlr;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.sdkinternal.MLTask;
import com.google.mlkit.vision.barcode.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.internal.zzb;
import com.google.mlkit.vision.barcode.internal.zzi;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.MobileVisionBase;
import java.util.List;
import java.util.concurrent.Executor;

public class BarcodeScannerImpl
extends MobileVisionBase<List<Barcode>>
implements BarcodeScanner {
    public static {
        new BarcodeScannerOptions.Builder().a();
    }

    @VisibleForTesting
    public BarcodeScannerImpl(@NonNull BarcodeScannerOptions barcodeScannerOptions, @NonNull zzi zzi2, @NonNull Executor executor, @NonNull zzlo zzlo2) {
        super((MLTask)zzi2, executor);
        zzjq zzjq2 = new zzjq();
        zzjq2.zzi(zzb.c((BarcodeScannerOptions)barcodeScannerOptions));
        zzjr zzjr2 = zzjq2.zzj();
        zzje zzje2 = new zzje();
        zzje2.zzf(zzjr2);
        zzlo2.zzd(zzlr.zze((zzje)zzje2, (int)1), zzjc.zzj);
    }

    @NonNull
    @Override
    public final Task<List<Barcode>> a(@RecentlyNonNull InputImage inputImage) {
        return super.b(inputImage);
    }
}

