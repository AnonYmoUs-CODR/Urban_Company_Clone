/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.ExecutorSelector
 *  com.google.mlkit.vision.barcode.internal.zze
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.vision.barcode.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.ExecutorSelector;
import com.google.mlkit.vision.barcode.internal.zze;
import com.google.mlkit.vision.barcode.internal.zzf;

public final class zzd
implements ComponentFactory {
    public static final /* synthetic */ zzd a;

    public static /* synthetic */ {
        a = new zzd();
    }

    private /* synthetic */ zzd() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new zze((zzf)((Object)componentContainer.a(zzf.class)), (ExecutorSelector)componentContainer.a(ExecutorSelector.class));
    }
}

