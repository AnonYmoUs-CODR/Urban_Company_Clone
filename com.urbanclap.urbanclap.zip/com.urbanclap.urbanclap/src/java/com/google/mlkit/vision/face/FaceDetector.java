/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.Detector
 *  com.google.mlkit.vision.face.Face
 *  java.lang.Object
 *  java.util.List
 */
package com.google.mlkit.vision.face;

import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.Detector;
import com.google.mlkit.vision.face.Face;
import java.util.List;

public interface FaceDetector
extends Detector<List<Face>> {
    @NonNull
    public Task<List<Face>> a(@RecentlyNonNull InputImage var1);

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public void close();
}

