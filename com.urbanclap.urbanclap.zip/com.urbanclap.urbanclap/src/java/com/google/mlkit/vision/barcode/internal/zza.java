/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzje
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjt
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzju
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlm
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlr
 *  java.lang.Object
 */
package com.google.mlkit.vision.barcode.internal;

import com.google.android.gms.internal.mlkit_vision_barcode.zzjb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzje;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjt;
import com.google.android.gms.internal.mlkit_vision_barcode.zzju;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlm;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlr;

public final class zza
implements zzlm {
    public final /* synthetic */ zzjb a;

    public /* synthetic */ zza(zzjb zzjb2) {
        this.a = zzjb2;
    }

    public final zzlr zza() {
        zzjb zzjb2 = this.a;
        zzje zzje2 = new zzje();
        zzjt zzjt2 = new zzjt();
        zzjt2.zzb(zzjb2);
        zzje2.zzg(zzjt2.zzc());
        return zzlr.zzd((zzje)zzje2);
    }
}

