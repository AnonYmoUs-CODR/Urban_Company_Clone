/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.vision.barcode.Barcode
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.Detector
 *  java.lang.Object
 *  java.util.List
 */
package com.google.mlkit.vision.barcode;

import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.Detector;
import java.util.List;

public interface BarcodeScanner
extends Detector<List<Barcode>> {
    @NonNull
    public Task<List<Barcode>> a(@RecentlyNonNull InputImage var1);

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public void close();
}

