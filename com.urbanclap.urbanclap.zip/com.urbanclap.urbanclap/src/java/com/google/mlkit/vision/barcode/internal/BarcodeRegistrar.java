/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzcb
 *  com.google.firebase.components.Component
 *  com.google.firebase.components.Component$Builder
 *  com.google.firebase.components.ComponentFactory
 *  com.google.firebase.components.ComponentRegistrar
 *  com.google.firebase.components.Dependency
 *  com.google.mlkit.common.sdkinternal.ExecutorSelector
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  com.google.mlkit.vision.barcode.internal.zze
 *  java.lang.Object
 *  java.util.List
 */
package com.google.mlkit.vision.barcode.internal;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.mlkit_vision_barcode.zzcb;
import com.google.firebase.components.Component;
import com.google.firebase.components.ComponentFactory;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.components.Dependency;
import com.google.mlkit.common.sdkinternal.ExecutorSelector;
import com.google.mlkit.common.sdkinternal.MlKitContext;
import com.google.mlkit.vision.barcode.internal.zzc;
import com.google.mlkit.vision.barcode.internal.zzd;
import com.google.mlkit.vision.barcode.internal.zze;
import com.google.mlkit.vision.barcode.internal.zzf;
import java.util.List;

@KeepForSdk
public class BarcodeRegistrar
implements ComponentRegistrar {
    @RecentlyNonNull
    public final List<Component<?>> getComponents() {
        Component.Builder builder = Component.a(zzf.class);
        builder.b(Dependency.h(MlKitContext.class));
        builder.f((ComponentFactory)zzc.a);
        Component component = builder.d();
        Component.Builder builder2 = Component.a(zze.class);
        builder2.b(Dependency.h(zzf.class));
        builder2.b(Dependency.h(ExecutorSelector.class));
        builder2.f((ComponentFactory)zzd.a);
        return zzcb.zzh((Object)component, (Object)builder2.d());
    }
}

