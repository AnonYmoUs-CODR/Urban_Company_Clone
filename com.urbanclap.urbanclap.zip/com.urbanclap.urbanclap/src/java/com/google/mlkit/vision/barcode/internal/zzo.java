/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.media.Image
 *  android.media.Image$Plane
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.os.RemoteException
 *  android.util.Log
 *  androidx.annotation.Nullable
 *  androidx.annotation.WorkerThread
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.dynamic.IObjectWrapper
 *  com.google.android.gms.dynamic.ObjectWrapper
 *  com.google.android.gms.dynamite.DynamiteModule
 *  com.google.android.gms.dynamite.DynamiteModule$LoadingException
 *  com.google.android.gms.dynamite.DynamiteModule$VersionPolicy
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzad
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzaf
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzah
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzaj
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzjb
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzlo
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzq
 *  com.google.mlkit.common.MlKitException
 *  com.google.mlkit.common.sdkinternal.OptionalModuleUtils
 *  com.google.mlkit.vision.barcode.Barcode
 *  com.google.mlkit.vision.barcode.BarcodeScannerOptions
 *  com.google.mlkit.vision.barcode.internal.zzb
 *  com.google.mlkit.vision.barcode.internal.zzj
 *  com.google.mlkit.vision.barcode.internal.zzk
 *  com.google.mlkit.vision.common.InputImage
 *  com.google.mlkit.vision.common.internal.CommonConvertUtils
 *  com.google.mlkit.vision.common.internal.ImageConvertUtils
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.mlkit.vision.barcode.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.internal.mlkit_vision_barcode.zzad;
import com.google.android.gms.internal.mlkit_vision_barcode.zzaf;
import com.google.android.gms.internal.mlkit_vision_barcode.zzah;
import com.google.android.gms.internal.mlkit_vision_barcode.zzaj;
import com.google.android.gms.internal.mlkit_vision_barcode.zzjb;
import com.google.android.gms.internal.mlkit_vision_barcode.zzlo;
import com.google.android.gms.internal.mlkit_vision_barcode.zzq;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.common.sdkinternal.OptionalModuleUtils;
import com.google.mlkit.vision.barcode.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.internal.zzb;
import com.google.mlkit.vision.barcode.internal.zzj;
import com.google.mlkit.vision.barcode.internal.zzk;
import com.google.mlkit.vision.barcode.internal.zzn;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.internal.CommonConvertUtils;
import com.google.mlkit.vision.common.internal.ImageConvertUtils;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public final class zzo
implements zzj {
    public boolean a;
    public final Context b;
    public final zzad c;
    public final zzlo d;
    @Nullable
    public zzaf e;

    public zzo(Context context, BarcodeScannerOptions barcodeScannerOptions, zzlo zzlo2) {
        zzad zzad2;
        this.c = zzad2 = new zzad();
        this.b = context;
        zzad2.zza = barcodeScannerOptions.a();
        this.d = zzlo2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @WorkerThread
    public final List<Barcode> a(InputImage var1_1) {
        if (this.e == null) {
            this.zzc();
        }
        if ((var2_2 = this.e) == null) throw new MlKitException("Error initializing the legacy barcode scanner.", 14);
        var3_3 = (zzaf)Preconditions.checkNotNull((Object)var2_2);
        var4_4 = new zzaj(var1_1.k(), var1_1.g(), 0, 0L, CommonConvertUtils.a((int)var1_1.j()));
        try {
            block8 : {
                block6 : {
                    block7 : {
                        var6_5 = var1_1.f();
                        var7_6 = 0;
                        if (var6_5 == -1) break block6;
                        if (var6_5 == 17) ** GOTO lbl26
                        if (var6_5 == 35) break block7;
                        if (var6_5 != 842094169) ** GOTO lbl-1000
                        var8_7 = var3_3.zze(ObjectWrapper.wrap((Object)ImageConvertUtils.f().d(var1_1, false)), var4_4);
                        break block8;
                    }
                    if (Build.VERSION.SDK_INT >= 19) {
                        var16_8 = (Image.Plane[])Preconditions.checkNotNull((Object)var1_1.i());
                        var4_4.zza = var16_8[0].getRowStride();
                        var8_7 = var3_3.zze(ObjectWrapper.wrap((Object)var16_8[0].getBuffer()), var4_4);
                    } else lbl-1000: // 2 sources:
                    {
                        var12_9 = var1_1.f();
                        var13_10 = new StringBuilder(37);
                        var13_10.append("Unsupported image format: ");
                        var13_10.append(var12_9);
                        throw new MlKitException(var13_10.toString(), 3);
lbl26: // 1 sources:
                        var8_7 = var3_3.zze(ObjectWrapper.wrap((Object)var1_1.e()), var4_4);
                    }
                    break block8;
                }
                var8_7 = var3_3.zzf(ObjectWrapper.wrap((Object)var1_1.d()), var4_4);
            }
            var9_11 = new ArrayList();
            var10_12 = var8_7.length;
        }
        catch (RemoteException var5_13) {
            throw new MlKitException("Failed to detect with legacy barcode detector", 13, (Throwable)var5_13);
        }
        while (var7_6 < var10_12) {
            var9_11.add((Object)new Barcode((zzk)new zzn(var8_7[var7_6])));
            ++var7_6;
        }
        return var9_11;
    }

    @WorkerThread
    public final void zzb() {
        zzaf zzaf2 = this.e;
        if (zzaf2 != null) {
            try {
                zzaf2.zzd();
            }
            catch (RemoteException remoteException) {
                Log.e((String)"LegacyBarcodeScanner", (String)"Failed to release legacy barcode detector.", (Throwable)remoteException);
            }
            this.e = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @WorkerThread
    public final boolean zzc() {
        if (this.e != null) {
            return false;
        }
        try {
            zzaf zzaf2;
            this.e = zzaf2 = zzah.zza((IBinder)DynamiteModule.load((Context)this.b, (DynamiteModule.VersionPolicy)DynamiteModule.PREFER_REMOTE, (String)"com.google.android.gms.vision.dynamite").instantiate("com.google.android.gms.vision.barcode.ChimeraNativeBarcodeDetectorCreator")).zzd(ObjectWrapper.wrap((Object)this.b), this.c);
            if (zzaf2 == null && !this.a) {
                Log.d((String)"LegacyBarcodeScanner", (String)"Request optional module download.");
                OptionalModuleUtils.a((Context)this.b, (String)"barcode");
                this.a = true;
                zzb.e((zzlo)this.d, (zzjb)zzjb.zzB);
                throw new MlKitException("Waiting for the barcode module to be downloaded. Please wait.", 14);
            }
            zzb.e((zzlo)this.d, (zzjb)zzjb.zza);
            return false;
        }
        catch (DynamiteModule.LoadingException loadingException) {
            throw new MlKitException("Failed to load deprecated vision dynamite module.", 13, (Throwable)loadingException);
        }
        catch (RemoteException remoteException) {
            throw new MlKitException("Failed to create legacy barcode detector.", 13, (Throwable)remoteException);
        }
    }
}

