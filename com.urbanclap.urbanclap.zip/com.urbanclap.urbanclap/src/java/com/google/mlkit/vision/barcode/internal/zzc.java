/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.vision.barcode.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.MlKitContext;
import com.google.mlkit.vision.barcode.internal.zzf;

public final class zzc
implements ComponentFactory {
    public static final /* synthetic */ zzc a;

    public static /* synthetic */ {
        a = new zzc();
    }

    private /* synthetic */ zzc() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new zzf((MlKitContext)componentContainer.a(MlKitContext.class));
    }
}

