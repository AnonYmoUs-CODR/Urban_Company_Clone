/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.graphics.Rect
 *  androidx.annotation.Nullable
 *  com.google.android.gms.internal.mlkit_vision_barcode.zzq
 *  com.google.mlkit.vision.barcode.internal.zzk
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.vision.barcode.internal;

import android.graphics.Point;
import android.graphics.Rect;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.mlkit_vision_barcode.zzq;
import com.google.mlkit.vision.barcode.internal.zzk;

public final class zzn
implements zzk {
    public final zzq a;

    public zzn(zzq zzq2) {
        this.a = zzq2;
    }

    public final int zza() {
        return this.a.zza;
    }

    public final int zzb() {
        return this.a.zzd;
    }

    @Nullable
    public final Rect zzc() {
        Point[] arrpoint;
        zzq zzq2 = this.a;
        int n = Integer.MIN_VALUE;
        int n2 = Integer.MIN_VALUE;
        int n3 = Integer.MAX_VALUE;
        int n4 = Integer.MAX_VALUE;
        for (int i = 0; i < (arrpoint = zzq2.zze).length; ++i) {
            Point point = arrpoint[i];
            n3 = Math.min((int)n3, (int)point.x);
            n = Math.max((int)n, (int)point.x);
            n4 = Math.min((int)n4, (int)point.y);
            n2 = Math.max((int)n2, (int)point.y);
        }
        return new Rect(n3, n4, n, n2);
    }

    @Nullable
    public final String zzm() {
        return this.a.zzc;
    }

    @Nullable
    public final String zzn() {
        return this.a.zzb;
    }
}

