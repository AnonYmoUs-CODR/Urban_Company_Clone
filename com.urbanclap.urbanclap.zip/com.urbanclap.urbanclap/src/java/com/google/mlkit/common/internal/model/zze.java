/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.tasks.TaskCompletionSource
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.mlkit.common.internal.model.zzg;
import com.google.mlkit.common.model.CustomRemoteModel;

public final class zze
implements Runnable {
    public final /* synthetic */ zzg a;
    public final /* synthetic */ CustomRemoteModel b;
    public final /* synthetic */ TaskCompletionSource c;

    public final void run() {
        this.a.b(this.b, this.c);
    }
}

