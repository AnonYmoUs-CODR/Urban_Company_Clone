/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.sdkinternal;

import android.net.Uri;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.mlkit.common.sdkinternal.ModelType;

@KeepForSdk
public class ModelInfo {
    public final String a;
    public final Uri b;
    public final String c;
    public final ModelType d;

    @RecentlyNonNull
    @KeepForSdk
    public String a() {
        return this.c;
    }

    @RecentlyNonNull
    @KeepForSdk
    public String b() {
        return this.a;
    }

    @RecentlyNonNull
    @KeepForSdk
    public ModelType c() {
        return this.d;
    }

    @RecentlyNonNull
    @KeepForSdk
    public Uri d() {
        return this.b;
    }
}

