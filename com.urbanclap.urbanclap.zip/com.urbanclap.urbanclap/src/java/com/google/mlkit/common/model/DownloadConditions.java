/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  com.google.android.gms.common.internal.Objects
 *  java.lang.Object
 */
package com.google.mlkit.common.model;

import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.Objects;

public class DownloadConditions {
    public final boolean a;
    public final boolean b;

    public boolean a() {
        return this.a;
    }

    public boolean b() {
        return this.b;
    }

    public boolean equals(@Nullable Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof DownloadConditions)) {
            return false;
        }
        DownloadConditions downloadConditions = (DownloadConditions)object;
        return this.a == downloadConditions.a && this.b == downloadConditions.b;
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{this.a, this.b};
        return Objects.hashCode((Object[])arrobject);
    }

    public static class Builder {
    }

}

