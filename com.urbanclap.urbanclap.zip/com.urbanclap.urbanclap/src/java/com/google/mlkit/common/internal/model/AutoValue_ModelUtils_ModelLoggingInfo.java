/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.mlkit.common.internal.model.ModelUtils
 *  com.google.mlkit.common.internal.model.ModelUtils$ModelLoggingInfo
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.mlkit.common.internal.model.ModelUtils;

public final class AutoValue_ModelUtils_ModelLoggingInfo
extends ModelUtils.ModelLoggingInfo {
    public final long a;
    public final String b;
    public final boolean c;

    @KeepForSdk
    public String a() {
        return this.b;
    }

    @KeepForSdk
    public long b() {
        return this.a;
    }

    @KeepForSdk
    public boolean c() {
        return this.c;
    }

    public final boolean equals(Object object) {
        ModelUtils.ModelLoggingInfo modelLoggingInfo;
        if (object == this) {
            return true;
        }
        return object instanceof ModelUtils.ModelLoggingInfo && this.a == (modelLoggingInfo = (ModelUtils.ModelLoggingInfo)object).b() && this.b.equals((Object)modelLoggingInfo.a()) && this.c == modelLoggingInfo.c();
    }

    public final int hashCode() {
        long l = this.a;
        int n = 1000003 * (1000003 * (1000003 ^ (int)(l ^ l >>> 32)) ^ this.b.hashCode());
        int n2 = true != this.c ? 1237 : 1231;
        return n2 ^ n;
    }

    public final String toString() {
        long l = this.a;
        String string = this.b;
        boolean bl = this.c;
        StringBuilder stringBuilder = new StringBuilder(71 + string.length());
        stringBuilder.append("ModelLoggingInfo{size=");
        stringBuilder.append(l);
        stringBuilder.append(", hash=");
        stringBuilder.append(string);
        stringBuilder.append(", manifestModel=");
        stringBuilder.append(bl);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

