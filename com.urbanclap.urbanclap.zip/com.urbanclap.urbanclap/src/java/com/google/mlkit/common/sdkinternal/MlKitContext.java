/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.tasks.TaskExecutors
 *  com.google.firebase.components.Component
 *  com.google.firebase.components.ComponentDiscovery
 *  com.google.firebase.components.ComponentRuntime
 *  com.google.firebase.components.ComponentRuntime$Builder
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.List
 *  java.util.concurrent.Executor
 *  java.util.concurrent.atomic.AtomicReference
 */
package com.google.mlkit.common.sdkinternal;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.components.Component;
import com.google.firebase.components.ComponentDiscovery;
import com.google.firebase.components.ComponentRuntime;
import com.google.mlkit.common.internal.MlKitComponentDiscoveryService;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

@KeepForSdk
public class MlKitContext {
    public static final AtomicReference<MlKitContext> b = new AtomicReference();
    @Nullable
    public ComponentRuntime a;

    private MlKitContext() {
    }

    @RecentlyNonNull
    @KeepForSdk
    public static MlKitContext c() {
        MlKitContext mlKitContext = (MlKitContext)b.get();
        boolean bl = mlKitContext != null;
        Preconditions.checkState((boolean)bl, (Object)"MlKitContext has not been initialized");
        return mlKitContext;
    }

    @RecentlyNonNull
    public static MlKitContext d(@RecentlyNonNull Context context) {
        ComponentRuntime componentRuntime;
        MlKitContext mlKitContext = new MlKitContext();
        Context context2 = MlKitContext.e(context);
        List list = ComponentDiscovery.c((Context)context2, MlKitComponentDiscoveryService.class).b();
        ComponentRuntime.Builder builder = ComponentRuntime.e((Executor)TaskExecutors.MAIN_THREAD);
        builder.b((Collection)list);
        builder.a(Component.o((Object)context2, Context.class, (Class[])new Class[0]));
        builder.a(Component.o((Object)mlKitContext, MlKitContext.class, (Class[])new Class[0]));
        mlKitContext.a = componentRuntime = builder.c();
        componentRuntime.h(true);
        MlKitContext mlKitContext2 = (MlKitContext)b.getAndSet((Object)mlKitContext);
        boolean bl = false;
        if (mlKitContext2 == null) {
            bl = true;
        }
        Preconditions.checkState((boolean)bl, (Object)"MlKitContext is already initialized");
        return mlKitContext;
    }

    public static Context e(Context context) {
        Context context2 = context.getApplicationContext();
        if (context2 != null) {
            return context2;
        }
        return context;
    }

    @RecentlyNonNull
    @KeepForSdk
    public <T> T a(@RecentlyNonNull Class<T> class_) {
        boolean bl = b.get() == this;
        Preconditions.checkState((boolean)bl, (Object)"MlKitContext has been deleted");
        Preconditions.checkNotNull((Object)this.a);
        return (T)this.a.a(class_);
    }

    @RecentlyNonNull
    @KeepForSdk
    public Context b() {
        return this.a(Context.class);
    }
}

