/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.internal.Objects
 *  com.google.android.gms.internal.mlkit_common.zzt
 *  com.google.android.gms.internal.mlkit_common.zzu
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.model;

import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.internal.mlkit_common.zzt;
import com.google.android.gms.internal.mlkit_common.zzu;

public abstract class RemoteModelSource {
    @Nullable
    public final String a;

    public boolean equals(@Nullable Object object) {
        if (object == this) {
            return true;
        }
        if (object != null && object.getClass().equals((Object)this.getClass())) {
            RemoteModelSource remoteModelSource = (RemoteModelSource)object;
            return Objects.equal((Object)this.a, (Object)remoteModelSource.a);
        }
        return false;
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{this.a};
        return Objects.hashCode((Object[])arrobject);
    }

    @RecentlyNonNull
    public String toString() {
        zzt zzt2 = zzu.zzb((String)"RemoteModelSource");
        zzt2.zza("firebaseModelName", (Object)this.a);
        return zzt2.toString();
    }
}

