/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.mlkit.common.sdkinternal.zza
 *  com.google.mlkit.common.sdkinternal.zzb
 *  com.google.mlkit.common.sdkinternal.zzc
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.ref.ReferenceQueue
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.mlkit.common.sdkinternal.zza;
import com.google.mlkit.common.sdkinternal.zzb;
import com.google.mlkit.common.sdkinternal.zzc;
import com.google.mlkit.common.sdkinternal.zzd;
import java.lang.ref.ReferenceQueue;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Cleaner {
    public final ReferenceQueue<Object> a = new ReferenceQueue();
    public final Set<zzd> b = Collections.synchronizedSet((Set)new HashSet());

    private Cleaner() {
    }

    @RecentlyNonNull
    @KeepForSdk
    public static Cleaner a() {
        Cleaner cleaner = new Cleaner();
        cleaner.b(cleaner, (Runnable)zzb.a);
        Thread thread = new Thread((Runnable)new zza(cleaner.a, cleaner.b), "MlKitCleaner");
        thread.setDaemon(true);
        thread.start();
        return cleaner;
    }

    @RecentlyNonNull
    @KeepForSdk
    public Cleanable b(@RecentlyNonNull Object object, @RecentlyNonNull Runnable runnable) {
        zzd zzd2 = new zzd(object, this.a, this.b, runnable, null);
        this.b.add((Object)zzd2);
        return zzd2;
    }

    public static interface Cleanable {
        @KeepForSdk
        public void a();
    }

}

