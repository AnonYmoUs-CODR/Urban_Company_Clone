/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.internal.mlkit_common.zzgc
 *  com.google.android.gms.internal.mlkit_common.zzgd
 *  com.google.android.gms.internal.mlkit_common.zzgm
 *  com.google.android.gms.internal.mlkit_common.zzgn
 *  com.google.android.gms.internal.mlkit_common.zzgv
 *  com.google.android.gms.internal.mlkit_common.zzgx
 *  com.google.android.gms.internal.mlkit_common.zzhf
 *  com.google.android.gms.internal.mlkit_common.zzjc
 *  com.google.android.gms.internal.mlkit_common.zzjl
 *  com.google.android.gms.internal.mlkit_common.zzjo
 *  com.google.android.gms.internal.mlkit_common.zzjw
 *  com.google.android.gms.tasks.Task
 *  com.google.android.gms.tasks.TaskCompletionSource
 *  com.google.mlkit.common.MlKitException
 *  com.google.mlkit.common.model.RemoteModel
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  com.google.mlkit.common.sdkinternal.ModelType
 *  com.google.mlkit.common.sdkinternal.model.ModelFileHelper
 *  com.google.mlkit.common.sdkinternal.model.ModelInfoRetrieverInterop
 *  com.google.mlkit.common.sdkinternal.model.ModelValidator
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelDownloadManager
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelFileManager
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelFileMover
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelManagerInterface
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.mlkit_common.zzgc;
import com.google.android.gms.internal.mlkit_common.zzgd;
import com.google.android.gms.internal.mlkit_common.zzgm;
import com.google.android.gms.internal.mlkit_common.zzgn;
import com.google.android.gms.internal.mlkit_common.zzgv;
import com.google.android.gms.internal.mlkit_common.zzgx;
import com.google.android.gms.internal.mlkit_common.zzhf;
import com.google.android.gms.internal.mlkit_common.zzjc;
import com.google.android.gms.internal.mlkit_common.zzjl;
import com.google.android.gms.internal.mlkit_common.zzjo;
import com.google.android.gms.internal.mlkit_common.zzjw;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.common.internal.model.zza;
import com.google.mlkit.common.model.CustomRemoteModel;
import com.google.mlkit.common.model.RemoteModel;
import com.google.mlkit.common.sdkinternal.MlKitContext;
import com.google.mlkit.common.sdkinternal.ModelType;
import com.google.mlkit.common.sdkinternal.model.ModelFileHelper;
import com.google.mlkit.common.sdkinternal.model.ModelInfoRetrieverInterop;
import com.google.mlkit.common.sdkinternal.model.ModelValidator;
import com.google.mlkit.common.sdkinternal.model.RemoteModelDownloadManager;
import com.google.mlkit.common.sdkinternal.model.RemoteModelFileManager;
import com.google.mlkit.common.sdkinternal.model.RemoteModelFileMover;
import com.google.mlkit.common.sdkinternal.model.RemoteModelManagerInterface;

public final class zzg
implements RemoteModelManagerInterface<CustomRemoteModel> {
    public final MlKitContext a;
    public final zzjl b;

    public zzg(MlKitContext mlKitContext) {
        zzjl zzjl2 = zzjw.zzb((String)"common");
        this.a = mlKitContext;
        this.b = zzjl2;
    }

    public final /* synthetic */ Boolean a(CustomRemoteModel customRemoteModel) {
        return this.e(customRemoteModel).h();
    }

    public final /* synthetic */ void b(CustomRemoteModel customRemoteModel, TaskCompletionSource taskCompletionSource) {
        try {
            new ModelFileHelper(this.a).a(ModelType.CUSTOM, (String)Preconditions.checkNotNull((Object)customRemoteModel.b()));
        }
        catch (RuntimeException runtimeException) {
            taskCompletionSource.setException((Exception)new MlKitException("Internal error has occurred when executing ML Kit tasks", 13, (Throwable)runtimeException));
            return;
        }
        taskCompletionSource.setResult(null);
    }

    public final /* synthetic */ void c(Task task) {
        boolean bl = task.isSuccessful();
        zzjl zzjl2 = this.b;
        zzgx zzgx2 = new zzgx();
        zzgc zzgc2 = new zzgc();
        zzgc2.zzb(zzhf.zzb);
        zzgc2.zza(Boolean.valueOf((boolean)bl));
        zzgx2.zze(zzgc2.zzc());
        zzjl2.zzc(zzjo.zzf((zzgx)zzgx2), zzgv.zzaW);
    }

    public final /* synthetic */ void d(Task task) {
        boolean bl = (Boolean)task.getResult();
        zzjl zzjl2 = this.b;
        zzgx zzgx2 = new zzgx();
        zzgm zzgm2 = new zzgm();
        zzgm2.zzb(zzhf.zzb);
        zzgm2.zza(Boolean.valueOf((boolean)bl));
        zzgx2.zzg(zzgm2.zzc());
        zzjl2.zzc(zzjo.zzf((zzgx)zzgx2), zzgv.zzaV);
    }

    public final RemoteModelDownloadManager e(CustomRemoteModel customRemoteModel) {
        MlKitContext mlKitContext = this.a;
        RemoteModelFileManager remoteModelFileManager = new RemoteModelFileManager(mlKitContext, (RemoteModel)customRemoteModel, null, new ModelFileHelper(mlKitContext), (RemoteModelFileMover)new zza(this.a, customRemoteModel.e()));
        MlKitContext mlKitContext2 = this.a;
        return RemoteModelDownloadManager.g((MlKitContext)mlKitContext2, (RemoteModel)customRemoteModel, (ModelFileHelper)new ModelFileHelper(mlKitContext2), (RemoteModelFileManager)remoteModelFileManager, (ModelInfoRetrieverInterop)((ModelInfoRetrieverInterop)this.a.a(ModelInfoRetrieverInterop.class)));
    }
}

