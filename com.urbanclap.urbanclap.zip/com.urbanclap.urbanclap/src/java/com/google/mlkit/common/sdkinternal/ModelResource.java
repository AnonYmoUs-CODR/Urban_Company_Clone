/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.VisibleForTesting
 *  androidx.annotation.WorkerThread
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.tasks.CancellationToken
 *  com.google.android.gms.tasks.CancellationTokenSource
 *  com.google.android.gms.tasks.Task
 *  com.google.android.gms.tasks.TaskCompletionSource
 *  com.google.android.gms.tasks.Tasks
 *  com.google.mlkit.common.sdkinternal.TaskQueue
 *  com.google.mlkit.common.sdkinternal.zzl
 *  com.google.mlkit.common.sdkinternal.zzm
 *  com.google.mlkit.common.sdkinternal.zzn
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Executor
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.RecentlyNonNull;
import androidx.annotation.VisibleForTesting;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.tasks.CancellationToken;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.MlKitException;
import com.google.mlkit.common.sdkinternal.TaskQueue;
import com.google.mlkit.common.sdkinternal.zzl;
import com.google.mlkit.common.sdkinternal.zzm;
import com.google.mlkit.common.sdkinternal.zzn;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@KeepForSdk
public abstract class ModelResource {
    @RecentlyNonNull
    @KeepForSdk
    public final TaskQueue a = new TaskQueue();
    public final AtomicInteger b = new AtomicInteger(0);
    public final AtomicBoolean c = new AtomicBoolean(false);

    @RecentlyNonNull
    @KeepForSdk
    public <T> Task<T> a(@RecentlyNonNull Executor executor, @RecentlyNonNull Callable<T> callable, @RecentlyNonNull CancellationToken cancellationToken) {
        boolean bl = this.b.get() > 0;
        Preconditions.checkState((boolean)bl);
        if (cancellationToken.isCancellationRequested()) {
            return Tasks.forCanceled();
        }
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource(cancellationTokenSource.getToken());
        zzn zzn2 = new zzn(executor, cancellationToken, cancellationTokenSource, taskCompletionSource);
        TaskQueue taskQueue = this.a;
        zzm zzm2 = new zzm(this, cancellationToken, cancellationTokenSource, callable, taskCompletionSource);
        taskQueue.a((Executor)zzn2, (Runnable)zzm2);
        return taskCompletionSource.getTask();
    }

    @VisibleForTesting
    @WorkerThread
    @KeepForSdk
    public abstract void b();

    @KeepForSdk
    public void c() {
        this.b.incrementAndGet();
    }

    @WorkerThread
    @KeepForSdk
    public abstract void d();

    @KeepForSdk
    public void e(@RecentlyNonNull Executor executor) {
        boolean bl = this.b.get() > 0;
        Preconditions.checkState((boolean)bl);
        this.a.a(executor, (Runnable)new zzl(this));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final /* synthetic */ void f(@RecentlyNonNull CancellationToken cancellationToken, @RecentlyNonNull CancellationTokenSource cancellationTokenSource, @RecentlyNonNull Callable callable, @RecentlyNonNull TaskCompletionSource taskCompletionSource) {
        if (cancellationToken.isCancellationRequested()) {
            cancellationTokenSource.cancel();
            return;
        }
        try {
            Object object;
            try {
                if (!this.c.get()) {
                    this.b();
                    this.c.set(true);
                }
                if (cancellationToken.isCancellationRequested()) {
                    cancellationTokenSource.cancel();
                    return;
                }
                object = callable.call();
            }
            catch (RuntimeException runtimeException) {
                throw new MlKitException("Internal error has occurred when executing ML Kit tasks", 13, runtimeException);
            }
            if (cancellationToken.isCancellationRequested()) {
                cancellationTokenSource.cancel();
                return;
            }
            taskCompletionSource.setResult(object);
            return;
        }
        catch (Exception exception) {}
        if (cancellationToken.isCancellationRequested()) {
            cancellationTokenSource.cancel();
            return;
        }
        taskCompletionSource.setException(exception);
    }

    public final /* synthetic */ void g() {
        int n2 = this.b.decrementAndGet();
        boolean bl = n2 >= 0;
        Preconditions.checkState((boolean)bl);
        if (n2 == 0) {
            this.d();
            this.c.set(false);
        }
    }
}

