/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.common.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.MlKitContext;

public final class zzg
implements ComponentFactory {
    public static final /* synthetic */ zzg a;

    public static /* synthetic */ {
        a = new zzg();
    }

    private /* synthetic */ zzg() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new com.google.mlkit.common.internal.model.zzg((MlKitContext)componentContainer.a(MlKitContext.class));
    }
}

