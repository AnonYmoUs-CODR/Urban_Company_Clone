/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.firebase.inject.Provider
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelManagerInterface
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Set
 */
package com.google.mlkit.common.model;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.firebase.inject.Provider;
import com.google.mlkit.common.model.RemoteModel;
import com.google.mlkit.common.sdkinternal.model.RemoteModelManagerInterface;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class RemoteModelManager {
    public final Map<Class<? extends RemoteModel>, Provider<? extends RemoteModelManagerInterface<? extends RemoteModel>>> a = new HashMap();

    @KeepForSdk
    public RemoteModelManager(@RecentlyNonNull Set<RemoteModelManagerRegistration> set) {
        for (RemoteModelManagerRegistration remoteModelManagerRegistration : set) {
            this.a.put(remoteModelManagerRegistration.b(), remoteModelManagerRegistration.a());
        }
    }

    @KeepForSdk
    public static class RemoteModelManagerRegistration {
        public final Class<? extends RemoteModel> a;
        public final Provider<? extends RemoteModelManagerInterface<? extends RemoteModel>> b;

        @KeepForSdk
        public <RemoteT extends RemoteModel> RemoteModelManagerRegistration(@RecentlyNonNull Class<RemoteT> class_, @RecentlyNonNull Provider<? extends RemoteModelManagerInterface<RemoteT>> provider) {
            this.a = class_;
            this.b = provider;
        }

        public final Provider<? extends RemoteModelManagerInterface<? extends RemoteModel>> a() {
            return this.b;
        }

        public final Class<? extends RemoteModel> b() {
            return this.a;
        }
    }

}

