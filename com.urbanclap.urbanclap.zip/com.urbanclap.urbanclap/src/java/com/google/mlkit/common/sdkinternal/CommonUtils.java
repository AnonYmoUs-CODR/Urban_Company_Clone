/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.text.TextUtils
 *  androidx.annotation.NonNull
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.GmsLogger
 *  com.google.android.gms.common.util.PlatformVersion
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Locale
 */
package com.google.mlkit.common.sdkinternal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.GmsLogger;
import com.google.android.gms.common.util.PlatformVersion;
import java.util.Locale;

@KeepForSdk
public class CommonUtils {
    public static final GmsLogger a = new GmsLogger("CommonUtils", "");

    private CommonUtils() {
    }

    @RecentlyNonNull
    @KeepForSdk
    public static String a(@RecentlyNonNull Context context) {
        try {
            String string = String.valueOf((int)context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionCode);
            return string;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            GmsLogger gmsLogger = a;
            String string = String.valueOf((Object)((Object)nameNotFoundException));
            StringBuilder stringBuilder = new StringBuilder(48 + String.valueOf((Object)string).length());
            stringBuilder.append("Exception thrown when trying to get app version ");
            stringBuilder.append(string);
            gmsLogger.e("CommonUtils", stringBuilder.toString());
            return "";
        }
    }

    @NonNull
    @KeepForSdk
    public static String b(@RecentlyNonNull Locale locale) {
        if (PlatformVersion.isAtLeastLollipop()) {
            return locale.toLanguageTag();
        }
        StringBuilder stringBuilder = new StringBuilder(locale.getLanguage());
        if (!TextUtils.isEmpty((CharSequence)locale.getCountry())) {
            stringBuilder.append("-");
            stringBuilder.append(locale.getCountry());
        }
        if (!TextUtils.isEmpty((CharSequence)locale.getVariant())) {
            stringBuilder.append("-");
            stringBuilder.append(locale.getVariant());
        }
        return stringBuilder.toString();
    }
}

