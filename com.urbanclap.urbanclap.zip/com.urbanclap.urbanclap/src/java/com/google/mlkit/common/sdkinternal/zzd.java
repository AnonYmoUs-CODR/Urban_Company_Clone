/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.mlkit.common.sdkinternal.Cleaner
 *  com.google.mlkit.common.sdkinternal.Cleaner$Cleanable
 *  com.google.mlkit.common.sdkinternal.zzc
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.ref.PhantomReference
 *  java.lang.ref.ReferenceQueue
 *  java.util.Set
 */
package com.google.mlkit.common.sdkinternal;

import com.google.mlkit.common.sdkinternal.Cleaner;
import com.google.mlkit.common.sdkinternal.zzc;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Set;

public final class zzd
extends PhantomReference<Object>
implements Cleaner.Cleanable {
    public final Set<zzd> a;
    public final Runnable b;

    public /* synthetic */ zzd(Object object, ReferenceQueue referenceQueue, Set set, Runnable runnable, zzc zzc2) {
        super(object, referenceQueue);
        this.a = set;
        this.b = runnable;
    }

    public final void a() {
        if (!this.a.remove((Object)this)) {
            return;
        }
        this.clear();
        this.b.run();
    }
}

