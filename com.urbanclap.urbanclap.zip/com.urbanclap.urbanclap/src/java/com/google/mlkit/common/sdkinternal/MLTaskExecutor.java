/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  androidx.annotation.GuardedBy
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.internal.mlkit_common.zza
 *  com.google.android.gms.tasks.Task
 *  com.google.android.gms.tasks.TaskCompletionSource
 *  com.google.mlkit.common.sdkinternal.zzg
 *  com.google.mlkit.common.sdkinternal.zzh
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Executor
 */
package com.google.mlkit.common.sdkinternal;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.mlkit_common.zza;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.mlkit.common.sdkinternal.zzg;
import com.google.mlkit.common.sdkinternal.zzh;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

@KeepForSdk
public class MLTaskExecutor {
    public static final Object b = new Object();
    @GuardedBy(value="lock")
    @Nullable
    public static MLTaskExecutor c;
    public Handler a;

    public MLTaskExecutor(Looper looper) {
        this.a = new zza(looper);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @RecentlyNonNull
    @KeepForSdk
    public static MLTaskExecutor b() {
        Object object;
        Object object2 = object = b;
        synchronized (object2) {
            if (c != null) return c;
            HandlerThread handlerThread = new HandlerThread("MLHandler", 9);
            handlerThread.start();
            c = new MLTaskExecutor(handlerThread.getLooper());
            return c;
        }
    }

    @RecentlyNonNull
    @KeepForSdk
    public static Executor e() {
        return zzh.zza;
    }

    public static /* synthetic */ Handler f(MLTaskExecutor mLTaskExecutor) {
        return mLTaskExecutor.a;
    }

    @RecentlyNonNull
    @KeepForSdk
    public Handler a() {
        return this.a;
    }

    @RecentlyNonNull
    @KeepForSdk
    public <ResultT> Task<ResultT> c(@RecentlyNonNull Callable<ResultT> callable) {
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        this.d((Runnable)new zzg(callable, taskCompletionSource));
        return taskCompletionSource.getTask();
    }

    @KeepForSdk
    public void d(@RecentlyNonNull Runnable runnable) {
        MLTaskExecutor.e().execute(runnable);
    }
}

