/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.mlkit.common.model.RemoteModel
 */
package com.google.mlkit.common.model;

import com.google.mlkit.common.model.RemoteModel;

public final class CustomRemoteModel
extends RemoteModel {
}

