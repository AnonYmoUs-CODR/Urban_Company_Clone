/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.firebase.inject.Provider
 *  com.google.mlkit.common.model.RemoteModelManager
 *  com.google.mlkit.common.model.RemoteModelManager$RemoteModelManagerRegistration
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.common.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.firebase.inject.Provider;
import com.google.mlkit.common.internal.model.zzg;
import com.google.mlkit.common.model.CustomRemoteModel;
import com.google.mlkit.common.model.RemoteModelManager;

public final class zzh
implements ComponentFactory {
    public static final /* synthetic */ zzh a;

    public static /* synthetic */ {
        a = new zzh();
    }

    private /* synthetic */ zzh() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new RemoteModelManager.RemoteModelManagerRegistration(CustomRemoteModel.class, componentContainer.d(zzg.class));
    }
}

