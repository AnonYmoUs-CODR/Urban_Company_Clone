/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  java.lang.Object
 */
package com.google.mlkit.common.sdkinternal;

import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public class Constants {
    private Constants() {
    }
}

