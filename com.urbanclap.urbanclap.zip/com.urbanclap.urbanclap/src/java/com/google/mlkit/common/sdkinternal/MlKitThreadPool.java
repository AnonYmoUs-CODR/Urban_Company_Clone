/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.android.gms.internal.mlkit_common.zzap
 *  com.google.mlkit.common.sdkinternal.zzi
 *  com.google.mlkit.common.sdkinternal.zzk
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.ThreadLocal
 *  java.util.ArrayDeque
 *  java.util.Deque
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.internal.mlkit_common.zzap;
import com.google.mlkit.common.sdkinternal.zzi;
import com.google.mlkit.common.sdkinternal.zzk;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@KeepForSdk
public class MlKitThreadPool
extends zzap {
    public static final ThreadLocal<Deque<Runnable>> b = new ThreadLocal();
    public final ThreadPoolExecutor a;

    public MlKitThreadPool() {
        ThreadPoolExecutor threadPoolExecutor;
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        int n = Runtime.getRuntime().availableProcessors();
        this.a = threadPoolExecutor = new ThreadPoolExecutor(n, n, 60L, TimeUnit.SECONDS, (BlockingQueue)new LinkedBlockingQueue(), (ThreadFactory)new zzk(threadFactory));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
    }

    public static /* synthetic */ void a(Runnable runnable) {
        MlKitThreadPool.c((Deque<Runnable>)((Deque)b.get()), runnable);
    }

    public static /* synthetic */ void b(Runnable runnable) {
        b.set((Object)new ArrayDeque());
        runnable.run();
    }

    public static void c(Deque<Runnable> deque, Runnable runnable) {
        Preconditions.checkNotNull(deque);
        deque.add((Object)runnable);
        if (deque.size() <= 1) {
            do {
                runnable.run();
                deque.removeFirst();
            } while ((runnable = (Runnable)deque.peekFirst()) != null);
        }
    }

    public final void execute(@RecentlyNonNull Runnable runnable) {
        Deque deque = (Deque)b.get();
        if (deque != null && deque.size() <= 1) {
            MlKitThreadPool.c((Deque<Runnable>)deque, runnable);
            return;
        }
        this.a.execute((Runnable)new zzi(runnable));
    }

    @RecentlyNonNull
    public final ExecutorService zzb() {
        return this.a;
    }
}

