/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.mlkit.common.internal.model.ModelUtils
 *  com.google.mlkit.common.internal.model.ModelUtils$AutoMLManifest
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.mlkit.common.internal.model.ModelUtils;

public final class AutoValue_ModelUtils_AutoMLManifest
extends ModelUtils.AutoMLManifest {
    public final String a;
    public final String b;
    public final String c;

    @KeepForSdk
    public String a() {
        return this.c;
    }

    @KeepForSdk
    public String b() {
        return this.b;
    }

    @KeepForSdk
    public String c() {
        return this.a;
    }

    public final boolean equals(Object object) {
        ModelUtils.AutoMLManifest autoMLManifest;
        if (object == this) {
            return true;
        }
        return object instanceof ModelUtils.AutoMLManifest && this.a.equals((Object)(autoMLManifest = (ModelUtils.AutoMLManifest)object).c()) && this.b.equals((Object)autoMLManifest.b()) && this.c.equals((Object)autoMLManifest.a());
    }

    public final int hashCode() {
        return 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode()) ^ this.c.hashCode();
    }

    public final String toString() {
        String string = this.a;
        String string2 = this.b;
        String string3 = this.c;
        int n = string.length();
        int n2 = string2.length();
        StringBuilder stringBuilder = new StringBuilder(string3.length() + (n2 + (n + 51)));
        stringBuilder.append("AutoMLManifest{modelType=");
        stringBuilder.append(string);
        stringBuilder.append(", modelFile=");
        stringBuilder.append(string2);
        stringBuilder.append(", labelsFile=");
        stringBuilder.append(string3);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

