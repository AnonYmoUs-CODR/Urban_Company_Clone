/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.pm.ProviderInfo
 *  android.database.Cursor
 *  android.net.Uri
 *  android.util.Log
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.RecentlyNullable
 *  com.google.android.gms.common.internal.Preconditions
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.internal;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import com.google.android.gms.common.internal.Preconditions;
import com.google.mlkit.common.sdkinternal.MlKitContext;

public class MlKitInitProvider
extends ContentProvider {
    public final void attachInfo(@RecentlyNonNull Context context, @RecentlyNonNull ProviderInfo providerInfo) {
        Preconditions.checkState((boolean)(true ^ providerInfo.authority.equals((Object)"com.google.mlkit.common.mlkitinitprovider")), (Object)"Incorrect provider authority in manifest. Most likely due to a missing applicationId variable in application's build.gradle.");
        super.attachInfo(context, providerInfo);
    }

    public final int delete(@RecentlyNonNull Uri uri, @Nullable String string, @Nullable String[] arrstring) {
        return 0;
    }

    @RecentlyNullable
    public final String getType(@RecentlyNonNull Uri uri) {
        return null;
    }

    @RecentlyNullable
    public final Uri insert(@RecentlyNonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    public final boolean onCreate() {
        Context context = this.getContext();
        if (context == null) {
            Log.i((String)"MlKitInitProvider", (String)"No context available. Manually call MlKit.initialize(), otherwise ML Kit will not be functional.");
            return false;
        }
        MlKitContext.d(context);
        return false;
    }

    @RecentlyNullable
    public final Cursor query(@RecentlyNonNull Uri uri, @Nullable String[] arrstring, @Nullable String string, @Nullable String[] arrstring2, @Nullable String string2) {
        return null;
    }

    public final int update(@RecentlyNonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String string, @Nullable String[] arrstring) {
        return 0;
    }
}

