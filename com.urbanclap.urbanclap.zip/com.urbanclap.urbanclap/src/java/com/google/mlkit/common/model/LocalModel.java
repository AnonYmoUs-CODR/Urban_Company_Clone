/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.internal.Objects
 *  com.google.android.gms.internal.mlkit_common.zzt
 *  com.google.android.gms.internal.mlkit_common.zzu
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.model;

import android.net.Uri;
import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.internal.mlkit_common.zzt;
import com.google.android.gms.internal.mlkit_common.zzu;

public class LocalModel {
    @Nullable
    public final String a;
    @Nullable
    public final String b;
    @Nullable
    public final Uri c;
    public final boolean d;

    public boolean equals(@Nullable Object object) {
        if (object == null) {
            return false;
        }
        if (object == this) {
            return true;
        }
        if (!(object instanceof LocalModel)) {
            return false;
        }
        LocalModel localModel = (LocalModel)object;
        return Objects.equal((Object)this.a, (Object)localModel.a) && Objects.equal((Object)this.b, (Object)localModel.b) && Objects.equal((Object)this.c, (Object)localModel.c) && this.d == localModel.d;
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{this.a, this.b, this.c, this.d};
        return Objects.hashCode((Object[])arrobject);
    }

    @RecentlyNonNull
    public String toString() {
        zzt zzt2 = zzu.zza((Object)this);
        zzt2.zza("absoluteFilePath", (Object)this.a);
        zzt2.zza("assetFilePath", (Object)this.b);
        zzt2.zza("uri", (Object)this.c);
        zzt2.zzb("isManifestFile", this.d);
        return zzt2.toString();
    }

    public static class Builder {
    }

}

