/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.MlKitThreadPool
 *  java.lang.Object
 */
package com.google.mlkit.common.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.MlKitThreadPool;

public final class zzb
implements ComponentFactory {
    public static final /* synthetic */ zzb a;

    public static /* synthetic */ {
        a = new zzb();
    }

    private /* synthetic */ zzb() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new MlKitThreadPool();
    }
}

