/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.GuardedBy
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  java.lang.Object
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.GuardedBy;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import java.util.HashMap;
import java.util.Map;

@KeepForSdk
public abstract class LazyInstanceMap<K, V> {
    @GuardedBy(value="instances")
    private final Map<K, V> zza = new HashMap();

    @RecentlyNonNull
    @KeepForSdk
    public abstract V create(@RecentlyNonNull K var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @RecentlyNonNull
    @KeepForSdk
    public V get(@RecentlyNonNull K k2) {
        Map<K, V> map;
        Map<K, V> map2 = map = this.zza;
        synchronized (map2) {
            if (this.zza.containsKey(k2)) {
                Object object = this.zza.get(k2);
                return (V)object;
            }
            V v = this.create(k2);
            this.zza.put(k2, v);
            return v;
        }
    }
}

