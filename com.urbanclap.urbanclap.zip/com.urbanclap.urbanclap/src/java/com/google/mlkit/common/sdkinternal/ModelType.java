/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;

@KeepForSdk
public final class ModelType
extends Enum<ModelType> {
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType BASE;
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType CUSTOM;
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType DIGITAL_INK;
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType ENTITY_EXTRACTION;
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType TRANSLATE;
    @RecentlyNonNull
    @KeepForSdk
    public static final /* enum */ ModelType UNKNOWN;
    private static final /* synthetic */ ModelType[] zza;

    public static {
        ModelType modelType;
        ModelType modelType2;
        ModelType modelType3;
        ModelType modelType4;
        ModelType modelType5;
        ModelType modelType6;
        UNKNOWN = modelType5 = new ModelType();
        BASE = modelType4 = new ModelType();
        TRANSLATE = modelType2 = new ModelType();
        ENTITY_EXTRACTION = modelType = new ModelType();
        CUSTOM = modelType6 = new ModelType();
        DIGITAL_INK = modelType3 = new ModelType();
        zza = new ModelType[]{modelType5, modelType4, modelType2, modelType, modelType6, modelType3};
    }

    @RecentlyNonNull
    public static ModelType[] values() {
        return (ModelType[])zza.clone();
    }
}

