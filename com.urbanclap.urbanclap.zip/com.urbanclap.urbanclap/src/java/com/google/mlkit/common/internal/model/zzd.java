/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.tasks.SuccessContinuation
 *  com.google.android.gms.tasks.Task
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelDownloadManager
 *  java.lang.Object
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.sdkinternal.model.RemoteModelDownloadManager;

public final class zzd
implements SuccessContinuation {
    public final /* synthetic */ RemoteModelDownloadManager a;

    public final Task then(Object object) {
        return this.a.a();
    }
}

