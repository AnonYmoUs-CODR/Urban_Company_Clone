/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.tasks.Continuation
 *  com.google.android.gms.tasks.Task
 *  java.lang.Object
 */
package com.google.mlkit.common.sdkinternal;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;

public final class zzf
implements Continuation {
    public static /* synthetic */ {
        new zzf();
    }

    private /* synthetic */ zzf() {
    }

    public final Object then(Task task) {
        return (Task)task.getResult();
    }
}

