/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.WorkerThread
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.mlkit.common.sdkinternal.MLTaskInput
 *  com.google.mlkit.common.sdkinternal.ModelResource
 *  java.lang.Object
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.RecentlyNonNull;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.mlkit.common.sdkinternal.MLTaskInput;
import com.google.mlkit.common.sdkinternal.ModelResource;

@KeepForSdk
public abstract class MLTask<T, S extends MLTaskInput>
extends ModelResource {
    @RecentlyNonNull
    @WorkerThread
    @KeepForSdk
    public abstract T h(@RecentlyNonNull S var1);
}

