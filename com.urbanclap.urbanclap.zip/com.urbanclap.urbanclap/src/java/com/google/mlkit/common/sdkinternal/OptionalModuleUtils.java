/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.text.TextUtils
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.internal.mlkit_common.zzaj
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.google.mlkit.common.sdkinternal;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.mlkit_common.zzaj;
import java.util.List;

@KeepForSdk
public class OptionalModuleUtils {
    private OptionalModuleUtils() {
    }

    @KeepForSdk
    public static void a(@RecentlyNonNull Context context, @RecentlyNonNull String string) {
        OptionalModuleUtils.b(context, (List<String>)zzaj.zzi((Object)string));
    }

    @KeepForSdk
    public static void b(@RecentlyNonNull Context context, @RecentlyNonNull List<String> list) {
        Intent intent = new Intent();
        intent.setClassName("com.google.android.gms", "com.google.android.gms.vision.DependencyBroadcastReceiverProxy");
        intent.setAction("com.google.android.gms.vision.DEPENDENCY");
        intent.putExtra("com.google.android.gms.vision.DEPENDENCIES", TextUtils.join((CharSequence)",", list));
        context.sendBroadcast(intent);
    }
}

