/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.model.RemoteModelManager
 *  com.google.mlkit.common.model.RemoteModelManager$RemoteModelManagerRegistration
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.Set
 */
package com.google.mlkit.common.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.model.RemoteModelManager;
import java.util.Set;

public final class zzc
implements ComponentFactory {
    public static final /* synthetic */ zzc a;

    public static /* synthetic */ {
        a = new zzc();
    }

    private /* synthetic */ zzc() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new RemoteModelManager(componentContainer.c(RemoteModelManager.RemoteModelManagerRegistration.class));
    }
}

