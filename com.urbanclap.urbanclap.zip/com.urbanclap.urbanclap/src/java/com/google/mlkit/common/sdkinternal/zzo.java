/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.SharedPrefManager
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.common.sdkinternal;

import android.content.Context;
import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.SharedPrefManager;

public final class zzo
implements ComponentFactory {
    public static final /* synthetic */ zzo a;

    public static /* synthetic */ {
        a = new zzo();
    }

    private /* synthetic */ zzo() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new SharedPrefManager((Context)componentContainer.a(Context.class));
    }
}

