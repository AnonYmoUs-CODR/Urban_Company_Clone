/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.internal.mlkit_common.zzgr
 *  com.google.android.gms.internal.mlkit_common.zzgs
 *  com.google.android.gms.internal.mlkit_common.zzgt
 *  com.google.android.gms.internal.mlkit_common.zzgv
 *  com.google.android.gms.internal.mlkit_common.zzgx
 *  com.google.android.gms.internal.mlkit_common.zzjc
 *  com.google.android.gms.internal.mlkit_common.zzjl
 *  com.google.android.gms.internal.mlkit_common.zzjo
 *  java.io.Closeable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Locale
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.google.mlkit.common.sdkinternal;

import android.util.Log;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.mlkit_common.zzgr;
import com.google.android.gms.internal.mlkit_common.zzgs;
import com.google.android.gms.internal.mlkit_common.zzgt;
import com.google.android.gms.internal.mlkit_common.zzgv;
import com.google.android.gms.internal.mlkit_common.zzgx;
import com.google.android.gms.internal.mlkit_common.zzjc;
import com.google.android.gms.internal.mlkit_common.zzjl;
import com.google.android.gms.internal.mlkit_common.zzjo;
import com.google.mlkit.common.sdkinternal.Cleaner;
import java.io.Closeable;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

@KeepForSdk
public class CloseGuard
implements Closeable {
    public final AtomicBoolean a;
    public final String b;
    public final Cleaner.Cleanable c;

    public final /* synthetic */ void b(int n2, zzjl zzjl2, Runnable runnable) {
        if (!this.a.get()) {
            Locale locale = Locale.ENGLISH;
            Object[] arrobject = new Object[]{this.b};
            Log.e((String)"MlKitCloseGuard", (String)String.format((Locale)locale, (String)"%s has not been closed", (Object[])arrobject));
            zzgx zzgx2 = new zzgx();
            zzgs zzgs2 = new zzgs();
            zzgs2.zzb(zzgr.zzb((int)n2));
            zzgx2.zzh(zzgs2.zzc());
            zzjl2.zzc(zzjo.zzf((zzgx)zzgx2), zzgv.zzbt);
        }
        runnable.run();
    }

    public final void close() {
        this.a.set(true);
        this.c.a();
    }

    @KeepForSdk
    public static class Factory {
        public Factory(@RecentlyNonNull Cleaner cleaner) {
        }
    }

}

