/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.firebase.inject.Provider
 *  java.lang.Object
 *  java.util.concurrent.Executor
 */
package com.google.mlkit.common.sdkinternal;

import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.firebase.inject.Provider;
import java.util.concurrent.Executor;

@KeepForSdk
public class ExecutorSelector {
    public final Provider<? extends Executor> a;

    public ExecutorSelector(@RecentlyNonNull Provider<? extends Executor> provider) {
        this.a = provider;
    }

    @RecentlyNonNull
    @KeepForSdk
    public Executor a(@Nullable Executor executor) {
        if (executor != null) {
            return executor;
        }
        return (Executor)this.a.get();
    }
}

