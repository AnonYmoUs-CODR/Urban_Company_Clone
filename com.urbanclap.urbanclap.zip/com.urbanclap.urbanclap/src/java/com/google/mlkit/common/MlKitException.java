/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.Preconditions
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.annotation.Annotation
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 */
package com.google.mlkit.common;

import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.Preconditions;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class MlKitException
extends Exception {
    @ErrorCode
    public final int a;

    @KeepForSdk
    public MlKitException(@RecentlyNonNull String string, @ErrorCode int n2) {
        super(Preconditions.checkNotEmpty((String)string, (Object)"Provided message must not be empty."));
        this.a = n2;
    }

    @KeepForSdk
    public MlKitException(@RecentlyNonNull String string, @ErrorCode int n2, @Nullable Throwable throwable) {
        super(Preconditions.checkNotEmpty((String)string, (Object)"Provided message must not be empty."), throwable);
        this.a = n2;
    }

    @ErrorCode
    public int a() {
        return this.a;
    }

    @Retention(value=RetentionPolicy.CLASS)
    public static @interface ErrorCode {
    }

}

