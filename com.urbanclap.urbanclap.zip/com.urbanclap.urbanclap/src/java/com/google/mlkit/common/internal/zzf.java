/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.components.ComponentContainer
 *  com.google.firebase.components.ComponentFactory
 *  com.google.mlkit.common.sdkinternal.Cleaner
 *  com.google.mlkit.common.sdkinternal.CloseGuard
 *  com.google.mlkit.common.sdkinternal.CloseGuard$Factory
 *  java.lang.Class
 *  java.lang.Object
 */
package com.google.mlkit.common.internal;

import com.google.firebase.components.ComponentContainer;
import com.google.firebase.components.ComponentFactory;
import com.google.mlkit.common.sdkinternal.Cleaner;
import com.google.mlkit.common.sdkinternal.CloseGuard;

public final class zzf
implements ComponentFactory {
    public static final /* synthetic */ zzf a;

    public static /* synthetic */ {
        a = new zzf();
    }

    private /* synthetic */ zzf() {
    }

    public final Object a(ComponentContainer componentContainer) {
        return new CloseGuard.Factory((Cleaner)componentContainer.a(Cleaner.class));
    }
}

