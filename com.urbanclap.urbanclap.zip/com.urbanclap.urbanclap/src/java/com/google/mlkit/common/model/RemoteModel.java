/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.RecentlyNullable
 *  androidx.annotation.VisibleForTesting
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.Objects
 *  com.google.android.gms.internal.mlkit_common.zzt
 *  com.google.android.gms.internal.mlkit_common.zzu
 *  com.google.mlkit.common.sdkinternal.model.BaseModel
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.EnumMap
 *  java.util.Map
 */
package com.google.mlkit.common.model;

import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.internal.mlkit_common.zzt;
import com.google.android.gms.internal.mlkit_common.zzu;
import com.google.mlkit.common.sdkinternal.ModelType;
import com.google.mlkit.common.sdkinternal.model.BaseModel;
import java.util.EnumMap;
import java.util.Map;

public abstract class RemoteModel {
    @RecentlyNonNull
    @VisibleForTesting
    public static final Map<BaseModel, String> e;
    @Nullable
    public final String a;
    @Nullable
    public final BaseModel b;
    public final ModelType c;
    public String d;

    public static {
        new EnumMap(BaseModel.class);
        e = new EnumMap(BaseModel.class);
    }

    @RecentlyNonNull
    @KeepForSdk
    public String a() {
        return this.d;
    }

    @RecentlyNullable
    @KeepForSdk
    public String b() {
        return this.a;
    }

    @RecentlyNonNull
    @KeepForSdk
    public String c() {
        String string = this.a;
        if (string != null) {
            return string;
        }
        return (String)e.get((Object)this.b);
    }

    @RecentlyNonNull
    @KeepForSdk
    public ModelType d() {
        return this.c;
    }

    @RecentlyNonNull
    @KeepForSdk
    public String e() {
        String string = this.a;
        if (string != null) {
            return string;
        }
        String string2 = String.valueOf((Object)((String)e.get((Object)this.b)));
        if (string2.length() != 0) {
            return "COM.GOOGLE.BASE_".concat(string2);
        }
        return new String("COM.GOOGLE.BASE_");
    }

    public boolean equals(@Nullable Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof RemoteModel)) {
            return false;
        }
        RemoteModel remoteModel = (RemoteModel)object;
        return Objects.equal((Object)this.a, (Object)remoteModel.a) && Objects.equal((Object)this.b, (Object)remoteModel.b) && Objects.equal((Object)((Object)this.c), (Object)((Object)remoteModel.c));
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{this.a, this.b, this.c};
        return Objects.hashCode((Object[])arrobject);
    }

    @RecentlyNonNull
    public String toString() {
        zzt zzt2 = zzu.zzb((String)"RemoteModel");
        zzt2.zza("modelName", (Object)this.a);
        zzt2.zza("baseModel", (Object)this.b);
        zzt2.zza("modelType", (Object)this.c);
        return zzt2.toString();
    }
}

