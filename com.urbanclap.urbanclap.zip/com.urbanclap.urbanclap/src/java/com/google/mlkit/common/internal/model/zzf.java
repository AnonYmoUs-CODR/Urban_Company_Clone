/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.google.mlkit.common.internal.model;

import com.google.mlkit.common.internal.model.zzg;
import com.google.mlkit.common.model.CustomRemoteModel;
import java.util.concurrent.Callable;

public final class zzf
implements Callable {
    public final /* synthetic */ zzg a;
    public final /* synthetic */ CustomRemoteModel b;

    public final Object call() {
        return this.a.a(this.b);
    }
}

