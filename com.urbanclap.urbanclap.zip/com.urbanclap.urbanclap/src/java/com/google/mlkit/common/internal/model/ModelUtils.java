/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.RecentlyNonNull
 *  androidx.annotation.RecentlyNullable
 *  androidx.annotation.WorkerThread
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.common.internal.GmsLogger
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 */
package com.google.mlkit.common.internal.model;

import androidx.annotation.Nullable;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.common.internal.GmsLogger;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WorkerThread
@KeepForSdk
public class ModelUtils {
    public static final GmsLogger a = new GmsLogger("ModelUtils", "");

    private ModelUtils() {
    }

    /*
     * Exception decompiling
     */
    @RecentlyNullable
    @KeepForSdk
    public static String a(@RecentlyNonNull File var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean b(@RecentlyNonNull File file, @RecentlyNonNull String string) {
        String string2 = ModelUtils.a(file);
        GmsLogger gmsLogger = a;
        String string3 = String.valueOf((Object)string2);
        String string4 = string3.length() != 0 ? "Calculated hash value is: ".concat(string3) : new String("Calculated hash value is: ");
        gmsLogger.d("ModelUtils", string4);
        return string.equals((Object)string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public static String c(InputStream inputStream) {
        try {
            int n2;
            MessageDigest messageDigest = MessageDigest.getInstance((String)"SHA-256");
            byte[] arrby = new byte[1048576];
            do {
                int n3 = inputStream.read(arrby);
                n2 = 0;
                if (n3 == -1) break;
                messageDigest.update(arrby, 0, n3);
            } while (true);
            byte[] arrby2 = messageDigest.digest();
            StringBuilder stringBuilder = new StringBuilder();
            while (n2 < arrby2.length) {
                String string = Integer.toHexString((int)(255 & arrby2[n2]));
                if (string.length() == 1) {
                    stringBuilder.append('0');
                }
                stringBuilder.append(string);
                ++n2;
            }
            return stringBuilder.toString();
        }
        catch (IOException throwable) {
            a.e("ModelUtils", "Failed to read model file");
            return null;
        }
        catch (NoSuchAlgorithmException throwable) {
            a.e("ModelUtils", "Do not have SHA-256 algorithm");
        }
        return null;
    }

    @KeepForSdk
    public static abstract class AutoMLManifest {
        @RecentlyNonNull
        @KeepForSdk
        public abstract String a();

        @RecentlyNonNull
        @KeepForSdk
        public abstract String b();

        @RecentlyNonNull
        @KeepForSdk
        public abstract String c();
    }

    @KeepForSdk
    public static abstract class ModelLoggingInfo {
        @RecentlyNonNull
        @KeepForSdk
        public abstract String a();

        @KeepForSdk
        public abstract long b();

        @KeepForSdk
        public abstract boolean c();
    }

}

