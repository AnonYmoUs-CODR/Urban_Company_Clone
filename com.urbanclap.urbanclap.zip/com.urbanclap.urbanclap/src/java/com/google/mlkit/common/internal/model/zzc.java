/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  java.lang.Object
 */
package com.google.mlkit.common.internal.model;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.internal.model.zzg;

public final class zzc
implements OnCompleteListener {
    public final /* synthetic */ zzg a;

    public final void onComplete(Task task) {
        this.a.d(task);
    }
}

