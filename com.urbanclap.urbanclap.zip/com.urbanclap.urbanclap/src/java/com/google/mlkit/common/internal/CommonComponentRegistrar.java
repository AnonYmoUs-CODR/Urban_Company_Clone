/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.RecentlyNonNull
 *  com.google.android.gms.common.annotation.KeepForSdk
 *  com.google.android.gms.internal.mlkit_common.zzaj
 *  com.google.firebase.components.Component
 *  com.google.firebase.components.Component$Builder
 *  com.google.firebase.components.ComponentFactory
 *  com.google.firebase.components.ComponentRegistrar
 *  com.google.firebase.components.Dependency
 *  com.google.mlkit.common.model.RemoteModelManager
 *  com.google.mlkit.common.model.RemoteModelManager$RemoteModelManagerRegistration
 *  com.google.mlkit.common.sdkinternal.Cleaner
 *  com.google.mlkit.common.sdkinternal.CloseGuard
 *  com.google.mlkit.common.sdkinternal.CloseGuard$Factory
 *  com.google.mlkit.common.sdkinternal.ExecutorSelector
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  com.google.mlkit.common.sdkinternal.MlKitThreadPool
 *  com.google.mlkit.common.sdkinternal.SharedPrefManager
 *  com.google.mlkit.common.sdkinternal.model.ModelFileHelper
 *  java.lang.Object
 *  java.util.List
 */
package com.google.mlkit.common.internal;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.internal.mlkit_common.zzaj;
import com.google.firebase.components.Component;
import com.google.firebase.components.ComponentFactory;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.components.Dependency;
import com.google.mlkit.common.internal.model.zzg;
import com.google.mlkit.common.internal.zza;
import com.google.mlkit.common.internal.zzb;
import com.google.mlkit.common.internal.zzc;
import com.google.mlkit.common.internal.zzd;
import com.google.mlkit.common.internal.zze;
import com.google.mlkit.common.internal.zzf;
import com.google.mlkit.common.internal.zzh;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.common.sdkinternal.Cleaner;
import com.google.mlkit.common.sdkinternal.CloseGuard;
import com.google.mlkit.common.sdkinternal.ExecutorSelector;
import com.google.mlkit.common.sdkinternal.MlKitContext;
import com.google.mlkit.common.sdkinternal.MlKitThreadPool;
import com.google.mlkit.common.sdkinternal.SharedPrefManager;
import com.google.mlkit.common.sdkinternal.model.ModelFileHelper;
import java.util.List;

@KeepForSdk
public class CommonComponentRegistrar
implements ComponentRegistrar {
    @RecentlyNonNull
    public final List<Component<?>> getComponents() {
        Component component = SharedPrefManager.b;
        Component.Builder builder = Component.a(ModelFileHelper.class);
        builder.b(Dependency.h(MlKitContext.class));
        builder.f((ComponentFactory)zza.a);
        Component component2 = builder.d();
        Component.Builder builder2 = Component.a(MlKitThreadPool.class);
        builder2.f((ComponentFactory)zzb.a);
        Component component3 = builder2.d();
        Component.Builder builder3 = Component.a(RemoteModelManager.class);
        builder3.b(Dependency.j(RemoteModelManager.RemoteModelManagerRegistration.class));
        builder3.f((ComponentFactory)zzc.a);
        Component component4 = builder3.d();
        Component.Builder builder4 = Component.a(ExecutorSelector.class);
        builder4.b(Dependency.i(MlKitThreadPool.class));
        builder4.f((ComponentFactory)zzd.a);
        Component component5 = builder4.d();
        Component.Builder builder5 = Component.a(Cleaner.class);
        builder5.f((ComponentFactory)zze.a);
        Component component6 = builder5.d();
        Component.Builder builder6 = Component.a(CloseGuard.Factory.class);
        builder6.b(Dependency.h(Cleaner.class));
        builder6.f((ComponentFactory)zzf.a);
        Component component7 = builder6.d();
        Component.Builder builder7 = Component.a(zzg.class);
        builder7.b(Dependency.h(MlKitContext.class));
        builder7.f((ComponentFactory)com.google.mlkit.common.internal.zzg.a);
        Component component8 = builder7.d();
        Component.Builder builder8 = Component.h(RemoteModelManager.RemoteModelManagerRegistration.class);
        builder8.b(Dependency.i(zzg.class));
        builder8.f((ComponentFactory)zzh.a);
        return zzaj.zzj((Object)component, (Object)component2, (Object)component3, (Object)component4, (Object)component5, (Object)component6, (Object)component7, (Object)component8, (Object)builder8.d());
    }
}

