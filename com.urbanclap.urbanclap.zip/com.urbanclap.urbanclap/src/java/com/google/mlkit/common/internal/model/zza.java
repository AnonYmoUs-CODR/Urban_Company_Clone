/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.google.android.gms.common.internal.GmsLogger
 *  com.google.android.gms.common.internal.Preconditions
 *  com.google.mlkit.common.sdkinternal.MlKitContext
 *  com.google.mlkit.common.sdkinternal.ModelType
 *  com.google.mlkit.common.sdkinternal.model.ModelFileHelper
 *  com.google.mlkit.common.sdkinternal.model.RemoteModelFileMover
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.mlkit.common.internal.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.GmsLogger;
import com.google.android.gms.common.internal.Preconditions;
import com.google.mlkit.common.sdkinternal.MlKitContext;
import com.google.mlkit.common.sdkinternal.ModelType;
import com.google.mlkit.common.sdkinternal.model.ModelFileHelper;
import com.google.mlkit.common.sdkinternal.model.RemoteModelFileMover;
import java.io.File;

public final class zza
implements RemoteModelFileMover {
    public static final GmsLogger c = new GmsLogger("CustomModelFileMover", "");
    public final String a;
    public final ModelFileHelper b;

    public zza(@NonNull MlKitContext mlKitContext, @NonNull String string) {
        this.a = string;
        this.b = new ModelFileHelper(mlKitContext);
    }

    public static boolean b(File file, File file2) {
        String string = file.getAbsolutePath();
        String string2 = file2.getAbsolutePath();
        if (file.renameTo(file2)) {
            c.d("CustomModelFileMover", String.format((String)"Moved file from %s to %s successfully", (Object[])new Object[]{string, string2}));
            file2.setExecutable(false);
            file2.setWritable(false);
            return true;
        }
        GmsLogger gmsLogger = c;
        gmsLogger.d("CustomModelFileMover", String.format((String)"Move file to %s failed, remove the temp file %s.", (Object[])new Object[]{string2, string}));
        if (!file.delete()) {
            String string3 = String.valueOf((Object)string);
            String string4 = string3.length() != 0 ? "Failed to delete the temp file: ".concat(string3) : new String("Failed to delete the temp file: ");
            gmsLogger.d("CustomModelFileMover", string4);
        }
        return false;
    }

    @Nullable
    public final File a(File file) {
        File file2;
        ModelFileHelper modelFileHelper = this.b;
        String string = this.a;
        ModelType modelType = ModelType.CUSTOM;
        File file3 = modelFileHelper.e(string, modelType);
        File file4 = new File(new File(file3, String.valueOf((int)(1 + this.b.d(file3)))), "model.tflite");
        File file5 = file4.getParentFile();
        if (file5 != null && !file5.exists()) {
            ((File)Preconditions.checkNotNull((Object)file5)).mkdirs();
        }
        if (!zza.b(file, file4)) {
            return null;
        }
        File file6 = this.b.g(this.a, modelType, "labels.txt");
        if (file6.exists()) {
            file2 = new File(file5, "labels.txt");
            if (!zza.b(file6, file2)) {
                return null;
            }
        } else {
            file2 = null;
        }
        File file7 = this.b.g(this.a, modelType, "manifest.json");
        boolean bl = file7.exists();
        File file8 = null;
        if (bl) {
            File file9 = new File(file5, "manifest.json");
            if (zza.b(file7, file9)) {
                file8 = file9;
            } else {
                return null;
            }
        }
        if (file2 == null && file8 == null) {
            return file4;
        }
        return file5;
    }
}

