/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  com.airbnb.lottie.model.content.PolystarShape$Type
 *  java.lang.Object
 *  java.lang.String
 *  t1.c.a.f
 *  t1.c.a.s.b.c
 *  t1.c.a.s.b.n
 *  t1.c.a.u.i.b
 *  t1.c.a.u.i.m
 *  t1.c.a.u.j.b
 *  t1.c.a.u.k.a
 */
package com.airbnb.lottie.model.content;

import android.graphics.PointF;
import com.airbnb.lottie.model.content.PolystarShape;
import t1.c.a.f;
import t1.c.a.s.b.c;
import t1.c.a.s.b.n;
import t1.c.a.u.i.m;
import t1.c.a.u.j.b;
import t1.c.a.u.k.a;

public class PolystarShape
implements b {
    public final String a;
    public final Type b;
    public final t1.c.a.u.i.b c;
    public final m<PointF, PointF> d;
    public final t1.c.a.u.i.b e;
    public final t1.c.a.u.i.b f;
    public final t1.c.a.u.i.b g;
    public final t1.c.a.u.i.b h;
    public final t1.c.a.u.i.b i;
    public final boolean j;

    public PolystarShape(String string, Type type, t1.c.a.u.i.b b2, m<PointF, PointF> m2, t1.c.a.u.i.b b3, t1.c.a.u.i.b b4, t1.c.a.u.i.b b5, t1.c.a.u.i.b b6, t1.c.a.u.i.b b7, boolean bl) {
        this.a = string;
        this.b = type;
        this.c = b2;
        this.d = m2;
        this.e = b3;
        this.f = b4;
        this.g = b5;
        this.h = b6;
        this.i = b7;
        this.j = bl;
    }

    public c a(f f2, a a2) {
        return new n(f2, a2, this);
    }

    public t1.c.a.u.i.b b() {
        return this.f;
    }

    public t1.c.a.u.i.b c() {
        return this.h;
    }

    public String d() {
        return this.a;
    }

    public t1.c.a.u.i.b e() {
        return this.g;
    }

    public t1.c.a.u.i.b f() {
        return this.i;
    }

    public t1.c.a.u.i.b g() {
        return this.c;
    }

    public m<PointF, PointF> h() {
        return this.d;
    }

    public t1.c.a.u.i.b i() {
        return this.e;
    }

    public Type j() {
        return this.b;
    }

    public boolean k() {
        return this.j;
    }
}

