/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  com.airbnb.lottie.model.content.MergePaths$MergePathsMode
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.c.a.f
 *  t1.c.a.s.b.c
 *  t1.c.a.s.b.l
 *  t1.c.a.u.j.b
 *  t1.c.a.u.k.a
 *  t1.c.a.x.d
 */
package com.airbnb.lottie.model.content;

import androidx.annotation.Nullable;
import com.airbnb.lottie.model.content.MergePaths;
import t1.c.a.f;
import t1.c.a.s.b.c;
import t1.c.a.s.b.l;
import t1.c.a.u.j.b;
import t1.c.a.u.k.a;
import t1.c.a.x.d;

public class MergePaths
implements b {
    public final String a;
    public final MergePathsMode b;
    public final boolean c;

    public MergePaths(String string, MergePathsMode mergePathsMode, boolean bl) {
        this.a = string;
        this.b = mergePathsMode;
        this.c = bl;
    }

    @Nullable
    public c a(f f2, a a2) {
        if (!f2.o()) {
            d.c((String)"Animation contains merge paths but they are disabled.");
            return null;
        }
        return new l(this);
    }

    public MergePathsMode b() {
        return this.b;
    }

    public String c() {
        return this.a;
    }

    public boolean d() {
        return this.c;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MergePaths{mode=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

