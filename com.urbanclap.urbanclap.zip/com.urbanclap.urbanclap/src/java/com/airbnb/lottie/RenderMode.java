/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

public final class RenderMode
extends Enum<RenderMode> {
    private static final /* synthetic */ RenderMode[] $VALUES;
    public static final /* enum */ RenderMode AUTOMATIC;
    public static final /* enum */ RenderMode HARDWARE;
    public static final /* enum */ RenderMode SOFTWARE;

    public static {
        RenderMode renderMode;
        RenderMode renderMode2;
        RenderMode renderMode3;
        AUTOMATIC = renderMode2 = new RenderMode();
        HARDWARE = renderMode3 = new RenderMode();
        SOFTWARE = renderMode = new RenderMode();
        $VALUES = new RenderMode[]{renderMode2, renderMode3, renderMode};
    }

    public static RenderMode valueOf(String string) {
        return (RenderMode)Enum.valueOf(RenderMode.class, (String)string);
    }

    public static RenderMode[] values() {
        return (RenderMode[])$VALUES.clone();
    }
}

