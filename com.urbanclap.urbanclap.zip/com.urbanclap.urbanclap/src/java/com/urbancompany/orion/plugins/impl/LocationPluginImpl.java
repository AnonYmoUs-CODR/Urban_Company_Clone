/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.urbancompany.orion.plugins.impl.LocationPluginImpl$LocationAccuracy
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.f.b
 *  t1.r.f.f.b.l
 *  t1.r.f.h.j
 *  t1.s.h.d.c.k
 */
package com.urbancompany.orion.plugins.impl;

import android.content.Context;
import com.urbancompany.orion.plugins.impl.LocationPluginImpl;
import t1.r.f.b;
import t1.r.f.f.b.l;
import t1.r.f.h.j;
import t1.s.h.d.c.k;

public final class LocationPluginImpl
extends j {
    public static k a;
    public static final LocationAccuracy b;
    public static final LocationPluginImpl c;

    public static {
        c = new LocationPluginImpl();
        b = LocationAccuracy.PRIORITY_HIGH_ACCURACY;
    }

    public void b(Context context, b<l, String> b2) {
        i2.a0.d.l.g((Object)context, (String)"context");
        i2.a0.d.l.g(b2, (String)"iPluginCapabilityListener");
        this.c(context, b2);
    }

    public final void c(Context context, b<l, String> b2) {
        k k2;
        i2.a0.d.l.g((Object)context, (String)"context");
        i2.a0.d.l.g(b2, (String)"iPluginCapabilityListener");
        a = k2 = new k(context, b2);
        if (k2 != null) {
            k2.u(false, b);
        }
    }
}

