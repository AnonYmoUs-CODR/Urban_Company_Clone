/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.adobe.xmp;

public class XMPException
extends Exception {
    public int a;

    public XMPException(String string, int n) {
        super(string);
        this.a = n;
    }

    public XMPException(String string, int n, Throwable throwable) {
        super(string, throwable);
        this.a = n;
    }

    public int a() {
        return this.a;
    }
}

