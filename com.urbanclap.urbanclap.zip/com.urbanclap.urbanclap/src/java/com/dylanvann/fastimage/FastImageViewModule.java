/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  com.dylanvann.fastimage.FastImageViewModule$a
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableArray
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.dylanvann.fastimage;

import android.app.Activity;
import com.dylanvann.fastimage.FastImageViewModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;

public class FastImageViewModule
extends ReactContextBaseJavaModule {
    private static final String REACT_CLASS = "FastImageView";

    public FastImageViewModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    public String getName() {
        return REACT_CLASS;
    }

    @ReactMethod
    public void preload(ReadableArray readableArray) {
        Activity activity = this.getCurrentActivity();
        if (activity == null) {
            return;
        }
        activity.runOnUiThread((Runnable)new a(this, readableArray, activity));
    }
}

