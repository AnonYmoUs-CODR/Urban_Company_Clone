/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  com.dylanvann.fastimage.FastImageOkHttpProgressGlideModule
 *  com.dylanvann.fastimage.FastImageProgressListener
 *  com.dylanvann.fastimage.FastImageRequestListener
 *  com.dylanvann.fastimage.FastImageSource
 *  com.facebook.react.bridge.JavaScriptModule
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.bridge.WritableNativeMap
 *  com.facebook.react.common.MapBuilder
 *  com.facebook.react.common.MapBuilder$Builder
 *  com.facebook.react.uimanager.SimpleViewManager
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.facebook.react.uimanager.ViewManager
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  com.facebook.react.uimanager.events.RCTEventEmitter
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 *  java.util.WeakHashMap
 *  t1.f.a.c
 *  t1.f.a.f
 *  t1.f.a.g
 *  t1.f.a.l.l.g
 *  t1.f.a.p.d
 *  t1.f.a.p.e
 *  t1.f.a.p.h.k
 *  t1.j.a.a
 *  t1.j.a.b
 */
package com.dylanvann.fastimage;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;
import com.dylanvann.fastimage.FastImageOkHttpProgressGlideModule;
import com.dylanvann.fastimage.FastImageProgressListener;
import com.dylanvann.fastimage.FastImageRequestListener;
import com.dylanvann.fastimage.FastImageSource;
import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewManager;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import t1.f.a.c;
import t1.f.a.f;
import t1.f.a.l.l.g;
import t1.f.a.p.d;
import t1.f.a.p.e;
import t1.f.a.p.h.k;
import t1.j.a.a;
import t1.j.a.b;

public class FastImageViewManager
extends SimpleViewManager<b>
implements FastImageProgressListener {
    private static final String REACT_CLASS = "FastImageView";
    private static final String REACT_ON_LOAD_START_EVENT = "onFastImageLoadStart";
    private static final String REACT_ON_PROGRESS_EVENT = "onFastImageProgress";
    private static final Map<String, List<b>> VIEWS_FOR_URLS = new WeakHashMap();
    private t1.f.a.g requestManager = null;

    private static Activity getActivityFromContext(Context context) {
        if (context instanceof Activity) {
            return (Activity)context;
        }
        if (context instanceof ThemedReactContext) {
            Context context2;
            Context context3 = ((ThemedReactContext)context).getBaseContext();
            if (context3 instanceof Activity) {
                return (Activity)context3;
            }
            if (context3 instanceof ContextWrapper && (context2 = ((ContextWrapper)context3).getBaseContext()) instanceof Activity) {
                return (Activity)context2;
            }
        }
        return null;
    }

    private static boolean isActivityDestroyed(Activity activity) {
        boolean bl;
        block8 : {
            block7 : {
                block4 : {
                    boolean bl2;
                    block6 : {
                        block5 : {
                            if (Build.VERSION.SDK_INT < 17) break block4;
                            if (activity.isDestroyed()) break block5;
                            boolean bl3 = activity.isFinishing();
                            bl2 = false;
                            if (!bl3) break block6;
                        }
                        bl2 = true;
                    }
                    return bl2;
                }
                if (activity.isDestroyed() || activity.isFinishing()) break block7;
                boolean bl4 = activity.isChangingConfigurations();
                bl = false;
                if (!bl4) break block8;
            }
            bl = true;
        }
        return bl;
    }

    private boolean isNullOrEmpty(String string) {
        return string == null || string.trim().isEmpty();
        {
        }
    }

    private static boolean isValidContextForGlide(Context context) {
        Activity activity = FastImageViewManager.getActivityFromContext(context);
        if (activity == null) {
            return false;
        }
        return true ^ FastImageViewManager.isActivityDestroyed(activity);
    }

    public b createViewInstance(ThemedReactContext themedReactContext) {
        if (FastImageViewManager.isValidContextForGlide((Context)themedReactContext)) {
            this.requestManager = c.u((Context)themedReactContext);
        }
        return new b((Context)themedReactContext);
    }

    public Map<String, Object> getExportedCustomDirectEventTypeConstants() {
        return MapBuilder.builder().put((Object)REACT_ON_LOAD_START_EVENT, (Object)MapBuilder.of((Object)"registrationName", (Object)REACT_ON_LOAD_START_EVENT)).put((Object)REACT_ON_PROGRESS_EVENT, (Object)MapBuilder.of((Object)"registrationName", (Object)REACT_ON_PROGRESS_EVENT)).put((Object)"onFastImageLoad", (Object)MapBuilder.of((Object)"registrationName", (Object)"onFastImageLoad")).put((Object)"onFastImageError", (Object)MapBuilder.of((Object)"registrationName", (Object)"onFastImageError")).put((Object)"onFastImageLoadEnd", (Object)MapBuilder.of((Object)"registrationName", (Object)"onFastImageLoadEnd")).build();
    }

    public float getGranularityPercentage() {
        return 0.5f;
    }

    public String getName() {
        return REACT_CLASS;
    }

    public void onDropViewInstance(b b2) {
        g g2;
        t1.f.a.g g3 = this.requestManager;
        if (g3 != null) {
            g3.m((View)b2);
        }
        if ((g2 = b2.a) != null) {
            String string = g2.toString();
            FastImageOkHttpProgressGlideModule.forget((String)string);
            Map<String, List<b>> map = VIEWS_FOR_URLS;
            List list = (List)map.get((Object)string);
            if (list != null) {
                list.remove((Object)b2);
                if (list.size() == 0) {
                    map.remove((Object)string);
                }
            }
        }
        ViewManager.super.onDropViewInstance((View)b2);
    }

    public void onProgress(String string, long l, long l2) {
        List list = (List)VIEWS_FOR_URLS.get((Object)string);
        if (list != null) {
            for (b b2 : list) {
                WritableNativeMap writableNativeMap = new WritableNativeMap();
                writableNativeMap.putInt("loaded", (int)l);
                writableNativeMap.putInt("total", (int)l2);
                ((RCTEventEmitter)((ThemedReactContext)b2.getContext()).getJSModule(RCTEventEmitter.class)).receiveEvent(b2.getId(), REACT_ON_PROGRESS_EVENT, (WritableMap)writableNativeMap);
            }
        }
    }

    @ReactProp(name="resizeMode")
    public void setResizeMode(b b2, String string) {
        b2.setScaleType(a.f((String)string));
    }

    @ReactProp(name="source")
    public void setSrc(b b2, ReadableMap readableMap) {
        g g2;
        if (readableMap != null && readableMap.hasKey("uri") && !this.isNullOrEmpty(readableMap.getString("uri"))) {
            g g3;
            FastImageSource fastImageSource = a.c((Context)b2.getContext(), (ReadableMap)readableMap);
            b2.a = g3 = fastImageSource.getGlideUrl();
            t1.f.a.g g4 = this.requestManager;
            if (g4 != null) {
                g4.m((View)b2);
            }
            String string = g3.h();
            FastImageOkHttpProgressGlideModule.expect((String)string, (FastImageProgressListener)this);
            Map<String, List<b>> map = VIEWS_FOR_URLS;
            List list = (List)map.get((Object)string);
            if (list != null && !list.contains((Object)b2)) {
                list.add((Object)b2);
            } else if (list == null) {
                map.put((Object)string, (Object)new ArrayList((Collection)Collections.singletonList((Object)b2)));
            }
            ThemedReactContext themedReactContext = (ThemedReactContext)b2.getContext();
            ((RCTEventEmitter)themedReactContext.getJSModule(RCTEventEmitter.class)).receiveEvent(b2.getId(), REACT_ON_LOAD_START_EVENT, (WritableMap)new WritableNativeMap());
            t1.f.a.g g5 = this.requestManager;
            if (g5 != null) {
                f f2 = g5.t(fastImageSource.getSourceForLoad());
                f2.a(a.d((Context)themedReactContext, (FastImageSource)fastImageSource, (ReadableMap)readableMap));
                f2.m((d)new FastImageRequestListener(string));
                f2.k((ImageView)b2);
            }
            return;
        }
        t1.f.a.g g6 = this.requestManager;
        if (g6 != null) {
            g6.m((View)b2);
        }
        if ((g2 = b2.a) != null) {
            FastImageOkHttpProgressGlideModule.forget((String)g2.h());
        }
        b2.setImageDrawable(null);
    }

    @ReactProp(customType="Color", name="tintColor")
    public void setTintColor(b b2, Integer n2) {
        if (n2 == null) {
            b2.clearColorFilter();
            return;
        }
        b2.setColorFilter(n2.intValue(), PorterDuff.Mode.SRC_IN);
    }
}

