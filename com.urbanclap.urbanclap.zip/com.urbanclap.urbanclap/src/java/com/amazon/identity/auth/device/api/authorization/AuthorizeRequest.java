/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.api.authorization.AuthCancellation
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeRequest$GrantType
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.List
 *  t1.d.a.a.a.a.b.b
 *  t1.d.a.a.a.a.b.c
 *  t1.d.a.a.a.a.b.e
 *  t1.d.a.a.a.a.c.a
 *  t1.d.a.a.a.b.c
 */
package com.amazon.identity.auth.device.api.authorization;

import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.authorization.AuthCancellation;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import t1.d.a.a.a.a.b.b;
import t1.d.a.a.a.a.b.e;
import t1.d.a.a.a.a.c.a;
import t1.d.a.a.a.b.c;

public final class AuthorizeRequest
extends c<b, t1.d.a.a.a.a.b.c, AuthCancellation, AuthError> {
    public List<e> b = new LinkedList();
    public GrantType c = GrantType.ACCESS_TOKEN;
    public String d;
    public String e;
    public boolean f = true;

    public AuthorizeRequest(a a2) {
        super(a2);
    }

    public final String e() {
        return "com.amazon.identity.auth.device.authorization.request.authorize";
    }

    public final Class<b> i() {
        return b.class;
    }

    public final Bundle k() {
        Bundle bundle = new Bundle();
        String[] arrstring = new String[this.b.size()];
        for (int i = 0; i < this.b.size(); ++i) {
            arrstring[i] = ((e)this.b.get(i)).getName();
        }
        bundle.putStringArray("requestedScopes", arrstring);
        bundle.putBoolean("shouldReturnUserData", this.w());
        return bundle;
    }

    public /* varargs */ void m(e ... arre) {
        Collections.addAll(this.b, (Object[])arre);
    }

    public String n() {
        return this.d;
    }

    public String o() {
        return this.e;
    }

    public GrantType p() {
        return this.c;
    }

    public List<e> q() {
        return this.b;
    }

    public void r(String string) {
        this.d = string;
    }

    public void s(String string) {
        this.e = string;
    }

    public void t(GrantType grantType) {
        this.c = grantType;
    }

    public void u(String string, String string2) {
        this.r(string);
        this.s(string2);
    }

    public void v(boolean bl) {
        this.f = bl;
    }

    public boolean w() {
        return this.f;
    }
}

