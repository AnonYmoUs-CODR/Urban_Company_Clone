/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentValues
 *  android.content.Context
 *  android.hardware.Camera
 *  android.hardware.Camera$Parameters
 *  android.hardware.Camera$PictureCallback
 *  android.hardware.Camera$PreviewCallback
 *  android.hardware.Camera$ShutterCallback
 *  android.media.CamcorderProfile
 *  android.media.MediaActionSound
 *  android.media.MediaRecorder
 *  android.media.MediaRecorder$OnErrorListener
 *  android.media.MediaRecorder$OnInfoListener
 *  android.media.MediaScannerConnection
 *  android.media.MediaScannerConnection$OnScanCompletedListener
 *  android.net.Uri
 *  android.os.Environment
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  android.util.Log
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableMap
 *  com.facebook.react.bridge.WritableMap
 *  com.facebook.react.bridge.WritableNativeMap
 *  com.lwansbrough.RCTCamera.MutableImage
 *  com.lwansbrough.RCTCamera.RCTCameraModule$a
 *  com.lwansbrough.RCTCamera.RCTCameraModule$b
 *  com.lwansbrough.RCTCamera.RCTCameraModule$c
 *  com.lwansbrough.RCTCamera.RCTCameraModule$d
 *  com.lwansbrough.RCTCamera.RCTCameraModule$e
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.text.SimpleDateFormat
 *  java.util.Collections
 *  java.util.Date
 *  java.util.List
 *  java.util.Map
 *  t1.l.a.a
 *  t1.l.a.e
 *  t1.l.a.f
 */
package com.lwansbrough.RCTCamera;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaActionSound;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.lwansbrough.RCTCamera.MutableImage;
import com.lwansbrough.RCTCamera.RCTCameraModule;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import t1.l.a.f;

public class RCTCameraModule
extends ReactContextBaseJavaModule
implements MediaRecorder.OnInfoListener,
MediaRecorder.OnErrorListener,
LifecycleEventListener {
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    public static final int RCT_CAMERA_ASPECT_FILL = 0;
    public static final int RCT_CAMERA_ASPECT_FIT = 1;
    public static final int RCT_CAMERA_ASPECT_STRETCH = 2;
    public static final int RCT_CAMERA_CAPTURE_MODE_STILL = 0;
    public static final int RCT_CAMERA_CAPTURE_MODE_VIDEO = 1;
    public static final String RCT_CAMERA_CAPTURE_QUALITY_1080P = "1080p";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_480P = "480p";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_720P = "720p";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_HIGH = "high";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_LOW = "low";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_MEDIUM = "medium";
    public static final String RCT_CAMERA_CAPTURE_QUALITY_PREVIEW = "preview";
    public static final int RCT_CAMERA_CAPTURE_TARGET_CAMERA_ROLL = 2;
    public static final int RCT_CAMERA_CAPTURE_TARGET_DISK = 1;
    public static final int RCT_CAMERA_CAPTURE_TARGET_MEMORY = 0;
    public static final int RCT_CAMERA_CAPTURE_TARGET_TEMP = 3;
    public static final int RCT_CAMERA_FLASH_MODE_AUTO = 2;
    public static final int RCT_CAMERA_FLASH_MODE_OFF = 0;
    public static final int RCT_CAMERA_FLASH_MODE_ON = 1;
    public static final int RCT_CAMERA_ORIENTATION_AUTO = Integer.MAX_VALUE;
    public static final int RCT_CAMERA_ORIENTATION_LANDSCAPE_LEFT = 1;
    public static final int RCT_CAMERA_ORIENTATION_LANDSCAPE_RIGHT = 3;
    public static final int RCT_CAMERA_ORIENTATION_PORTRAIT = 0;
    public static final int RCT_CAMERA_ORIENTATION_PORTRAIT_UPSIDE_DOWN = 2;
    public static final int RCT_CAMERA_TORCH_MODE_AUTO = 2;
    public static final int RCT_CAMERA_TORCH_MODE_OFF = 0;
    public static final int RCT_CAMERA_TORCH_MODE_ON = 1;
    public static final int RCT_CAMERA_TYPE_BACK = 2;
    public static final int RCT_CAMERA_TYPE_FRONT = 1;
    private static final String TAG = "RCTCameraModule";
    private static ReactApplicationContext _reactContext;
    private long MRStartTime;
    private t1.l.a.e _sensorOrientationChecker;
    private Camera mCamera = null;
    private MediaRecorder mMediaRecorder;
    private ReadableMap mRecordingOptions;
    private Promise mRecordingPromise = null;
    private Boolean mSafeToCapture = Boolean.TRUE;
    private File mVideoFile;

    public RCTCameraModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        _reactContext = reactApplicationContext;
        this._sensorOrientationChecker = new t1.l.a.e(reactApplicationContext);
        _reactContext.addLifecycleEventListener((LifecycleEventListener)this);
    }

    public static /* synthetic */ t1.l.a.e access$000(RCTCameraModule rCTCameraModule) {
        return rCTCameraModule._sensorOrientationChecker;
    }

    public static /* synthetic */ void access$100(RCTCameraModule rCTCameraModule, ReadableMap readableMap, Promise promise, int n2) {
        rCTCameraModule.captureWithOrientation(readableMap, promise, n2);
    }

    public static /* synthetic */ void access$200(RCTCameraModule rCTCameraModule, MutableImage mutableImage, ReadableMap readableMap, Promise promise) {
        rCTCameraModule.processImage(mutableImage, readableMap, promise);
    }

    public static /* synthetic */ Boolean access$302(RCTCameraModule rCTCameraModule, Boolean bl) {
        rCTCameraModule.mSafeToCapture = bl;
        return bl;
    }

    private void addToMediaStore(String string) {
        MediaScannerConnection.scanFile((Context)_reactContext, (String[])new String[]{string}, null, null);
    }

    private void captureWithOrientation(ReadableMap readableMap, Promise promise, int n2) {
        Camera camera = t1.l.a.a.h().a(readableMap.getInt("type"));
        if (camera == null) {
            promise.reject("No camera found.");
            return;
        }
        if (readableMap.getInt("mode") == 1) {
            this.record(readableMap, promise, n2);
            return;
        }
        t1.l.a.a.h().w(readableMap.getInt("type"), readableMap.getString("quality"));
        if (readableMap.hasKey("playSoundOnCapture") && readableMap.getBoolean("playSoundOnCapture")) {
            new MediaActionSound().play(0);
        }
        if (readableMap.hasKey("quality")) {
            t1.l.a.a.h().w(readableMap.getInt("type"), readableMap.getString("quality"));
        }
        t1.l.a.a.h().b(readableMap.getInt("type"), n2);
        camera.setPreviewCallback(null);
        c c2 = new c(this, readableMap, promise);
        d d2 = new d(this, camera);
        if (this.mSafeToCapture.booleanValue()) {
            try {
                camera.takePicture((Camera.ShutterCallback)d2, null, (Camera.PictureCallback)c2);
                this.mSafeToCapture = Boolean.FALSE;
                return;
            }
            catch (RuntimeException runtimeException) {
                Log.e((String)TAG, (String)"Couldn't capture photo.", (Throwable)runtimeException);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static byte[] convertFileToByteArray(File file) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] arrby = new byte[8192];
            do {
                int n2;
                if ((n2 = fileInputStream.read(arrby)) == -1) {
                    return byteArrayOutputStream.toByteArray();
                }
                byteArrayOutputStream.write(arrby, 0, n2);
            } while (true);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    private File getOutputCameraRollFile(int n2) {
        return this.getOutputFile(n2, Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DCIM));
    }

    private File getOutputFile(int n2, File file) {
        block6 : {
            String string;
            block5 : {
                String string2;
                block4 : {
                    if (!file.exists() && !file.mkdirs()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("failed to create directory:");
                        stringBuilder.append(file.getAbsolutePath());
                        Log.e((String)TAG, (String)stringBuilder.toString());
                        return null;
                    }
                    Object[] arrobject = new Object[]{new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())};
                    string2 = String.format((String)"%s", (Object[])arrobject);
                    if (n2 != 1) break block4;
                    string = String.format((String)"IMG_%s.jpg", (Object[])new Object[]{string2});
                    break block5;
                }
                if (n2 != 2) break block6;
                string = String.format((String)"VID_%s.mp4", (Object[])new Object[]{string2});
            }
            Object[] arrobject = new Object[]{file.getPath(), File.separator, string};
            return new File(String.format((String)"%s%s%s", (Object[])arrobject));
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unsupported media type:");
        stringBuilder.append(n2);
        Log.e((String)TAG, (String)stringBuilder.toString());
        return null;
    }

    private File getOutputMediaFile(int n2) {
        block4 : {
            String string;
            block3 : {
                block2 : {
                    if (n2 != 1) break block2;
                    string = Environment.DIRECTORY_PICTURES;
                    break block3;
                }
                if (n2 != 2) break block4;
                string = Environment.DIRECTORY_MOVIES;
            }
            return this.getOutputFile(n2, Environment.getExternalStoragePublicDirectory((String)string));
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unsupported media type:");
        stringBuilder.append(n2);
        Log.e((String)TAG, (String)stringBuilder.toString());
        return null;
    }

    public static ReactApplicationContext getReactContextSingleton() {
        return _reactContext;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private File getTempMediaFile(int n2) {
        try {
            String string = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            File file = _reactContext.getCacheDir();
            if (n2 == 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("IMG_");
                stringBuilder.append(string);
                return File.createTempFile((String)stringBuilder.toString(), (String)".jpg", (File)file);
            }
            if (n2 == 2) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("VID_");
                stringBuilder.append(string);
                return File.createTempFile((String)stringBuilder.toString(), (String)".mp4", (File)file);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unsupported media type:");
            stringBuilder.append(n2);
            Log.e((String)TAG, (String)stringBuilder.toString());
            return null;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)exception.getMessage());
            return null;
        }
    }

    private Throwable prepareMediaRecorder(ReadableMap readableMap, int n2) {
        MediaRecorder mediaRecorder;
        CamcorderProfile camcorderProfile = t1.l.a.a.h().x(readableMap.getInt("type"), readableMap.getString("quality"));
        if (camcorderProfile == null) {
            return new RuntimeException("CamcorderProfile not found in prepareMediaRecorder.");
        }
        this.mCamera.unlock();
        this.mMediaRecorder = mediaRecorder = new MediaRecorder();
        mediaRecorder.setOnInfoListener((MediaRecorder.OnInfoListener)this);
        this.mMediaRecorder.setOnErrorListener((MediaRecorder.OnErrorListener)this);
        this.mMediaRecorder.setCamera(this.mCamera);
        this.mMediaRecorder.setAudioSource(5);
        this.mMediaRecorder.setVideoSource(1);
        if (n2 != 0) {
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 == 3) {
                        this.mMediaRecorder.setOrientationHint(180);
                    }
                } else {
                    this.mMediaRecorder.setOrientationHint(270);
                }
            } else {
                this.mMediaRecorder.setOrientationHint(0);
            }
        } else {
            this.mMediaRecorder.setOrientationHint(90);
        }
        camcorderProfile.fileFormat = 2;
        this.mMediaRecorder.setProfile(camcorderProfile);
        this.mVideoFile = null;
        int n3 = readableMap.getInt("target");
        this.mVideoFile = n3 != 0 ? (n3 != 2 ? (n3 != 3 ? this.getOutputMediaFile(2) : this.getTempMediaFile(2)) : this.getOutputCameraRollFile(2)) : this.getTempMediaFile(2);
        File file = this.mVideoFile;
        if (file == null) {
            return new RuntimeException("Error while preparing output file in prepareMediaRecorder.");
        }
        this.mMediaRecorder.setOutputFile(file.getPath());
        if (readableMap.hasKey("totalSeconds")) {
            int n4 = readableMap.getInt("totalSeconds");
            this.mMediaRecorder.setMaxDuration(n4 * 1000);
        }
        if (readableMap.hasKey("maxFileSize")) {
            int n5 = readableMap.getInt("maxFileSize");
            this.mMediaRecorder.setMaxFileSize((long)n5);
        }
        try {
            this.mMediaRecorder.prepare();
            return null;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Media recorder prepare error.", (Throwable)exception);
            this.releaseMediaRecorder();
            return exception;
        }
    }

    /*
     * Exception decompiling
     */
    private void processImage(MutableImage var1, ReadableMap var2, Promise var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl91 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private void record(ReadableMap readableMap, Promise promise, int n2) {
        Camera camera;
        if (this.mRecordingPromise != null) {
            return;
        }
        this.mCamera = camera = t1.l.a.a.h().a(readableMap.getInt("type"));
        if (camera == null) {
            promise.reject((Throwable)new RuntimeException("No camera found."));
            return;
        }
        Throwable throwable = this.prepareMediaRecorder(readableMap, n2);
        if (throwable != null) {
            promise.reject(throwable);
            return;
        }
        try {
            this.mMediaRecorder.start();
            this.MRStartTime = System.currentTimeMillis();
            this.mRecordingOptions = readableMap;
            this.mRecordingPromise = promise;
            return;
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Media recorder start error.", (Throwable)exception);
            promise.reject((Throwable)exception);
            return;
        }
    }

    private void releaseMediaRecorder() {
        block15 : {
            File file;
            WritableNativeMap writableNativeMap;
            block12 : {
                block13 : {
                    block14 : {
                        Camera camera;
                        MediaRecorder mediaRecorder;
                        long l2 = System.currentTimeMillis() - this.MRStartTime;
                        if (l2 < 1500L) {
                            long l3 = 1500L - l2;
                            try {
                                Thread.sleep((long)l3);
                            }
                            catch (InterruptedException interruptedException) {
                                Log.e((String)TAG, (String)"releaseMediaRecorder thread sleep error.", (Throwable)interruptedException);
                            }
                        }
                        if ((mediaRecorder = this.mMediaRecorder) != null) {
                            try {
                                mediaRecorder.stop();
                            }
                            catch (RuntimeException runtimeException) {
                                Log.e((String)TAG, (String)"Media recorder stop error.", (Throwable)runtimeException);
                            }
                            this.mMediaRecorder.reset();
                            this.mMediaRecorder.release();
                            this.mMediaRecorder = null;
                        }
                        if ((camera = this.mCamera) != null) {
                            camera.lock();
                        }
                        if (this.mRecordingPromise == null) {
                            return;
                        }
                        file = new File(this.mVideoFile.getPath());
                        if (!file.exists()) {
                            this.mRecordingPromise.reject((Throwable)new RuntimeException("There is nothing recorded."));
                            this.mRecordingPromise = null;
                            return;
                        }
                        file.setReadable(true, false);
                        file.setWritable(true, false);
                        writableNativeMap = new WritableNativeMap();
                        int n2 = this.mRecordingOptions.getInt("target");
                        if (n2 == 0) break block12;
                        if (n2 == 1) break block13;
                        if (n2 == 2) break block14;
                        if (n2 == 3) break block13;
                        break block15;
                    }
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("_data", this.mVideoFile.getPath());
                    String string = this.mRecordingOptions.hasKey("title") ? this.mRecordingOptions.getString("title") : "video";
                    contentValues.put("title", string);
                    if (this.mRecordingOptions.hasKey("description")) {
                        contentValues.put("description", Boolean.valueOf((boolean)this.mRecordingOptions.hasKey("description")));
                    }
                    if (this.mRecordingOptions.hasKey("latitude")) {
                        contentValues.put("latitude", this.mRecordingOptions.getString("latitude"));
                    }
                    if (this.mRecordingOptions.hasKey("longitude")) {
                        contentValues.put("longitude", this.mRecordingOptions.getString("longitude"));
                    }
                    contentValues.put("mime_type", "video/mp4");
                    _reactContext.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);
                    this.addToMediaStore(this.mVideoFile.getAbsolutePath());
                    writableNativeMap.putString("path", Uri.fromFile((File)this.mVideoFile).toString());
                    this.mRecordingPromise.resolve((Object)writableNativeMap);
                    break block15;
                }
                writableNativeMap.putString("path", Uri.fromFile((File)this.mVideoFile).toString());
                this.mRecordingPromise.resolve((Object)writableNativeMap);
                break block15;
            }
            writableNativeMap.putString("data", new String(RCTCameraModule.convertFileToByteArray(this.mVideoFile), 2));
            this.mRecordingPromise.resolve((Object)writableNativeMap);
            file.delete();
        }
        this.mRecordingPromise = null;
    }

    private void resolveImage(File file, int n2, int n3, Promise promise, boolean bl) {
        WritableNativeMap writableNativeMap = new WritableNativeMap();
        writableNativeMap.putString("path", Uri.fromFile((File)file).toString());
        writableNativeMap.putInt("width", n2);
        writableNativeMap.putInt("height", n3);
        if (bl) {
            ReactApplicationContext reactApplicationContext = _reactContext;
            String[] arrstring = new String[]{file.getAbsolutePath()};
            MediaScannerConnection.scanFile((Context)reactApplicationContext, (String[])arrstring, null, (MediaScannerConnection.OnScanCompletedListener)new e(this, (WritableMap)writableNativeMap, promise));
            return;
        }
        promise.resolve((Object)writableNativeMap);
    }

    @ReactMethod
    public void capture(ReadableMap readableMap, Promise promise) {
        if (t1.l.a.a.h() == null) {
            promise.reject("Camera is not ready yet.");
            return;
        }
        int n2 = readableMap.hasKey("orientation") ? readableMap.getInt("orientation") : t1.l.a.a.h().i();
        if (n2 == Integer.MAX_VALUE) {
            this._sensorOrientationChecker.d();
            this._sensorOrientationChecker.e((f)new b(this, readableMap, promise));
            return;
        }
        this.captureWithOrientation(readableMap, promise, n2);
    }

    public Map<String, Object> getConstants() {
        return Collections.unmodifiableMap((Map)new a(this));
    }

    public String getName() {
        return TAG;
    }

    @ReactMethod
    public void hasFlash(ReadableMap readableMap, Promise promise) {
        Camera camera = t1.l.a.a.h().a(readableMap.getInt("type"));
        if (camera == null) {
            promise.reject("No camera found.");
            return;
        }
        List list = camera.getParameters().getSupportedFlashModes();
        boolean bl = list != null && !list.isEmpty();
        promise.resolve((Object)bl);
    }

    public void onError(MediaRecorder mediaRecorder, int n2, int n3) {
        if (this.mRecordingPromise != null) {
            this.releaseMediaRecorder();
        }
    }

    public void onHostDestroy() {
    }

    public void onHostPause() {
        if (this.mRecordingPromise != null) {
            this.releaseMediaRecorder();
        }
    }

    public void onHostResume() {
        this.mSafeToCapture = Boolean.TRUE;
    }

    public void onInfo(MediaRecorder mediaRecorder, int n2, int n3) {
        if ((n2 == 800 || n2 == 801) && this.mRecordingPromise != null) {
            this.releaseMediaRecorder();
        }
    }

    @ReactMethod
    public void setZoom(ReadableMap readableMap, int n2) {
        t1.l.a.a a2 = t1.l.a.a.h();
        if (a2 == null) {
            return;
        }
        Camera camera = a2.a(readableMap.getInt("type"));
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        int n3 = parameters.getMaxZoom();
        if (parameters.isZoomSupported() && n2 >= 0 && n2 < n3) {
            parameters.setZoom(n2);
            try {
                camera.setParameters(parameters);
                return;
            }
            catch (RuntimeException runtimeException) {
                Log.e((String)TAG, (String)"setParameters failed", (Throwable)runtimeException);
            }
        }
    }

    @ReactMethod
    public void stopCapture(Promise promise) {
        if (this.mRecordingPromise != null) {
            this.releaseMediaRecorder();
            promise.resolve((Object)"Finished recording.");
            return;
        }
        promise.resolve((Object)"Not recording.");
    }
}

