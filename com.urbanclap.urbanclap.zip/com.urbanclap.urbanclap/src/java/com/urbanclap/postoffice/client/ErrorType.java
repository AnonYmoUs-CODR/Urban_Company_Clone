/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postoffice.client;

import i2.a0.d.g;
import i2.a0.d.l;

public final class ErrorType
extends Enum<ErrorType> {
    private static final /* synthetic */ ErrorType[] $VALUES;
    public static final a Companion;
    public static final /* enum */ ErrorType SLOT_EXPIRY_ERROR_TYPE;
    private final String type;

    public static {
        ErrorType errorType;
        ErrorType[] arrerrorType = new ErrorType[1];
        SLOT_EXPIRY_ERROR_TYPE = errorType = new ErrorType("slot_expiry_error");
        arrerrorType[0] = errorType;
        $VALUES = arrerrorType;
        Companion = new a(null);
    }

    private ErrorType(String string2) {
        this.type = string2;
    }

    public static ErrorType valueOf(String string) {
        return (ErrorType)Enum.valueOf(ErrorType.class, (String)string);
    }

    public static ErrorType[] values() {
        return (ErrorType[])$VALUES.clone();
    }

    public final String getType() {
        return this.type;
    }

    public static final class a {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public final ErrorType a(String string) {
            l.g((Object)string, (String)"type");
            for (ErrorType errorType : ErrorType.values()) {
                if (!l.c((Object)errorType.getType(), (Object)string)) continue;
                return errorType;
            }
            return null;
        }
    }

}

