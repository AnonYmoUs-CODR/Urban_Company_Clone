/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postoffice.client;

public final class TypeOfRequest
extends Enum<TypeOfRequest> {
    private static final /* synthetic */ TypeOfRequest[] $VALUES;
    public static final /* enum */ TypeOfRequest ASYNCHRONOUS;
    public static final /* enum */ TypeOfRequest MULTI_PART;
    public static final /* enum */ TypeOfRequest SYNCHRONOUS;

    public static {
        TypeOfRequest typeOfRequest;
        TypeOfRequest typeOfRequest2;
        TypeOfRequest typeOfRequest3;
        TypeOfRequest[] arrtypeOfRequest = new TypeOfRequest[3];
        SYNCHRONOUS = typeOfRequest2 = new TypeOfRequest();
        arrtypeOfRequest[0] = typeOfRequest2;
        ASYNCHRONOUS = typeOfRequest = new TypeOfRequest();
        arrtypeOfRequest[1] = typeOfRequest;
        MULTI_PART = typeOfRequest3 = new TypeOfRequest();
        arrtypeOfRequest[2] = typeOfRequest3;
        $VALUES = arrtypeOfRequest;
    }

    public static TypeOfRequest valueOf(String string) {
        return (TypeOfRequest)Enum.valueOf(TypeOfRequest.class, (String)string);
    }

    public static TypeOfRequest[] values() {
        return (TypeOfRequest[])$VALUES.clone();
    }
}

