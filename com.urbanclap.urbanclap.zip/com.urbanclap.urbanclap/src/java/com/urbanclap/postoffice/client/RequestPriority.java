/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postoffice.client;

public final class RequestPriority
extends Enum<RequestPriority> {
    private static final /* synthetic */ RequestPriority[] $VALUES;
    public static final /* enum */ RequestPriority HIGH;
    public static final /* enum */ RequestPriority IMMEDIATE;
    public static final /* enum */ RequestPriority LOW;
    public static final /* enum */ RequestPriority NORMAL;

    public static {
        RequestPriority requestPriority;
        RequestPriority requestPriority2;
        RequestPriority requestPriority3;
        RequestPriority requestPriority4;
        RequestPriority[] arrrequestPriority = new RequestPriority[4];
        LOW = requestPriority3 = new RequestPriority();
        arrrequestPriority[0] = requestPriority3;
        NORMAL = requestPriority4 = new RequestPriority();
        arrrequestPriority[1] = requestPriority4;
        HIGH = requestPriority2 = new RequestPriority();
        arrrequestPriority[2] = requestPriority2;
        IMMEDIATE = requestPriority = new RequestPriority();
        arrrequestPriority[3] = requestPriority;
        $VALUES = arrrequestPriority;
    }

    public static RequestPriority valueOf(String string) {
        return (RequestPriority)Enum.valueOf(RequestPriority.class, (String)string);
    }

    public static RequestPriority[] values() {
        return (RequestPriority[])$VALUES.clone();
    }
}

