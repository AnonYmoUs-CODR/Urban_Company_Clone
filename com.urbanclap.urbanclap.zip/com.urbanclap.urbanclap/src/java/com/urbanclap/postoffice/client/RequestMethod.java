/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postoffice.client;

public final class RequestMethod
extends Enum<RequestMethod> {
    private static final /* synthetic */ RequestMethod[] $VALUES;
    public static final /* enum */ RequestMethod GET;
    public static final /* enum */ RequestMethod POST;
    public static final /* enum */ RequestMethod PUT;

    public static {
        RequestMethod requestMethod;
        RequestMethod requestMethod2;
        RequestMethod requestMethod3;
        RequestMethod[] arrrequestMethod = new RequestMethod[3];
        GET = requestMethod3 = new RequestMethod();
        arrrequestMethod[0] = requestMethod3;
        PUT = requestMethod2 = new RequestMethod();
        arrrequestMethod[1] = requestMethod2;
        POST = requestMethod = new RequestMethod();
        arrrequestMethod[2] = requestMethod;
        $VALUES = arrrequestMethod;
    }

    public static RequestMethod valueOf(String string) {
        return (RequestMethod)Enum.valueOf(RequestMethod.class, (String)string);
    }

    public static RequestMethod[] values() {
        return (RequestMethod[])$VALUES.clone();
    }
}

