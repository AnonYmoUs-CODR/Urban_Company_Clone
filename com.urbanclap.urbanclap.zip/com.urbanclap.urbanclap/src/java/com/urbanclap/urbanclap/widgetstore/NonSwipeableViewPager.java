/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  androidx.viewpager.widget.ViewPager
 *  com.urbanclap.urbanclap.widgetstore.NonSwipeableViewPager$a
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.viewpager.widget.ViewPager;
import com.urbanclap.urbanclap.widgetstore.NonSwipeableViewPager;
import java.lang.reflect.Field;

/*
 * Exception performing whole class analysis.
 */
public class NonSwipeableViewPager
extends ViewPager {
    public NonSwipeableViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a();
    }

    public final void a() {
        try {
            Field field = ViewPager.class.getDeclaredField("mScroller");
            field.setAccessible(true);
            field.set((Object)this, (Object)new /* Unavailable Anonymous Inner Class!! */);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return false;
    }
}

