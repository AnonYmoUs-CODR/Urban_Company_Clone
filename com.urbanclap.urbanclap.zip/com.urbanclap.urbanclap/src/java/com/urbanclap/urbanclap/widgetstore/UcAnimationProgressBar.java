/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.view.View
 *  android.view.Window
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.core.content.ContextCompat
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.urbanclap.urbanclap.widgetstore.UcAnimationImageView
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  t1.r.k.p.b0
 *  t1.r.k.p.d0
 *  t1.r.k.p.v
 *  t1.r.k.p.z
 */
package com.urbanclap.urbanclap.widgetstore;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import com.urbanclap.urbanclap.widgetstore.UcAnimationImageView;
import i2.a0.d.l;
import java.util.Objects;
import t1.r.k.p.b0;
import t1.r.k.p.d0;
import t1.r.k.p.v;
import t1.r.k.p.z;

public final class UcAnimationProgressBar
implements LifecycleObserver {
    public Dialog a;
    public UcAnimationImageView b;
    public Boolean c;
    public final LifecycleOwner d;

    public UcAnimationProgressBar(LifecycleOwner lifecycleOwner) {
        l.g((Object)lifecycleOwner, (String)"lifecycleOwner");
        this.d = lifecycleOwner;
        this.c = Boolean.FALSE;
        lifecycleOwner.getLifecycle().addObserver((LifecycleObserver)this);
    }

    public static /* synthetic */ void f(UcAnimationProgressBar ucAnimationProgressBar, Activity activity, boolean bl, Integer n2, int n3, Object object) {
        if ((n3 & 4) != 0) {
            n2 = null;
        }
        ucAnimationProgressBar.e(activity, bl, n2);
    }

    public final void b() {
        if (this.a != null) {
            Dialog dialog;
            UcAnimationImageView ucAnimationImageView = this.b;
            if (ucAnimationImageView != null) {
                ucAnimationImageView.d();
            }
            if ((dialog = this.a) != null) {
                dialog.dismiss();
            }
            this.a = null;
            this.b = null;
            this.c = Boolean.FALSE;
        }
        this.d.getLifecycle().removeObserver((LifecycleObserver)this);
    }

    public final void c(Context context) {
        if (this.a != null && l.c((Object)this.c, (Object)Boolean.TRUE) && context != null) {
            Dialog dialog;
            UcAnimationImageView ucAnimationImageView = this.b;
            if (ucAnimationImageView != null) {
                ucAnimationImageView.d();
            }
            if ((dialog = this.a) != null) {
                dialog.dismiss();
            }
            this.a = null;
            this.b = null;
            this.c = Boolean.FALSE;
        }
    }

    public final void d(Activity activity, boolean bl) {
        UcAnimationProgressBar.f(this, activity, bl, null, 4, null);
    }

    public final void e(Activity activity, boolean bl, Integer n2) {
        l.g((Object)activity, (String)"context");
        if (this.a == null && l.c((Object)this.c, (Object)Boolean.FALSE)) {
            Dialog dialog;
            Dialog dialog2;
            UcAnimationImageView ucAnimationImageView;
            Dialog dialog3;
            Dialog dialog4;
            Dialog dialog5;
            Window window;
            Dialog dialog6;
            Window window2;
            Dialog dialog7;
            Dialog dialog8;
            this.a = dialog7 = new Dialog((Context)activity, d0.b);
            if (dialog7 != null) {
                dialog7.requestWindowFeature(1);
            }
            if ((dialog4 = this.a) != null && (window = dialog4.getWindow()) != null) {
                window.setBackgroundDrawableResource(v.s);
            }
            if ((dialog6 = this.a) != null && (window2 = dialog6.getWindow()) != null) {
                window2.clearFlags(1024);
            }
            if ((dialog = this.a) != null) {
                dialog.setContentView(b0.p);
            }
            UcAnimationImageView ucAnimationImageView2 = (dialog8 = this.a) != null ? (UcAnimationImageView)dialog8.findViewById(z.B0) : null;
            Objects.requireNonNull((Object)ucAnimationImageView2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.widgetstore.UcAnimationImageView");
            this.b = ucAnimationImageView2;
            if (ucAnimationImageView2 != null) {
                ucAnimationImageView2.setVisibility(0);
            }
            if ((ucAnimationImageView = this.b) != null) {
                ucAnimationImageView.f();
            }
            if (n2 != null) {
                ConstraintLayout constraintLayout;
                int n3 = n2;
                Dialog dialog9 = this.a;
                if (dialog9 != null && (constraintLayout = (ConstraintLayout)dialog9.findViewById(z.n)) != null) {
                    constraintLayout.setBackgroundColor(ContextCompat.getColor((Context)activity, (int)n3));
                }
            }
            if ((dialog5 = this.a) != null) {
                dialog5.setCancelable(bl);
            }
            if ((dialog3 = this.a) != null) {
                dialog3.setCanceledOnTouchOutside(bl);
            }
            if ((dialog2 = this.a) != null) {
                dialog2.show();
            }
            this.c = Boolean.TRUE;
        }
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public final void onDestroy() {
        this.b();
    }
}

