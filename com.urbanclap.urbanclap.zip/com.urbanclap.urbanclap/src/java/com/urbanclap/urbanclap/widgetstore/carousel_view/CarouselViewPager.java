/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.animation.Interpolator
 *  androidx.viewpager.widget.ViewPager
 *  com.urbanclap.urbanclap.widgetstore.carousel_view.CarouselViewPager$a
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  t1.r.k.p.u0.a
 *  t1.r.k.p.u0.c
 */
package com.urbanclap.urbanclap.widgetstore.carousel_view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.animation.Interpolator;
import androidx.viewpager.widget.ViewPager;
import com.urbanclap.urbanclap.widgetstore.carousel_view.CarouselViewPager;
import java.lang.reflect.Field;
import t1.r.k.p.u0.c;

public class CarouselViewPager
extends ViewPager {
    public c a;
    public float b = 0.0f;
    public float c = 0.0f;
    public float d = 5.0f;
    public t1.r.k.p.u0.a e = null;

    public CarouselViewPager(Context context) {
        super(context);
        this.a();
    }

    public CarouselViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a();
    }

    public final void a() {
        try {
            t1.r.k.p.u0.a a2;
            Field field = ViewPager.class.getDeclaredField("mScroller");
            field.setAccessible(true);
            this.e = a2 = new t1.r.k.p.u0.a(this.getContext(), (Interpolator)new a(this));
            field.set((Object)this, (Object)a2);
        }
        catch (Exception exception) {}
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int n2 = motionEvent.getAction();
        if (n2 != 0) {
            if (n2 == 1) {
                float f2;
                this.c = f2 = motionEvent.getX();
                if (Math.abs((float)(this.b - f2)) < this.d) {
                    c c2 = this.a;
                    if (c2 != null) {
                        c2.a(this.getCurrentItem());
                    }
                    return true;
                }
                this.b = 0.0f;
                this.c = 0.0f;
            }
        } else {
            this.b = motionEvent.getX();
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setImageClickListener(c c2) {
        this.a = c2;
    }

    public void setTransitionVelocity(int n2) {
        this.e.a(n2);
    }
}

