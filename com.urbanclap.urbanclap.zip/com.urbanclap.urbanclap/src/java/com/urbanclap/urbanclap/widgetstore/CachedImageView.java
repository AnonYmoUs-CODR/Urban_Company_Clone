/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.LinearGradient
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.Drawable
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.appcompat.widget.AppCompatImageView
 *  androidx.core.content.ContextCompat
 *  com.urbanclap.urbanclap.widgetstore.CachedImageView$a
 *  com.urbanclap.utilities.PhotoUtils
 *  com.urbanclap.utilities.PhotoUtils$DecodeFormat
 *  com.urbanclap.utilities.PhotoUtils$DiskStrategy
 *  com.urbanclap.utilities.PhotoUtils$PictureSize
 *  com.urbanclap.utilities.PhotoUtils$Transformation
 *  com.urbanclap.utilities.PhotoUtils$b
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.k.p.e0
 *  t1.r.k.p.n
 *  t1.r.l.i.a.a
 *  t1.r.l.i.a.b
 *  t1.r.l.i.a.c
 */
package com.urbanclap.urbanclap.widgetstore;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import com.urbanclap.urbanclap.widgetstore.CachedImageView;
import com.urbanclap.utilities.PhotoUtils;
import java.util.ArrayList;
import java.util.List;
import t1.r.k.p.e0;
import t1.r.k.p.n;
import t1.r.l.i.a.b;
import t1.r.l.i.a.c;

public class CachedImageView
extends AppCompatImageView
implements n {
    public static final ImageView.ScaleType[] A;
    public t1.r.l.i.a.a a = null;
    public PhotoUtils.Transformation b;
    public int c;
    public int d;
    public int e;
    public float f;
    public float g;
    public int h;
    public String i;
    public boolean j;
    public int k;
    public Drawable s;
    public int t;
    public int u;
    public int v;
    public Paint w;
    public LinearGradient x;
    public RectF y;
    public ImageView.ScaleType z = null;

    public static {
        ImageView.ScaleType[] arrscaleType = new ImageView.ScaleType[]{ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE};
        A = arrscaleType;
    }

    public CachedImageView(Context context) {
        super(context);
        this.c(null);
    }

    public CachedImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c(attributeSet);
    }

    public static boolean d(Context context) {
        if (context == null) {
            return false;
        }
        if (context instanceof Activity) {
            Activity activity = (Activity)context;
            boolean bl = activity.isDestroyed();
            boolean bl2 = false;
            if (!bl) {
                boolean bl3 = activity.isFinishing();
                bl2 = false;
                if (!bl3) {
                    bl2 = true;
                }
            }
            return bl2;
        }
        return true;
    }

    public void a(@NonNull String string, @Nullable PhotoUtils.b b2) {
        this.i = null;
        if (this.isInEditMode()) {
            this.setBackgroundColor(-16776961);
            return;
        }
        if (!TextUtils.equals((CharSequence)string, (CharSequence)this.i) && !TextUtils.isEmpty((CharSequence)string)) {
            this.i = string;
            if (CachedImageView.d(this.getContext())) {
                this.e(b2);
            }
            return;
        }
        this.g();
    }

    public final void c(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().getTheme().obtainStyledAttributes(attributeSet, e0.k, 0, 0);
        int n2 = typedArray.getInt(e0.p, 0);
        int n3 = typedArray.getInt(e0.v, 0);
        int n4 = typedArray.getInt(e0.o, 0);
        float f2 = typedArray.getDimension(e0.n, 0.0f);
        float f3 = typedArray.getDimension(e0.m, 0.0f);
        int n5 = typedArray.getResourceId(e0.t, -1);
        boolean bl = typedArray.getBoolean(e0.w, true);
        int n6 = typedArray.getResourceId(e0.l, -1);
        int n7 = typedArray.getResourceId(e0.u, -1);
        int n8 = typedArray.getColor(e0.s, 0);
        int n9 = typedArray.getColor(e0.r, 0);
        int n10 = typedArray.getInt(e0.q, -1);
        if (n10 != -1) {
            this.z = A[n10];
        }
        typedArray.recycle();
        this.w = new Paint();
        this.setCornerMargin(f3);
        this.setEffect(n2);
        this.setSquare(n3);
        this.setDecodeFormat(n4);
        this.setCornerRadius(f2);
        this.setPlaceHolder(n5);
        this.setThumbnail(bl);
        this.setAnimateId(n6);
        this.setImageSource(n7);
        this.f(n8, n9);
    }

    public final void e(@Nullable PhotoUtils.b b2) {
        ArrayList arrayList = new ArrayList();
        t1.r.l.i.a.a a2 = this.a;
        if (a2 != null) {
            arrayList.add((Object)a2);
        }
        String string = this.i;
        PhotoUtils.DecodeFormat decodeFormat = this.e == 1 ? PhotoUtils.DecodeFormat.RGB_565 : PhotoUtils.DecodeFormat.ARGB_8888;
        PhotoUtils.DecodeFormat decodeFormat2 = decodeFormat;
        PhotoUtils.PictureSize pictureSize = this.j ? PhotoUtils.PictureSize.THUMBNAIL : PhotoUtils.PictureSize.FULL;
        PhotoUtils.PictureSize pictureSize2 = pictureSize;
        Drawable drawable = -1 != this.h ? ContextCompat.getDrawable((Context)this.getContext(), (int)this.h) : this.s;
        Drawable drawable2 = drawable;
        int n2 = this.k;
        Integer n3 = -1 != n2 ? Integer.valueOf((int)n2) : null;
        PhotoUtils.f((ImageView)this, (String)string, (PhotoUtils.DecodeFormat)decodeFormat2, (PhotoUtils.PictureSize)pictureSize2, (Drawable)drawable2, (Integer)n3, (PhotoUtils.Transformation)this.b, (List)arrayList, (PhotoUtils.DiskStrategy)PhotoUtils.DiskStrategy.ALL, (PhotoUtils.b)b2);
    }

    public void f(int n2, int n3) {
        if (this.isInEditMode()) {
            return;
        }
        if (this.u != n2 || this.v != n3) {
            this.u = n2;
            this.v = n3;
        }
    }

    public final void g() {
        Drawable drawable = this.s;
        if (drawable != null) {
            this.setImageDrawable(drawable);
            return;
        }
        int n2 = this.h;
        if (-1 != n2) {
            this.setImageResource(n2);
        }
    }

    public final void h() {
        if (this.isInEditMode()) {
            return;
        }
        int n2 = this.c;
        if (n2 != 1) {
            if (n2 != 2) {
                this.a = null;
                return;
            }
            this.a = new c(this.f, this.g);
            return;
        }
        this.a = new b();
    }

    public void onDraw(Canvas canvas) {
        LinearGradient linearGradient;
        ImageView.super.onDraw(canvas);
        if (this.x == null && (this.u != 0 || this.v != 0)) {
            LinearGradient linearGradient2;
            this.x = linearGradient2 = new LinearGradient(0.0f, (float)this.getHeight(), 0.0f, 0.0f, this.u, this.v, Shader.TileMode.CLAMP);
            this.y = new RectF(0.0f, 0.0f, (float)this.getWidth(), (float)this.getHeight());
        }
        if ((linearGradient = this.x) != null) {
            this.w.setShader((Shader)linearGradient);
            RectF rectF = this.y;
            float f2 = this.f;
            canvas.drawRoundRect(rectF, f2, f2, this.w);
        }
    }

    public void onMeasure(int n2, int n3) {
        int n4 = this.d;
        if (n4 == 1) {
            n3 = n2;
        } else if (n4 == 2) {
            n2 = n3;
        }
        ImageView.super.onMeasure(n2, n3);
    }

    public void setAnimateId(int n2) {
        this.k = n2;
    }

    public void setCornerMargin(float f2) {
        this.g = f2;
        this.h();
    }

    public void setCornerRadius(float f2) {
        this.f = f2;
        this.h();
    }

    public void setDecodeFormat(int n2) {
        this.e = n2;
    }

    public void setEffect(int n2) {
        if (this.c == n2) {
            return;
        }
        this.c = n2;
        this.h();
    }

    public void setImageSource(int n2) {
        if (this.t != n2) {
            if (-1 == n2) {
                return;
            }
            this.t = n2;
            if (this.isInEditMode()) {
                this.setImageResource(n2);
                return;
            }
            this.e(null);
        }
    }

    public void setPlaceHolder(int n2) {
        this.h = n2;
        try {
            this.setImageResource(n2);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void setPlaceHolderDrawable(Drawable drawable) {
        this.s = drawable;
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        int n2;
        ImageView.super.setScaleType(scaleType);
        if (this.isInEditMode()) {
            return;
        }
        ImageView.ScaleType scaleType2 = this.z;
        if (scaleType2 != null) {
            scaleType = scaleType2;
        }
        if ((n2 = a.a[scaleType.ordinal()]) != 1) {
            if (n2 != 2) {
                this.b = null;
                return;
            }
            this.b = PhotoUtils.Transformation.FIT_CENTER;
            return;
        }
        this.b = PhotoUtils.Transformation.CENTER_CROP;
    }

    public void setSquare(int n2) {
        this.d = n2;
    }

    public void setThumbnail(boolean bl) {
        this.j = bl;
    }

    public void setUri(@NonNull String string) {
        this.a(string, null);
    }
}

