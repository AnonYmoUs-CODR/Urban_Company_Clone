/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.d
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Join
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.Path$FillType
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.Typeface
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnTouchListener
 *  androidx.appcompat.widget.AppCompatRatingBar
 *  androidx.core.content.ContextCompat
 *  com.urbanclap.urbanclap.widgetstore.UcRatingBar$a
 *  com.urbanclap.urbanclap.widgetstore.UcRatingBar$b
 *  com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants
 *  java.lang.Deprecated
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.String
 *  t1.r.k.e.a
 *  t1.r.k.p.e0
 */
package com.urbanclap.urbanclap.widgetstore;

import a2.d;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.core.content.ContextCompat;
import com.urbanclap.urbanclap.widgetstore.UcRatingBar;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants;
import t1.r.k.p.e0;

public class UcRatingBar
extends AppCompatRatingBar {
    public float A;
    public boolean B;
    public boolean C;
    public int D;
    public boolean E;
    public int F;
    public int G;
    public boolean H;
    public boolean I;
    public String J;
    public b K;
    public final Paint a = new Paint();
    public final Paint b = new Paint();
    public final Paint c = new Paint(1);
    public final RectF d = new RectF();
    public final Matrix e = new Matrix();
    public final float f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    public int s;
    public int t;
    public Path u;
    public Path v;
    public float w;
    public float x;
    public Bitmap y;
    public int z;

    public UcRatingBar(Context context, AttributeSet attributeSet) {
        int n2;
        super(context, attributeSet);
        this.f = this.getResources().getDisplayMetrics().density;
        this.g = Color.rgb((int)246, (int)135, (int)15);
        this.h = n2 = d.a((String)"#e2e2e2");
        this.i = n2;
        this.j = n2;
        this.k = 5;
        this.s = 0;
        this.u = new Path();
        this.w = 2.6f;
        this.B = false;
        this.C = false;
        this.D = 0;
        this.E = false;
        this.F = 0;
        this.G = 0;
        this.H = false;
        this.I = true;
        this.J = "";
        this.K = null;
        this.e(context, attributeSet);
        this.f();
    }

    public static int d(int n2) {
        return (int)((float)n2 * Resources.getSystem().getDisplayMetrics().density);
    }

    public final Bitmap a(Bitmap bitmap, Bitmap bitmap2) {
        this.y = Bitmap.createBitmap((int)(bitmap.getWidth() + bitmap2.getWidth()), (int)bitmap.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(this.y);
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
        canvas.drawBitmap(bitmap2, (float)bitmap.getWidth(), 0.0f, null);
        return this.y;
    }

    public final Path b(float f2, int n2) {
        if (n2 == 0) {
            this.u.addOval(new RectF(0.0f, 0.0f, f2, f2), Path.Direction.CW);
            this.u.close();
            return this.u;
        }
        if (n2 == 4) {
            float f3 = this.A;
            return this.g(f3, f3);
        }
        float f4 = f2 / 2.0f;
        float f5 = f4 / this.w;
        float f6 = (float)Math.toRadians((double)(360.0f / (float)n2));
        float f7 = f6 / 2.0f;
        this.u.setFillType(Path.FillType.EVEN_ODD);
        float f8 = 6.2831855f;
        this.u.moveTo(f4, 0.0f);
        double d2 = 0.0;
        while (d2 < (double)f8) {
            Path path = this.u;
            double d3 = f4;
            path.lineTo((float)(d3 - d3 * Math.sin((double)d2)), (float)(d3 - d3 * Math.cos((double)d2)));
            Path path2 = this.u;
            double d4 = f5;
            double d5 = d2 + (double)f7;
            double d6 = d4 * Math.sin((double)d5);
            double d7 = d2;
            path2.lineTo((float)(d3 - d6), (float)(d3 - d4 * Math.cos((double)d5)));
            d2 = d7 + (double)f6;
            f8 = 6.2831855f;
        }
        this.u.close();
        return this.u;
    }

    public final View.OnTouchListener c() {
        return new a(this);
    }

    public final void e(Context context, AttributeSet attributeSet) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attributeSet, e0.R1, 0, 0);
        try {
            this.B = typedArray.getBoolean(e0.d2, false);
            this.i = typedArray.getInteger(e0.U1, 0);
            this.j = typedArray.getInteger(e0.T1, 0);
            this.g = typedArray.getInteger(e0.V1, d.a((String)"#dc6711"));
            this.h = typedArray.getInteger(e0.S1, d.a((String)"#e2e2e2"));
            this.k = typedArray.getInteger(e0.Z1, 5);
            this.s = typedArray.getInteger(e0.Y1, 0);
            this.t = (int)typedArray.getDimension(e0.f2, -1.0f);
            this.z = UcRatingBar.d(typedArray.getInteger(e0.X1, 8));
            this.A = UcRatingBar.d(typedArray.getInteger(e0.b2, 0));
            this.C = typedArray.getBoolean(e0.e2, false);
            this.D = UcRatingBar.d(typedArray.getInteger(e0.a2, 0));
            this.E = typedArray.getBoolean(e0.c2, false);
            int n2 = e0.g2;
            this.F = UcRatingBar.d(typedArray.getInteger(n2, 0));
            this.G = UcRatingBar.d(typedArray.getInteger(n2, 0));
            this.H = typedArray.getBoolean(e0.W1, false);
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    public final void f() {
        this.a.setAntiAlias(true);
        this.b.setStrokeWidth((float)this.t);
        this.b.setStyle(Paint.Style.STROKE);
        this.b.setStrokeJoin(Paint.Join.ROUND);
        this.b.setAntiAlias(true);
        if (this.H) {
            this.setOnTouchListener(this.c());
        }
        Typeface typeface = t1.r.k.e.a.b((Integer)UCFontConstants.FONT_OS_REGULAR.getFont());
        this.c.setTypeface(typeface);
    }

    public final Path g(float f2, float f3) {
        float f4;
        float f5;
        float f6;
        Path path = new Path();
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f2 > (f6 = (f4 = this.x) / 2.0f)) {
            f2 = f6;
        }
        if (f3 > (f5 = f4 / 2.0f)) {
            f3 = f5;
        }
        float f7 = f4 - f2 * 2.0f;
        float f8 = f4 - 2.0f * f3;
        path.moveTo(0.0f, f3 + 0.0f);
        float f9 = -f3;
        float f10 = -f2;
        path.rQuadTo(0.0f, f9, f10, f9);
        path.rLineTo(-f7, 0.0f);
        path.rQuadTo(f10, 0.0f, f10, f3);
        path.rLineTo(0.0f, f8);
        path.rQuadTo(0.0f, f3, f2, f3);
        path.rLineTo(f7, 0.0f);
        path.rQuadTo(f2, 0.0f, f2, f9);
        path.rLineTo(0.0f, -f8);
        path.close();
        return path;
    }

    public final BitmapShader h(int n2, int n3) {
        int n4 = (int)(this.getRating() * (float)this.getWidth() / (float)this.getNumStars());
        if (n4 > 0 && this.getWidth() - n4 > 0) {
            Bitmap bitmap = Bitmap.createBitmap((int)n4, (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(n2);
            Bitmap bitmap2 = Bitmap.createBitmap((int)(this.getWidth() - n4), (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
            bitmap2.eraseColor(n3);
            this.y = this.a(bitmap, bitmap2);
        } else {
            Bitmap bitmap;
            this.y = bitmap = Bitmap.createBitmap((int)this.getWidth(), (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
            if (n4 <= 0) {
                n2 = n3;
            }
            bitmap.eraseColor(n2);
        }
        Bitmap bitmap = this.y;
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        return new BitmapShader(bitmap, tileMode, tileMode);
    }

    @SuppressLint(value={"WrongCall"})
    public void onDraw(Canvas canvas) {
        float f2;
        b b2 = this.K;
        if (b2 != null) {
            this.J = b2.y((int)Math.ceil((double)this.getRating()));
            this.g = this.K.v((int)this.getRating());
        }
        BitmapShader bitmapShader = this.h(this.g, this.h);
        this.a.setShader((Shader)bitmapShader);
        this.c.setColor(ContextCompat.getColor((Context)this.getContext(), (int)17170443));
        int n2 = this.D;
        if (n2 == 0) {
            this.c.setTextSize(3.0f * this.d.height() / 8.0f);
        } else {
            this.c.setTextSize((float)n2);
        }
        this.c.setFakeBoldText(true);
        this.u.rewind();
        Path path = this.v;
        if (path == null) {
            path = this.b(this.x, this.k);
        }
        this.u = path;
        if (this.s != 0) {
            path.computeBounds(this.d, true);
            float f3 = Math.max((float)this.d.height(), (float)this.d.width());
            Matrix matrix = this.e;
            float f4 = this.x;
            float f5 = f3 * 1.15f;
            matrix.setScale(f4 / f5, f4 / f5);
            this.e.preRotate((float)this.s);
            this.u.transform(this.e);
        }
        int n3 = 0;
        do {
            int n4 = this.getNumStars();
            f2 = 0.38f;
            if (n3 >= n4) break;
            if (this.B) {
                Paint paint = this.b;
                int n5 = (float)n3 < this.getRating() ? this.i : this.j;
                paint.setColor(n5);
            }
            this.u.computeBounds(this.d, true);
            Path path2 = this.u;
            float f6 = n3;
            path2.offset((0.5f + f6) * (float)this.getWidth() / (float)this.getNumStars() - this.d.centerX(), (float)(this.getHeight() / 2) - this.d.centerY());
            canvas.drawPath(this.u, this.a);
            if (this.C && this.getRating() == 0.0f) {
                b b3 = this.K;
                this.J = b3 != null ? b3.y(n3 + 1) : String.valueOf((float)this.getRating());
                float f7 = f6 * this.d.width() + (float)(1 + n3 * 2) * (((float)this.getWidth() - this.d.width() * (float)this.getNumStars()) / (float)(2 * this.getNumStars()));
                if (this.J.length() != 1) {
                    f2 = 0.24f;
                }
                float f8 = f7 + f2 * this.d.width();
                canvas.drawText(this.J, f8 + (float)this.F, (float)(this.getHeight() / 2) + this.d.height() / 8.0f + (float)this.G, this.c);
            }
            ++n3;
        } while (true);
        if (this.C && this.getRating() > 0.0f) {
            float f9 = (this.getRating() - 1.0f) * this.d.width() + (2.0f * this.getRating() - 1.0f) * (((float)this.getWidth() - this.d.width() * (float)this.getNumStars()) / (float)(2 * this.getNumStars()));
            if (this.J.length() != 1) {
                f2 = 0.24f;
            }
            float f10 = f9 + f2 * this.d.width();
            canvas.drawText(this.J, f10 + (float)this.F, (float)(this.getHeight() / 2) + this.d.height() / 8.0f + (float)this.G, this.c);
        }
        if (this.I) {
            this.I = false;
            this.onDraw(canvas);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onMeasure(int n2, int n3) {
        UcRatingBar ucRatingBar = this;
        synchronized (ucRatingBar) {
            float f2;
            int n4 = (int)(50.0f * this.f * (float)this.getNumStars());
            int n5 = (int)(32.0f * this.f);
            int n6 = View.MeasureSpec.getMode((int)n2);
            int n7 = View.MeasureSpec.getSize((int)n2);
            int n8 = View.MeasureSpec.getMode((int)n3);
            int n9 = View.MeasureSpec.getSize((int)n3);
            if (this.E) {
                if (n8 == 1073741824) {
                    n5 = n9;
                } else if (n8 == Integer.MIN_VALUE) {
                    n5 = Math.min((int)n5, (int)n9);
                }
                if (n6 != 1073741824) {
                    n7 = n6 == Integer.MIN_VALUE ? Math.min((int)n7, (int)(n5 * this.getNumStars() + (-1 + this.getNumStars()) * this.z)) : n5 * this.getNumStars();
                }
                n9 = n5;
            } else {
                if (n6 == 1073741824) {
                    n4 = n7;
                } else if (n6 == Integer.MIN_VALUE) {
                    n4 = Math.min((int)n4, (int)n7);
                }
                if (n8 != 1073741824) {
                    n9 = n8 == Integer.MIN_VALUE ? Math.min((int)n9, (int)(n4 / this.getNumStars())) : n4 / this.getNumStars();
                }
                n7 = n4;
            }
            this.x = f2 = (float)Math.min((int)n9, (int)(n7 / this.getNumStars()));
            if (this.t < 0) {
                this.t = (int)(f2 / 15.0f);
            }
            this.x = f2 - (float)this.t;
            this.setMeasuredDimension(n7, n9);
            return;
        }
    }

    public void setColorFillOff(int n2) {
        this.h = n2;
    }

    public void setColorFillOn(int n2) {
        this.g = n2;
    }

    @Deprecated
    public void setColorFillPressedOff(int n2) {
    }

    @Deprecated
    public void setColorFillPressedOn(int n2) {
    }

    public void setColorOutlineOff(int n2) {
        this.j = n2;
    }

    public void setColorOutlineOn(int n2) {
        this.i = n2;
    }

    @Deprecated
    public void setColorOutlinePressed(int n2) {
    }

    public void setCustomPath(Path path) {
        this.v = path;
    }

    public void setDisableSwipe(boolean bl) {
        this.H = bl;
        if (bl) {
            this.setOnTouchListener(this.c());
        }
    }

    public void setInitialText(String string) {
        this.J = string;
    }

    public void setInteriorAngleModifier(float f2) {
        this.w = f2;
    }

    public void setPadding(int n2) {
        this.z = n2;
    }

    public void setPolygonRotation(int n2) {
        this.s = n2;
    }

    public void setPolygonVertices(int n2) {
        this.k = n2;
    }

    public void setRadius(float f2) {
        this.A = UcRatingBar.d((int)f2);
    }

    public void setRatingBarUpdateListener(b b2) {
        this.K = b2;
    }

    public void setScaleToHeight(boolean bl) {
        this.E = bl;
    }

    public void setShowOutline(boolean bl) {
        this.B = bl;
    }

    public void setShowRatingText(boolean bl) {
        this.C = bl;
    }

    public void setStrokeWidth(int n2) {
        this.t = n2;
    }

    public void setTextSize(int n2) {
        this.D = UcRatingBar.d(n2);
    }

    public void setTextXOffset(int n2) {
        this.F = UcRatingBar.d(n2);
    }

    public void setTextYOffset(int n2) {
        this.G = UcRatingBar.d(n2);
    }
}

