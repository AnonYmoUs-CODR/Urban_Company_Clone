/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.CountDownTimer
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ProgressBar
 *  androidx.core.content.ContextCompat
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  com.urbanclap.urbanclap.widgetstore.carousel_view.BarPageIndicator$a
 *  com.urbanclap.urbanclap.widgetstore.carousel_view.BarPageIndicator$b
 *  i2.a0.d.l
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  t1.r.k.p.a0
 *  t1.r.k.p.e0
 *  t1.r.k.p.o0
 *  t1.r.k.p.o0$a
 *  t1.r.k.p.t
 *  t1.r.k.p.u0.d
 *  t1.r.k.p.v
 *  t1.r.k.p.w
 *  t1.r.k.p.x
 */
package com.urbanclap.urbanclap.widgetstore.carousel_view;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.CountDownTimer;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.urbanclap.urbanclap.widgetstore.carousel_view.BarPageIndicator;
import i2.a0.d.l;
import java.util.Objects;
import t1.r.k.p.a0;
import t1.r.k.p.e0;
import t1.r.k.p.o0;
import t1.r.k.p.t;
import t1.r.k.p.u0.d;
import t1.r.k.p.v;
import t1.r.k.p.w;
import t1.r.k.p.x;

public final class BarPageIndicator
extends LinearLayout
implements d {
    public final long a;
    public int b;
    public Paint c;
    public Paint d;
    public float e;
    public ViewPager f;
    public final int g;
    public CountDownTimer h;
    public ProgressBar i;
    public int j;
    public long k;
    public long s;
    public a t;
    public boolean u;

    public BarPageIndicator(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        this(context, attributeSet, t.c);
    }

    public BarPageIndicator(Context context, AttributeSet attributeSet, int n2) {
        l.g((Object)context, (String)"context");
        super(context, attributeSet, n2);
        this.a = 3500L;
        this.c = new Paint(1);
        this.d = new Paint(1);
        this.e = 2.0f;
        this.u = true;
        if (this.isInEditMode()) {
            return;
        }
        Resources resources = this.getResources();
        int n3 = ContextCompat.getColor((Context)context, (int)v.a);
        int n4 = ContextCompat.getColor((Context)context, (int)v.t);
        int n5 = resources.getInteger(a0.a);
        float f2 = resources.getDimension(w.a);
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, e0.F, n2, 0);
        this.b = typedArray.getInt(e0.G, n5);
        this.d.setStyle(Paint.Style.FILL);
        this.d.setColor(typedArray.getColor(e0.K, n3));
        this.c.setStyle(Paint.Style.FILL);
        this.c.setColor(typedArray.getColor(e0.J, n4));
        this.e = typedArray.getDimension(e0.L, f2);
    }

    public static final /* synthetic */ ProgressBar a(BarPageIndicator barPageIndicator) {
        return barPageIndicator.i;
    }

    public static final /* synthetic */ CountDownTimer b(BarPageIndicator barPageIndicator) {
        return barPageIndicator.h;
    }

    public static final /* synthetic */ long c(BarPageIndicator barPageIndicator) {
        return barPageIndicator.k;
    }

    public static final /* synthetic */ int d(BarPageIndicator barPageIndicator) {
        return barPageIndicator.j;
    }

    public static final /* synthetic */ long e(BarPageIndicator barPageIndicator) {
        return barPageIndicator.s;
    }

    public static final /* synthetic */ a f(BarPageIndicator barPageIndicator) {
        return barPageIndicator.t;
    }

    public static final /* synthetic */ ViewPager g(BarPageIndicator barPageIndicator) {
        return barPageIndicator.f;
    }

    public static final /* synthetic */ void h(BarPageIndicator barPageIndicator, long l2) {
        barPageIndicator.s = l2;
    }

    public void f0() {
        this.i();
    }

    public final boolean getCancelCalled() {
        return this.u;
    }

    public final int getFillColor() {
        return this.c.getColor();
    }

    public final int getMOrientation() {
        return this.b;
    }

    public final float getMRadius() {
        return this.e;
    }

    public final int getPageColor() {
        return this.d.getColor();
    }

    public final void i() {
        CountDownTimer countDownTimer = this.h;
        this.h = null;
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        this.u = true;
    }

    public final void j() {
        if (!this.u) {
            return;
        }
        this.u = false;
        a a2 = this.t;
        long l2 = a2 != null ? (long)a2.a(this.j) : this.a;
        this.k = l2;
        ProgressBar progressBar = this.i;
        if (progressBar != null) {
            progressBar.setMax((int)l2);
        }
        if ((int)this.s == 0) {
            this.s = this.k;
        }
        b b2 = new b(this, this.s, 10L);
        this.h = b2;
        if (b2 != null) {
            b2.start();
        }
    }

    public final void k() {
        PagerAdapter pagerAdapter;
        ViewPager viewPager = this.f;
        int n2 = viewPager != null && (pagerAdapter = viewPager.getAdapter()) != null ? pagerAdapter.getCount() : 0;
        this.setWeightSum((float)n2);
        if (n2 > 0) {
            for (int i2 = 0; i2 < n2; ++i2) {
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -1, 1.0f);
                if (i2 != n2 - 1) {
                    layoutParams.rightMargin = o0.a.b(8);
                }
                ProgressBar progressBar = new ProgressBar(this.getContext(), null, 16842872);
                progressBar.setProgressDrawable(ContextCompat.getDrawable((Context)this.getContext(), (int)x.b));
                if (Build.VERSION.SDK_INT >= 21) {
                    progressBar.setProgressBackgroundTintList(ColorStateList.valueOf((int)Color.parseColor((String)"#33ffffff")));
                }
                progressBar.setIndeterminate(false);
                progressBar.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                this.addView((View)progressBar);
            }
        }
        this.requestLayout();
        this.onPageSelected(0);
    }

    public final void l() {
        this.m();
        if (this.getChildAt(0) != null) {
            int n2 = this.getChildCount();
            for (int i2 = 0; i2 < n2; ++i2) {
                View view = this.getChildAt(i2);
                Objects.requireNonNull((Object)view, (String)"null cannot be cast to non-null type android.widget.ProgressBar");
                ((ProgressBar)view).setProgress(0);
            }
            this.onPageSelected(0);
        }
    }

    public final void m() {
        this.i();
        this.s = 0L;
    }

    public void onPageScrollStateChanged(int n2) {
    }

    public void onPageScrolled(int n2, float f2, int n3) {
    }

    public void onPageSelected(int n2) {
        ProgressBar progressBar;
        if (n2 == this.getChildCount()) {
            return;
        }
        this.m();
        View view = this.getChildAt(n2);
        Objects.requireNonNull((Object)view, (String)"null cannot be cast to non-null type android.widget.ProgressBar");
        this.i = progressBar = (ProgressBar)view;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        this.j = n2;
        if (n2 != 0) {
            int n3 = n2 - 1;
            View view2 = this.getChildAt(n3);
            Objects.requireNonNull((Object)view2, (String)"null cannot be cast to non-null type android.widget.ProgressBar");
            ProgressBar progressBar2 = (ProgressBar)view2;
            a a2 = this.t;
            int n4 = a2 != null ? a2.a(n3) : (int)this.a;
            progressBar2.setProgress(n4);
        }
        if (n2 != -1 + this.getChildCount()) {
            View view3 = this.getChildAt(n2 + 1);
            Objects.requireNonNull((Object)view3, (String)"null cannot be cast to non-null type android.widget.ProgressBar");
            ((ProgressBar)view3).setProgress(this.g);
        }
    }

    public void p1() {
        this.j();
    }

    public final void setCancelCalled(boolean bl) {
        this.u = bl;
    }

    public void setCurrentItem(int n2) {
    }

    public final void setFillColor(int n2) {
        this.c.setColor(n2);
    }

    public final void setListener(a a2) {
        l.g((Object)a2, (String)"listener");
        this.t = a2;
    }

    public final void setMOrientation(int n2) {
        this.b = n2;
    }

    public final void setMRadius(float f2) {
        this.e = f2;
    }

    public void setOnPageChangeListener(ViewPager.OnPageChangeListener onPageChangeListener) {
    }

    public final void setPageColor(int n2) {
        this.d.setColor(n2);
        this.invalidate();
    }

    public void setViewPager(ViewPager viewPager) {
        if (this.f == viewPager) {
            return;
        }
        PagerAdapter pagerAdapter = viewPager != null ? viewPager.getAdapter() : null;
        if (pagerAdapter != null) {
            this.f = viewPager;
            this.k();
            return;
        }
        throw new IllegalStateException("ViewPager does not have adapter instance.");
    }
}

