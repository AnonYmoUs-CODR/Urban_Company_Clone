/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$State
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.p.p
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.p.p;

public final class UcLinearLayoutManager
extends LinearLayoutManager {
    public final p a;

    public UcLinearLayoutManager(Context context, p p2, Integer n2) {
        l.g((Object)context, (String)"context");
        l.g((Object)p2, (String)"listener");
        l.e((Object)n2);
        super(context, n2.intValue(), false);
        this.a = p2;
    }

    public /* synthetic */ UcLinearLayoutManager(Context context, p p2, Integer n2, int n3, g g2) {
        if ((n3 & 4) != 0) {
            n2 = 1;
        }
        this(context, p2, n2);
    }

    public void onLayoutCompleted(RecyclerView.State state) {
        super.onLayoutCompleted(state);
        this.a.a();
    }
}

