/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.widget.ImageView
 *  androidx.appcompat.widget.AppCompatImageView
 *  androidx.vectordrawable.graphics.drawable.Animatable2Compat
 *  androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback
 *  androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.p.e0
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import com.urbanclap.urbanclap.widgetstore.UcAnimationImageView;
import i2.a0.d.l;
import t1.r.k.p.e0;

public final class UcAnimationImageView
extends AppCompatImageView {
    public int a;
    public AnimatedVectorDrawableCompat b;

    public UcAnimationImageView(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        l.g((Object)attributeSet, (String)"attrs");
        this(context, attributeSet, 0);
        this.e(attributeSet);
    }

    public UcAnimationImageView(Context context, AttributeSet attributeSet, int n2) {
        l.g((Object)context, (String)"context");
        l.g((Object)attributeSet, (String)"attrs");
        super(context, attributeSet, n2);
        this.a = -1;
    }

    public final void c() {
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat = this.b;
        if (animatedVectorDrawableCompat != null) {
            animatedVectorDrawableCompat.start();
        }
    }

    public final void d() {
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat = this.b;
        if (animatedVectorDrawableCompat != null) {
            animatedVectorDrawableCompat.stop();
        }
    }

    public final void e(AttributeSet attributeSet) {
        Context context = this.getContext();
        l.f((Object)context, (String)"context");
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attributeSet, e0.b1, 0, 0);
        try {
            this.setImageResource(typedArray.getResourceId(e0.c1, 0));
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    public final void f() {
        if (this.a != -1) {
            AnimatedVectorDrawableCompat animatedVectorDrawableCompat;
            this.b = animatedVectorDrawableCompat = AnimatedVectorDrawableCompat.create((Context)this.getContext(), (int)this.a);
            if (animatedVectorDrawableCompat != null) {
                animatedVectorDrawableCompat.registerAnimationCallback(new Animatable2Compat.AnimationCallback(this){
                    public final /* synthetic */ UcAnimationImageView a;
                    {
                        this.a = ucAnimationImageView;
                    }

                    public void onAnimationEnd(Drawable drawable) {
                        this.a.c();
                    }
                });
            }
            this.setImageDrawable((Drawable)this.b);
            this.c();
        }
    }

    public final int getResourceId() {
        return this.a;
    }

    public void onDetachedFromWindow() {
        this.d();
        AnimatedVectorDrawableCompat animatedVectorDrawableCompat = this.b;
        if (animatedVectorDrawableCompat != null) {
            animatedVectorDrawableCompat.clearAnimationCallbacks();
        }
        this.b = null;
        ImageView.super.onDetachedFromWindow();
    }

    public void setImageResource(int n2) {
        super.setImageResource(n2);
        this.a = n2;
    }
}

