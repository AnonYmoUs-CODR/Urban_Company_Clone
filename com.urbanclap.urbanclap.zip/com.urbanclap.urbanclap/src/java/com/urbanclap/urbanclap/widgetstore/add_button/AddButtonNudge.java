/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewPropertyAnimator
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.urbanclap.urbanclap.widgetstore.add_button.AddButtonNudge$a
 *  com.urbanclap.urbanclap.widgetstore.add_button.AddButtonNudge$b
 *  com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView
 *  java.lang.Deprecated
 *  t1.r.k.p.b0
 *  t1.r.k.p.e0
 *  t1.r.k.p.q0.a
 *  t1.r.k.p.q0.b
 *  t1.r.k.p.z
 */
package com.urbanclap.urbanclap.widgetstore.add_button;

import android.animation.Animator;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.urbanclap.urbanclap.widgetstore.add_button.AddButtonNudge;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView;
import t1.r.k.p.b0;
import t1.r.k.p.e0;
import t1.r.k.p.z;

@Deprecated
public class AddButtonNudge
extends t1.r.k.p.q0.a
implements View.OnClickListener {
    public View t;

    public AddButtonNudge(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a(context, attributeSet);
    }

    private void a(Context context, AttributeSet attributeSet) {
        View view;
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, e0.i);
        int n2 = typedArray.getResourceId(e0.j, b0.t);
        this.t = view = LayoutInflater.from((Context)this.getContext()).inflate(n2, null);
        view.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
        typedArray.recycle();
        this.addView(this.t);
    }

    public static /* synthetic */ View c(AddButtonNudge addButtonNudge) {
        return addButtonNudge.t;
    }

    public static /* synthetic */ void d(AddButtonNudge addButtonNudge) {
        super.b();
    }

    public static /* synthetic */ void e(AddButtonNudge addButtonNudge) {
        super.b();
    }

    public void b() {
        super.b();
        if (this.h > 0) {
            this.t.setVisibility(8);
            return;
        }
        this.t.setAlpha(1.0f);
        this.t.setOnClickListener((View.OnClickListener)this);
        this.t.setVisibility(0);
    }

    public final void f() {
        if (this.h > 0) {
            this.t.animate().alpha(0.0f).setDuration(200L).setListener((Animator.AnimatorListener)new a(this));
            return;
        }
        this.t.animate().alpha(1.0f).setDuration(200L).setListener((Animator.AnimatorListener)new b(this));
    }

    public void onClick(View view) {
        super.onClick(view);
        t1.r.k.p.q0.b b2 = this.i;
        if (b2 == null) {
            return;
        }
        if (view == this.t) {
            b2.a(true);
        }
    }

    public void onFinishInflate() {
        UCTextView uCTextView;
        super.onFinishInflate();
        this.t.setOnClickListener((View.OnClickListener)this);
        UCTextView uCTextView2 = (UCTextView)this.findViewById(z.k0);
        if (uCTextView2 != null) {
            uCTextView2.setTextColor(this.d);
            uCTextView2.setFont(this.g);
            uCTextView2.setTextSize(0, this.f);
        }
        if ((uCTextView = (UCTextView)this.findViewById(z.j0)) != null) {
            uCTextView.setTextColor(this.d);
            uCTextView2.setFont(this.g);
            uCTextView.setTextSize(0, 1.3f * this.f);
        }
        this.b();
    }

    public void setCallBackListener(t1.r.k.p.q0.b b2) {
        super.setCallBackListener(b2);
    }

    public void setCounter(int n2) {
        super.setCounter(n2);
        this.b();
    }

    public void setCounterAndAnimate(int n2) {
        super.setCounter(n2);
        this.f();
    }
}

