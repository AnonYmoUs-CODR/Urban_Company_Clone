/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  androidx.core.content.ContextCompat
 *  com.urbanclap.urbanclap.widgetstore.circle_loader.CircleLoadingView
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Objects
 *  t1.r.k.p.b0
 *  t1.r.k.p.e
 *  t1.r.k.p.v
 *  t1.r.k.p.z
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.core.content.ContextCompat;
import com.urbanclap.urbanclap.widgetstore.circle_loader.CircleLoadingView;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView;
import i2.a0.d.l;
import java.util.HashMap;
import java.util.Objects;
import t1.r.k.p.b0;
import t1.r.k.p.v;
import t1.r.k.p.z;

public final class CheckoutButtonView
extends RelativeLayout {
    public FrameLayout a;
    public FrameLayout b;
    public a c;
    public a d;
    public UCTextView e;
    public UCTextView f;
    public LinearLayout g;
    public UCTextView h;
    public UCTextView i;
    public LinearLayout j;
    public UCTextView k;
    public CircleLoadingView s;
    public String t;
    public HashMap u;

    public CheckoutButtonView(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        l.g((Object)attributeSet, (String)"attrs");
        super(context, attributeSet);
        this.g(context);
    }

    public View a(int n) {
        View view;
        if (this.u == null) {
            this.u = new HashMap();
        }
        if ((view = (View)this.u.get((Object)n)) == null) {
            view = this.findViewById(n);
            this.u.put((Object)n, (Object)view);
        }
        return view;
    }

    public final void d(View view, boolean bl) {
        l.g((Object)view, (String)"view");
        view.setEnabled(bl);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            int n = viewGroup.getChildCount();
            for (int i2 = 0; i2 < n; ++i2) {
                View view2 = viewGroup.getChildAt(i2);
                l.f((Object)view2, (String)"view.getChildAt(idx)");
                this.d(view2, bl);
            }
        }
    }

    public final void e() {
        this.setVisibility(8);
    }

    public final void f(View view) {
        l.g((Object)view, (String)"view");
        this.d(view, true);
        LinearLayout linearLayout = (LinearLayout)this.a(z.p);
        l.f((Object)linearLayout, (String)"continue_with_payment_button_container");
        linearLayout.setVisibility(0);
        LinearLayout linearLayout2 = (LinearLayout)this.a(z.q);
        l.f((Object)linearLayout2, (String)"continue_with_payment_button_container_loader");
        linearLayout2.setVisibility(8);
        LinearLayout linearLayout3 = (LinearLayout)this.a(z.h);
        l.f((Object)linearLayout3, (String)"bt_checkout_cta_spaced");
        linearLayout3.setVisibility(0);
        LinearLayout linearLayout4 = (LinearLayout)this.a(z.j);
        l.f((Object)linearLayout4, (String)"bt_checkout_cta_spaced_loader");
        linearLayout4.setVisibility(8);
        RelativeLayout relativeLayout = (RelativeLayout)this.a(z.d);
        l.f((Object)relativeLayout, (String)"bt_checkout_cta_center");
        relativeLayout.setVisibility(0);
        RelativeLayout relativeLayout2 = (RelativeLayout)this.a(z.f);
        l.f((Object)relativeLayout2, (String)"bt_checkout_cta_center_loader");
        relativeLayout2.setVisibility(8);
    }

    public final void g(Context context) {
        UCTextView uCTextView;
        LayoutInflater.from((Context)context).inflate(b0.u, (ViewGroup)this);
        this.a = (FrameLayout)this.findViewById(z.e);
        this.b = (FrameLayout)this.findViewById(z.i);
        View view = this.findViewById(z.g);
        l.f((Object)view, (String)"findViewById(R.id.bt_checkout_cta_center_text)");
        this.e = (UCTextView)view;
        View view2 = this.findViewById(z.k);
        l.f((Object)view2, (String)"findViewById(R.id.bt_checkout_cta_spaced_text)");
        this.f = (UCTextView)view2;
        this.g = (LinearLayout)this.findViewById(z.m);
        this.h = (UCTextView)this.findViewById(z.N);
        this.i = (UCTextView)this.findViewById(z.M);
        this.j = (LinearLayout)this.findViewById(z.p);
        this.k = (UCTextView)this.findViewById(z.o);
        this.s = (CircleLoadingView)this.findViewById(z.P);
        ((RelativeLayout)this.a(z.d)).setOnClickListener(new View.OnClickListener(){

            public final void onClick(View view) {
                a a2 = this.c;
                if (a2 != null) {
                    a2.x4();
                }
            }
        });
        ((LinearLayout)this.a(z.h)).setOnClickListener(new View.OnClickListener(){

            public final void onClick(View view) {
                a a2 = this.c;
                if (a2 != null) {
                    a2.x4();
                }
            }
        });
        LinearLayout linearLayout = this.j;
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener(){

                public final void onClick(View view) {
                    a a2 = this.d;
                    if (a2 != null) {
                        a2.x4();
                    }
                }
            });
        }
        if ((uCTextView = this.i) != null) {
            uCTextView.setOnClickListener(new View.OnClickListener(){

                public final void onClick(View view) {
                    a a2 = this.d;
                    if (a2 != null) {
                        a2.s();
                    }
                }
            });
        }
    }

    public final Drawable getCheckoutBackground() {
        RelativeLayout relativeLayout = (RelativeLayout)this.a(z.d);
        l.f((Object)relativeLayout, (String)"bt_checkout_cta_center");
        return relativeLayout.getBackground();
    }

    public final String getCheckoutButtonText() {
        return this.t;
    }

    public final void h(CheckoutButtonGravity checkoutButtonGravity, String string) {
        block31 : {
            block29 : {
                UCTextView uCTextView;
                FrameLayout frameLayout;
                block27 : {
                    block30 : {
                        UCTextView uCTextView2;
                        LinearLayout linearLayout;
                        block28 : {
                            LinearLayout linearLayout2;
                            FrameLayout frameLayout2;
                            this.t = string;
                            if (checkoutButtonGravity == null) {
                                return;
                            }
                            int n = t1.r.k.p.e.a[checkoutButtonGravity.ordinal()];
                            if (n == 1) break block27;
                            if (n == 2) break block28;
                            if (n != 3) {
                                return;
                            }
                            FrameLayout frameLayout3 = this.b;
                            if (frameLayout3 != null) {
                                frameLayout3.setVisibility(0);
                            }
                            if ((linearLayout2 = this.g) != null) {
                                linearLayout2.setVisibility(0);
                            }
                            if (!TextUtils.isEmpty((CharSequence)string)) {
                                CircleLoadingView circleLoadingView;
                                UCTextView uCTextView3;
                                UCTextView uCTextView4 = this.h;
                                if (uCTextView4 != null) {
                                    if (string == null) {
                                        string = "";
                                    }
                                    uCTextView4.setText((CharSequence)string);
                                }
                                if ((circleLoadingView = this.s) != null) {
                                    circleLoadingView.setVisibility(8);
                                }
                                if ((uCTextView3 = this.h) != null) {
                                    uCTextView3.setVisibility(0);
                                }
                            } else {
                                CircleLoadingView circleLoadingView;
                                UCTextView uCTextView5;
                                UCTextView uCTextView6 = this.h;
                                if (uCTextView6 != null) {
                                    if (string == null) {
                                        string = "";
                                    }
                                    uCTextView6.setText((CharSequence)string);
                                }
                                if ((circleLoadingView = this.s) != null) {
                                    circleLoadingView.setVisibility(0);
                                }
                                if ((uCTextView5 = this.h) != null) {
                                    uCTextView5.setVisibility(8);
                                }
                            }
                            if ((frameLayout2 = this.a) != null) {
                                frameLayout2.setVisibility(8);
                                return;
                            }
                            break block29;
                        }
                        FrameLayout frameLayout4 = this.b;
                        if (frameLayout4 != null) {
                            frameLayout4.setVisibility(0);
                        }
                        if ((uCTextView2 = this.f) == null) break block30;
                        if (string == null) {
                            string = "";
                        }
                        uCTextView2.setText((CharSequence)string);
                        FrameLayout frameLayout5 = this.a;
                        if (frameLayout5 != null) {
                            frameLayout5.setVisibility(8);
                        }
                        if ((linearLayout = this.g) != null) {
                            linearLayout.setVisibility(8);
                            return;
                        }
                        break block29;
                    }
                    l.v((String)"checkoutButtonSpacedText");
                    throw null;
                }
                FrameLayout frameLayout6 = this.a;
                if (frameLayout6 != null) {
                    frameLayout6.setVisibility(0);
                }
                if ((uCTextView = this.e) == null) break block31;
                if (string == null) {
                    string = "";
                }
                uCTextView.setText((CharSequence)string);
                LinearLayout linearLayout = this.g;
                if (linearLayout != null) {
                    linearLayout.setVisibility(8);
                }
                if ((frameLayout = this.b) != null) {
                    frameLayout.setVisibility(8);
                }
            }
            return;
        }
        l.v((String)"checkoutButtonCenterText");
        throw null;
    }

    public final void i() {
        this.setVisibility(0);
    }

    public final void j(View view) {
        l.g((Object)view, (String)"view");
        this.d(view, false);
        LinearLayout linearLayout = (LinearLayout)this.a(z.q);
        l.f((Object)linearLayout, (String)"continue_with_payment_button_container_loader");
        linearLayout.setVisibility(0);
        LinearLayout linearLayout2 = (LinearLayout)this.a(z.j);
        l.f((Object)linearLayout2, (String)"bt_checkout_cta_spaced_loader");
        linearLayout2.setVisibility(0);
        RelativeLayout relativeLayout = (RelativeLayout)this.a(z.f);
        l.f((Object)relativeLayout, (String)"bt_checkout_cta_center_loader");
        relativeLayout.setVisibility(0);
    }

    public final void k(boolean bl, String string) {
        Drawable drawable;
        UCTextView uCTextView;
        l.g((Object)string, (String)"ctaText");
        LinearLayout linearLayout = this.j;
        Drawable drawable2 = linearLayout != null && (drawable = linearLayout.getBackground()) != null ? drawable.mutate() : null;
        Objects.requireNonNull(drawable2, (String)"null cannot be cast to non-null type android.graphics.drawable.GradientDrawable");
        GradientDrawable gradientDrawable = (GradientDrawable)drawable2;
        if (bl) {
            gradientDrawable.setColor(ContextCompat.getColor((Context)this.getContext(), (int)v.m));
            LinearLayout linearLayout2 = this.j;
            if (linearLayout2 != null) {
                linearLayout2.setEnabled(true);
            }
        } else {
            gradientDrawable.setColor(ContextCompat.getColor((Context)this.getContext(), (int)v.j));
            LinearLayout linearLayout3 = this.j;
            if (linearLayout3 != null) {
                linearLayout3.setEnabled(false);
            }
        }
        if ((uCTextView = this.k) != null) {
            uCTextView.setText((CharSequence)string);
        }
    }

    public final void setCheckoutButtonViewClickListener(a a2) {
        this.c = a2;
    }

    public final void setSecondCheckoutButtonViewClickListener(a a2) {
        this.d = a2;
    }

    public static final class CheckoutButtonGravity
    extends Enum<CheckoutButtonGravity> {
        private static final /* synthetic */ CheckoutButtonGravity[] $VALUES;
        public static final /* enum */ CheckoutButtonGravity CENTER;
        public static final /* enum */ CheckoutButtonGravity COLUMN;
        public static final /* enum */ CheckoutButtonGravity SPACED;

        public static {
            CheckoutButtonGravity checkoutButtonGravity;
            CheckoutButtonGravity checkoutButtonGravity2;
            CheckoutButtonGravity checkoutButtonGravity3;
            CheckoutButtonGravity[] arrcheckoutButtonGravity = new CheckoutButtonGravity[3];
            CENTER = checkoutButtonGravity3 = new CheckoutButtonGravity();
            arrcheckoutButtonGravity[0] = checkoutButtonGravity3;
            SPACED = checkoutButtonGravity = new CheckoutButtonGravity();
            arrcheckoutButtonGravity[1] = checkoutButtonGravity;
            COLUMN = checkoutButtonGravity2 = new CheckoutButtonGravity();
            arrcheckoutButtonGravity[2] = checkoutButtonGravity2;
            $VALUES = arrcheckoutButtonGravity;
        }

        public static CheckoutButtonGravity valueOf(String string) {
            return (CheckoutButtonGravity)Enum.valueOf(CheckoutButtonGravity.class, (String)string);
        }

        public static CheckoutButtonGravity[] values() {
            return (CheckoutButtonGravity[])$VALUES.clone();
        }
    }

    public static interface a {
        public void s();

        public void x4();
    }

}

