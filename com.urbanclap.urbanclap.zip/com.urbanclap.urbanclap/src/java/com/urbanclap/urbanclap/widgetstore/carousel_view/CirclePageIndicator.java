/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.drawable.Drawable
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewConfiguration
 *  androidx.core.view.MotionEventCompat
 *  androidx.core.view.ViewConfigurationCompat
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  com.urbanclap.urbanclap.widgetstore.carousel_view.CirclePageIndicator$SavedState
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.String
 *  t1.r.k.p.a0
 *  t1.r.k.p.e0
 *  t1.r.k.p.t
 *  t1.r.k.p.u
 *  t1.r.k.p.u0.d
 *  t1.r.k.p.v
 *  t1.r.k.p.w
 */
package com.urbanclap.urbanclap.widgetstore.carousel_view;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewConfigurationCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.urbanclap.urbanclap.widgetstore.carousel_view.CirclePageIndicator;
import t1.r.k.p.a0;
import t1.r.k.p.e0;
import t1.r.k.p.t;
import t1.r.k.p.u;
import t1.r.k.p.u0.d;
import t1.r.k.p.v;
import t1.r.k.p.w;

/*
 * Exception performing whole class analysis.
 */
public class CirclePageIndicator
extends View
implements d {
    public final Paint a;
    public final Paint b;
    public final Paint c;
    public float d;
    public ViewPager e;
    public ViewPager.OnPageChangeListener f;
    public int g;
    public int h;
    public float i;
    public int j;
    public int k;
    public boolean s;
    public boolean t;
    public int u;
    public float v;
    public int w;
    public boolean x;

    public CirclePageIndicator(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, t.c);
    }

    public CirclePageIndicator(Context context, AttributeSet attributeSet, int n2) {
        Paint paint;
        Paint paint2;
        Paint paint3;
        super(context, attributeSet, n2);
        this.a = paint2 = new Paint(1);
        this.b = paint = new Paint(1);
        this.c = paint3 = new Paint(1);
        this.v = -1.0f;
        this.w = -1;
        if (this.isInEditMode()) {
            return;
        }
        Resources resources = this.getResources();
        int n3 = resources.getColor(v.f);
        int n4 = resources.getColor(v.e);
        int n5 = resources.getInteger(a0.a);
        int n6 = resources.getColor(v.g);
        float f2 = resources.getDimension(w.c);
        float f3 = resources.getDimension(w.b);
        boolean bl = resources.getBoolean(u.a);
        boolean bl2 = resources.getBoolean(u.b);
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, e0.F, n2, 0);
        this.s = typedArray.getBoolean(e0.I, bl);
        this.k = typedArray.getInt(e0.G, n5);
        paint2.setStyle(Paint.Style.FILL);
        paint2.setColor(typedArray.getColor(e0.K, n3));
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(typedArray.getColor(e0.N, n6));
        paint.setStrokeWidth(typedArray.getDimension(e0.O, f2));
        paint3.setStyle(Paint.Style.FILL_AND_STROKE);
        paint3.setStrokeWidth(this.getContext().getResources().getDimension(w.e));
        paint3.setColor(typedArray.getColor(e0.J, n4));
        this.d = typedArray.getDimension(e0.L, f3);
        this.t = typedArray.getBoolean(e0.M, bl2);
        Drawable drawable = typedArray.getDrawable(e0.H);
        if (drawable != null) {
            this.setBackgroundDrawable(drawable);
        }
        typedArray.recycle();
        this.u = ViewConfigurationCompat.getScaledPagingTouchSlop((ViewConfiguration)ViewConfiguration.get((Context)context));
    }

    public final int a(int n2) {
        int n3 = View.MeasureSpec.getMode((int)n2);
        int n4 = View.MeasureSpec.getSize((int)n2);
        if (n3 != 1073741824) {
            ViewPager viewPager = this.e;
            if (viewPager == null) {
                return n4;
            }
            int n5 = viewPager.getAdapter().getCount();
            float f2 = this.getPaddingLeft() + this.getPaddingRight();
            float f3 = n5 * 2;
            float f4 = this.d;
            int n6 = (int)(1.0f + (f2 + f3 * f4 + 3.0f * (f4 * (float)(n5 - 1))));
            if (n3 == Integer.MIN_VALUE) {
                return Math.min((int)n6, (int)n4);
            }
            n4 = n6;
        }
        return n4;
    }

    public final int b(int n2) {
        int n3 = View.MeasureSpec.getMode((int)n2);
        int n4 = View.MeasureSpec.getSize((int)n2);
        if (n3 == 1073741824) {
            return n4;
        }
        int n5 = (int)(1.0f + (2.0f * this.d + (float)this.getPaddingTop() + (float)this.getPaddingBottom()));
        if (n3 == Integer.MIN_VALUE) {
            return Math.min((int)n5, (int)n4);
        }
        return n5;
    }

    public void f0() {
    }

    public int getFillColor() {
        return this.c.getColor();
    }

    public int getOrientation() {
        return this.k;
    }

    public int getPageColor() {
        return this.a.getColor();
    }

    public float getRadius() {
        return this.d;
    }

    public int getStrokeColor() {
        return this.b.getColor();
    }

    public float getStrokeWidth() {
        return this.b.getStrokeWidth();
    }

    public void onDraw(Canvas canvas) {
        int n2;
        int n3;
        int n4;
        float f2;
        int n5;
        super.onDraw(canvas);
        ViewPager viewPager = this.e;
        if (viewPager == null) {
            return;
        }
        int n6 = viewPager.getAdapter().getCount();
        if (n6 == 0) {
            return;
        }
        if (this.g >= n6) {
            this.setCurrentItem(n6 - 1);
            return;
        }
        if (this.k == 0) {
            n2 = this.getWidth();
            n5 = this.getPaddingLeft();
            n3 = this.getPaddingRight();
            n4 = this.getPaddingTop();
        } else {
            n2 = this.getHeight();
            n5 = this.getPaddingTop();
            n3 = this.getPaddingBottom();
            n4 = this.getPaddingLeft();
        }
        float f3 = this.d;
        float f4 = 5.0f * f3;
        float f5 = f3 + (float)n4;
        float f6 = f3 + (float)n5;
        if (this.s) {
            f6 += (float)(n2 - n5 - n3) / 2.0f - f4 * (float)n6 / 2.0f;
        }
        if (this.b.getStrokeWidth() > 0.0f) {
            f3 -= this.b.getStrokeWidth() / 2.0f;
        }
        for (int i2 = 0; i2 < n6; ++i2) {
            float f7;
            float f8;
            float f9 = f6 + f4 * (float)i2;
            if (this.k == 0) {
                f7 = f5;
            } else {
                f7 = f9;
                f9 = f5;
            }
            if (this.a.getAlpha() > 0) {
                canvas.drawCircle(f9, f7, f3, this.a);
            }
            if (f3 == (f8 = this.d)) continue;
            canvas.drawCircle(f9, f7, f8, this.b);
        }
        boolean bl = this.t;
        int n7 = bl ? this.h : this.g;
        float f10 = f4 * (float)n7;
        if (!bl) {
            f10 += f4 * this.i;
        }
        if (this.k == 0) {
            float f11 = f6 + f10;
            f2 = f5;
            f5 = f11;
        } else {
            f2 = f6 + f10;
        }
        canvas.drawCircle(f5, f2, this.d, this.c);
    }

    public void onMeasure(int n2, int n3) {
        if (this.k == 0) {
            this.setMeasuredDimension(this.a(n2), this.b(n3));
            return;
        }
        this.setMeasuredDimension(this.b(n2), this.a(n3));
    }

    public void onPageScrollStateChanged(int n2) {
        this.j = n2;
        ViewPager.OnPageChangeListener onPageChangeListener = this.f;
        if (onPageChangeListener != null) {
            onPageChangeListener.onPageScrollStateChanged(n2);
        }
    }

    public void onPageScrolled(int n2, float f2, int n3) {
        this.g = n2;
        this.i = f2;
        this.invalidate();
        ViewPager.OnPageChangeListener onPageChangeListener = this.f;
        if (onPageChangeListener != null) {
            onPageChangeListener.onPageScrolled(n2, f2, n3);
        }
    }

    public void onPageSelected(int n2) {
        ViewPager.OnPageChangeListener onPageChangeListener;
        if (this.t || this.j == 0) {
            this.g = n2;
            this.h = n2;
            this.invalidate();
        }
        if ((onPageChangeListener = this.f) != null) {
            onPageChangeListener.onPageSelected(n2);
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        int n2;
        SavedState savedState = parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.g = n2 = savedState.a;
        this.h = n2;
        this.requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new /* Unavailable Anonymous Inner Class!! */;
        savedState.a = this.g;
        return savedState;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (super.onTouchEvent(motionEvent)) {
            return true;
        }
        ViewPager viewPager = this.e;
        if (viewPager == null) return false;
        if (viewPager.getAdapter().getCount() == 0) {
            return false;
        }
        int n2 = 255 & motionEvent.getAction();
        if (n2 != 0) {
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) {
                        if (n2 != 5) {
                            if (n2 != 6) {
                                return true;
                            }
                            int n3 = MotionEventCompat.getActionIndex((MotionEvent)motionEvent);
                            if (MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n3) == this.w) {
                                int n4 = 0;
                                if (n3 == 0) {
                                    n4 = 1;
                                }
                                this.w = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n4);
                            }
                            this.v = MotionEventCompat.getX((MotionEvent)motionEvent, (int)MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.w));
                            return true;
                        }
                        int n5 = MotionEventCompat.getActionIndex((MotionEvent)motionEvent);
                        this.v = MotionEventCompat.getX((MotionEvent)motionEvent, (int)n5);
                        this.w = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)n5);
                        return true;
                    }
                } else {
                    float f2 = MotionEventCompat.getX((MotionEvent)motionEvent, (int)MotionEventCompat.findPointerIndex((MotionEvent)motionEvent, (int)this.w));
                    float f3 = f2 - this.v;
                    if (!this.x && Math.abs((float)f3) > (float)this.u) {
                        this.x = true;
                    }
                    if (!this.x) return true;
                    this.v = f2;
                    if (!this.e.isFakeDragging() && !this.e.beginFakeDrag()) return true;
                    this.e.fakeDragBy(f3);
                    return true;
                }
            }
            if (!this.x) {
                int n6 = this.e.getAdapter().getCount();
                float f4 = this.getWidth();
                float f5 = f4 / 2.0f;
                float f6 = f4 / 6.0f;
                if (this.g > 0 && motionEvent.getX() < f5 - f6) {
                    if (n2 == 3) return true;
                    this.e.setCurrentItem(this.g - 1);
                    return true;
                }
                if (this.g < n6 - 1 && motionEvent.getX() > f5 + f6) {
                    if (n2 == 3) return true;
                    this.e.setCurrentItem(1 + this.g);
                    return true;
                }
            }
            this.x = false;
            this.w = -1;
            if (!this.e.isFakeDragging()) return true;
            this.e.endFakeDrag();
            return true;
        }
        this.w = MotionEventCompat.getPointerId((MotionEvent)motionEvent, (int)0);
        this.v = motionEvent.getX();
        return true;
    }

    public void p1() {
    }

    public void setCentered(boolean bl) {
        this.s = bl;
        this.invalidate();
    }

    public void setCurrentItem(int n2) {
        ViewPager viewPager = this.e;
        if (viewPager != null) {
            viewPager.setCurrentItem(n2);
            this.g = n2;
            this.invalidate();
            return;
        }
        throw new IllegalStateException("ViewPager has not been bound.");
    }

    public void setFillColor(int n2) {
        this.c.setColor(n2);
        this.invalidate();
    }

    public void setOnPageChangeListener(ViewPager.OnPageChangeListener onPageChangeListener) {
        this.f = onPageChangeListener;
    }

    public void setOrientation(int n2) {
        if (n2 != 0 && n2 != 1) {
            throw new IllegalArgumentException("Orientation must be either HORIZONTAL or VERTICAL.");
        }
        this.k = n2;
        this.requestLayout();
    }

    public void setPageColor(int n2) {
        this.a.setColor(n2);
        this.invalidate();
    }

    public void setRadius(float f2) {
        this.d = f2;
        this.invalidate();
    }

    public void setSnap(boolean bl) {
        this.t = bl;
        this.invalidate();
    }

    public void setStrokeColor(int n2) {
        this.b.setColor(n2);
        this.invalidate();
    }

    public void setStrokeWidth(float f2) {
        this.b.setStrokeWidth(f2);
        this.invalidate();
    }

    public void setViewPager(ViewPager viewPager) {
        ViewPager viewPager2 = this.e;
        if (viewPager2 == viewPager) {
            return;
        }
        if (viewPager2 != null) {
            viewPager2.addOnPageChangeListener(null);
        }
        if (viewPager.getAdapter() != null) {
            this.e = viewPager;
            viewPager.addOnPageChangeListener((ViewPager.OnPageChangeListener)this);
            this.invalidate();
            return;
        }
        throw new IllegalStateException("ViewPager does not have adapter instance.");
    }
}

