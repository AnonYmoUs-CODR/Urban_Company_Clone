/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.constraintlayout.widget.ConstraintLayout;
import i2.a0.d.l;

public final class UntouchableConstraintLayout
extends ConstraintLayout {
    public UntouchableConstraintLayout(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        super(context, attributeSet);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return true;
    }
}

