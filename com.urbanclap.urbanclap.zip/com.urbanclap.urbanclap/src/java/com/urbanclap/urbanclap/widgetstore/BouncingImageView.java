/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.AttributeSet
 *  android.view.View
 *  androidx.core.content.ContextCompat
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Timer
 *  java.util.TimerTask
 *  t1.r.k.p.b
 *  t1.r.k.p.c
 *  t1.r.k.p.d
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.content.ContextCompat;
import com.urbanclap.urbanclap.widgetstore.AnimationState;
import i2.a0.d.l;
import java.util.Timer;
import java.util.TimerTask;
import t1.r.k.p.c;
import t1.r.k.p.d;

public final class BouncingImageView
extends View {
    public float a;
    public float b;
    public float c;
    public float d;
    public final float e;
    public float f;
    public float g;
    public long h;
    public final long i;
    public final long j;
    public final long k;
    public final Timer s;
    public int t;
    public AnimationState u;
    public boolean v;
    public t1.r.k.p.b w;
    public Drawable x;

    public BouncingImageView(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        this(context, attributeSet, 0);
    }

    public BouncingImageView(Context context, AttributeSet attributeSet, int n) {
        l.g((Object)context, (String)"context");
        super(context, attributeSet, n);
        this.e = d.a((int)6);
        this.g = 0.08f * d.a((int)3);
        this.i = 3000L;
        this.j = 32L;
        this.s = new Timer();
        this.t = 1;
        this.u = AnimationState.LOAD_IMAGE;
    }

    public static final /* synthetic */ void n(BouncingImageView bouncingImageView, AnimationState animationState) {
        bouncingImageView.u = animationState;
    }

    public static final /* synthetic */ void o(BouncingImageView bouncingImageView, float f2) {
        bouncingImageView.b = f2;
    }

    public static final /* synthetic */ void p(BouncingImageView bouncingImageView, long l2) {
        bouncingImageView.h = l2;
    }

    public static final /* synthetic */ void q(BouncingImageView bouncingImageView, float f2) {
        bouncingImageView.f = f2;
    }

    public static final /* synthetic */ void r(BouncingImageView bouncingImageView, boolean bl) {
        bouncingImageView.v = bl;
    }

    public static final /* synthetic */ void s(BouncingImageView bouncingImageView, int n) {
        bouncingImageView.t = n;
    }

    public static final /* synthetic */ void t(BouncingImageView bouncingImageView, float f2) {
        bouncingImageView.c = f2;
    }

    public void onDraw(Canvas canvas) {
        l.g((Object)canvas, (String)"canvas");
        this.w();
        Drawable drawable = this.x;
        if (drawable != null) {
            float f2 = this.a;
            float f3 = this.c;
            int n = (int)(f2 - f3);
            float f4 = this.b;
            drawable.setBounds(n, (int)(f4 - f3), (int)(f2 + f3), (int)(f4 + f3));
            canvas.save();
            drawable.draw(canvas);
            canvas.restore();
        }
    }

    public final void u() {
        this.s.cancel();
    }

    public final void v() {
        this.v = true;
    }

    public final void w() {
        if (this.a == 0.0f) {
            float f2;
            float f3 = this.getWidth();
            float f4 = 2;
            this.a = f2 = f3 / f4;
            this.b = f2 - this.e;
            this.c = 0.0f;
            this.d = (float)this.getWidth() / f4 - this.e - d.a((int)3);
        }
    }

    public final void x(int n, final t1.r.k.p.b b2) {
        l.g((Object)b2, (String)"animationListener");
        this.w = b2;
        this.x = ContextCompat.getDrawable((Context)this.getContext(), (int)n);
        this.s.scheduleAtFixedRate(new TimerTask(){

            public void run() {
                AnimationState animationState = this.u;
                int n = c.a[animationState.ordinal()];
                if (n != 1) {
                    if (n == 2) {
                        if (this.t == 1) {
                            if (this.b < this.a - this.e) {
                                BouncingImageView.q(this, 0.0f);
                                BouncingImageView.s(this, 0);
                            } else {
                                BouncingImageView bouncingImageView = this;
                                BouncingImageView.q(bouncingImageView, bouncingImageView.f - this.g);
                                float f2 = this.f;
                                float f3 = this.g;
                                float f4 = 2;
                                if (f2 <= f3 * f4) {
                                    BouncingImageView bouncingImageView2 = this;
                                    BouncingImageView.q(bouncingImageView2, f4 * bouncingImageView2.g);
                                }
                                BouncingImageView bouncingImageView3 = this;
                                BouncingImageView.o(bouncingImageView3, bouncingImageView3.b - this.f);
                            }
                        } else if (this.b >= this.a + this.e) {
                            BouncingImageView bouncingImageView = this;
                            BouncingImageView.q(bouncingImageView, bouncingImageView.f - this.g);
                            BouncingImageView bouncingImageView4 = this;
                            BouncingImageView.o(bouncingImageView4, bouncingImageView4.a + this.e);
                            BouncingImageView.s(this, 1);
                        } else {
                            BouncingImageView bouncingImageView = this;
                            BouncingImageView.q(bouncingImageView, bouncingImageView.f + this.g);
                            BouncingImageView bouncingImageView5 = this;
                            BouncingImageView.o(bouncingImageView5, bouncingImageView5.b + this.f);
                        }
                        if (this.v && this.h > this.i) {
                            new Handler(Looper.getMainLooper()).post(new Runnable(){

                                public final void run() {
                                    b2.c();
                                    BouncingImageView.r(this, false);
                                }
                            });
                        }
                    }
                } else {
                    BouncingImageView bouncingImageView = this;
                    BouncingImageView.t(bouncingImageView, bouncingImageView.c + d.a((int)3));
                    if (this.d != 0.0f && this.c >= this.d) {
                        BouncingImageView bouncingImageView6 = this;
                        BouncingImageView.t(bouncingImageView6, bouncingImageView6.d);
                        BouncingImageView.n(this, AnimationState.BOUNCE_IMAGE);
                        new Handler(Looper.getMainLooper()).post(new Runnable(){

                            public final void run() {
                                b2.b();
                            }
                        });
                    }
                }
                BouncingImageView bouncingImageView = this;
                BouncingImageView.p(bouncingImageView, bouncingImageView.h + this.j);
                this.postInvalidate();
            }

        }, this.k, this.j);
    }

}

