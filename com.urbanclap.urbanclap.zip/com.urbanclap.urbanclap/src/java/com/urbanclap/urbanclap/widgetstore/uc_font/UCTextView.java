/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.d
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.view.View
 *  com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants
 *  java.lang.Integer
 *  java.lang.String
 *  t1.r.k.p.a1.a
 *  t1.r.k.p.e0
 *  t1.r.k.p.j0
 */
package com.urbanclap.urbanclap.widgetstore.uc_font;

import a2.d;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants;
import t1.r.k.p.a1.a;
import t1.r.k.p.e0;
import t1.r.k.p.j0;
import t1.r.k.p.l;

public class UCTextView
extends l
implements a {
    public int a;
    public int b;
    public int c;
    public float d;
    public boolean e;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    public float k;
    public float s;

    public UCTextView(Context context) {
        super(context);
        this.c(null);
    }

    public UCTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c(attributeSet);
    }

    public final void a() {
        j0 j02 = new j0(this.getContext());
        j02.d(this.a);
        j02.c(this.b);
        j02.e(this.c, this.d, this.e, this.f, this.g);
        j02.f(this.h, this.j, this.i, this.k, this.s);
        j02.a((View)this);
    }

    public final void b() {
        if (this.getBackground() != null) {
            return;
        }
        this.a();
    }

    public final void c(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().getTheme().obtainStyledAttributes(attributeSet, e0.N0, 0, 0);
        int n2 = typedArray.getInt(e0.a1, 0);
        this.a = typedArray.getInt(e0.O0, 0);
        this.b = typedArray.getColor(e0.V0, 0);
        this.c = typedArray.getColor(e0.W0, 0);
        this.d = typedArray.getDimension(e0.X0, 0.0f);
        this.e = typedArray.getBoolean(e0.R0, false);
        this.f = typedArray.getDimension(e0.T0, -1.0f);
        this.g = typedArray.getDimension(e0.S0, -1.0f);
        this.h = typedArray.getDimension(e0.U0, 0.0f);
        this.i = typedArray.getDimension(e0.Z0, 0.0f);
        this.j = typedArray.getDimension(e0.Y0, 0.0f);
        this.k = typedArray.getDimension(e0.Q0, 0.0f);
        this.s = typedArray.getDimension(e0.P0, 0.0f);
        typedArray.recycle();
        this.setFont(n2);
        this.b();
    }

    public void setBackgroundColor(int n2) {
        this.b = n2;
        this.a();
    }

    public void setBackgroundColor(String string) {
        this.setBackgroundColor(d.a((String)string));
    }

    public void setBackgroundShape(int n2) {
        if (this.a == n2) {
            return;
        }
        this.a = n2;
        this.a();
    }

    public void setBottomLeftEdgeRadius(float f2) {
        if (this.s == f2) {
            return;
        }
        this.s = f2;
        this.a();
    }

    public void setBottomRightEdgeRadius(float f2) {
        if (this.k == f2) {
            return;
        }
        this.k = f2;
        this.a();
    }

    public void setDashedStroke(boolean bl) {
        if (this.e == bl) {
            return;
        }
        this.e = bl;
        this.a();
    }

    public void setDashedStrokeGapLength(float f2) {
        if (this.g == f2) {
            return;
        }
        this.g = f2;
        this.a();
    }

    public void setDashedStrokeLength(float f2) {
        if (this.g == f2) {
            return;
        }
        this.f = f2;
        this.a();
    }

    public void setEdgeRadius(float f2) {
        if (this.h == f2) {
            return;
        }
        this.h = f2;
        this.a();
    }

    public void setFont(int n2) {
        if (n2 >= 0) {
            if (n2 >= UCFontConstants.values().length) {
                return;
            }
            this.setCustomFont(UCFontConstants.values()[n2].getFont());
        }
    }

    public void setStrokeColor(int n2) {
        this.c = n2;
        this.a();
    }

    public void setStrokeColor(String string) {
        this.setStrokeColor(d.a((String)string));
    }

    public void setStrokeWidth(float f2) {
        if (this.d == f2) {
            return;
        }
        this.d = f2;
        this.a();
    }

    public void setTopLeftEdgeRadius(float f2) {
        if (this.j == f2) {
            return;
        }
        this.j = f2;
        this.a();
    }

    public void setTopRightEdgeRadius(float f2) {
        if (this.i == f2) {
            return;
        }
        this.i = f2;
        this.a();
    }
}

