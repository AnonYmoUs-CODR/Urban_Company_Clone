/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Typeface
 *  android.text.Html
 *  android.util.AttributeSet
 *  androidx.annotation.StringRes
 *  androidx.appcompat.widget.AppCompatTextView
 *  java.lang.CharSequence
 *  java.lang.String
 *  t1.r.k.e.a
 *  t1.r.k.p.e0
 */
package com.urbanclap.urbanclap.widgetstore;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.Html;
import android.util.AttributeSet;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.AppCompatTextView;
import t1.r.k.e.a;
import t1.r.k.p.e0;

public class IconTextView
extends AppCompatTextView {
    public IconTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b(attributeSet);
    }

    public final CharSequence a(String string) {
        if (string != null) {
            return Html.fromHtml((String)string);
        }
        return null;
    }

    public final void b(AttributeSet attributeSet) {
        String string = this.getContext().getTheme().obtainStyledAttributes(attributeSet, e0.S, 0, 0).getString(e0.T);
        if (this.isInEditMode()) {
            a.h((Context)this.getContext());
        }
        this.setTypeface(a.e());
        this.setIcon(string);
    }

    public void setIcon(@StringRes int n2) {
        this.setIcon(this.getContext().getResources().getString(n2));
    }

    public void setIcon(String string) {
        this.setText(this.a(string));
    }
}

