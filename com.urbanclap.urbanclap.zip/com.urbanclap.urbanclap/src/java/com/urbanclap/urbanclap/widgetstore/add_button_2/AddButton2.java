/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.View
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$a
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$b
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$c
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$d
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$e
 *  com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2$f
 *  com.urbanclap.urbanclap.widgetstore.uc_custom_views.UcFrameLayout
 *  i2.a0.c.a
 *  i2.a0.c.l
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.t
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.p.e0
 *  t1.r.k.p.r0.a
 *  t1.r.k.p.r0.b
 */
package com.urbanclap.urbanclap.widgetstore.add_button_2;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import com.urbanclap.urbanclap.widgetstore.add_button_2.AddButton2;
import com.urbanclap.urbanclap.widgetstore.uc_custom_views.UcFrameLayout;
import i2.a0.d.g;
import i2.a0.d.l;
import i2.t;
import t1.r.k.p.e0;

public final class AddButton2
extends UcFrameLayout {
    public i2.a0.c.a<t> A;
    public i2.a0.c.a<t> B;
    public t1.r.k.p.r0.b w;
    public t1.r.k.p.r0.a x;
    public int y;
    public int z;

    public AddButton2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
    }

    public AddButton2(Context context, AttributeSet attributeSet, int n2) {
        l.g((Object)context, (String)"context");
        super(context, attributeSet, n2);
        this.A = b.a;
        this.B = a.a;
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, e0.f);
        this.y = typedArray.getInt(e0.g, 1);
        this.z = typedArray.getInt(e0.h, 0);
        typedArray.recycle();
        this.m();
    }

    public /* synthetic */ AddButton2(Context context, AttributeSet attributeSet, int n2, int n3, g g2) {
        if ((n3 & 2) != 0) {
            attributeSet = null;
        }
        if ((n3 & 4) != 0) {
            n2 = 0;
        }
        this(context, attributeSet, n2);
    }

    public static final /* synthetic */ i2.a0.c.a h(AddButton2 addButton2) {
        return addButton2.B;
    }

    public static final /* synthetic */ i2.a0.c.a i(AddButton2 addButton2) {
        return addButton2.A;
    }

    public final void j() {
        if (this.y != 0) {
            return;
        }
        t1.r.k.p.r0.b b2 = this.w;
        if (b2 != null) {
            b2.j();
        }
    }

    public final void k() {
        if (this.y != 0) {
            return;
        }
        t1.r.k.p.r0.b b2 = this.w;
        if (b2 != null) {
            b2.k();
        }
    }

    public final void l(String string, String string2) {
        if (this.y != 0) {
            return;
        }
        t1.r.k.p.r0.b b2 = this.w;
        if (b2 != null) {
            b2.l(string, string2);
        }
    }

    public final void m() {
        this.removeAllViews();
        this.w = null;
        this.x = null;
        int n2 = this.y;
        int n3 = 1;
        if (n2 != 0) {
            if (n2 == n3) {
                t1.r.k.p.r0.a a2;
                Context context = this.getContext();
                l.f((Object)context, (String)"context");
                this.x = a2 = new t1.r.k.p.r0.a(context, null, 0, 6, null);
                this.addView((View)a2);
            }
        } else {
            t1.r.k.p.r0.b b2;
            Context context = this.getContext();
            l.f((Object)context, (String)"context");
            this.w = b2 = new t1.r.k.p.r0.b(context, null, 0, 6, null);
            this.addView((View)b2);
        }
        t1.r.k.p.r0.b b3 = this.w;
        if (b3 != null) {
            int n4 = this.z;
            if (n4 != 0) {
                if (n4 != n3) {
                    throw new IllegalArgumentException();
                }
            } else {
                n3 = 0;
            }
            b3.setSelectionType(n3);
        }
    }

    public final void n(boolean bl) {
        if (this.y != 0) {
            return;
        }
        t1.r.k.p.r0.b b2 = this.w;
        if (b2 != null) {
            b2.n(bl);
        }
    }

    public final void setButtonType(int n2) {
        if (n2 != 0 && n2 != 1) {
            throw new IllegalArgumentException("Possible values are AddButton2.BUTTON_TYPE_TOGGLE and AddButton2.BUTTON_TYPE_STEPPER");
        }
        this.y = n2;
        this.m();
    }

    public final void setDecrementCallback(i2.a0.c.a<t> a2) {
        l.g(a2, (String)"callback");
        this.B = a2;
        int n2 = this.y;
        if (n2 != 0) {
            if (n2 != 1) {
                return;
            }
            t1.r.k.p.r0.a a3 = this.x;
            if (a3 != null) {
                a3.setDecrementCallback((i2.a0.c.l)new d(this));
                return;
            }
        } else {
            t1.r.k.p.r0.b b2 = this.w;
            if (b2 != null) {
                b2.setSelectionCallback((i2.a0.c.l)new c(this));
            }
        }
    }

    public final void setIncrementCallback(i2.a0.c.a<t> a2) {
        l.g(a2, (String)"callback");
        this.A = a2;
        int n2 = this.y;
        if (n2 != 0) {
            if (n2 != 1) {
                return;
            }
            t1.r.k.p.r0.a a3 = this.x;
            if (a3 != null) {
                a3.setIncrementCallback((i2.a0.c.l)new f(this));
                return;
            }
        } else {
            t1.r.k.p.r0.b b2 = this.w;
            if (b2 != null) {
                b2.setSelectionCallback((i2.a0.c.l)new e(this));
            }
        }
    }

    public final void setQuantity(int n2) {
        boolean bl = this.y;
        boolean bl2 = true;
        if (bl) {
            if (bl != bl2) {
                return;
            }
            t1.r.k.p.r0.a a2 = this.x;
            if (a2 != null) {
                a2.setQuantity(n2);
                return;
            }
        } else {
            t1.r.k.p.r0.b b2 = this.w;
            if (b2 != null) {
                if (n2 == 0) {
                    bl2 = false;
                }
                b2.setSelection(bl2);
            }
        }
    }

    public final void setSelectionType(int n2) {
        if (n2 != 0 && n2 != 1) {
            throw new IllegalArgumentException("Possible values are AddButton2.SELECTION_TYPE_SINGLE_SELECT and AddButton2.SELECTION_TYPE_MULTI_SELECT");
        }
        this.z = n2;
        this.m();
    }
}

