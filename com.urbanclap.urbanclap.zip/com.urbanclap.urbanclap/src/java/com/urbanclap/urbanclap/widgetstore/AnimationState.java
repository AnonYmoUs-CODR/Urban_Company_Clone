/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.widgetstore;

public final class AnimationState
extends Enum<AnimationState> {
    private static final /* synthetic */ AnimationState[] $VALUES;
    public static final /* enum */ AnimationState BOUNCE_IMAGE;
    public static final /* enum */ AnimationState LOAD_IMAGE;

    public static {
        AnimationState animationState;
        AnimationState animationState2;
        AnimationState[] arranimationState = new AnimationState[2];
        LOAD_IMAGE = animationState = new AnimationState();
        arranimationState[0] = animationState;
        BOUNCE_IMAGE = animationState2 = new AnimationState();
        arranimationState[1] = animationState2;
        $VALUES = arranimationState;
    }

    public static AnimationState valueOf(String string) {
        return (AnimationState)Enum.valueOf(AnimationState.class, (String)string);
    }

    public static AnimationState[] values() {
        return (AnimationState[])$VALUES.clone();
    }
}

