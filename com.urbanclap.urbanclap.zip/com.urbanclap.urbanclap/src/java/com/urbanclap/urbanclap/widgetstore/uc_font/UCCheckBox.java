/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants
 *  java.lang.Integer
 *  t1.r.k.p.a1.a
 *  t1.r.k.p.e0
 */
package com.urbanclap.urbanclap.widgetstore.uc_font;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCFontConstants;
import t1.r.k.p.a1.a;
import t1.r.k.p.e0;
import t1.r.k.p.h;

public class UCCheckBox
extends h
implements a {
    public UCCheckBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c(attributeSet);
    }

    public final void c(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().getTheme().obtainStyledAttributes(attributeSet, e0.F0, 0, 0);
        int n2 = typedArray.getInt(e0.G0, 0);
        typedArray.recycle();
        this.setFont(n2);
    }

    public void setFont(int n2) {
        if (n2 >= 0) {
            if (n2 >= UCFontConstants.values().length) {
                return;
            }
            this.setCustomFont(UCFontConstants.values()[n2].getFont());
        }
    }
}

