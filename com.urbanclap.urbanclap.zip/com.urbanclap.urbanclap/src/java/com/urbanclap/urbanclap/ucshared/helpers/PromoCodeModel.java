/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.helpers.PromoCodeModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.helpers;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.helpers.PromoCodeModel;
import com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel;

public class PromoCodeModel
extends ApiResponseBaseModel {
    public static final Parcelable.Creator<PromoCodeModel> CREATOR = new a();
    @Expose
    @SerializedName(value="coupon_code")
    private String e;
    @Expose
    @SerializedName(value="coupon_discount")
    private double f;
    @Expose
    @SerializedName(value="coupon_method")
    private String g;
    @Expose
    @SerializedName(value="coupon_id")
    private String h;
    @Expose
    @SerializedName(value="cashback_amount")
    private int i = 0;
    @Expose
    @SerializedName(value="cashback_text")
    private String j;

    public PromoCodeModel() {
    }

    public PromoCodeModel(Parcel parcel) {
        super(parcel);
        this.e = parcel.readString();
        this.f = parcel.readDouble();
        this.g = parcel.readString();
        this.h = parcel.readString();
        this.i = parcel.readInt();
        this.j = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public String h() {
        return this.h;
    }

    public double i() {
        return this.f;
    }

    public String j() {
        return this.e;
    }

    public void k(String string) {
        this.h = string;
    }

    public void l(double d2) {
        this.f = d2;
    }

    public void m(String string) {
        this.e = string;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeString(this.e);
        parcel.writeDouble(this.f);
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeInt(this.i);
        parcel.writeString(this.j);
    }
}

