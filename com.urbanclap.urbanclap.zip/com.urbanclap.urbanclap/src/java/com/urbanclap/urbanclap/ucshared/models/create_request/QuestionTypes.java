/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class QuestionTypes
extends Enum<QuestionTypes> {
    private static final /* synthetic */ QuestionTypes[] $VALUES;
    public static final /* enum */ QuestionTypes AREA_PRICE_SUMMARY;
    public static final /* enum */ QuestionTypes COLLECTIVE;
    public static final /* enum */ QuestionTypes DATE;
    public static final /* enum */ QuestionTypes DEFAULT;
    public static final /* enum */ QuestionTypes DYNAMIC_PRICING;
    public static final /* enum */ QuestionTypes DYNAMIC_PRICING_ADDON;
    private static final Map<String, QuestionTypes> ENUM_MAP;
    public static final /* enum */ QuestionTypes EXTRA;
    public static final /* enum */ QuestionTypes LOCATION;
    public static final /* enum */ QuestionTypes MULTISELECT_POWERED_BY_CART;
    public static final /* enum */ QuestionTypes MULTI_LOCATION;
    public static final /* enum */ QuestionTypes MULTI_SELECT;
    public static final /* enum */ QuestionTypes NEW_PACKAGES;
    public static final /* enum */ QuestionTypes PRICE_SUGGESTIVE_CHOOSE;
    public static final /* enum */ QuestionTypes SINGLE_SELECT;
    public static final /* enum */ QuestionTypes STATIC_TEXT;
    public static final /* enum */ QuestionTypes STATIC_TEXT_BULLET;
    private final String name;

    public static {
        QuestionTypes questionTypes;
        QuestionTypes questionTypes2;
        QuestionTypes questionTypes3;
        QuestionTypes questionTypes4;
        QuestionTypes questionTypes5;
        QuestionTypes questionTypes6;
        QuestionTypes questionTypes7;
        QuestionTypes questionTypes8;
        QuestionTypes questionTypes9;
        QuestionTypes questionTypes10;
        QuestionTypes questionTypes11;
        QuestionTypes questionTypes12;
        QuestionTypes questionTypes13;
        QuestionTypes questionTypes14;
        QuestionTypes questionTypes15;
        QuestionTypes questionTypes16;
        SINGLE_SELECT = questionTypes6 = new QuestionTypes("singleselect");
        MULTI_SELECT = questionTypes = new QuestionTypes("multiselect");
        LOCATION = questionTypes10 = new QuestionTypes("location");
        EXTRA = questionTypes14 = new QuestionTypes("extra");
        DATE = questionTypes2 = new QuestionTypes("date");
        STATIC_TEXT = questionTypes12 = new QuestionTypes("static_text");
        PRICE_SUGGESTIVE_CHOOSE = questionTypes5 = new QuestionTypes("price_suggestive_choose");
        STATIC_TEXT_BULLET = questionTypes16 = new QuestionTypes("static_text_bullets");
        NEW_PACKAGES = questionTypes11 = new QuestionTypes("package_v2");
        MULTI_LOCATION = questionTypes4 = new QuestionTypes("multi_location");
        AREA_PRICE_SUMMARY = questionTypes3 = new QuestionTypes("area_pricing_summary");
        COLLECTIVE = questionTypes15 = new QuestionTypes("collective");
        DYNAMIC_PRICING = questionTypes13 = new QuestionTypes("dynamic_pricing_cart");
        DYNAMIC_PRICING_ADDON = questionTypes9 = new QuestionTypes("cart_with_addon");
        MULTISELECT_POWERED_BY_CART = questionTypes8 = new QuestionTypes("multiselect_powered_by_cart");
        DEFAULT = questionTypes7 = new QuestionTypes("default");
        QuestionTypes[] arrquestionTypes = new QuestionTypes[16];
        arrquestionTypes[0] = questionTypes6;
        arrquestionTypes[1] = questionTypes;
        arrquestionTypes[2] = questionTypes10;
        arrquestionTypes[3] = questionTypes14;
        arrquestionTypes[4] = questionTypes2;
        arrquestionTypes[5] = questionTypes12;
        arrquestionTypes[6] = questionTypes5;
        arrquestionTypes[7] = questionTypes16;
        arrquestionTypes[8] = questionTypes11;
        arrquestionTypes[9] = questionTypes4;
        arrquestionTypes[10] = questionTypes3;
        arrquestionTypes[11] = questionTypes15;
        arrquestionTypes[12] = questionTypes13;
        arrquestionTypes[13] = questionTypes9;
        arrquestionTypes[14] = questionTypes8;
        arrquestionTypes[15] = questionTypes7;
        $VALUES = arrquestionTypes;
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        for (QuestionTypes questionTypes17 : QuestionTypes.values()) {
            concurrentHashMap.put((Object)questionTypes17.getName(), (Object)questionTypes17);
        }
        ENUM_MAP = Collections.unmodifiableMap((Map)concurrentHashMap);
    }

    private QuestionTypes(String string2) {
        this.name = string2;
    }

    public static QuestionTypes get(String string) {
        Map<String, QuestionTypes> map = ENUM_MAP;
        if (map.containsKey((Object)string)) {
            return (QuestionTypes)((Object)map.get((Object)string));
        }
        return DEFAULT;
    }

    public static QuestionTypes valueOf(String string) {
        return (QuestionTypes)Enum.valueOf(QuestionTypes.class, (String)string);
    }

    public static QuestionTypes[] values() {
        return (QuestionTypes[])$VALUES.clone();
    }

    public String getName() {
        return this.name;
    }
}

