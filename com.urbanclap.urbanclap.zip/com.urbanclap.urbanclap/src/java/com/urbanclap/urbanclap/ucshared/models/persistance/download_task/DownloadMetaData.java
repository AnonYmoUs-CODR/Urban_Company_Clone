/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.persistance.download_task;

import android.os.Parcel;
import android.os.Parcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public final class DownloadMetaData
implements Parcelable {
    public static final a CREATOR = new a(null);
    public final String a;
    public final String b;

    public DownloadMetaData(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.e((Object)string);
        String string2 = parcel.readString();
        l.e((Object)string2);
        this(string, string2);
    }

    public DownloadMetaData(String string, String string2) {
        l.g((Object)string, (String)"key");
        l.g((Object)string2, (String)"fileUrl");
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DownloadMetaData)) break block3;
                DownloadMetaData downloadMetaData = (DownloadMetaData)object;
                if (l.c((Object)this.a, (Object)downloadMetaData.a) && l.c((Object)this.b, (Object)downloadMetaData.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = 0;
        if (string2 != null) {
            n3 = string2.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DownloadMetaData(key=");
        stringBuilder.append(this.a);
        stringBuilder.append(", fileUrl=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<DownloadMetaData> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public DownloadMetaData a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new DownloadMetaData(parcel);
        }

        public DownloadMetaData[] b(int n) {
            return new DownloadMetaData[n];
        }
    }

}

