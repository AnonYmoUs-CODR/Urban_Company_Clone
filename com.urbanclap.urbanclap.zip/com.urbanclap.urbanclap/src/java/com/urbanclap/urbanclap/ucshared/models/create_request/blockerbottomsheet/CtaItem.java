/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.CtaItem$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.CtaItem;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class CtaItem
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="ribbon_text")
    private final String b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CtaItem(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(string, parcel.readString());
    }

    public CtaItem(String string, String string2) {
        l.g((Object)string, (String)"text");
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CtaItem)) break block3;
                CtaItem ctaItem = (CtaItem)object;
                if (l.c((Object)this.a, (Object)ctaItem.a) && l.c((Object)this.b, (Object)ctaItem.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = 0;
        if (string2 != null) {
            n4 = string2.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CtaItem(text=");
        stringBuilder.append(this.a);
        stringBuilder.append(", ribbonText=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }
}

