/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.ucshared.models.PackageItemCart$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Set
 *  t1.r.e.b.a.b
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.ucshared.models.PackageItemCart;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import java.util.HashMap;
import java.util.Set;
import t1.r.e.b.a.b;

public class PackageItemCart
implements b<NewPackageItemModel>,
Parcelable {
    public static final Parcelable.Creator<PackageItemCart> CREATOR = new a();
    public HashMap<String, NewPackageItemModel> a = new HashMap();
    public int b;

    public PackageItemCart() {
    }

    public PackageItemCart(Parcel parcel) {
        this.b = parcel.readInt();
        int n2 = parcel.readInt();
        for (int i2 = 0; i2 < n2; ++i2) {
            this.a.put((Object)parcel.readString(), (Object)((NewPackageItemModel)parcel.readParcelable(NewPackageItemModel.class.getClassLoader())));
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeInt(this.b);
        parcel.writeInt(this.a.size());
        for (String string : this.a.keySet()) {
            parcel.writeString(string);
            parcel.writeParcelable((Parcelable)this.a.get((Object)string), n2);
        }
    }
}

