/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class SubscriptionLoader
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="color")
    private final String b;

    public SubscriptionLoader(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString());
    }

    public SubscriptionLoader(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<SubscriptionLoader> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SubscriptionLoader a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SubscriptionLoader(parcel);
        }

        public SubscriptionLoader[] b(int n) {
            return new SubscriptionLoader[n];
        }
    }

}

