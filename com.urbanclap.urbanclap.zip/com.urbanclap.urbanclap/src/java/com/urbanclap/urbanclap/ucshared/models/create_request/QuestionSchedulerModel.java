/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.LocationModel
 *  com.urbanclap.urbanclap.ucshared.models.SlotModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionSchedulerModel$MetaData
 *  java.lang.CharSequence
 *  java.lang.String
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.LocationModel;
import com.urbanclap.urbanclap.ucshared.models.SlotModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionSchedulerModel;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

public class QuestionSchedulerModel
extends QuestionBaseModel
implements Parcelable {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;
    public String H;

    public SlotModel A() {
        return this.z().a();
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
        parcel.writeString(this.H);
    }

    public boolean x() {
        return this.z().b(this.i());
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        LocationModel locationModel = this.i();
        if (this.s()) {
            if (locationModel != null && !TextUtils.isEmpty((CharSequence)locationModel.h())) {
                if (locationModel.d() != 0.0 && locationModel.e() != 0.0) {
                    if (TextUtils.isEmpty((CharSequence)locationModel.j())) {
                        l2.d(false);
                        l2.c(p.b.getString(m.j));
                        return l2;
                    }
                    if (this.A() == null) {
                        l2.d(false);
                        l2.c(p.b.getString(m.C));
                        return l2;
                    }
                    l2.d(true);
                    return l2;
                }
                l2.d(false);
                l2.c(p.b.getString(m.n));
                return l2;
            }
            l2.d(false);
            l2.c(p.b.getString(m.A));
            return l2;
        }
        l2.d(true);
        return l2;
    }

    public MetaData z() {
        return this.G;
    }
}

