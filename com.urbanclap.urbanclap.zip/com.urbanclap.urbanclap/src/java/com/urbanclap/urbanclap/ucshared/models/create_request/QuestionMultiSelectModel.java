/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiSelectModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiSelectModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.SingleSelectAndMultiSelectOptionModel
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.i
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiSelectModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.SingleSelectAndMultiSelectOptionModel;
import java.util.ArrayList;
import java.util.Iterator;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.i;
import t1.r.k.n.q0.q.l;

/*
 * Exception performing whole class analysis ignored.
 */
public class QuestionMultiSelectModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionMultiSelectModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public MetaData A() {
        return this.G;
    }

    public ArrayList<SingleSelectAndMultiSelectOptionModel> B() {
        return DataItem.a(this.A().b());
    }

    public String C() {
        return this.A().c();
    }

    public void D() {
        for (SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel : DataItem.a(this.A().b())) {
            if (!singleSelectAndMultiSelectOptionModel.t()) continue;
            singleSelectAndMultiSelectOptionModel.v(false);
        }
    }

    public String a() {
        ArrayList<String> arrayList = this.z();
        if (arrayList.size() > 0) {
            return TextUtils.join((CharSequence)", ", arrayList);
        }
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public Object m(Object object, Context context) {
        if (object instanceof i) {
            Iterator iterator = this.B().iterator();
            double d2 = 0.0;
            while (iterator.hasNext()) {
                SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel = (SingleSelectAndMultiSelectOptionModel)iterator.next();
                if (!singleSelectAndMultiSelectOptionModel.t() || singleSelectAndMultiSelectOptionModel.n() <= -1) continue;
                d2 += (double)singleSelectAndMultiSelectOptionModel.n();
            }
            ((i)object).v1(d2);
        }
        return null;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return MetaData.a(this.A());
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        if (this.s()) {
            Iterator iterator = this.B().iterator();
            while (iterator.hasNext()) {
                if (!((SingleSelectAndMultiSelectOptionModel)iterator.next()).t()) continue;
                l2.d(true);
                break;
            }
            if (!l2.b()) {
                l2.c(p.b.getString(m.y));
                return l2;
            }
        } else {
            l2.d(true);
        }
        return l2;
    }

    public ArrayList<String> z() {
        ArrayList arrayList = new ArrayList();
        for (SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel : DataItem.a(this.A().b())) {
            if (!singleSelectAndMultiSelectOptionModel.t()) continue;
            arrayList.add((Object)singleSelectAndMultiSelectOptionModel.a());
        }
        return arrayList;
    }
}

