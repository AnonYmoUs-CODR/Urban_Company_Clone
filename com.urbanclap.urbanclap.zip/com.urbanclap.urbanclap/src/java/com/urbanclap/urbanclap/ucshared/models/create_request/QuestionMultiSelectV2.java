/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$Section
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$CartModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$SectionItemModel
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.p$a
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import java.util.ArrayList;
import java.util.List;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

/*
 * Exception performing whole class analysis.
 */
public final class QuestionMultiSelectV2
extends QuestionCartWithAddOn {
    public ArrayList<String> H;

    public QuestionMultiSelectV2(Parcel parcel) {
        i2.a0.d.l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.H = parcel.readArrayList(String.class.getClassLoader());
    }

    @Override
    private final void B() {
        block5 : {
            ArrayList arrayList;
            String string;
            boolean bl;
            QuestionCartWithAddOn.MetaData metaData;
            block7 : {
                block6 : {
                    QuestionNewPackageModel.CartModel cartModel;
                    QuestionNewPackageModel.SectionItemModel sectionItemModel;
                    QuestionCartWithAddOn.Data data;
                    ArrayList<String> arrayList2;
                    ArrayList arrayList3;
                    QuestionCartWithAddOn.MetaData metaData2 = this.z();
                    string = metaData2 != null && (data = metaData2.a()) != null && (cartModel = data.b()) != null && (arrayList3 = cartModel.q()) != null && (sectionItemModel = arrayList3.get(0)) != null ? sectionItemModel.o() : null;
                    QuestionCartWithAddOn.MetaData metaData3 = this.z();
                    if (metaData3 != null) {
                        metaData3.c(new ArrayList());
                    }
                    if ((arrayList2 = this.H) == null) break block5;
                    if (arrayList2 == null) break block6;
                    boolean bl2 = arrayList2.isEmpty();
                    bl = false;
                    if (!bl2) break block7;
                }
                bl = true;
            }
            if (!bl && (metaData = this.z()) != null && (arrayList = metaData.b()) != null) {
                ArrayList arrayList4 = new ArrayList();
                ArrayList<String> arrayList5 = this.H;
                i2.a0.d.l.e(arrayList5);
                arrayList4.add(arrayList5);
                i2.a0.d.l.e((Object)string);
                arrayList.add((Object)new /* Unavailable Anonymous Inner Class!! */);
            }
        }
    }

    public final ArrayList<String> C() {
        if (this.H == null) {
            this.H = new ArrayList();
        }
        ArrayList<String> arrayList = this.H;
        i2.a0.d.l.e(arrayList);
        return arrayList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int n2) {
        i2.a0.d.l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeList(this.H);
    }

    @Override
    public boolean x() {
        ArrayList<String> arrayList = this.H;
        if (arrayList == null) {
            return false;
        }
        Integer n2 = arrayList != null ? Integer.valueOf((int)arrayList.size()) : null;
        i2.a0.d.l.e((Object)n2);
        int n3 = n2;
        boolean bl = false;
        if (n3 > 0) {
            bl = true;
        }
        return bl;
    }

    @Override
    public l y(int n2, float f2, String string) {
        ArrayList arrayList;
        QuestionCartWithAddOn.MetaData metaData;
        this.B();
        if (this.s() && (metaData = this.z()) != null && (arrayList = metaData.b()) != null) {
            boolean bl = arrayList == null || arrayList.isEmpty();
            if (bl) {
                l l2 = new l();
                l2.d(false);
                l2.c(p.d.a().getString(m.k));
                return l2;
            }
        }
        l l3 = new l();
        l3.d(true);
        return l3;
    }
}

