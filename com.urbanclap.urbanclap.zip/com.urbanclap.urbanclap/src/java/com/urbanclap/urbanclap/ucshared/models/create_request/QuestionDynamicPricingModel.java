/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$ConfigModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$ItemGroup
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$PriceModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel$b
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$CartModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$PricingModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$PricingStrategy
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.j
 *  i2.k
 *  i2.t
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 *  java.util.Set
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.p$a
 *  t1.r.k.n.q0.q.a
 *  t1.r.k.n.q0.q.h
 *  t1.r.k.n.q0.q.l
 *  t1.r.k.n.s
 *  t1.r.k.n.s$a
 *  t1.r.k.n.t0.a
 *  t1.r.k.n.t0.b
 *  t1.r.k.n.t0.c
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.DynamicPricingPrefillModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import i2.a0.d.g;
import i2.a0.d.l;
import i2.j;
import i2.k;
import i2.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.h;
import t1.r.k.n.s;
import t1.r.k.n.t0.c;

/*
 * Exception performing whole class analysis.
 */
public final class QuestionDynamicPricingModel
extends QuestionBaseModel
implements t1.r.k.n.t0.a {
    @Expose
    @SerializedName(value="meta_data")
    private final MetaData G;
    public t1.r.k.n.t0.b H;
    public LinkedHashMap<NewPackageItemModel.ItemGroup, ArrayList<NewPackageItemModel>> I;
    public a J;

    public QuestionDynamicPricingModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.G = parcel.readParcelable(j.class.getClassLoader());
        this.I = new LinkedHashMap();
    }

    public final LinkedHashMap<NewPackageItemModel.ItemGroup, ArrayList<NewPackageItemModel>> A() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        MetaData metaData = this.G;
        if (metaData != null) {
            QuestionNewPackageModel.DataItem dataItem = metaData.a();
            l.e((Object)dataItem);
            QuestionNewPackageModel.CartModel cartModel = dataItem.b();
            l.f((Object)cartModel, (String)"metaData.cartData!!.cart");
            HashMap hashMap = cartModel.m();
            l.f((Object)hashMap, (String)"metaData.cartData!!.cart.itemsDictionary");
            for (Map.Entry entry : hashMap.entrySet()) {
                Object object = entry.getValue();
                l.f((Object)object, (String)"it.value");
                NewPackageItemModel.ItemGroup itemGroup = ((NewPackageItemModel)object).j();
                if (itemGroup == null) continue;
                if (linkedHashMap.containsKey((Object)itemGroup)) {
                    ArrayList arrayList = (ArrayList)linkedHashMap.get((Object)itemGroup);
                    l.e((Object)arrayList);
                    arrayList.add(entry.getValue());
                    linkedHashMap.put((Object)itemGroup, (Object)arrayList);
                    continue;
                }
                ArrayList arrayList = new ArrayList();
                arrayList.add(entry.getValue());
                linkedHashMap.put((Object)itemGroup, (Object)arrayList);
            }
        }
        return linkedHashMap;
    }

    public final MetaData B() {
        return this.G;
    }

    public DynamicPricingPrefillModel C() {
        QuestionNewPackageModel.PricingModel pricingModel;
        h h2;
        QuestionNewPackageModel.DataItem dataItem;
        MetaData metaData = this.G;
        LinkedHashMap linkedHashMap = metaData != null && (dataItem = metaData.a()) != null && (pricingModel = dataItem.e()) != null && (h2 = pricingModel.a()) != null ? h2.c() : null;
        return new DynamicPricingPrefillModel((HashMap<String, ArrayList<ArrayList<Double>>>)linkedHashMap);
    }

    public void C1(boolean bl, PackageCartItem packageCartItem) {
        l.g((Object)packageCartItem, (String)"packageCartItem");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An operation is not implemented: ");
        stringBuilder.append("not implemented");
        throw new k(stringBuilder.toString());
    }

    public void D(Object object, Context context) {
        block10 : {
            block13 : {
                block12 : {
                    LinkedHashMap linkedHashMap;
                    block11 : {
                        l.g((Object)context, (String)"context");
                        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel.DynamicPricingCallBackListners");
                        this.J = object;
                        MetaData metaData = this.G;
                        l.e((Object)metaData);
                        QuestionNewPackageModel.DataItem dataItem = metaData.a();
                        l.e((Object)dataItem);
                        QuestionNewPackageModel.PricingModel pricingModel = dataItem.e();
                        QuestionNewPackageModel.DataItem dataItem2 = this.G.a();
                        l.e((Object)dataItem2);
                        ArrayList arrayList = dataItem2.f();
                        LinkedHashMap<NewPackageItemModel.ItemGroup, ArrayList<NewPackageItemModel>> linkedHashMap2 = this.A();
                        l.e(linkedHashMap2);
                        this.I = linkedHashMap2;
                        linkedHashMap = new LinkedHashMap();
                        s.a a2 = s.b;
                        l.f((Object)pricingModel, (String)"pricingModel");
                        QuestionNewPackageModel.PricingStrategy pricingStrategy = pricingModel.b();
                        l.f((Object)pricingStrategy, (String)"pricingModel.strategy");
                        l.f((Object)arrayList, (String)"sectionList");
                        a a3 = this.J;
                        if (a3 == null) break block10;
                        this.H = new t1.r.k.n.t0.b(a2.h(pricingStrategy, pricingModel, arrayList, a3.a()), (t1.r.k.n.t0.a)this, context);
                        if (!pricingModel.b().equals((Object)QuestionNewPackageModel.PricingStrategy.DYNAMIC)) break block11;
                        for (Map.Entry entry : this.I.entrySet()) {
                            ArrayList arrayList2 = new ArrayList();
                            Iterator iterator = ((Iterable)entry.getValue()).iterator();
                            String string = "";
                            while (iterator.hasNext()) {
                                NewPackageItemModel newPackageItemModel = (NewPackageItemModel)iterator.next();
                                ArrayList arrayList3 = newPackageItemModel.c();
                                NewPackageItemModel.ConfigModel configModel = newPackageItemModel.i();
                                l.f((Object)configModel, (String)"it.itemConfiguration");
                                int n2 = configModel.b();
                                if (!TextUtils.isEmpty((CharSequence)string)) {
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append(string);
                                    stringBuilder.append(",");
                                    string = stringBuilder.toString();
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(string);
                                stringBuilder.append(n2);
                                string = stringBuilder.toString();
                                String string2 = newPackageItemModel.k();
                                l.f((Object)string2, (String)"it.itemKey");
                                l.f((Object)arrayList3, (String)"catalogIds");
                                t1.r.k.n.q0.q.a a4 = new t1.r.k.n.q0.q.a(string2, (List)arrayList3, Integer.valueOf((int)n2), null, 8, null);
                                arrayList2.add((Object)a4);
                            }
                            t1.r.k.n.t0.b b2 = this.H;
                            if (b2 != null) {
                                b2.c(string, arrayList2);
                                continue;
                            }
                            l.v((String)"dynamicFragmentPricingManager");
                            throw null;
                        }
                        break block12;
                    }
                    Iterator iterator = this.I.entrySet().iterator();
                    while (iterator.hasNext()) {
                        for (NewPackageItemModel newPackageItemModel : (Iterable)((Map.Entry)iterator.next()).getValue()) {
                            NewPackageItemModel.ConfigModel configModel = newPackageItemModel.i();
                            l.f((Object)configModel, (String)"newPackageItemModel.itemConfiguration");
                            int n3 = configModel.b();
                            if (n3 <= 0) continue;
                            String string = newPackageItemModel.k();
                            l.f((Object)string, (String)"newPackageItemModel.itemKey");
                            NewPackageItemModel.ItemGroup itemGroup = newPackageItemModel.j();
                            l.f((Object)itemGroup, (String)"newPackageItemModel.itemGroup");
                            String string3 = itemGroup.a();
                            l.f((Object)string3, (String)"newPackageItemModel.itemGroup.key");
                            NewPackageItemModel.PriceModel priceModel = newPackageItemModel.q();
                            l.e((Object)priceModel);
                            l.f((Object)priceModel, (String)"newPackageItemModel.price!!");
                            if (linkedHashMap.containsKey((Object)new /* Unavailable Anonymous Inner Class!! */)) {
                                String string4 = newPackageItemModel.k();
                                l.f((Object)string4, (String)"newPackageItemModel.itemKey");
                                NewPackageItemModel.ItemGroup itemGroup2 = newPackageItemModel.j();
                                l.f((Object)itemGroup2, (String)"newPackageItemModel.itemGroup");
                                String string5 = itemGroup2.a();
                                l.f((Object)string5, (String)"newPackageItemModel.itemGroup.key");
                                NewPackageItemModel.PriceModel priceModel2 = newPackageItemModel.q();
                                l.e((Object)priceModel2);
                                l.f((Object)priceModel2, (String)"newPackageItemModel.price!!");
                                ArrayList arrayList = (ArrayList)linkedHashMap.get((Object)new /* Unavailable Anonymous Inner Class!! */);
                                l.e((Object)arrayList);
                                NewPackageItemModel.PriceModel priceModel3 = newPackageItemModel.q();
                                l.e((Object)priceModel3);
                                l.f((Object)priceModel3, (String)"newPackageItemModel.price!!");
                                arrayList.add((Object)(n3 * priceModel3.b()));
                                String string6 = newPackageItemModel.k();
                                l.f((Object)string6, (String)"newPackageItemModel.itemKey");
                                NewPackageItemModel.ItemGroup itemGroup3 = newPackageItemModel.j();
                                l.f((Object)itemGroup3, (String)"newPackageItemModel.itemGroup");
                                String string7 = itemGroup3.a();
                                l.f((Object)string7, (String)"newPackageItemModel.itemGroup.key");
                                NewPackageItemModel.PriceModel priceModel4 = newPackageItemModel.q();
                                l.e((Object)priceModel4);
                                l.f((Object)priceModel4, (String)"newPackageItemModel.price!!");
                                linkedHashMap.put((Object)new /* Unavailable Anonymous Inner Class!! */, (Object)arrayList);
                                continue;
                            }
                            ArrayList arrayList = new ArrayList();
                            NewPackageItemModel.PriceModel priceModel5 = newPackageItemModel.q();
                            l.e((Object)priceModel5);
                            l.f((Object)priceModel5, (String)"newPackageItemModel.price!!");
                            arrayList.add((Object)(n3 * priceModel5.b()));
                            String string8 = newPackageItemModel.k();
                            l.f((Object)string8, (String)"newPackageItemModel.itemKey");
                            NewPackageItemModel.ItemGroup itemGroup4 = newPackageItemModel.j();
                            l.f((Object)itemGroup4, (String)"newPackageItemModel.itemGroup");
                            String string9 = itemGroup4.a();
                            l.f((Object)string9, (String)"newPackageItemModel.itemGroup.key");
                            NewPackageItemModel.PriceModel priceModel6 = newPackageItemModel.q();
                            l.e((Object)priceModel6);
                            l.f((Object)priceModel6, (String)"newPackageItemModel.price!!");
                            linkedHashMap.put((Object)new /* Unavailable Anonymous Inner Class!! */, (Object)arrayList);
                        }
                    }
                    a a5 = this.J;
                    if (a5 == null) break block13;
                    a5.U7(linkedHashMap);
                }
                return;
            }
            l.v((String)"dynamicPricingCallBackListners");
            throw null;
        }
        l.v((String)"dynamicPricingCallBackListners");
        throw null;
    }

    public String a() {
        return null;
    }

    public void b0(int n2, int n3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An operation is not implemented: ");
        stringBuilder.append("not implemented");
        throw new k(stringBuilder.toString());
    }

    public int describeContents() {
        return 0;
    }

    public void m0(LinkedHashMap<String, ArrayList<ArrayList<Double>>> linkedHashMap) {
        l.g(linkedHashMap, (String)"priceMapReceived");
        MetaData metaData = this.G;
        l.e((Object)metaData);
        QuestionNewPackageModel.DataItem dataItem = metaData.a();
        l.e((Object)dataItem);
        QuestionNewPackageModel.PricingModel pricingModel = dataItem.e();
        l.f((Object)pricingModel, (String)"metaData!!.cartData!!.pricingModel");
        LinkedHashMap linkedHashMap2 = pricingModel.a().c();
        l.e((Object)linkedHashMap2);
        linkedHashMap2.putAll(linkedHashMap);
    }

    public void s0(ArrayList<ArrayList<Double>> arrayList) {
        ArrayList<ArrayList<Double>> arrayList2 = arrayList;
        l.g(arrayList2, (String)"lookupKeysPrices");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        MetaData metaData = this.G;
        l.e((Object)metaData);
        QuestionNewPackageModel.DataItem dataItem = metaData.a();
        l.e((Object)dataItem);
        QuestionNewPackageModel.PricingModel pricingModel = dataItem.e();
        Iterator iterator = this.I.entrySet().iterator();
        while (iterator.hasNext()) {
            for (NewPackageItemModel newPackageItemModel : (Iterable)((Map.Entry)iterator.next()).getValue()) {
                NewPackageItemModel.ConfigModel configModel = newPackageItemModel.i();
                l.f((Object)configModel, (String)"it.itemConfiguration");
                if (configModel.b() > 0) {
                    l.f((Object)pricingModel, (String)"pricingModel");
                    LinkedHashMap linkedHashMap2 = pricingModel.a().b();
                    l.e((Object)linkedHashMap2);
                    Integer n2 = (Integer)linkedHashMap2.get((Object)newPackageItemModel.k());
                    l.e((Object)n2);
                    Object object = arrayList2.get(n2.intValue());
                    l.f((Object)object, (String)"lookupKeysPrices.get(index!!)");
                    Iterator iterator2 = ((Iterable)object).iterator();
                    while (iterator2.hasNext()) {
                        double d2 = ((Number)iterator2.next()).doubleValue();
                        String string = newPackageItemModel.k();
                        l.f((Object)string, (String)"it.itemKey");
                        NewPackageItemModel.ItemGroup itemGroup = newPackageItemModel.j();
                        l.f((Object)itemGroup, (String)"it.itemGroup");
                        String string2 = itemGroup.a();
                        l.f((Object)string2, (String)"it.itemGroup.key");
                        NewPackageItemModel.PriceModel priceModel = newPackageItemModel.q();
                        l.e((Object)priceModel);
                        QuestionNewPackageModel.PricingModel pricingModel2 = pricingModel;
                        l.f((Object)priceModel, (String)"it.price!!");
                        if (linkedHashMap.containsKey((Object)new /* Unavailable Anonymous Inner Class!! */)) {
                            String string3 = newPackageItemModel.k();
                            l.f((Object)string3, (String)"it.itemKey");
                            NewPackageItemModel.ItemGroup itemGroup2 = newPackageItemModel.j();
                            l.f((Object)itemGroup2, (String)"it.itemGroup");
                            String string4 = itemGroup2.a();
                            l.f((Object)string4, (String)"it.itemGroup.key");
                            NewPackageItemModel.PriceModel priceModel2 = newPackageItemModel.q();
                            l.e((Object)priceModel2);
                            l.f((Object)priceModel2, (String)"it.price!!");
                            ArrayList arrayList3 = (ArrayList)linkedHashMap.get((Object)new /* Unavailable Anonymous Inner Class!! */);
                            l.e((Object)arrayList3);
                            arrayList3.add((Object)((int)d2));
                            String string5 = newPackageItemModel.k();
                            l.f((Object)string5, (String)"it.itemKey");
                            NewPackageItemModel.ItemGroup itemGroup3 = newPackageItemModel.j();
                            l.f((Object)itemGroup3, (String)"it.itemGroup");
                            String string6 = itemGroup3.a();
                            l.f((Object)string6, (String)"it.itemGroup.key");
                            NewPackageItemModel.PriceModel priceModel3 = newPackageItemModel.q();
                            l.e((Object)priceModel3);
                            l.f((Object)priceModel3, (String)"it.price!!");
                            linkedHashMap.put((Object)new /* Unavailable Anonymous Inner Class!! */, (Object)arrayList3);
                        } else {
                            ArrayList arrayList4 = new ArrayList();
                            arrayList4.add((Object)((int)d2));
                            String string7 = newPackageItemModel.k();
                            l.f((Object)string7, (String)"it.itemKey");
                            NewPackageItemModel.ItemGroup itemGroup4 = newPackageItemModel.j();
                            l.f((Object)itemGroup4, (String)"it.itemGroup");
                            String string8 = itemGroup4.a();
                            l.f((Object)string8, (String)"it.itemGroup.key");
                            NewPackageItemModel.PriceModel priceModel4 = newPackageItemModel.q();
                            l.e((Object)priceModel4);
                            l.f((Object)priceModel4, (String)"it.price!!");
                            linkedHashMap.put((Object)new /* Unavailable Anonymous Inner Class!! */, (Object)arrayList4);
                        }
                        pricingModel = pricingModel2;
                    }
                }
                QuestionNewPackageModel.PricingModel pricingModel3 = pricingModel;
                arrayList2 = arrayList;
                pricingModel = pricingModel3;
            }
            arrayList2 = arrayList;
        }
        a a2 = this.J;
        if (a2 != null) {
            a2.U7(linkedHashMap);
            return;
        }
        l.v((String)"dynamicPricingCallBackListners");
        throw null;
    }

    public void t(Object object) {
        QuestionNewPackageModel.PricingModel pricingModel;
        QuestionNewPackageModel.DataItem dataItem;
        h h2;
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.DynamicPricingPrefillModel");
        DynamicPricingPrefillModel dynamicPricingPrefillModel = (DynamicPricingPrefillModel)((Object)object);
        MetaData metaData = this.G;
        if (metaData != null && (dataItem = metaData.a()) != null && (pricingModel = dataItem.e()) != null && (h2 = pricingModel.a()) != null) {
            HashMap<String, ArrayList<ArrayList<Double>>> hashMap = dynamicPricingPrefillModel.a();
            l.e(hashMap);
            h2.e(hashMap);
        }
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        ArrayList arrayList;
        MetaData metaData = this.G;
        int n2 = metaData != null && (arrayList = metaData.b()) != null ? arrayList.size() : 0;
        boolean bl = false;
        if (n2 > 0) {
            bl = true;
        }
        return bl;
    }

    public t1.r.k.n.q0.q.l y(int n2, float f2, String string) {
        t1.r.k.n.q0.q.l l2 = new t1.r.k.n.q0.q.l();
        ArrayList<NewPackageItemModel> arrayList = this.z();
        if (this.s() && arrayList.size() == 0) {
            l2.d(false);
            l2.c(p.d.a().getString(m.J));
            return l2;
        }
        l2.d(true);
        MetaData metaData = this.G;
        if (metaData != null) {
            metaData.c(arrayList);
        }
        return l2;
    }

    public void y6(HashMap<String, Integer> hashMap, PackageCartItem packageCartItem, NewPackageItemModel newPackageItemModel) {
        l.g((Object)packageCartItem, (String)"packageCartItem");
        l.g((Object)newPackageItemModel, (String)"item");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An operation is not implemented: ");
        stringBuilder.append("not implemented");
        throw new k(stringBuilder.toString());
    }

    public final ArrayList<NewPackageItemModel> z() {
        HashMap hashMap;
        QuestionNewPackageModel.CartModel cartModel;
        QuestionNewPackageModel.DataItem dataItem;
        HashMap hashMap2 = new HashMap();
        hashMap2.putAll(((CartRepository)CartRepository.l.a()).t());
        Set set = hashMap2.keySet();
        MetaData metaData = this.G;
        Set set2 = metaData != null && (dataItem = metaData.a()) != null && (cartModel = dataItem.b()) != null && (hashMap = cartModel.m()) != null ? hashMap.keySet() : null;
        l.e(set2);
        l.f(set2, (String)"metaData?.cartData?.cart?.itemsDictionary?.keys!!");
        set.retainAll(set2);
        ArrayList arrayList = new ArrayList();
        Iterator iterator = hashMap2.values().iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((PackageCartItem)iterator.next()).c());
        }
        return arrayList;
    }
}

