/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.subscription;

public final class SubscriptionPlanBottomSheetSource
extends Enum<SubscriptionPlanBottomSheetSource> {
    private static final /* synthetic */ SubscriptionPlanBottomSheetSource[] $VALUES;
    public static final /* enum */ SubscriptionPlanBottomSheetSource BPR;
    public static final /* enum */ SubscriptionPlanBottomSheetSource SUMMARY;
    public static final /* enum */ SubscriptionPlanBottomSheetSource TRIAL_SUBSCRIPTION_ACTIVITY;
    private final String value;

    public static {
        SubscriptionPlanBottomSheetSource subscriptionPlanBottomSheetSource;
        SubscriptionPlanBottomSheetSource subscriptionPlanBottomSheetSource2;
        SubscriptionPlanBottomSheetSource subscriptionPlanBottomSheetSource3;
        SubscriptionPlanBottomSheetSource[] arrsubscriptionPlanBottomSheetSource = new SubscriptionPlanBottomSheetSource[3];
        BPR = subscriptionPlanBottomSheetSource3 = new SubscriptionPlanBottomSheetSource("bpr");
        arrsubscriptionPlanBottomSheetSource[0] = subscriptionPlanBottomSheetSource3;
        TRIAL_SUBSCRIPTION_ACTIVITY = subscriptionPlanBottomSheetSource2 = new SubscriptionPlanBottomSheetSource("review");
        arrsubscriptionPlanBottomSheetSource[1] = subscriptionPlanBottomSheetSource2;
        SUMMARY = subscriptionPlanBottomSheetSource = new SubscriptionPlanBottomSheetSource("summary");
        arrsubscriptionPlanBottomSheetSource[2] = subscriptionPlanBottomSheetSource;
        $VALUES = arrsubscriptionPlanBottomSheetSource;
    }

    private SubscriptionPlanBottomSheetSource(String string2) {
        this.value = string2;
    }

    public static SubscriptionPlanBottomSheetSource valueOf(String string) {
        return (SubscriptionPlanBottomSheetSource)Enum.valueOf(SubscriptionPlanBottomSheetSource.class, (String)string);
    }

    public static SubscriptionPlanBottomSheetSource[] values() {
        return (SubscriptionPlanBottomSheetSource[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

