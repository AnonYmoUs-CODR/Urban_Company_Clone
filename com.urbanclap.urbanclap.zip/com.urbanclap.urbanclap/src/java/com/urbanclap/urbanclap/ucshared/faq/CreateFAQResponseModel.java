/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.faq.FAQItemModel
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 */
package com.urbanclap.urbanclap.ucshared.faq;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.faq.FAQItemModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

@SuppressLint(value={"ParcelCreator"})
public final class CreateFAQResponseModel
extends ResponseBaseModel {
    @SerializedName(value="faq")
    private final FAQItemModel e;

    public final FAQItemModel e() {
        return this.e;
    }
}

