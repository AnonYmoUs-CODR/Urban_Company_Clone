/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriberAnimationDetail;
import i2.a0.d.l;

public final class SubscriptionDetail
implements Parcelable {
    public static final Parcelable.Creator<SubscriptionDetail> CREATOR = new Parcelable.Creator<SubscriptionDetail>(){

        public SubscriptionDetail a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new SubscriptionDetail(parcel);
        }

        public SubscriptionDetail[] b(int n) {
            return new SubscriptionDetail[n];
        }
    };
    @SerializedName(value="animation_detail")
    private final SubscriberAnimationDetail a;

    public SubscriptionDetail(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this((SubscriberAnimationDetail)parcel.readParcelable(SubscriberAnimationDetail.class.getClassLoader()));
    }

    public SubscriptionDetail(SubscriberAnimationDetail subscriberAnimationDetail) {
        this.a = subscriberAnimationDetail;
    }

    public final SubscriberAnimationDetail a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SubscriptionDetail)) break block3;
                SubscriptionDetail subscriptionDetail = (SubscriptionDetail)object;
                if (l.c((Object)this.a, (Object)subscriptionDetail.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        SubscriberAnimationDetail subscriberAnimationDetail = this.a;
        if (subscriberAnimationDetail != null) {
            return subscriberAnimationDetail.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SubscriptionDetail(subscriberAnimationDetail=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, 0);
    }

}

