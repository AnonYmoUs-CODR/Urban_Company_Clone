/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.amazon_generate_signature.response;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

@SuppressLint(value={"ParcelCreator"})
public class AmazonGenerateSignatureResponseModel
extends ResponseBaseModel {
    @SerializedName(value="payload")
    private String e;
    @SerializedName(value="key")
    private String f;
    @SerializedName(value="iv")
    private String g;
}

