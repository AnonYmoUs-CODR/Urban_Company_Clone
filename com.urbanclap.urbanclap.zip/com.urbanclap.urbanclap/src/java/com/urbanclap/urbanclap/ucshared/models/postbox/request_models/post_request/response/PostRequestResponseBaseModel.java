/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response.PostRequestResponseBaseModel$a
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response.PostRequestResponseBaseModel;
import i2.a0.d.l;

public class PostRequestResponseBaseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<PostRequestResponseBaseModel> CREATOR = new a();
    @SerializedName(value="is_templatized")
    private boolean e;

    public PostRequestResponseBaseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        boolean bl = parcel.readInt() != 0;
        this.e = bl;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeInt((int)this.e);
    }
}

