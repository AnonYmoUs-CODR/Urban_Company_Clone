/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class DividerTheme
implements Parcelable {
    public static final Parcelable.Creator<DividerTheme> CREATOR = new a();
    @SerializedName(value="show")
    private final boolean a;
    @SerializedName(value="color")
    private final String b;

    public DividerTheme(boolean bl, String string) {
        this.a = bl;
        this.b = string;
    }

    public final String a() {
        return this.b;
    }

    public final boolean b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DividerTheme)) break block3;
                DividerTheme dividerTheme = (DividerTheme)object;
                if (this.a == dividerTheme.a && l.c((Object)this.b, (Object)dividerTheme.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int n = this.a ? 1 : 0;
        if (n != 0) {
            n = 1;
        }
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DividerTheme(show=");
        stringBuilder.append(this.a);
        stringBuilder.append(", color=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeInt((int)this.a);
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<DividerTheme> {
        public final DividerTheme a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            boolean bl = parcel.readInt() != 0;
            return new DividerTheme(bl, parcel.readString());
        }

        public final DividerTheme[] b(int n) {
            return new DividerTheme[n];
        }
    }

}

