/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Header$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Header;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class Header
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="header_text")
    private final String a;
    @SerializedName(value="header_sub_heading")
    private final String b;
    @SerializedName(value="header_image")
    private final String c;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public Header(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        String string3 = parcel.readString();
        l.f((Object)string3, (String)"parcel.readString()");
        this(string, string2, string3);
    }

    public Header(String string, String string2, String string3) {
        l.g((Object)string, (String)"headerText");
        l.g((Object)string2, (String)"headerSubHeading");
        l.g((Object)string3, (String)"headerImage");
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Header)) break block3;
                Header header = (Header)object;
                if (l.c((Object)this.a, (Object)header.a) && l.c((Object)this.b, (Object)header.b) && l.c((Object)this.c, (Object)header.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string3 = this.c;
        int n6 = 0;
        if (string3 != null) {
            n6 = string3.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Header(headerText=");
        stringBuilder.append(this.a);
        stringBuilder.append(", headerSubHeading=");
        stringBuilder.append(this.b);
        stringBuilder.append(", headerImage=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.a);
        parcel.writeString(this.c);
    }
}

