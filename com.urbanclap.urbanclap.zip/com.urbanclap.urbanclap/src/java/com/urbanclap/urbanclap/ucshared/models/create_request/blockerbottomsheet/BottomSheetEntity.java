/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.BottomSheetEntity$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Body;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.BottomSheetEntity;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Cta;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Header;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class BottomSheetEntity
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="header")
    private final Header a;
    @SerializedName(value="body")
    private final Body b;
    @SerializedName(value="cta")
    private final Cta c;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public BottomSheetEntity(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(Header.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(He\u2026::class.java.classLoader)");
        Header header = (Header)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(Body.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Bo\u2026::class.java.classLoader)");
        Body body = (Body)parcelable2;
        Parcelable parcelable3 = parcel.readParcelable(Cta.class.getClassLoader());
        l.f((Object)parcelable3, (String)"parcel.readParcelable(Cta::class.java.classLoader)");
        this(header, body, (Cta)parcelable3);
    }

    public BottomSheetEntity(Header header, Body body, Cta cta) {
        l.g((Object)header, (String)"header");
        l.g((Object)body, (String)"body");
        l.g((Object)cta, (String)"cta");
        this.a = header;
        this.b = body;
        this.c = cta;
    }

    public final Body a() {
        return this.b;
    }

    public final Cta b() {
        return this.c;
    }

    public final Header c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof BottomSheetEntity)) break block3;
                BottomSheetEntity bottomSheetEntity = (BottomSheetEntity)object;
                if (l.c((Object)this.a, (Object)bottomSheetEntity.a) && l.c((Object)this.b, (Object)bottomSheetEntity.b) && l.c((Object)this.c, (Object)bottomSheetEntity.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Header header = this.a;
        int n2 = header != null ? header.hashCode() : 0;
        int n3 = n2 * 31;
        Body body = this.b;
        int n4 = body != null ? body.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        Cta cta = this.c;
        int n6 = 0;
        if (cta != null) {
            n6 = cta.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("BottomSheetEntity(header=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", body=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", cta=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n2);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeParcelable((Parcelable)this.c, n2);
    }
}

