/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CartWithAddonPrefillModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.CartWithAddonPrefillModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class CartWithAddonPrefillModel
extends BasePrefillAnswerModel {
    public static final a CREATOR;
    public HashMap<String, ArrayList<ArrayList<String>>> a;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CartWithAddonPrefillModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Serializable serializable = parcel.readSerializable();
        Objects.requireNonNull((Object)serializable, (String)"null cannot be cast to non-null type java.util.HashMap<kotlin.String, java.util.ArrayList<java.util.ArrayList<kotlin.String>>>");
        this((HashMap<String, ArrayList<ArrayList<String>>>)((HashMap)serializable));
    }

    public CartWithAddonPrefillModel(HashMap<String, ArrayList<ArrayList<String>>> hashMap) {
        l.g(hashMap, (String)"stepperSectionItemList");
        this.a = hashMap;
    }

    public final HashMap<String, ArrayList<ArrayList<String>>> a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CartWithAddonPrefillModel)) break block3;
                CartWithAddonPrefillModel cartWithAddonPrefillModel = (CartWithAddonPrefillModel)((Object)object);
                if (l.c(this.a, cartWithAddonPrefillModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        HashMap<String, ArrayList<ArrayList<String>>> hashMap = this.a;
        if (hashMap != null) {
            return hashMap.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CartWithAddonPrefillModel(stepperSectionItemList=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeSerializable(this.a);
    }
}

