/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CollectionPrefillModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.CollectionPrefillModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class CollectionPrefillModel
extends BasePrefillAnswerModel {
    public static final a CREATOR;
    public boolean a;
    public final ArrayList<BasePrefillAnswerModel> b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CollectionPrefillModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        ArrayList arrayList = parcel.readArrayList(BasePrefillAnswerModel.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel> /* = java.util.ArrayList<com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel> */");
        this((ArrayList<BasePrefillAnswerModel>)arrayList);
    }

    public CollectionPrefillModel(ArrayList<BasePrefillAnswerModel> arrayList) {
        l.g(arrayList, (String)"prefillModelList");
        this.b = arrayList;
    }

    public final ArrayList<BasePrefillAnswerModel> a() {
        return this.b;
    }

    public final boolean b() {
        return this.a;
    }

    public final void c(boolean bl) {
        this.a = bl;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CollectionPrefillModel)) break block3;
                CollectionPrefillModel collectionPrefillModel = (CollectionPrefillModel)((Object)object);
                if (l.c(this.b, collectionPrefillModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        ArrayList<BasePrefillAnswerModel> arrayList = this.b;
        if (arrayList != null) {
            return arrayList.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CollectionPrefillModel(prefillModelList=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        if (parcel != null) {
            parcel.writeList(this.b);
        }
    }
}

