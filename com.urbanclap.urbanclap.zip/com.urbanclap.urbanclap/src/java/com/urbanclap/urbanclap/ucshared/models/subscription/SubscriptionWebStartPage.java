/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

public final class SubscriptionWebStartPage
extends Enum<SubscriptionWebStartPage> {
    private static final /* synthetic */ SubscriptionWebStartPage[] $VALUES;
    public static final /* enum */ SubscriptionWebStartPage bottomTab;
    public static final /* enum */ SubscriptionWebStartPage bpr;
    public static final /* enum */ SubscriptionWebStartPage cart;
    public static final /* enum */ SubscriptionWebStartPage homescreen;
    public static final /* enum */ SubscriptionWebStartPage inTheFlow;
    public static final /* enum */ SubscriptionWebStartPage summary;

    public static {
        SubscriptionWebStartPage subscriptionWebStartPage;
        SubscriptionWebStartPage subscriptionWebStartPage2;
        SubscriptionWebStartPage subscriptionWebStartPage3;
        SubscriptionWebStartPage subscriptionWebStartPage4;
        SubscriptionWebStartPage subscriptionWebStartPage5;
        SubscriptionWebStartPage subscriptionWebStartPage6;
        SubscriptionWebStartPage[] arrsubscriptionWebStartPage = new SubscriptionWebStartPage[6];
        homescreen = subscriptionWebStartPage6 = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[0] = subscriptionWebStartPage6;
        cart = subscriptionWebStartPage4 = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[1] = subscriptionWebStartPage4;
        bpr = subscriptionWebStartPage5 = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[2] = subscriptionWebStartPage5;
        inTheFlow = subscriptionWebStartPage = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[3] = subscriptionWebStartPage;
        summary = subscriptionWebStartPage2 = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[4] = subscriptionWebStartPage2;
        bottomTab = subscriptionWebStartPage3 = new SubscriptionWebStartPage();
        arrsubscriptionWebStartPage[5] = subscriptionWebStartPage3;
        $VALUES = arrsubscriptionWebStartPage;
    }

    public static SubscriptionWebStartPage valueOf(String string) {
        return (SubscriptionWebStartPage)Enum.valueOf(SubscriptionWebStartPage.class, (String)string);
    }

    public static SubscriptionWebStartPage[] values() {
        return (SubscriptionWebStartPage[])$VALUES.clone();
    }
}

