/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.image;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Large
implements Parcelable {
    public static final Parcelable.Creator<Large> CREATOR = new Parcelable.Creator<Large>(){

        public Large a(Parcel parcel) {
            return new Large(parcel, null);
        }

        public Large[] b(int n) {
            return new Large[n];
        }
    };
    @SerializedName(value="low_res")
    public String a;
    @SerializedName(value="medium_res")
    public String b;
    @SerializedName(value="high_res")
    public String c;

    public Large(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
    }

    public /* synthetic */ Large(Parcel parcel, a a2) {
        this(parcel);
    }

    public Large(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public String a() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (!(object instanceof Large)) {
            return false;
        }
        Large large = (Large)object;
        boolean bl = this.c.equals((Object)large.c);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.b.equals((Object)large.b);
            bl2 = false;
            if (bl3) {
                boolean bl4 = this.a.equals((Object)large.a);
                bl2 = false;
                if (bl4) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

}

