/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.TextUtils
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.MutableLiveData
 *  com.urbanclap.urbanclap.ucshared.models.ModifiedPackageItemFields
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$ConfigModel
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$Status
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$a
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$b
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$c$a
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$d
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$e
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$f
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$g
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$h
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$i
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$j
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$k
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$l
 *  com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository$m
 *  i2.a0.c.a
 *  i2.a0.c.l
 *  i2.a0.c.p
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.f
 *  i2.h
 *  i2.t
 *  i2.x.d
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  t1.r.k.n.b0.g
 *  t1.r.k.n.q0.x.c
 *  t1.r.k.n.q0.x.c$a
 *  t1.r.k.n.q0.x.d
 *  t1.r.k.n.q0.x.f.a
 *  t1.r.k.n.q0.x.g.a
 */
package com.urbanclap.urbanclap.ucshared.models.uccart;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.urbanclap.urbanclap.ucshared.models.ModifiedPackageItemFields;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase;
import i2.a0.c.p;
import i2.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import t1.r.k.n.q0.x.c;

public final class CartRepository
implements t1.r.k.n.q0.x.d {
    public static final c l = new c(null);
    public final i2.f a = i2.h.b((i2.a0.c.a)l.a);
    public String b = "";
    public final HashMap<String, t1.r.k.n.q0.x.g.a> c = new HashMap();
    public final HashMap<String, PackageCartItem> d = new HashMap();
    public String e = "";
    public MutableLiveData<Status> f = new MutableLiveData();
    public MutableLiveData<PackageCartItem> g = new MutableLiveData();
    public final MutableLiveData<PackageCartItem> h;
    public final LiveData<PackageCartItem> i;
    public final MutableLiveData<List<ModifiedPackageItemFields>> j;
    public final LiveData<List<ModifiedPackageItemFields>> k;

    public CartRepository(Context context) {
        MutableLiveData mutableLiveData;
        MutableLiveData mutableLiveData2;
        this.h = mutableLiveData = new MutableLiveData();
        this.i = mutableLiveData;
        this.j = mutableLiveData2 = new MutableLiveData();
        this.k = mutableLiveData2;
        this.f.setValue((Object)Status.INACTIVE);
        UCDatabase.l.b((Object)context);
        t1.r.k.n.q0.x.c.a.a((i2.a0.c.l)new a(this, null));
    }

    public /* synthetic */ CartRepository(Context context, i2.a0.d.g g2) {
        this(context);
    }

    public static final /* synthetic */ HashMap h(CartRepository cartRepository) {
        return cartRepository.d;
    }

    public static final /* synthetic */ HashMap i(CartRepository cartRepository) {
        return cartRepository.c;
    }

    public static final /* synthetic */ UCDatabase j(CartRepository cartRepository) {
        return cartRepository.x();
    }

    public static final /* synthetic */ MutableLiveData k(CartRepository cartRepository) {
        return cartRepository.h;
    }

    public static final /* synthetic */ t1.r.k.n.q0.x.g.a l(CartRepository cartRepository, PackageCartItem packageCartItem) {
        return cartRepository.C(packageCartItem);
    }

    public static final /* synthetic */ void m(CartRepository cartRepository) {
        cartRepository.G();
    }

    public boolean A() {
        Iterator iterator = this.d.values().iterator();
        while (iterator.hasNext()) {
            NewPackageItemModel newPackageItemModel = ((PackageCartItem)iterator.next()).c();
            i2.a0.d.l.f((Object)newPackageItemModel, (String)"item.getmItem()");
            if (TextUtils.isEmpty((CharSequence)newPackageItemModel.a())) continue;
            return true;
        }
        return false;
    }

    public boolean B() {
        Iterator iterator = this.d.values().iterator();
        boolean bl = false;
        boolean bl2 = false;
        while (iterator.hasNext()) {
            NewPackageItemModel newPackageItemModel = ((PackageCartItem)iterator.next()).c();
            i2.a0.d.l.f((Object)newPackageItemModel, (String)"item.getmItem()");
            String string = newPackageItemModel.a();
            boolean bl3 = string == null || string.length() == 0;
            if (bl3) {
                bl2 = true;
                continue;
            }
            bl = true;
        }
        boolean bl4 = false;
        if (bl) {
            bl4 = false;
            if (!bl2) {
                bl4 = true;
            }
        }
        return bl4;
    }

    public final t1.r.k.n.q0.x.g.a C(PackageCartItem packageCartItem) {
        String string = packageCartItem.id();
        i2.a0.d.l.f((Object)string, (String)"packageCartItem.id()");
        NewPackageItemModel newPackageItemModel = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel, (String)"packageCartItem.getmItem()");
        String string2 = this.s(string, newPackageItemModel.a());
        NewPackageItemModel newPackageItemModel2 = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel2, (String)"packageCartItem.getmItem()");
        NewPackageItemModel.ConfigModel configModel = newPackageItemModel2.i();
        i2.a0.d.l.f((Object)configModel, (String)"packageCartItem.getmItem().itemConfiguration");
        int n2 = configModel.b();
        String string3 = packageCartItem.a();
        i2.a0.d.l.f((Object)string3, (String)"packageCartItem.sectionKey");
        String string4 = this.e;
        String string5 = this.b;
        NewPackageItemModel newPackageItemModel3 = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel3, (String)"packageCartItem.getmItem()");
        t1.r.k.n.q0.x.g.a a2 = new t1.r.k.n.q0.x.g.a(string2, n2, string3, string4, string5, newPackageItemModel3.m());
        return a2;
    }

    public final void D(boolean bl) {
    }

    public void E(PackageCartItem packageCartItem, i2.a0.c.a<t> a2) {
        i2.a0.d.l.g((Object)packageCartItem, (String)"packageCartItem");
        NewPackageItemModel newPackageItemModel = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel, (String)"packageCartItem.getmItem()");
        String string = newPackageItemModel.k();
        i2.a0.d.l.f((Object)string, (String)"packageCartItem.getmItem().itemKey");
        NewPackageItemModel newPackageItemModel2 = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel2, (String)"packageCartItem.getmItem()");
        String string2 = this.s(string, newPackageItemModel2.a());
        if (this.d.get((Object)string2) != null) {
            t1.r.k.n.q0.x.g.a a3 = this.C(packageCartItem);
            c.a a4 = t1.r.k.n.q0.x.c.a;
            m m2 = new m(this, a3, string2, packageCartItem, a2, null);
            a4.a((i2.a0.c.l)m2);
        }
    }

    public void F(List<ModifiedPackageItemFields> list) {
        i2.a0.d.l.g(list, (String)"modifiedPackageItemFields");
        this.j.postValue(list);
    }

    public final void G() {
        this.c.clear();
        for (t1.r.k.n.q0.x.g.a a2 : this.x().m().j()) {
            this.c.put((Object)a2.c(), (Object)a2);
        }
    }

    public int a(String string, String string2) {
        NewPackageItemModel.ConfigModel configModel;
        NewPackageItemModel newPackageItemModel;
        i2.a0.d.l.g((Object)string, (String)"uuid");
        PackageCartItem packageCartItem = (PackageCartItem)this.d.get((Object)this.s(string, string2));
        if (packageCartItem != null && (newPackageItemModel = packageCartItem.c()) != null && (configModel = newPackageItemModel.i()) != null) {
            return configModel.b();
        }
        return 0;
    }

    public void b(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"city");
        i2.a0.d.l.g((Object)string2, (String)"category");
        if (!string.equals((Object)this.b)) {
            this.d.clear();
        }
        this.b = string;
        this.e = string2;
    }

    public void c() {
        this.d.clear();
        this.o(this.e, this.b);
    }

    public void d(ArrayList<PackageCartItem> arrayList, p<? super PackageCartItem, ? super String, Boolean> p2) {
        i2.a0.d.l.g(arrayList, (String)"packageList");
        ArrayList arrayList2 = new ArrayList();
        for (PackageCartItem packageCartItem : arrayList) {
            NewPackageItemModel newPackageItemModel = packageCartItem.c();
            i2.a0.d.l.f((Object)newPackageItemModel, (String)"item.getmItem()");
            String string = newPackageItemModel.k();
            i2.a0.d.l.f((Object)string, (String)"item.getmItem().itemKey");
            NewPackageItemModel newPackageItemModel2 = packageCartItem.c();
            i2.a0.d.l.f((Object)newPackageItemModel2, (String)"item.getmItem()");
            String string2 = this.s(string, newPackageItemModel2.a());
            arrayList2.add((Object)string2);
            if (!this.c.containsKey((Object)string2)) continue;
            if (p2 != null) {
                i2.a0.d.l.f((Object)packageCartItem, (String)"item");
                t1.r.k.n.q0.x.g.a a2 = (t1.r.k.n.q0.x.g.a)this.c.get((Object)string2);
                String string3 = a2 != null ? a2.d() : null;
                if (!((Boolean)p2.invoke((Object)packageCartItem, (Object)string3)).booleanValue()) continue;
            }
            NewPackageItemModel newPackageItemModel3 = packageCartItem.c();
            i2.a0.d.l.f((Object)newPackageItemModel3, (String)"item.getmItem()");
            NewPackageItemModel.ConfigModel configModel = newPackageItemModel3.i();
            i2.a0.d.l.f((Object)configModel, (String)"item.getmItem().itemConfiguration");
            t1.r.k.n.q0.x.g.a a3 = (t1.r.k.n.q0.x.g.a)this.c.get((Object)string2);
            Integer n2 = null;
            if (a3 != null) {
                n2 = a3.e();
            }
            i2.a0.d.l.e(n2);
            configModel.i(n2.intValue());
            HashMap<String, PackageCartItem> hashMap = this.d;
            i2.a0.d.l.f((Object)packageCartItem, (String)"item");
            hashMap.put((Object)string2, (Object)packageCartItem);
        }
        for (t1.r.k.n.q0.x.g.a a4 : this.c.values()) {
            if (!i2.a0.d.l.c((Object)a4.a(), (Object)this.e) || !i2.a0.d.l.c((Object)a4.b(), (Object)this.b) || arrayList2.contains((Object)a4.c()) || !this.d.containsKey((Object)a4.c())) continue;
            this.d.remove((Object)a4.c());
        }
        this.f.setValue((Object)Status.ACTIVE);
    }

    public List<PackageCartItem> e() {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.d.values());
        return arrayList;
    }

    public String f(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"uuid");
        t1.r.k.n.q0.x.g.a a2 = (t1.r.k.n.q0.x.g.a)this.c.get((Object)this.s(string, string2));
        String string3 = a2 != null ? a2.a() : null;
        if (string3 != null) {
            return string3;
        }
        return "NA";
    }

    public void g(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"packageId");
        if (this.f.getValue() == Status.ACTIVE) {
            this.f.setValue((Object)Status.WORKING);
            t1.r.k.n.q0.x.c.a.a((i2.a0.c.l)new f(this, string, string2, null));
        }
    }

    public void n(i2.a0.c.a<t> a2) {
        this.f.setValue((Object)Status.WORKING);
        t1.r.k.n.q0.x.c.a.a((i2.a0.c.l)new d(this, a2, null));
    }

    public void o(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"category");
        i2.a0.d.l.g((Object)string2, (String)"city");
        if (this.f.getValue() == Status.ACTIVE) {
            this.f.setValue((Object)Status.WORKING);
            t1.r.k.n.q0.x.c.a.a((i2.a0.c.l)new e(this, string, string2, null));
        }
    }

    public void p(List<String> list, i2.a0.c.a<t> a2) {
        i2.a0.d.l.g(list, (String)"packageIds");
        this.f.postValue((Object)Status.WORKING);
        t1.r.k.n.q0.x.c.a.a((i2.a0.c.l)new g(this, list, a2, null));
    }

    public void q(String string, PackageCartItem packageCartItem, b b2) {
        NewPackageItemModel.ConfigModel configModel;
        i2.a0.d.l.g((Object)string, (String)"uuid");
        i2.a0.d.l.g((Object)packageCartItem, (String)"packageCartItem");
        this.f.setValue((Object)Status.WORKING);
        NewPackageItemModel newPackageItemModel = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel, (String)"packageCartItem.getmItem()");
        String string2 = this.s(string, newPackageItemModel.a());
        if (string2 == null) {
            string2 = "";
        }
        PackageCartItem packageCartItem2 = (PackageCartItem)this.d.get((Object)string2);
        if (packageCartItem2 != null) {
            NewPackageItemModel.ConfigModel configModel2;
            NewPackageItemModel.ConfigModel configModel3;
            NewPackageItemModel newPackageItemModel2 = packageCartItem2.c();
            if (newPackageItemModel2 != null && (configModel3 = newPackageItemModel2.i()) != null) {
                NewPackageItemModel.ConfigModel configModel4;
                NewPackageItemModel newPackageItemModel3 = packageCartItem2.c();
                Integer n2 = newPackageItemModel3 != null && (configModel4 = newPackageItemModel3.i()) != null ? Integer.valueOf((int)configModel4.b()) : null;
                i2.a0.d.l.e(n2);
                configModel3.i(-1 + n2);
            }
            NewPackageItemModel newPackageItemModel4 = packageCartItem.c();
            i2.a0.d.l.f((Object)newPackageItemModel4, (String)"packageCartItem.getmItem()");
            NewPackageItemModel.ConfigModel configModel5 = newPackageItemModel4.i();
            i2.a0.d.l.f((Object)configModel5, (String)"packageCartItem.getmItem().itemConfiguration");
            NewPackageItemModel newPackageItemModel5 = packageCartItem2.c();
            Integer n3 = newPackageItemModel5 != null && (configModel2 = newPackageItemModel5.i()) != null ? Integer.valueOf((int)configModel2.b()) : null;
            i2.a0.d.l.e(n3);
            configModel5.i(n3.intValue());
            NewPackageItemModel newPackageItemModel6 = packageCartItem2.c();
            Integer n4 = null;
            if (newPackageItemModel6 != null) {
                NewPackageItemModel.ConfigModel configModel6 = newPackageItemModel6.i();
                n4 = null;
                if (configModel6 != null) {
                    n4 = configModel6.b();
                }
            }
            i2.a0.d.l.e(n4);
            if (n4 <= 0) {
                c.a a2 = t1.r.k.n.q0.x.c.a;
                h h2 = new h(this, packageCartItem2, string2, packageCartItem, b2, null);
                a2.a((i2.a0.c.l)h2);
                return;
            }
            c.a a3 = t1.r.k.n.q0.x.c.a;
            i i2 = new i(this, string2, packageCartItem, b2, packageCartItem2, null);
            a3.a((i2.a0.c.l)i2);
            return;
        }
        NewPackageItemModel newPackageItemModel7 = packageCartItem.c();
        if (newPackageItemModel7 != null && (configModel = newPackageItemModel7.i()) != null) {
            NewPackageItemModel newPackageItemModel8 = packageCartItem.c();
            Integer n5 = null;
            if (newPackageItemModel8 != null) {
                NewPackageItemModel.ConfigModel configModel7 = newPackageItemModel8.i();
                n5 = null;
                if (configModel7 != null) {
                    n5 = configModel7.b();
                }
            }
            i2.a0.d.l.e(n5);
            configModel.i(-1 + n5);
        }
        this.f.postValue((Object)Status.ACTIVE);
        this.g.postValue((Object)packageCartItem);
        new Handler(Looper.getMainLooper()).post((Runnable)new j(b2, packageCartItem));
    }

    public PackageCartItem r(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"itemKey");
        return (PackageCartItem)this.d.get((Object)this.s(string, string2));
    }

    public String s(String string, String string2) {
        i2.a0.d.l.g((Object)string, (String)"itemKey");
        if (string2 == null) {
            return string;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append('#');
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public Map<String, PackageCartItem> t() {
        return this.d;
    }

    public final MutableLiveData<Status> u() {
        return this.f;
    }

    public final LiveData<PackageCartItem> v() {
        return this.i;
    }

    public final MutableLiveData<PackageCartItem> w() {
        return this.g;
    }

    public final UCDatabase x() {
        return (UCDatabase)((Object)this.a.getValue());
    }

    public final LiveData<List<ModifiedPackageItemFields>> y() {
        return this.k;
    }

    public void z(String string, PackageCartItem packageCartItem, b b2) {
        NewPackageItemModel newPackageItemModel;
        NewPackageItemModel.ConfigModel configModel;
        i2.a0.d.l.g((Object)string, (String)"uuid");
        i2.a0.d.l.g((Object)packageCartItem, (String)"packageCartItem");
        NewPackageItemModel newPackageItemModel2 = packageCartItem.c();
        i2.a0.d.l.f((Object)newPackageItemModel2, (String)"packageCartItem.getmItem()");
        String string2 = this.s(string, newPackageItemModel2.a());
        if (string2 == null) {
            string2 = "";
        }
        String string3 = string2;
        PackageCartItem packageCartItem2 = this.d.containsKey((Object)string3) ? (PackageCartItem)this.d.get((Object)string3) : packageCartItem;
        Integer n2 = packageCartItem2 != null && (newPackageItemModel = packageCartItem2.c()) != null && (configModel = newPackageItemModel.i()) != null ? Integer.valueOf((int)configModel.b()) : null;
        i2.a0.d.l.e(n2);
        int n3 = 1 + n2;
        NewPackageItemModel newPackageItemModel3 = packageCartItem2.c();
        i2.a0.d.l.f((Object)newPackageItemModel3, (String)"item.getmItem()");
        NewPackageItemModel.ConfigModel configModel2 = newPackageItemModel3.i();
        i2.a0.d.l.f((Object)configModel2, (String)"item.getmItem().itemConfiguration");
        if (n3 <= configModel2.a()) {
            this.f.setValue((Object)Status.WORKING);
            c.a a2 = t1.r.k.n.q0.x.c.a;
            k k2 = new k(this, packageCartItem2, packageCartItem, string3, b2, null);
            a2.a((i2.a0.c.l)k2);
            return;
        }
        if (b2 != null) {
            NewPackageItemModel newPackageItemModel4 = packageCartItem2.c();
            Integer n4 = null;
            if (newPackageItemModel4 != null) {
                NewPackageItemModel.ConfigModel configModel3 = newPackageItemModel4.i();
                n4 = null;
                if (configModel3 != null) {
                    n4 = configModel3.b();
                }
            }
            i2.a0.d.l.e(n4);
            b2.a(false, n4.intValue());
        }
    }

    public static final class c
    extends t1.r.k.n.b0.g<CartRepository, Context> {
        public c() {
            super((i2.a0.c.l)a.j);
        }

        public /* synthetic */ c(i2.a0.d.g g2) {
            this();
        }
    }

}

