/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.ucshared.models.ViewDetailsInfoPopUpWidgetItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CalenderMetaTag
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds
 *  com.urbanclap.urbanclap.ucshared.models.create_request.OptionInputText
 *  com.urbanclap.urbanclap.ucshared.models.create_request.OtherMetaTag
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.ViewDetailsInfoPopUpWidgetItemModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.CalenderMetaTag;
import com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds;
import com.urbanclap.urbanclap.ucshared.models.create_request.FilterMetaTag;
import com.urbanclap.urbanclap.ucshared.models.create_request.OptionInputText;
import com.urbanclap.urbanclap.ucshared.models.create_request.OtherMetaTag;
import java.util.ArrayList;
import java.util.List;

public class SingleSelectAndMultiSelectOptionModel
implements Parcelable {
    public static final Parcelable.Creator<SingleSelectAndMultiSelectOptionModel> CREATOR = new Parcelable.Creator<SingleSelectAndMultiSelectOptionModel>(){

        public SingleSelectAndMultiSelectOptionModel a(Parcel parcel) {
            return new SingleSelectAndMultiSelectOptionModel(parcel);
        }

        public SingleSelectAndMultiSelectOptionModel[] b(int n) {
            return new SingleSelectAndMultiSelectOptionModel[n];
        }
    };
    @SerializedName(value="old_price_text")
    private String A;
    @SerializedName(value="discount_text")
    private String B;
    @SerializedName(value="package_strip")
    private String C;
    @SerializedName(value="package_details")
    private ArrayList<PackageDetails> D;
    @SerializedName(value="view_details")
    private ArrayList<ViewDetailsInfoPopUpWidgetItemModel> E;
    @SerializedName(value="images")
    private List<PictureObject> F;
    @SerializedName(value="offer_ribbon")
    private String G;
    @SerializedName(value="catalog_ids")
    private ArrayList<CatalogIds> H;
    public boolean I;
    public boolean J;
    @SerializedName(value="title")
    private String a;
    @SerializedName(value="order_index")
    private String b;
    @SerializedName(value="answer_tag")
    private String c;
    @SerializedName(value="icon_type")
    private String d;
    @SerializedName(value="price")
    private ArrayList<Integer> e;
    @SerializedName(value="price_booking")
    private String f;
    @SerializedName(value="optional_text")
    private String g;
    @SerializedName(value="image_url")
    private String h;
    @SerializedName(value="other_metatags")
    private ArrayList<OtherMetaTag> i;
    @SerializedName(value="filter_metatags")
    private ArrayList<FilterMetaTag> j;
    @SerializedName(value="quantity")
    private int k;
    @SerializedName(value="is_serious")
    private boolean s;
    @SerializedName(value="input_text")
    private OptionInputText t;
    @SerializedName(value="info_popup_text")
    private String u;
    @SerializedName(value="color")
    private String v;
    @SerializedName(value="calender_metatags")
    private ArrayList<CalenderMetaTag> w;
    @SerializedName(value="lead_value")
    private int x;
    @SerializedName(value="default_selected")
    private boolean y;
    @SerializedName(value="price_text")
    private String z;

    public SingleSelectAndMultiSelectOptionModel(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        this.e = parcel.readArrayList(Integer.class.getClassLoader());
        this.f = parcel.readString();
        this.g = parcel.readString();
        this.h = parcel.readString();
        this.i = parcel.createTypedArrayList(OtherMetaTag.CREATOR);
        this.j = parcel.createTypedArrayList(FilterMetaTag.CREATOR);
        this.k = parcel.readInt();
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.s = bl2;
        this.t = (OptionInputText)parcel.readParcelable(OptionInputText.class.getClassLoader());
        this.u = parcel.readString();
        this.v = parcel.readString();
        this.w = parcel.createTypedArrayList(CalenderMetaTag.CREATOR);
        this.x = parcel.readInt();
        boolean bl3 = parcel.readByte() != 0;
        this.y = bl3;
        this.z = parcel.readString();
        this.A = parcel.readString();
        this.B = parcel.readString();
        this.C = parcel.readString();
        this.D = parcel.createTypedArrayList(PackageDetails.CREATOR);
        this.E = parcel.createTypedArrayList(ViewDetailsInfoPopUpWidgetItemModel.CREATOR);
        this.F = parcel.createTypedArrayList(PictureObject.CREATOR);
        this.G = parcel.readString();
        this.H = parcel.createTypedArrayList(CatalogIds.CREATOR);
        boolean bl4 = parcel.readByte() != 0;
        this.I = bl4;
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.J = bl;
    }

    public String a() {
        return this.c;
    }

    public String b() {
        return this.C;
    }

    public ArrayList<PackageDetails> c() {
        return this.D;
    }

    public ArrayList<CatalogIds> d() {
        return this.H;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.v;
    }

    public String f() {
        return this.B;
    }

    public String g() {
        return this.h;
    }

    public List<PictureObject> h() {
        return this.F;
    }

    public String i() {
        return this.u;
    }

    public String j() {
        return this.G;
    }

    public String k() {
        return this.A;
    }

    public String l() {
        return this.g;
    }

    public ArrayList<Integer> m() {
        return this.e;
    }

    public int n() {
        if (!TextUtils.isEmpty((CharSequence)this.f)) {
            return Integer.parseInt((String)this.f);
        }
        return -1;
    }

    public String o() {
        return this.z;
    }

    public String p() {
        return this.a;
    }

    public ArrayList<ViewDetailsInfoPopUpWidgetItemModel> q() {
        return this.E;
    }

    public boolean r() {
        return this.J;
    }

    public boolean s() {
        return this.y;
    }

    public boolean t() {
        return this.I;
    }

    public void u(boolean bl) {
        this.J = bl;
    }

    public void v(boolean bl) {
        this.I = bl;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeList(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeTypedList(this.i);
        parcel.writeTypedList(this.j);
        parcel.writeInt(this.k);
        parcel.writeByte((byte)(this.s ? 1 : 0));
        parcel.writeParcelable((Parcelable)this.t, n);
        parcel.writeString(this.u);
        parcel.writeString(this.v);
        parcel.writeTypedList(this.w);
        parcel.writeInt(this.x);
        parcel.writeByte((byte)(this.y ? 1 : 0));
        parcel.writeString(this.z);
        parcel.writeString(this.A);
        parcel.writeString(this.B);
        parcel.writeString(this.C);
        parcel.writeTypedList(this.D);
        parcel.writeTypedList(this.E);
        parcel.writeTypedList(this.F);
        parcel.writeString(this.G);
        parcel.writeTypedList(this.H);
        parcel.writeByte((byte)(this.I ? 1 : 0));
        parcel.writeByte((byte)(this.J ? 1 : 0));
    }

    public static class PackageDetails
    implements Parcelable {
        public static final Parcelable.Creator<PackageDetails> CREATOR = new Parcelable.Creator<PackageDetails>(){

            public PackageDetails a(Parcel parcel) {
                return new PackageDetails(parcel);
            }

            public PackageDetails[] b(int n) {
                return new PackageDetails[n];
            }
        };
        @SerializedName(value="icon_color")
        private String a;
        @SerializedName(value="icon_font")
        private String b;
        @SerializedName(value="text")
        private String c;

        public PackageDetails(Parcel parcel) {
            this.a = parcel.readString();
            this.b = parcel.readString();
            this.c = parcel.readString();
        }

        public String a() {
            return this.a;
        }

        public String b() {
            return this.b;
        }

        public String c() {
            return this.c;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int n) {
            parcel.writeString(this.a);
            parcel.writeString(this.b);
            parcel.writeString(this.c);
        }

    }

}

