/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class SelectButtonModel
implements Parcelable {
    public static final Parcelable.Creator<SelectButtonModel> CREATOR = new a();
    @SerializedName(value="selected_text")
    private final String a;
    @SerializedName(value="unselected_text")
    private final String b;
    @SerializedName(value="selection_type")
    private final SelectionType c;
    @SerializedName(value="is_disabled")
    private final boolean d;
    @SerializedName(value="disable_text")
    private final String e;

    public SelectButtonModel(String string, String string2, SelectionType selectionType, boolean bl, String string3) {
        this.a = string;
        this.b = string2;
        this.c = selectionType;
        this.d = bl;
        this.e = string3;
    }

    public final String a() {
        return this.e;
    }

    public final String b() {
        return this.a;
    }

    public final SelectionType c() {
        return this.c;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public final boolean e() {
        return this.d;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SelectButtonModel)) break block3;
                SelectButtonModel selectButtonModel = (SelectButtonModel)object;
                if (l.c((Object)this.a, (Object)selectButtonModel.a) && l.c((Object)this.b, (Object)selectButtonModel.b) && l.c((Object)((Object)this.c), (Object)((Object)selectButtonModel.c)) && this.d == selectButtonModel.d && l.c((Object)this.e, (Object)selectButtonModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        SelectionType selectionType = this.c;
        int n5 = selectionType != null ? selectionType.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        int n7 = this.d ? 1 : 0;
        if (n7 != 0) {
            n7 = 1;
        }
        int n8 = 31 * (n6 + n7);
        String string3 = this.e;
        int n9 = 0;
        if (string3 != null) {
            n9 = string3.hashCode();
        }
        return n8 + n9;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SelectButtonModel(selectedText=");
        stringBuilder.append(this.a);
        stringBuilder.append(", unSelectedText=");
        stringBuilder.append(this.b);
        stringBuilder.append(", selectionType=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", isDisabled=");
        stringBuilder.append(this.d);
        stringBuilder.append(", disabledText=");
        stringBuilder.append(this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        SelectionType selectionType = this.c;
        if (selectionType != null) {
            parcel.writeInt(1);
            parcel.writeString(selectionType.name());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeInt((int)this.d);
        parcel.writeString(this.e);
    }

    public static final class SelectionType
    extends Enum<SelectionType> {
        private static final /* synthetic */ SelectionType[] $VALUES;
        @SerializedName(value="stepper")
        public static final /* enum */ SelectionType STEPPER;
        @SerializedName(value="toggle")
        public static final /* enum */ SelectionType TOGGLE;

        public static {
            SelectionType selectionType;
            SelectionType selectionType2;
            SelectionType[] arrselectionType = new SelectionType[2];
            TOGGLE = selectionType = new SelectionType();
            arrselectionType[0] = selectionType;
            STEPPER = selectionType2 = new SelectionType();
            arrselectionType[1] = selectionType2;
            $VALUES = arrselectionType;
        }

        public static SelectionType valueOf(String string) {
            return (SelectionType)Enum.valueOf(SelectionType.class, (String)string);
        }

        public static SelectionType[] values() {
            return (SelectionType[])$VALUES.clone();
        }
    }

    public static final class a
    implements Parcelable.Creator<SelectButtonModel> {
        public final SelectButtonModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            SelectionType selectionType = parcel.readInt() != 0 ? (SelectionType)Enum.valueOf(SelectionType.class, (String)parcel.readString()) : null;
            SelectionType selectionType2 = selectionType;
            boolean bl = parcel.readInt() != 0;
            SelectButtonModel selectButtonModel = new SelectButtonModel(string, string2, selectionType2, bl, parcel.readString());
            return selectButtonModel;
        }

        public final SelectButtonModel[] b(int n) {
            return new SelectButtonModel[n];
        }
    }

}

