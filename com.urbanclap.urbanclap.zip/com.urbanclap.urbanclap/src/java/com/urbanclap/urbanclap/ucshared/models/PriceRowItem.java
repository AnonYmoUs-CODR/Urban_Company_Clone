/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.PriceRowItem$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.PriceRowItem;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class PriceRowItem
implements KParcelable {
    public static final Parcelable.Creator<PriceRowItem> CREATOR = new a();
    public boolean a;
    @SerializedName(value="key")
    private final TextModel b;
    @SerializedName(value="value")
    private final TextModel c;
    @SerializedName(value="description")
    private final TextModel d;
    @SerializedName(value="hidden_items")
    private final ArrayList<PriceRowItem> e;
    @SerializedName(value="show_divider_above")
    private final boolean f;
    public final String g;

    public PriceRowItem(Parcel parcel) {
        TextModel textModel = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        TextModel textModel2 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        TextModel textModel3 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        ArrayList arrayList = parcel.readArrayList(PriceRowItem.class.getClassLoader());
        boolean bl = parcel.readInt() != 0;
        this(textModel, textModel2, textModel3, (ArrayList<PriceRowItem>)arrayList, bl, parcel.readString());
    }

    public /* synthetic */ PriceRowItem(Parcel parcel, g g2) {
        this(parcel);
    }

    public PriceRowItem(TextModel textModel, TextModel textModel2, TextModel textModel3, ArrayList<PriceRowItem> arrayList, boolean bl, String string) {
        this.b = textModel;
        this.c = textModel2;
        this.d = textModel3;
        this.e = arrayList;
        this.f = bl;
        this.g = string;
    }

    public final TextModel a() {
        return this.d;
    }

    public final ArrayList<PriceRowItem> b() {
        return this.e;
    }

    public final TextModel c() {
        return this.b;
    }

    public final boolean d() {
        return this.f;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public final TextModel e() {
        return this.c;
    }

    public final boolean f() {
        return this.a;
    }

    public final void g(boolean bl) {
        this.a = bl;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeParcelable((Parcelable)this.d, n2);
        parcel.writeList(this.e);
        parcel.writeInt((int)this.f);
        parcel.writeString(this.g);
    }
}

