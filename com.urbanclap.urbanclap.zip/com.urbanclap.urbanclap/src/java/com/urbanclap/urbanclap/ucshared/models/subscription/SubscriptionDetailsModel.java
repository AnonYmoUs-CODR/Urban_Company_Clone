/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.extras.EventData
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  t1.r.l.f
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.extras.EventData;
import com.urbanclap.urbanclap.ucshared.models.subscription.BottomStrip;
import com.urbanclap.urbanclap.ucshared.models.subscription.PlanDetails;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionBottomStrip;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionLoader;
import com.urbanclap.urbanclap.ucshared.models.subscription.SummaryDetails;
import com.urbanclap.urbanclap.ucshared.models.subscription.Theme;
import com.urbanclap.urbanclap.ucshared.models.subscription.UserType;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;
import t1.r.l.f;

public final class SubscriptionDetailsModel
implements Parcelable {
    public static final Parcelable.Creator<SubscriptionDetailsModel> CREATOR = new a();
    @SerializedName(value="user_type")
    private final String a;
    @SerializedName(value="event_data")
    private final EventData b;
    @SerializedName(value="total_amount")
    private final String c;
    @SerializedName(value="source")
    private final String d;
    @SerializedName(value="subscription_type")
    private final String e;
    @SerializedName(value="bottom_strip")
    private final BottomStrip f;
    @SerializedName(value="subscription_bottom_strip")
    private final SubscriptionBottomStrip g;
    @SerializedName(value="subscription_loader")
    private final SubscriptionLoader h;
    @SerializedName(value="plan_details")
    private PlanDetails i;
    @SerializedName(value="available_plans_list")
    private final ArrayList<PlanDetails> j;
    @SerializedName(value="summary_details")
    private SummaryDetails k;
    @SerializedName(value="show_on_bullet_screen")
    private final boolean s;
    @SerializedName(value="inflow_selected_plan_id")
    private final String t;
    @SerializedName(value="mba_reward_limit")
    private final Integer u;
    @SerializedName(value="show_strip_low_amount")
    private final Boolean v;
    @SerializedName(value="theme")
    private final Theme w;
    public PlanDetails x;
    public boolean y;
    public boolean z;

    public SubscriptionDetailsModel(String string, EventData eventData, String string2, String string3, String string4, BottomStrip bottomStrip, SubscriptionBottomStrip subscriptionBottomStrip, SubscriptionLoader subscriptionLoader, PlanDetails planDetails, ArrayList<PlanDetails> arrayList, SummaryDetails summaryDetails, boolean bl, String string5, Integer n, Boolean bl2, Theme theme, PlanDetails planDetails2, boolean bl3, boolean bl4) {
        this.a = string;
        this.b = eventData;
        this.c = string2;
        this.d = string3;
        this.e = string4;
        this.f = bottomStrip;
        this.g = subscriptionBottomStrip;
        this.h = subscriptionLoader;
        this.i = planDetails;
        this.j = arrayList;
        this.k = summaryDetails;
        this.s = bl;
        this.t = string5;
        this.u = n;
        this.v = bl2;
        this.w = theme;
        this.x = planDetails2;
        this.y = bl3;
        this.z = bl4;
    }

    public final ArrayList<PlanDetails> a() {
        return this.j;
    }

    public final BottomStrip b() {
        return this.f;
    }

    public final EventData c() {
        return this.b;
    }

    public final Integer d() {
        return this.u;
    }

    public int describeContents() {
        return 0;
    }

    public final PlanDetails e() {
        return this.i;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SubscriptionDetailsModel)) break block3;
                SubscriptionDetailsModel subscriptionDetailsModel = (SubscriptionDetailsModel)object;
                if (l.c((Object)this.a, (Object)subscriptionDetailsModel.a) && l.c((Object)this.b, (Object)subscriptionDetailsModel.b) && l.c((Object)this.c, (Object)subscriptionDetailsModel.c) && l.c((Object)this.d, (Object)subscriptionDetailsModel.d) && l.c((Object)this.e, (Object)subscriptionDetailsModel.e) && l.c((Object)this.f, (Object)subscriptionDetailsModel.f) && l.c((Object)this.g, (Object)subscriptionDetailsModel.g) && l.c((Object)this.h, (Object)subscriptionDetailsModel.h) && l.c((Object)this.i, (Object)subscriptionDetailsModel.i) && l.c(this.j, subscriptionDetailsModel.j) && l.c((Object)this.k, (Object)subscriptionDetailsModel.k) && this.s == subscriptionDetailsModel.s && l.c((Object)this.t, (Object)subscriptionDetailsModel.t) && l.c((Object)this.u, (Object)subscriptionDetailsModel.u) && l.c((Object)this.v, (Object)subscriptionDetailsModel.v) && l.c((Object)this.w, (Object)subscriptionDetailsModel.w) && l.c((Object)this.x, (Object)subscriptionDetailsModel.x) && this.y == subscriptionDetailsModel.y && this.z == subscriptionDetailsModel.z) break block2;
            }
            return false;
        }
        return true;
    }

    public final PlanDetails f() {
        return this.x;
    }

    public final Boolean g() {
        return this.v;
    }

    public final String h() {
        return this.d;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        EventData eventData = this.b;
        int n3 = eventData != null ? eventData.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string3 = this.d;
        int n7 = string3 != null ? string3.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string4 = this.e;
        int n9 = string4 != null ? string4.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        BottomStrip bottomStrip = this.f;
        int n11 = bottomStrip != null ? bottomStrip.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        SubscriptionBottomStrip subscriptionBottomStrip = this.g;
        int n13 = subscriptionBottomStrip != null ? subscriptionBottomStrip.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        SubscriptionLoader subscriptionLoader = this.h;
        int n15 = subscriptionLoader != null ? subscriptionLoader.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        PlanDetails planDetails = this.i;
        int n17 = planDetails != null ? planDetails.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        ArrayList<PlanDetails> arrayList = this.j;
        int n19 = arrayList != null ? arrayList.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        SummaryDetails summaryDetails = this.k;
        int n21 = summaryDetails != null ? summaryDetails.hashCode() : 0;
        int n22 = 31 * (n20 + n21);
        int n23 = this.s;
        int n24 = 1;
        if (n23 != 0) {
            n23 = 1;
        }
        int n25 = 31 * (n22 + n23);
        String string5 = this.t;
        int n26 = string5 != null ? string5.hashCode() : 0;
        int n27 = 31 * (n25 + n26);
        Integer n28 = this.u;
        int n29 = n28 != null ? n28.hashCode() : 0;
        int n30 = 31 * (n27 + n29);
        Boolean bl = this.v;
        int n31 = bl != null ? bl.hashCode() : 0;
        int n32 = 31 * (n30 + n31);
        Theme theme = this.w;
        int n33 = theme != null ? theme.hashCode() : 0;
        int n34 = 31 * (n32 + n33);
        PlanDetails planDetails2 = this.x;
        int n35 = 0;
        if (planDetails2 != null) {
            n35 = planDetails2.hashCode();
        }
        int n36 = 31 * (n34 + n35);
        int n37 = this.y ? 1 : 0;
        if (n37 != 0) {
            n37 = 1;
        }
        int n38 = 31 * (n36 + n37);
        int n39 = this.z;
        if (n39 == 0) {
            n24 = n39;
        }
        return n38 + n24;
    }

    public final SubscriptionBottomStrip i() {
        return this.g;
    }

    public final SubscriptionLoader j() {
        return this.h;
    }

    public final String k() {
        String string;
        PlanDetails planDetails;
        boolean bl = this.y;
        String string2 = "";
        if (bl && (planDetails = this.x) != null && (string = planDetails.b()) != null) {
            string2 = string;
        }
        return string2;
    }

    public final String l() {
        return this.e;
    }

    public final SummaryDetails m() {
        return this.k;
    }

    public final Theme n() {
        return this.w;
    }

    public final String o() {
        return this.c;
    }

    public final String p() {
        return this.a;
    }

    public final boolean q() {
        return f.a((String)UserType.NEVER_SUBSCRIBED.name(), (String)this.a) || f.a((String)UserType.EXPIRED_LOW_SAVINGS.name(), (String)this.a) || f.a((String)UserType.EXPIRED_MEDIUM_SAVINGS.name(), (String)this.a) || f.a((String)UserType.EXPIRED_HIGH_SAVINGS.name(), (String)this.a);
        {
        }
    }

    public final boolean r() {
        return this.s;
    }

    public final boolean s() {
        return this.z;
    }

    public final boolean t() {
        return this.y;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SubscriptionDetailsModel(userType=");
        stringBuilder.append(this.a);
        stringBuilder.append(", eventData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", totalAmount=");
        stringBuilder.append(this.c);
        stringBuilder.append(", source=");
        stringBuilder.append(this.d);
        stringBuilder.append(", subscriptionType=");
        stringBuilder.append(this.e);
        stringBuilder.append(", bottomStrip=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", subscriptionBottomStrip=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", subscriptionLoader=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", planDetails=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", availablePlansDetails=");
        stringBuilder.append(this.j);
        stringBuilder.append(", summaryDetails=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(", isShowOnBulletScreen=");
        stringBuilder.append(this.s);
        stringBuilder.append(", inflowSelectedPlanId=");
        stringBuilder.append(this.t);
        stringBuilder.append(", mbaRewardLimit=");
        stringBuilder.append((Object)this.u);
        stringBuilder.append(", showStripLowAmount=");
        stringBuilder.append((Object)this.v);
        stringBuilder.append(", theme=");
        stringBuilder.append((Object)this.w);
        stringBuilder.append(", selectedPlanDetails=");
        stringBuilder.append((Object)this.x);
        stringBuilder.append(", isSubscriptionAdded=");
        stringBuilder.append(this.y);
        stringBuilder.append(", isSubscribed=");
        stringBuilder.append(this.z);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final void u(PlanDetails planDetails) {
        this.i = planDetails;
    }

    public final void v(PlanDetails planDetails) {
        this.x = planDetails;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        EventData eventData = this.b;
        if (eventData != null) {
            parcel.writeInt(1);
            eventData.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeParcelable((Parcelable)this.f, n);
        parcel.writeParcelable((Parcelable)this.g, n);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeParcelable((Parcelable)this.i, n);
        ArrayList<PlanDetails> arrayList = this.j;
        if (arrayList != null) {
            parcel.writeInt(1);
            parcel.writeInt(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                parcel.writeParcelable((Parcelable)((PlanDetails)iterator.next()), n);
            }
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.k, n);
        parcel.writeInt((int)this.s);
        parcel.writeString(this.t);
        Integer n2 = this.u;
        if (n2 != null) {
            parcel.writeInt(1);
            parcel.writeInt(n2.intValue());
        } else {
            parcel.writeInt(0);
        }
        Boolean bl = this.v;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        Theme theme = this.w;
        if (theme != null) {
            parcel.writeInt(1);
            theme.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.x, n);
        parcel.writeInt((int)this.y);
        parcel.writeInt((int)this.z);
    }

    public final void x(boolean bl) {
        this.z = bl;
    }

    public final void y(boolean bl) {
        this.y = bl;
    }

    public static final class a
    implements Parcelable.Creator<SubscriptionDetailsModel> {
        public final SubscriptionDetailsModel a(Parcel parcel) {
            Boolean bl;
            ArrayList arrayList;
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            EventData eventData = parcel.readInt() != 0 ? (EventData)EventData.CREATOR.createFromParcel(parcel) : null;
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            String string4 = parcel.readString();
            BottomStrip bottomStrip = (BottomStrip)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            SubscriptionBottomStrip subscriptionBottomStrip = (SubscriptionBottomStrip)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            SubscriptionLoader subscriptionLoader = (SubscriptionLoader)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            PlanDetails planDetails = (PlanDetails)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            if (parcel.readInt() != 0) {
                int n;
                arrayList = new ArrayList(n);
                for (n = parcel.readInt(); n != 0; --n) {
                    arrayList.add((Object)((PlanDetails)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader())));
                }
            } else {
                arrayList = null;
            }
            SummaryDetails summaryDetails = (SummaryDetails)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            boolean bl2 = parcel.readInt() != 0;
            String string5 = parcel.readString();
            Integer n = parcel.readInt() != 0 ? Integer.valueOf((int)parcel.readInt()) : null;
            if (parcel.readInt() != 0) {
                boolean bl3 = parcel.readInt() != 0;
                bl = bl3;
            } else {
                bl = null;
            }
            Theme theme = parcel.readInt() != 0 ? (Theme)Theme.CREATOR.createFromParcel(parcel) : null;
            PlanDetails planDetails2 = (PlanDetails)parcel.readParcelable(SubscriptionDetailsModel.class.getClassLoader());
            boolean bl4 = parcel.readInt() != 0;
            boolean bl5 = parcel.readInt() != 0;
            SubscriptionDetailsModel subscriptionDetailsModel = new SubscriptionDetailsModel(string, eventData, string2, string3, string4, bottomStrip, subscriptionBottomStrip, subscriptionLoader, planDetails, (ArrayList<PlanDetails>)arrayList, summaryDetails, bl2, string5, n, bl, theme, planDetails2, bl4, bl5);
            return subscriptionDetailsModel;
        }

        public final SubscriptionDetailsModel[] b(int n) {
            return new SubscriptionDetailsModel[n];
        }
    }

}

