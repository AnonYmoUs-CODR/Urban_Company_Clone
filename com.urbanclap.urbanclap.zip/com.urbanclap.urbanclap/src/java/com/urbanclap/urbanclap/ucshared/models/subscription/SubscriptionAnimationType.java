/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

public final class SubscriptionAnimationType
extends Enum<SubscriptionAnimationType> {
    private static final /* synthetic */ SubscriptionAnimationType[] $VALUES;
    public static final /* enum */ SubscriptionAnimationType GOLD;
    public static final /* enum */ SubscriptionAnimationType HOMECARE;
    public static final /* enum */ SubscriptionAnimationType PRIVILEGE;
    public static final /* enum */ SubscriptionAnimationType UCPLUS;
    public static final /* enum */ SubscriptionAnimationType WELLNESS;

    public static {
        SubscriptionAnimationType subscriptionAnimationType;
        SubscriptionAnimationType subscriptionAnimationType2;
        SubscriptionAnimationType subscriptionAnimationType3;
        SubscriptionAnimationType subscriptionAnimationType4;
        SubscriptionAnimationType subscriptionAnimationType5;
        SubscriptionAnimationType[] arrsubscriptionAnimationType = new SubscriptionAnimationType[5];
        HOMECARE = subscriptionAnimationType3 = new SubscriptionAnimationType();
        arrsubscriptionAnimationType[0] = subscriptionAnimationType3;
        WELLNESS = subscriptionAnimationType2 = new SubscriptionAnimationType();
        arrsubscriptionAnimationType[1] = subscriptionAnimationType2;
        GOLD = subscriptionAnimationType5 = new SubscriptionAnimationType();
        arrsubscriptionAnimationType[2] = subscriptionAnimationType5;
        PRIVILEGE = subscriptionAnimationType = new SubscriptionAnimationType();
        arrsubscriptionAnimationType[3] = subscriptionAnimationType;
        UCPLUS = subscriptionAnimationType4 = new SubscriptionAnimationType();
        arrsubscriptionAnimationType[4] = subscriptionAnimationType4;
        $VALUES = arrsubscriptionAnimationType;
    }

    public static SubscriptionAnimationType valueOf(String string) {
        return (SubscriptionAnimationType)Enum.valueOf(SubscriptionAnimationType.class, (String)string);
    }

    public static SubscriptionAnimationType[] values() {
        return (SubscriptionAnimationType[])$VALUES.clone();
    }
}

