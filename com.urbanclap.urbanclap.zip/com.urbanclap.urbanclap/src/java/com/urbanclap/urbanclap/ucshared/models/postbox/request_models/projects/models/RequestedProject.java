/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.ProviderResponse;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.RequestStateModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.WarrantyInfo;
import java.util.ArrayList;
import java.util.List;

public class RequestedProject
implements Parcelable {
    public static final Parcelable.Creator<RequestedProject> CREATOR = new Parcelable.Creator<RequestedProject>(){

        public RequestedProject a(Parcel parcel) {
            return new RequestedProject(parcel);
        }

        public RequestedProject[] b(int n) {
            return new RequestedProject[n];
        }
    };
    public int A = -1;
    public transient boolean B = false;
    @SerializedName(value="customer_request_id")
    private String a;
    @SerializedName(value="booking_time")
    private String b = "";
    @SerializedName(value="booking_time_display")
    private String c = "";
    @SerializedName(value="server_time")
    private String d = "";
    @SerializedName(value="is_closed")
    private boolean e;
    @SerializedName(value="is_hired")
    private boolean f;
    @SerializedName(value="category_name")
    private String g;
    @SerializedName(value="category_singular")
    private String h;
    @SerializedName(value="category_plural")
    private String i;
    @SerializedName(value="category_key")
    private String j;
    @SerializedName(value="is_booking")
    private boolean k;
    @SerializedName(value="status")
    private boolean s;
    @SerializedName(value="all_notified_count")
    private int t = -1;
    @SerializedName(value="all_decline_message")
    private String u;
    @SerializedName(value="all_decline_flag")
    private boolean v;
    @SerializedName(value="provider_responses")
    private ArrayList<ProviderResponse> w;
    @SerializedName(value="request_state")
    private RequestStateModel x;
    @SerializedName(value="warranty_info")
    private WarrantyInfo y;
    @SerializedName(value="scheduled_booking_info")
    private ScheduledBookingInfoModel z;

    public RequestedProject() {
    }

    public RequestedProject(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        boolean bl = parcel.readByte() != 0;
        this.e = bl;
        boolean bl2 = parcel.readByte() != 0;
        this.f = bl2;
        this.g = parcel.readString();
        this.h = parcel.readString();
        this.i = parcel.readString();
        this.j = parcel.readString();
        boolean bl3 = parcel.readByte() != 0;
        this.k = bl3;
        boolean bl4 = parcel.readByte() != 0;
        this.s = bl4;
        this.t = parcel.readInt();
        this.u = parcel.readString();
        byte by = parcel.readByte();
        boolean bl5 = false;
        if (by != 0) {
            bl5 = true;
        }
        this.v = bl5;
        this.w = parcel.createTypedArrayList(ProviderResponse.CREATOR);
        this.x = (RequestStateModel)parcel.readParcelable(RequestStateModel.class.getClassLoader());
        this.x = (RequestStateModel)parcel.readParcelable(WarrantyInfo.class.getClassLoader());
        this.A = parcel.readInt();
        this.z = (ScheduledBookingInfoModel)parcel.readParcelable(ScheduledBookingInfoModel.class.getClassLoader());
    }

    public String a() {
        return this.u;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.j;
    }

    public String d() {
        return this.g;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.i;
    }

    public String f() {
        return this.h;
    }

    public String g() {
        return this.a;
    }

    public String h() {
        return this.c;
    }

    public int i() {
        return this.A;
    }

    public int j() {
        return this.t;
    }

    public ArrayList<ProviderResponse> k() {
        return this.w;
    }

    public RequestStateModel l() {
        return this.x;
    }

    public ScheduledBookingInfoModel m() {
        return this.z;
    }

    public String n() {
        return this.d;
    }

    public WarrantyInfo o() {
        return this.y;
    }

    public boolean p() {
        return this.v;
    }

    public boolean q() {
        return this.k;
    }

    public boolean r() {
        return this.e;
    }

    public boolean s() {
        return this.f;
    }

    public boolean t() {
        return this.B;
    }

    public void u(int n) {
        this.A = n;
    }

    public void v(boolean bl) {
        this.B = bl;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeByte((byte)this.e);
        parcel.writeByte((byte)this.f);
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeString(this.i);
        parcel.writeString(this.j);
        parcel.writeByte((byte)this.k);
        parcel.writeByte((byte)this.s);
        parcel.writeInt(this.t);
        parcel.writeString(this.u);
        parcel.writeByte((byte)this.v);
        parcel.writeTypedList(this.w);
        parcel.writeParcelable((Parcelable)this.x, n);
        parcel.writeParcelable((Parcelable)this.y, n);
        parcel.writeInt(this.A);
        parcel.writeParcelable((Parcelable)this.z, n);
    }

}

