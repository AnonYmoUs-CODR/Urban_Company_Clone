/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import com.google.gson.annotations.SerializedName;

public final class TimeUnit
extends Enum<TimeUnit> {
    private static final /* synthetic */ TimeUnit[] $VALUES;
    @SerializedName(value="min")
    public static final /* enum */ TimeUnit MIN;

    public static {
        TimeUnit timeUnit;
        TimeUnit[] arrtimeUnit = new TimeUnit[1];
        MIN = timeUnit = new TimeUnit("min");
        arrtimeUnit[0] = timeUnit;
        $VALUES = arrtimeUnit;
    }

    private TimeUnit(String string2) {
    }

    public static TimeUnit valueOf(String string) {
        return (TimeUnit)Enum.valueOf(TimeUnit.class, (String)string);
    }

    public static TimeUnit[] values() {
        return (TimeUnit[])$VALUES.clone();
    }
}

