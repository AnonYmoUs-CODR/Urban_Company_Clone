/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

public final class RequestType
extends Enum<RequestType> {
    private static final /* synthetic */ RequestType[] $VALUES;
    public static final /* enum */ RequestType auto;
    public static final /* enum */ RequestType both;
    public static final /* enum */ RequestType manual;

    public static {
        RequestType requestType;
        RequestType requestType2;
        RequestType requestType3;
        auto = requestType2 = new RequestType();
        manual = requestType = new RequestType();
        both = requestType3 = new RequestType();
        $VALUES = new RequestType[]{requestType2, requestType, requestType3};
    }

    public static RequestType valueOf(String string) {
        return (RequestType)Enum.valueOf(RequestType.class, (String)string);
    }

    public static RequestType[] values() {
        return (RequestType[])$VALUES.clone();
    }
}

