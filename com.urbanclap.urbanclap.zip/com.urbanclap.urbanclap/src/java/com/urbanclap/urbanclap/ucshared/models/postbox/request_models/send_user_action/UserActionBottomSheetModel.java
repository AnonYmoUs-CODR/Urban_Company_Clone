/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action.ToggleData;
import i2.a0.d.g;
import i2.a0.d.l;

public final class UserActionBottomSheetModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="image_url")
    private final PictureObject a;
    @SerializedName(value="text")
    private final String b;
    @SerializedName(value="toggle")
    private final ToggleData c;

    public UserActionBottomSheetModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader()), parcel.readString(), (ToggleData)parcel.readParcelable(ToggleData.class.getClassLoader()));
    }

    public UserActionBottomSheetModel(PictureObject pictureObject, String string, ToggleData toggleData) {
        this.a = pictureObject;
        this.b = string;
        this.c = toggleData;
    }

    public final PictureObject a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final ToggleData c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof UserActionBottomSheetModel)) break block3;
                UserActionBottomSheetModel userActionBottomSheetModel = (UserActionBottomSheetModel)object;
                if (l.c((Object)this.a, (Object)userActionBottomSheetModel.a) && l.c((Object)this.b, (Object)userActionBottomSheetModel.b) && l.c((Object)this.c, (Object)userActionBottomSheetModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        ToggleData toggleData = this.c;
        int n5 = 0;
        if (toggleData != null) {
            n5 = toggleData.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UserActionBottomSheetModel(imageUrl=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", text=");
        stringBuilder.append(this.b);
        stringBuilder.append(", toggle=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
    }

    public static final class a
    implements Parcelable.Creator<UserActionBottomSheetModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public UserActionBottomSheetModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new UserActionBottomSheetModel(parcel);
        }

        public UserActionBottomSheetModel[] b(int n) {
            return new UserActionBottomSheetModel[n];
        }
    }

}

