/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RescheduleProviderModel
implements Parcelable {
    public static final Parcelable.Creator<RescheduleProviderModel> CREATOR = new Parcelable.Creator<RescheduleProviderModel>(){

        public RescheduleProviderModel a(Parcel parcel) {
            return new RescheduleProviderModel(parcel);
        }

        public RescheduleProviderModel[] b(int n) {
            return new RescheduleProviderModel[n];
        }
    };
    @Expose
    @SerializedName(value="provider_id")
    private String a;
    @Expose
    @SerializedName(value="name")
    private String b;

    public RescheduleProviderModel(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

}

