/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.DividerTheme;
import com.urbanclap.urbanclap.ucshared.models.subscription.SearchBarTheme;
import com.urbanclap.urbanclap.ucshared.models.subscription.StatusBarTheme;
import i2.a0.d.l;

public final class Theme
implements Parcelable {
    public static final Parcelable.Creator<Theme> CREATOR = new a();
    @SerializedName(value="bg_color")
    private final String a;
    @SerializedName(value="text_color")
    private final String b;
    @SerializedName(value="status_bar")
    private final StatusBarTheme c;
    @SerializedName(value="search_bar")
    private final SearchBarTheme d;
    @SerializedName(value="divider")
    private final DividerTheme e;

    public Theme(String string, String string2, StatusBarTheme statusBarTheme, SearchBarTheme searchBarTheme, DividerTheme dividerTheme) {
        l.g((Object)string, (String)"bgColor");
        l.g((Object)string2, (String)"textColor");
        l.g((Object)statusBarTheme, (String)"statusBarTheme");
        this.a = string;
        this.b = string2;
        this.c = statusBarTheme;
        this.d = searchBarTheme;
        this.e = dividerTheme;
    }

    public final String a() {
        return this.a;
    }

    public final DividerTheme b() {
        return this.e;
    }

    public final StatusBarTheme c() {
        return this.c;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Theme)) break block3;
                Theme theme = (Theme)object;
                if (l.c((Object)this.a, (Object)theme.a) && l.c((Object)this.b, (Object)theme.b) && l.c((Object)this.c, (Object)theme.c) && l.c((Object)this.d, (Object)theme.d) && l.c((Object)this.e, (Object)theme.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        StatusBarTheme statusBarTheme = this.c;
        int n5 = statusBarTheme != null ? statusBarTheme.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        SearchBarTheme searchBarTheme = this.d;
        int n7 = searchBarTheme != null ? searchBarTheme.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        DividerTheme dividerTheme = this.e;
        int n9 = 0;
        if (dividerTheme != null) {
            n9 = dividerTheme.hashCode();
        }
        return n8 + n9;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Theme(bgColor=");
        stringBuilder.append(this.a);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", statusBarTheme=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", searchBarTheme=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", divider=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        this.c.writeToParcel(parcel, 0);
        SearchBarTheme searchBarTheme = this.d;
        if (searchBarTheme != null) {
            parcel.writeInt(1);
            searchBarTheme.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        DividerTheme dividerTheme = this.e;
        if (dividerTheme != null) {
            parcel.writeInt(1);
            dividerTheme.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<Theme> {
        public final Theme a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            StatusBarTheme statusBarTheme = (StatusBarTheme)StatusBarTheme.CREATOR.createFromParcel(parcel);
            SearchBarTheme searchBarTheme = parcel.readInt() != 0 ? (SearchBarTheme)SearchBarTheme.CREATOR.createFromParcel(parcel) : null;
            DividerTheme dividerTheme = parcel.readInt() != 0 ? (DividerTheme)DividerTheme.CREATOR.createFromParcel(parcel) : null;
            Theme theme = new Theme(string, string2, statusBarTheme, searchBarTheme, dividerTheme);
            return theme;
        }

        public final Theme[] b(int n) {
            return new Theme[n];
        }
    }

}

