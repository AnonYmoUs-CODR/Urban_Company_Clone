/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class ChatModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="is_chat_enabled")
    private final Boolean a;
    @SerializedName(value="url")
    private final String b;
    @SerializedName(value="channel_id")
    private final String c;
    @SerializedName(value="unseen_message_count")
    private final Integer d;
    @SerializedName(value="unseen_last_message_timestamp")
    private final String e;

    public ChatModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        boolean bl = parcel.readInt() != 0;
        this(bl, parcel.readString(), parcel.readString(), parcel.readInt(), parcel.readString());
    }

    public ChatModel(Boolean bl, String string, String string2, Integer n, String string3) {
        this.a = bl;
        this.b = string;
        this.c = string2;
        this.d = n;
        this.e = string3;
    }

    public final String a() {
        return this.c;
    }

    public final String b() {
        return this.e;
    }

    public final Integer c() {
        return this.d;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public final Boolean e() {
        return this.a;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ChatModel)) break block3;
                ChatModel chatModel = (ChatModel)object;
                if (l.c((Object)this.a, (Object)chatModel.a) && l.c((Object)this.b, (Object)chatModel.b) && l.c((Object)this.c, (Object)chatModel.c) && l.c((Object)this.d, (Object)chatModel.d) && l.c((Object)this.e, (Object)chatModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Boolean bl = this.a;
        int n = bl != null ? bl.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        Integer n7 = this.d;
        int n8 = n7 != null ? n7.hashCode() : 0;
        int n9 = 31 * (n6 + n8);
        String string3 = this.e;
        int n10 = 0;
        if (string3 != null) {
            n10 = string3.hashCode();
        }
        return n9 + n10;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ChatModel(isEnabled=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", url=");
        stringBuilder.append(this.b);
        stringBuilder.append(", channelId=");
        stringBuilder.append(this.c);
        stringBuilder.append(", unseenMessageCount=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", unseenLastMessageTimestamp=");
        stringBuilder.append(this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        Boolean bl = this.a;
        int n2 = bl != null ? bl : 0;
        parcel.writeInt(n2);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        Integer n3 = this.d;
        int n4 = 0;
        if (n3 != null) {
            n4 = n3;
        }
        parcel.writeInt(n4);
        parcel.writeString(this.e);
    }

    public static final class a
    implements Parcelable.Creator<ChatModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ChatModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ChatModel(parcel);
        }

        public ChatModel[] b(int n) {
            return new ChatModel[n];
        }
    }

}

