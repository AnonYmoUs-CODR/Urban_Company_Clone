/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.Cursor
 *  androidx.room.DatabaseConfiguration
 *  androidx.room.InvalidationTracker
 *  androidx.room.RoomDatabase
 *  androidx.room.RoomOpenHelper
 *  androidx.room.RoomOpenHelper$Delegate
 *  androidx.sqlite.db.SupportSQLiteDatabase
 *  androidx.sqlite.db.SupportSQLiteOpenHelper
 *  androidx.sqlite.db.SupportSQLiteOpenHelper$Callback
 *  androidx.sqlite.db.SupportSQLiteOpenHelper$Configuration
 *  androidx.sqlite.db.SupportSQLiteOpenHelper$Configuration$Builder
 *  androidx.sqlite.db.SupportSQLiteOpenHelper$Factory
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  t1.r.k.n.q0.u.a.c
 *  t1.r.k.n.q0.u.a.d
 *  t1.r.k.n.q0.u.b.a
 *  t1.r.k.n.q0.u.b.b
 *  t1.r.k.n.q0.u.c.b.a
 *  t1.r.k.n.q0.u.c.b.b
 *  t1.r.k.n.q0.u.d.b.a
 *  t1.r.k.n.q0.u.d.b.b
 *  t1.r.k.n.q0.x.f.a
 *  t1.r.k.n.q0.x.f.b
 */
package com.urbanclap.urbanclap.ucshared.models.uccart;

import android.content.Context;
import android.database.Cursor;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase;
import com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase_Impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import t1.r.k.n.q0.u.a.c;
import t1.r.k.n.q0.u.a.d;
import t1.r.k.n.q0.u.d.b.b;

public final class UCDatabase_Impl
extends UCDatabase {
    public volatile t1.r.k.n.q0.x.f.a m;
    public volatile t1.r.k.n.q0.u.d.b.a n;
    public volatile t1.r.k.n.q0.u.c.b.a o;
    public volatile c p;
    public volatile t1.r.k.n.q0.u.b.a q;

    public static /* synthetic */ List A(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List q(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List r(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List s(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List t(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List u(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List v(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ List w(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public static /* synthetic */ SupportSQLiteDatabase x(UCDatabase_Impl uCDatabase_Impl, SupportSQLiteDatabase supportSQLiteDatabase) {
        uCDatabase_Impl.mDatabase = supportSQLiteDatabase;
        return supportSQLiteDatabase;
    }

    public static /* synthetic */ void y(UCDatabase_Impl uCDatabase_Impl, SupportSQLiteDatabase supportSQLiteDatabase) {
        uCDatabase_Impl.internalInitInvalidationTracker(supportSQLiteDatabase);
    }

    public static /* synthetic */ List z(UCDatabase_Impl uCDatabase_Impl) {
        return uCDatabase_Impl.mCallbacks;
    }

    public void clearAllTables() {
        RoomDatabase.super.assertNotMainThread();
        SupportSQLiteDatabase supportSQLiteDatabase = RoomDatabase.super.getOpenHelper().getWritableDatabase();
        try {
            RoomDatabase.super.beginTransaction();
            supportSQLiteDatabase.execSQL("DELETE FROM `questions`");
            supportSQLiteDatabase.execSQL("DELETE FROM `packageItems`");
            supportSQLiteDatabase.execSQL("DELETE FROM `WebResourceTable`");
            supportSQLiteDatabase.execSQL("DELETE FROM `VideoSeenRequests`");
            supportSQLiteDatabase.execSQL("DELETE FROM `TaskTable`");
            supportSQLiteDatabase.execSQL("DELETE FROM `SearchTable`");
            RoomDatabase.super.setTransactionSuccessful();
            return;
        }
        finally {
            RoomDatabase.super.endTransaction();
            supportSQLiteDatabase.query("PRAGMA wal_checkpoint(FULL)").close();
            if (!supportSQLiteDatabase.inTransaction()) {
                supportSQLiteDatabase.execSQL("VACUUM");
            }
        }
    }

    public InvalidationTracker createInvalidationTracker() {
        return new InvalidationTracker((RoomDatabase)this, (Map)new HashMap(0), (Map)new HashMap(0), new String[]{"questions", "packageItems", "WebResourceTable", "VideoSeenRequests", "TaskTable", "SearchTable"});
    }

    public SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration databaseConfiguration) {
        RoomOpenHelper roomOpenHelper = new RoomOpenHelper(databaseConfiguration, new RoomOpenHelper.Delegate(this, 8){
            public final /* synthetic */ UCDatabase_Impl a;
            {
                this.a = uCDatabase_Impl;
                super(n2);
            }

            public void createAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `questions` (`updatedAt` INTEGER NOT NULL, `questionId` TEXT NOT NULL, `questionType` TEXT NOT NULL, `cityKey` TEXT NOT NULL, `categoryKey` TEXT NOT NULL, PRIMARY KEY(`questionId`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `packageItems` (`updatedAt` INTEGER NOT NULL, `itemId` TEXT NOT NULL, `quantity` INTEGER NOT NULL, `sectionId` TEXT NOT NULL, `categoryKey` TEXT NOT NULL, `cityKey` TEXT NOT NULL, `metaDataJson` TEXT, PRIMARY KEY(`itemId`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WebResourceTable` (`resourceKey` TEXT NOT NULL, `fileHash` TEXT NOT NULL, `mimeType` TEXT NOT NULL, PRIMARY KEY(`resourceKey`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `VideoSeenRequests` (`requestId` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`requestId`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `TaskTable` (`taskId` TEXT NOT NULL, `taskType` INTEGER NOT NULL, `serializedMetaData` BLOB, PRIMARY KEY(`taskId`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `SearchTable` (`_id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `cityKey` TEXT NOT NULL, `image` TEXT, `imageShape` TEXT, `title` TEXT NOT NULL, `subtitles` TEXT, `tapAction` TEXT NOT NULL, `analytics` TEXT)");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
                supportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '42bc71dd82db92d393593a39c545ebbc')");
            }

            public void dropAllTables(SupportSQLiteDatabase supportSQLiteDatabase) {
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `questions`");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `packageItems`");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `WebResourceTable`");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `VideoSeenRequests`");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `TaskTable`");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `SearchTable`");
                if (UCDatabase_Impl.q(this.a) != null) {
                    int n2 = UCDatabase_Impl.r(this.a).size();
                    for (int i2 = 0; i2 < n2; ++i2) {
                        ((androidx.room.RoomDatabase$Callback)UCDatabase_Impl.t(this.a).get(i2)).onDestructiveMigration(supportSQLiteDatabase);
                    }
                }
            }

            public void onCreate(SupportSQLiteDatabase supportSQLiteDatabase) {
                if (UCDatabase_Impl.u(this.a) != null) {
                    int n2 = UCDatabase_Impl.v(this.a).size();
                    for (int i2 = 0; i2 < n2; ++i2) {
                        ((androidx.room.RoomDatabase$Callback)UCDatabase_Impl.w(this.a).get(i2)).onCreate(supportSQLiteDatabase);
                    }
                }
            }

            public void onOpen(SupportSQLiteDatabase supportSQLiteDatabase) {
                UCDatabase_Impl.x(this.a, supportSQLiteDatabase);
                UCDatabase_Impl.y(this.a, supportSQLiteDatabase);
                if (UCDatabase_Impl.z(this.a) != null) {
                    int n2 = UCDatabase_Impl.A(this.a).size();
                    for (int i2 = 0; i2 < n2; ++i2) {
                        ((androidx.room.RoomDatabase$Callback)UCDatabase_Impl.s(this.a).get(i2)).onOpen(supportSQLiteDatabase);
                    }
                }
            }

            public void onPostMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            }

            public void onPreMigrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                androidx.room.util.DBUtil.dropFtsSyncTriggers((SupportSQLiteDatabase)supportSQLiteDatabase);
            }

            public androidx.room.RoomOpenHelper$ValidationResult onValidateSchema(SupportSQLiteDatabase supportSQLiteDatabase) {
                HashMap hashMap = new HashMap(5);
                androidx.room.util.TableInfo$Column column = new androidx.room.util.TableInfo$Column("updatedAt", "INTEGER", true, 0, null, 1);
                hashMap.put((java.lang.Object)"updatedAt", (java.lang.Object)column);
                androidx.room.util.TableInfo$Column column2 = new androidx.room.util.TableInfo$Column("questionId", "TEXT", true, 1, null, 1);
                hashMap.put((java.lang.Object)"questionId", (java.lang.Object)column2);
                androidx.room.util.TableInfo$Column column3 = new androidx.room.util.TableInfo$Column("questionType", "TEXT", true, 0, null, 1);
                hashMap.put((java.lang.Object)"questionType", (java.lang.Object)column3);
                androidx.room.util.TableInfo$Column column4 = new androidx.room.util.TableInfo$Column("cityKey", "TEXT", true, 0, null, 1);
                hashMap.put((java.lang.Object)"cityKey", (java.lang.Object)column4);
                androidx.room.util.TableInfo$Column column5 = new androidx.room.util.TableInfo$Column("categoryKey", "TEXT", true, 0, null, 1);
                hashMap.put((java.lang.Object)"categoryKey", (java.lang.Object)column5);
                androidx.room.util.TableInfo tableInfo = new androidx.room.util.TableInfo("questions", (Map)hashMap, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo2 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"questions");
                if (!tableInfo.equals((java.lang.Object)tableInfo2)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("questions(com.urbanclap.urbanclap.ucshared.models.uccart.entity.QuestionEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo2);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                HashMap hashMap2 = new HashMap(7);
                androidx.room.util.TableInfo$Column column6 = new androidx.room.util.TableInfo$Column("updatedAt", "INTEGER", true, 0, null, 1);
                hashMap2.put((java.lang.Object)"updatedAt", (java.lang.Object)column6);
                androidx.room.util.TableInfo$Column column7 = new androidx.room.util.TableInfo$Column("itemId", "TEXT", true, 1, null, 1);
                hashMap2.put((java.lang.Object)"itemId", (java.lang.Object)column7);
                androidx.room.util.TableInfo$Column column8 = new androidx.room.util.TableInfo$Column("quantity", "INTEGER", true, 0, null, 1);
                hashMap2.put((java.lang.Object)"quantity", (java.lang.Object)column8);
                androidx.room.util.TableInfo$Column column9 = new androidx.room.util.TableInfo$Column("sectionId", "TEXT", true, 0, null, 1);
                hashMap2.put((java.lang.Object)"sectionId", (java.lang.Object)column9);
                androidx.room.util.TableInfo$Column column10 = new androidx.room.util.TableInfo$Column("categoryKey", "TEXT", true, 0, null, 1);
                hashMap2.put((java.lang.Object)"categoryKey", (java.lang.Object)column10);
                androidx.room.util.TableInfo$Column column11 = new androidx.room.util.TableInfo$Column("cityKey", "TEXT", true, 0, null, 1);
                hashMap2.put((java.lang.Object)"cityKey", (java.lang.Object)column11);
                androidx.room.util.TableInfo$Column column12 = new androidx.room.util.TableInfo$Column("metaDataJson", "TEXT", false, 0, null, 1);
                hashMap2.put((java.lang.Object)"metaDataJson", (java.lang.Object)column12);
                androidx.room.util.TableInfo tableInfo3 = new androidx.room.util.TableInfo("packageItems", (Map)hashMap2, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo4 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"packageItems");
                if (!tableInfo3.equals((java.lang.Object)tableInfo4)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("packageItems(com.urbanclap.urbanclap.ucshared.models.uccart.entity.PackageItemEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo3);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo4);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                HashMap hashMap3 = new HashMap(3);
                androidx.room.util.TableInfo$Column column13 = new androidx.room.util.TableInfo$Column("resourceKey", "TEXT", true, 1, null, 1);
                hashMap3.put((java.lang.Object)"resourceKey", (java.lang.Object)column13);
                androidx.room.util.TableInfo$Column column14 = new androidx.room.util.TableInfo$Column("fileHash", "TEXT", true, 0, null, 1);
                hashMap3.put((java.lang.Object)"fileHash", (java.lang.Object)column14);
                androidx.room.util.TableInfo$Column column15 = new androidx.room.util.TableInfo$Column("mimeType", "TEXT", true, 0, null, 1);
                hashMap3.put((java.lang.Object)"mimeType", (java.lang.Object)column15);
                androidx.room.util.TableInfo tableInfo5 = new androidx.room.util.TableInfo("WebResourceTable", (Map)hashMap3, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo6 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"WebResourceTable");
                if (!tableInfo5.equals((java.lang.Object)tableInfo6)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("WebResourceTable(com.urbanclap.urbanclap.ucshared.models.persistance.web_resources.entity.WebResourceEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo5);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo6);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                HashMap hashMap4 = new HashMap(2);
                androidx.room.util.TableInfo$Column column16 = new androidx.room.util.TableInfo$Column("requestId", "TEXT", true, 1, null, 1);
                hashMap4.put((java.lang.Object)"requestId", (java.lang.Object)column16);
                androidx.room.util.TableInfo$Column column17 = new androidx.room.util.TableInfo$Column("status", "TEXT", true, 0, null, 1);
                hashMap4.put((java.lang.Object)"status", (java.lang.Object)column17);
                androidx.room.util.TableInfo tableInfo7 = new androidx.room.util.TableInfo("VideoSeenRequests", (Map)hashMap4, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo8 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"VideoSeenRequests");
                if (!tableInfo7.equals((java.lang.Object)tableInfo8)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("VideoSeenRequests(com.urbanclap.urbanclap.ucshared.models.persistance.videoseenstatus.entity.VideoSeenStatusEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo7);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo8);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                HashMap hashMap5 = new HashMap(3);
                androidx.room.util.TableInfo$Column column18 = new androidx.room.util.TableInfo$Column("taskId", "TEXT", true, 1, null, 1);
                hashMap5.put((java.lang.Object)"taskId", (java.lang.Object)column18);
                androidx.room.util.TableInfo$Column column19 = new androidx.room.util.TableInfo$Column("taskType", "INTEGER", true, 0, null, 1);
                hashMap5.put((java.lang.Object)"taskType", (java.lang.Object)column19);
                androidx.room.util.TableInfo$Column column20 = new androidx.room.util.TableInfo$Column("serializedMetaData", "BLOB", false, 0, null, 1);
                hashMap5.put((java.lang.Object)"serializedMetaData", (java.lang.Object)column20);
                androidx.room.util.TableInfo tableInfo9 = new androidx.room.util.TableInfo("TaskTable", (Map)hashMap5, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo10 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"TaskTable");
                if (!tableInfo9.equals((java.lang.Object)tableInfo10)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("TaskTable(com.urbanclap.urbanclap.ucshared.models.persistance.download_task.TaskEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo9);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo10);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                HashMap hashMap6 = new HashMap(8);
                androidx.room.util.TableInfo$Column column21 = new androidx.room.util.TableInfo$Column("_id", "INTEGER", true, 1, null, 1);
                hashMap6.put((java.lang.Object)"_id", (java.lang.Object)column21);
                androidx.room.util.TableInfo$Column column22 = new androidx.room.util.TableInfo$Column("cityKey", "TEXT", true, 0, null, 1);
                hashMap6.put((java.lang.Object)"cityKey", (java.lang.Object)column22);
                androidx.room.util.TableInfo$Column column23 = new androidx.room.util.TableInfo$Column("image", "TEXT", false, 0, null, 1);
                hashMap6.put((java.lang.Object)"image", (java.lang.Object)column23);
                androidx.room.util.TableInfo$Column column24 = new androidx.room.util.TableInfo$Column("imageShape", "TEXT", false, 0, null, 1);
                hashMap6.put((java.lang.Object)"imageShape", (java.lang.Object)column24);
                androidx.room.util.TableInfo$Column column25 = new androidx.room.util.TableInfo$Column("title", "TEXT", true, 0, null, 1);
                hashMap6.put((java.lang.Object)"title", (java.lang.Object)column25);
                androidx.room.util.TableInfo$Column column26 = new androidx.room.util.TableInfo$Column("subtitles", "TEXT", false, 0, null, 1);
                hashMap6.put((java.lang.Object)"subtitles", (java.lang.Object)column26);
                androidx.room.util.TableInfo$Column column27 = new androidx.room.util.TableInfo$Column("tapAction", "TEXT", true, 0, null, 1);
                hashMap6.put((java.lang.Object)"tapAction", (java.lang.Object)column27);
                androidx.room.util.TableInfo$Column column28 = new androidx.room.util.TableInfo$Column("analytics", "TEXT", false, 0, null, 1);
                hashMap6.put((java.lang.Object)"analytics", (java.lang.Object)column28);
                androidx.room.util.TableInfo tableInfo11 = new androidx.room.util.TableInfo("SearchTable", (Map)hashMap6, (java.util.Set)new java.util.HashSet(0), (java.util.Set)new java.util.HashSet(0));
                androidx.room.util.TableInfo tableInfo12 = androidx.room.util.TableInfo.read((SupportSQLiteDatabase)supportSQLiteDatabase, (String)"SearchTable");
                if (!tableInfo11.equals((java.lang.Object)tableInfo12)) {
                    java.lang.StringBuilder stringBuilder = new java.lang.StringBuilder();
                    stringBuilder.append("SearchTable(com.urbanclap.urbanclap.ucshared.models.persistance.search_v2.SearchEntity).\n Expected:\n");
                    stringBuilder.append((java.lang.Object)tableInfo11);
                    stringBuilder.append("\n");
                    stringBuilder.append(" Found:\n");
                    stringBuilder.append((java.lang.Object)tableInfo12);
                    return new androidx.room.RoomOpenHelper$ValidationResult(false, stringBuilder.toString());
                }
                return new androidx.room.RoomOpenHelper$ValidationResult(true, null);
            }
        }, "42bc71dd82db92d393593a39c545ebbc", "fff6ecd0173232bf3eb3a6ac7a0ee792");
        SupportSQLiteOpenHelper.Configuration configuration = SupportSQLiteOpenHelper.Configuration.builder((Context)databaseConfiguration.context).name(databaseConfiguration.name).callback((SupportSQLiteOpenHelper.Callback)roomOpenHelper).build();
        return databaseConfiguration.sqliteOpenHelperFactory.create(configuration);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public c l() {
        if (this.p != null) {
            return this.p;
        }
        UCDatabase_Impl uCDatabase_Impl = this;
        synchronized (uCDatabase_Impl) {
            if (this.p != null) return this.p;
            this.p = new d((RoomDatabase)this);
            return this.p;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public t1.r.k.n.q0.x.f.a m() {
        if (this.m != null) {
            return this.m;
        }
        UCDatabase_Impl uCDatabase_Impl = this;
        synchronized (uCDatabase_Impl) {
            if (this.m != null) return this.m;
            this.m = new t1.r.k.n.q0.x.f.b((RoomDatabase)this);
            return this.m;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public t1.r.k.n.q0.u.b.a n() {
        if (this.q != null) {
            return this.q;
        }
        UCDatabase_Impl uCDatabase_Impl = this;
        synchronized (uCDatabase_Impl) {
            if (this.q != null) return this.q;
            this.q = new t1.r.k.n.q0.u.b.b((RoomDatabase)this);
            return this.q;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public t1.r.k.n.q0.u.c.b.a o() {
        if (this.o != null) {
            return this.o;
        }
        UCDatabase_Impl uCDatabase_Impl = this;
        synchronized (uCDatabase_Impl) {
            if (this.o != null) return this.o;
            this.o = new t1.r.k.n.q0.u.c.b.b((RoomDatabase)this);
            return this.o;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public t1.r.k.n.q0.u.d.b.a p() {
        if (this.n != null) {
            return this.n;
        }
        UCDatabase_Impl uCDatabase_Impl = this;
        synchronized (uCDatabase_Impl) {
            if (this.n != null) return this.n;
            this.n = new b((RoomDatabase)this);
            return this.n;
        }
    }
}

