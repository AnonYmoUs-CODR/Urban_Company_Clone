/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.warranty;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.warranty.WarrantyCta;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class TermsAndConditionModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="sticky_text")
    private final String a;
    @SerializedName(value="sticky_page_title")
    private final String b;
    @SerializedName(value="static_page_header")
    private final String c;
    @SerializedName(value="static_page_details")
    private final ArrayList<String> d;
    @SerializedName(value="cta")
    private final WarrantyCta e;

    public TermsAndConditionModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), parcel.readString(), (ArrayList<String>)parcel.createStringArrayList(), (WarrantyCta)parcel.readParcelable(WarrantyCta.class.getClassLoader()));
    }

    public TermsAndConditionModel(String string, String string2, String string3, ArrayList<String> arrayList, WarrantyCta warrantyCta) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = arrayList;
        this.e = warrantyCta;
    }

    public final WarrantyCta a() {
        return this.e;
    }

    public final String b() {
        return this.c;
    }

    public final ArrayList<String> c() {
        return this.d;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof TermsAndConditionModel)) break block3;
                TermsAndConditionModel termsAndConditionModel = (TermsAndConditionModel)object;
                if (l.c((Object)this.a, (Object)termsAndConditionModel.a) && l.c((Object)this.b, (Object)termsAndConditionModel.b) && l.c((Object)this.c, (Object)termsAndConditionModel.c) && l.c(this.d, termsAndConditionModel.d) && l.c((Object)this.e, (Object)termsAndConditionModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        ArrayList<String> arrayList = this.d;
        int n7 = arrayList != null ? arrayList.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        WarrantyCta warrantyCta = this.e;
        int n9 = 0;
        if (warrantyCta != null) {
            n9 = warrantyCta.hashCode();
        }
        return n8 + n9;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TermsAndConditionModel(tncText=");
        stringBuilder.append(this.a);
        stringBuilder.append(", tncTitle=");
        stringBuilder.append(this.b);
        stringBuilder.append(", tncHeader=");
        stringBuilder.append(this.c);
        stringBuilder.append(", tncPoints=");
        stringBuilder.append(this.d);
        stringBuilder.append(", tncCta=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeStringList(this.d);
        parcel.writeParcelable((Parcelable)this.e, n);
    }

    public static final class a
    implements Parcelable.Creator<TermsAndConditionModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public TermsAndConditionModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new TermsAndConditionModel(parcel);
        }

        public TermsAndConditionModel[] b(int n) {
            return new TermsAndConditionModel[n];
        }
    }

}

