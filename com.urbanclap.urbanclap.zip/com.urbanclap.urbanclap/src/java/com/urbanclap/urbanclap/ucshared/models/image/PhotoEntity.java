/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.image;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.image.Large;
import com.urbanclap.urbanclap.ucshared.models.image.Medium;
import com.urbanclap.urbanclap.ucshared.models.image.Thumb;

public class PhotoEntity
implements Parcelable {
    public static final Parcelable.Creator<PhotoEntity> CREATOR = new Parcelable.Creator<PhotoEntity>(){

        public PhotoEntity a(Parcel parcel) {
            return new PhotoEntity(parcel, null);
        }

        public PhotoEntity[] b(int n) {
            return new PhotoEntity[n];
        }
    };
    @SerializedName(value="s3_path")
    private String a;
    @SerializedName(value="base_url")
    private String b;
    @SerializedName(value="thumb")
    private Thumb c;
    @SerializedName(value="medium")
    private Medium d;
    @SerializedName(value="large")
    private Large e;

    public PhotoEntity() {
        this.a = "";
        this.b = "";
    }

    public PhotoEntity(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = (Thumb)parcel.readParcelable(Thumb.class.getClassLoader());
        this.d = (Medium)parcel.readParcelable(Medium.class.getClassLoader());
        this.e = (Large)parcel.readParcelable(Large.class.getClassLoader());
    }

    public /* synthetic */ PhotoEntity(Parcel parcel, a a2) {
        this(parcel);
    }

    public PhotoEntity(String string, String string2, Thumb thumb, Medium medium, Large large) {
        this.a = string;
        this.b = string2;
        this.c = thumb;
        this.d = medium;
        this.e = large;
    }

    public String a() {
        return this.b;
    }

    public String b() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.b);
        stringBuilder.append(this.e.a());
        stringBuilder.append(",f_webp");
        stringBuilder.append(this.a);
        return stringBuilder.toString();
    }

    public String c() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.b);
        stringBuilder.append(this.d.a());
        stringBuilder.append(",f_webp");
        stringBuilder.append(this.a);
        return stringBuilder.toString();
    }

    public String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.b);
        stringBuilder.append(this.c.a());
        stringBuilder.append(",f_webp");
        stringBuilder.append(this.a);
        return stringBuilder.toString();
    }

    public boolean equals(Object object) {
        if (!(object instanceof PhotoEntity)) {
            return false;
        }
        PhotoEntity photoEntity = (PhotoEntity)object;
        boolean bl = this.a.equals((Object)photoEntity.a);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.b.equals((Object)photoEntity.b);
            bl2 = false;
            if (bl3) {
                Thumb thumb = this.c;
                Thumb thumb2 = photoEntity.c;
                bl2 = false;
                if (thumb == thumb2) {
                    Medium medium = this.d;
                    Medium medium2 = photoEntity.d;
                    bl2 = false;
                    if (medium == medium2) {
                        Large large = this.e;
                        Large large2 = photoEntity.e;
                        bl2 = false;
                        if (large == large2) {
                            bl2 = true;
                        }
                    }
                }
            }
        }
        return bl2;
    }

    public String f() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.b);
        stringBuilder.append(this.c.b());
        stringBuilder.append(",f_webp");
        stringBuilder.append(this.a);
        return stringBuilder.toString();
    }

    public String g() {
        return this.e.a();
    }

    public boolean h() {
        String string;
        String string2 = this.a;
        return string2 != null && string2.length() > 0 && (string = this.b) != null && string.length() > 0;
    }

    public String i() {
        return this.c.b();
    }

    public String j() {
        return this.d.a();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeParcelable((Parcelable)this.e, n);
    }

}

