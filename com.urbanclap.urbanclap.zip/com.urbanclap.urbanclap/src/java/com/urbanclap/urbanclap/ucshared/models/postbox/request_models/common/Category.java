/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  androidx.annotation.NonNull
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common.CollaborationModel;
import java.util.ArrayList;
import java.util.List;

public class Category
implements Parcelable,
Comparable<Category> {
    public static final Parcelable.Creator<Category> CREATOR = new Parcelable.Creator<Category>(){

        public Category a(Parcel parcel) {
            return new Category(parcel);
        }

        public Category[] b(int n) {
            return new Category[n];
        }
    };
    @SerializedName(value="description_text_list")
    private ArrayList<String> A;
    @SerializedName(value="offer_text")
    private String B;
    @SerializedName(value="cta_text")
    private String C;
    @SerializedName(value="display_text")
    private String D;
    @SerializedName(value="collaboration_offer")
    private CollaborationModel E;
    @SerializedName(value="cta")
    private String F = "category";
    @SerializedName(value="_id")
    public String a;
    @SerializedName(value="key_name")
    public String b;
    @SerializedName(value="uuid_appflyer")
    public String c;
    @SerializedName(value="color")
    public String d;
    @SerializedName(value="font_name")
    public String e;
    @SerializedName(value="is_booking")
    public boolean f = false;
    @SerializedName(value="is_luminosity_enabled")
    public boolean g;
    @SerializedName(value="order_index")
    public String h;
    @SerializedName(value="display_name")
    public String i;
    @SerializedName(value="picture")
    public PictureObject j = new PictureObject();
    public String[] k;
    @SerializedName(value="gsv")
    public double s = 0.0;
    @SerializedName(value="quick_booking_enabled")
    private boolean t = false;
    @SerializedName(value="is_enable_fast_booking_flow")
    private boolean u = false;
    @SerializedName(value="desc")
    private String v;
    @SerializedName(value="is_single_page_qa_enabled")
    private boolean w;
    @SerializedName(value="provider_preference_enabled")
    private boolean x = false;
    @SerializedName(value="template_subtype")
    private String y;
    @SerializedName(value="description_text")
    private String z;

    public Category(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        this.e = parcel.readString();
        boolean bl = parcel.readByte() != 0;
        this.f = bl;
        boolean bl2 = parcel.readByte() != 0;
        this.g = bl2;
        this.h = parcel.readString();
        this.i = parcel.readString();
        this.j = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        this.k = parcel.createStringArray();
        this.s = parcel.readDouble();
        boolean bl3 = parcel.readByte() != 0;
        this.t = bl3;
        boolean bl4 = parcel.readByte() != 0;
        this.u = bl4;
        this.v = parcel.readString();
        boolean bl5 = parcel.readByte() != 0;
        this.w = bl5;
        byte by = parcel.readByte();
        boolean bl6 = false;
        if (by != 0) {
            bl6 = true;
        }
        this.x = bl6;
        this.y = parcel.readString();
        this.z = parcel.readString();
        this.A = parcel.createStringArrayList();
        this.B = parcel.readString();
        this.C = parcel.readString();
        this.D = parcel.readString();
        this.E = (CollaborationModel)parcel.readParcelable(CollaborationModel.class.getClassLoader());
        this.F = parcel.readString();
    }

    public Category(String string, String string2, String string3, PictureObject pictureObject) {
        this.i = string;
        this.b = string2;
        this.e = string3;
        this.j = pictureObject;
    }

    public int a(@NonNull Category category) {
        return this.i.compareToIgnoreCase(category.d());
    }

    public String b() {
        return this.v;
    }

    public PictureObject c() {
        return this.j;
    }

    public String d() {
        if (!TextUtils.isEmpty((CharSequence)this.i)) {
            return this.i;
        }
        if (!TextUtils.isEmpty((CharSequence)this.D)) {
            return this.D;
        }
        return "";
    }

    public int describeContents() {
        return 0;
    }

    public String f() {
        return this.b;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeByte((byte)this.f);
        parcel.writeByte((byte)this.g);
        parcel.writeString(this.h);
        parcel.writeString(this.i);
        parcel.writeParcelable((Parcelable)this.j, n);
        parcel.writeStringArray(this.k);
        parcel.writeDouble(this.s);
        parcel.writeByte((byte)this.t);
        parcel.writeByte((byte)this.u);
        parcel.writeString(this.v);
        parcel.writeByte((byte)this.w);
        parcel.writeByte((byte)this.x);
        parcel.writeString(this.y);
        parcel.writeString(this.z);
        parcel.writeStringList(this.A);
        parcel.writeString(this.B);
        parcel.writeString(this.C);
        parcel.writeString(this.D);
        parcel.writeParcelable((Parcelable)this.E, n);
        parcel.writeString(this.F);
    }

}

