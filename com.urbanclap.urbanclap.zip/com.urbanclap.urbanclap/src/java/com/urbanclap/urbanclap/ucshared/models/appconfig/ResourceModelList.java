/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.common.web.StaticResourceModel
 *  com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.urbanclap.urbanclap.ucshared.models.appconfig;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.common.web.StaticResourceModel;
import com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel;
import i2.a0.d.l;
import java.util.ArrayList;

@SuppressLint(value={"ParcelCreator"})
public final class ResourceModelList
extends ApiResponseBaseModel {
    @SerializedName(value="chunks")
    private final ArrayList<StaticResourceModel> e;

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ResourceModelList)) break block3;
                ResourceModelList resourceModelList = (ResourceModelList)((Object)object);
                if (l.c(this.e, resourceModelList.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public final ArrayList<StaticResourceModel> h() {
        return this.e;
    }

    public int hashCode() {
        ArrayList<StaticResourceModel> arrayList = this.e;
        if (arrayList != null) {
            return arrayList.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ResourceModelList(staticResourceModelList=");
        stringBuilder.append(this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

