/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.LocationModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionLocationModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionLocationModel$MetaData
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.String
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.LocationModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionLocationModel;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

public class QuestionLocationModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionLocationModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public MetaData A() {
        return this.G;
    }

    public boolean B() {
        return this.A() != null && this.A().a() != null && this.A().a().a();
    }

    public boolean C() {
        return this.A().a().b();
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void u(LocationModel locationModel) {
        super.u(locationModel);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return this.A().b(this.i());
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        LocationModel locationModel = this.i();
        if (this.s()) {
            if (locationModel != null && !TextUtils.isEmpty((CharSequence)locationModel.h())) {
                if (locationModel.d() != 0.0 && locationModel.e() != 0.0) {
                    if (TextUtils.isEmpty((CharSequence)locationModel.j())) {
                        l2.d(false);
                        l2.c(p.b.getString(m.j));
                        return l2;
                    }
                    l2.d(true);
                    return l2;
                }
                l2.d(false);
                l2.c(p.b.getString(m.n));
                return l2;
            }
            l2.d(false);
            l2.c(p.b.getString(m.f));
            return l2;
        }
        l2.d(true);
        return l2;
    }

    public String z() {
        if (this.C()) {
            return "Location/ Service area";
        }
        return "";
    }
}

