/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AvailableVoucher
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AvailableVoucher$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.DefaultVoucher
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.AvailableVoucher;
import com.urbanclap.urbanclap.ucshared.models.create_request.DefaultVoucher;
import com.urbanclap.urbanclap.ucshared.models.create_request.SummaryDetails;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class VoucherDetails
implements Parcelable {
    public static final Parcelable.Creator<VoucherDetails> CREATOR = new Parcelable.Creator<VoucherDetails>(){

        public VoucherDetails a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new VoucherDetails(parcel);
        }

        public VoucherDetails[] b(int n) {
            return new VoucherDetails[n];
        }
    };
    @SerializedName(value="available_vouchers")
    private final List<AvailableVoucher> a;
    @SerializedName(value="default_voucher")
    private final DefaultVoucher b;
    @SerializedName(value="summary_details")
    private final SummaryDetails c;
    public AvailableVoucher d;
    public int e;
    public int f;
    public int g;

    public VoucherDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        ArrayList arrayList = parcel.createTypedArrayList((Parcelable.Creator)AvailableVoucher.CREATOR);
        l.f((Object)arrayList, (String)"source.createTypedArrayList(AvailableVoucher)");
        Parcelable parcelable = parcel.readParcelable(DefaultVoucher.class.getClassLoader());
        l.f((Object)parcelable, (String)"source.readParcelable<De\u2026::class.java.classLoader)");
        this((List<AvailableVoucher>)arrayList, (DefaultVoucher)parcelable, (SummaryDetails)parcel.readParcelable(SummaryDetails.class.getClassLoader()), (AvailableVoucher)parcel.readParcelable(AvailableVoucher.class.getClassLoader()), parcel.readInt(), parcel.readInt(), parcel.readInt());
    }

    public VoucherDetails(List<AvailableVoucher> list, DefaultVoucher defaultVoucher, SummaryDetails summaryDetails, AvailableVoucher availableVoucher, int n, int n2, int n3) {
        l.g(list, (String)"available_vouchers");
        l.g((Object)defaultVoucher, (String)"default_voucher");
        this.a = list;
        this.b = defaultVoucher;
        this.c = summaryDetails;
        this.d = availableVoucher;
        this.e = n;
        this.f = n2;
        this.g = n3;
    }

    public final AvailableVoucher a() {
        return this.d;
    }

    public final int b() {
        return this.g;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof VoucherDetails)) break block3;
                VoucherDetails voucherDetails = (VoucherDetails)object;
                if (l.c(this.a, voucherDetails.a) && l.c((Object)this.b, (Object)voucherDetails.b) && l.c((Object)this.c, (Object)voucherDetails.c) && l.c((Object)this.d, (Object)voucherDetails.d) && this.e == voucherDetails.e && this.f == voucherDetails.f && this.g == voucherDetails.g) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        List<AvailableVoucher> list = this.a;
        int n = list != null ? list.hashCode() : 0;
        int n2 = n * 31;
        DefaultVoucher defaultVoucher = this.b;
        int n3 = defaultVoucher != null ? defaultVoucher.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        SummaryDetails summaryDetails = this.c;
        int n5 = summaryDetails != null ? summaryDetails.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        AvailableVoucher availableVoucher = this.d;
        int n7 = 0;
        if (availableVoucher != null) {
            n7 = availableVoucher.hashCode();
        }
        return 31 * (31 * (31 * (n6 + n7) + this.e) + this.f) + this.g;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("VoucherDetails(available_vouchers=");
        stringBuilder.append(this.a);
        stringBuilder.append(", default_voucher=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", summary_details=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", selectedVoucher=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", totalAcServicePrice=");
        stringBuilder.append(this.e);
        stringBuilder.append(", serviceAcQuantity=");
        stringBuilder.append(this.f);
        stringBuilder.append(", serviceDiscountedValue=");
        stringBuilder.append(this.g);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeTypedList(this.a);
        parcel.writeParcelable((Parcelable)this.b, 0);
        parcel.writeParcelable((Parcelable)this.c, 0);
        parcel.writeParcelable((Parcelable)this.d, 0);
        parcel.writeInt(this.e);
        parcel.writeInt(this.f);
        parcel.writeInt(this.g);
    }

}

