/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.NameData
 *  com.urbanclap.urbanclap.ucshared.models.UcAddress$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.k.n.q0.f
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.NameData;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import t1.r.k.n.q0.f;

public final class UcAddress
implements Parcelable,
f {
    public static final Parcelable.Creator<UcAddress> CREATOR = new a();
    public static final String F = "My Address";
    public boolean A;
    public int B;
    @Expose
    @SerializedName(value="house_address")
    private String C;
    @Expose
    @SerializedName(value="optional_instructions")
    private String D;
    @SerializedName(value="geoProofingLocality")
    private String E;
    @Expose
    @SerializedName(value="_id")
    private String a;
    @Expose
    @SerializedName(value="name")
    private String b;
    @Expose
    @SerializedName(value="city")
    private String c;
    @Expose
    @SerializedName(value="google_place_id")
    private String d;
    @Expose
    @SerializedName(value="address")
    private String e;
    @Expose
    @SerializedName(value="locality")
    private String f;
    @Expose
    @SerializedName(value="pin_code")
    private String g;
    @Expose
    @SerializedName(value="city_key")
    private String h;
    @Expose
    @SerializedName(value="accuracy")
    private double i;
    @Expose
    @SerializedName(value="is_auto_detected")
    private boolean j;
    @Expose
    @SerializedName(value="is_pin_moved")
    private boolean k;
    @Expose
    @SerializedName(value="point")
    private ArrayList<Double> s;
    @Expose
    @SerializedName(value="recipient_name_obj")
    private NameData t;
    @Expose
    @SerializedName(value="address_phone")
    private String u;
    @Expose
    @SerializedName(value="address_phone_with_isd")
    private String v;
    @Expose
    @SerializedName(value="isDefault")
    private boolean w;
    @Expose
    @SerializedName(value="show_map")
    private boolean x;
    public String y;
    public String z;

    public UcAddress() {
        this(null, null, null, null, null, null, null, null, 0.0, false, false, null, null, null, null, false, false, null, null, false, 0, null, null, null, 16777215, null);
    }

    public UcAddress(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        String string4 = parcel.readString();
        String string5 = parcel.readString();
        String string6 = parcel.readString();
        String string7 = parcel.readString();
        String string8 = parcel.readString();
        double d2 = parcel.readDouble();
        boolean bl = 1 == parcel.readInt();
        boolean bl2 = 1 == parcel.readInt();
        ArrayList arrayList = new ArrayList();
        parcel.readList((List)arrayList, Double.TYPE.getClassLoader());
        NameData nameData = (NameData)parcel.readParcelable(NameData.class.getClassLoader());
        String string9 = parcel.readString();
        String string10 = parcel.readString();
        boolean bl3 = 1 == parcel.readInt();
        boolean bl4 = 1 == parcel.readInt();
        String string11 = parcel.readString();
        String string12 = parcel.readString();
        boolean bl5 = 1 == parcel.readInt();
        int n2 = parcel.readInt();
        String string13 = parcel.readString();
        String string14 = parcel.readString();
        String string15 = parcel.readString();
        this(string, string2, string3, string4, string5, string6, string7, string8, d2, bl, bl2, (ArrayList<Double>)arrayList, nameData, string9, string10, bl3, bl4, string11, string12, bl5, n2, string13, string14, string15);
    }

    public UcAddress(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, double d2, boolean bl, boolean bl2, ArrayList<Double> arrayList, NameData nameData, String string9, String string10, boolean bl3) {
        this(string, string2, string3, string4, string5, string6, string7, string8, d2, bl, bl2, arrayList, nameData, string9, string10, bl3, false, null, null, false, 0, null, null, null, 16711680, null);
    }

    public UcAddress(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, double d2, boolean bl, boolean bl2, ArrayList<Double> arrayList, NameData nameData, String string9, String string10, boolean bl3, boolean bl4, String string11, String string12, boolean bl5, int n2, String string13, String string14, String string15) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = string6;
        this.g = string7;
        this.h = string8;
        this.i = d2;
        this.j = bl;
        this.k = bl2;
        this.s = arrayList;
        this.t = nameData;
        this.u = string9;
        this.v = string10;
        this.w = bl3;
        this.x = bl4;
        this.y = string11;
        this.z = string12;
        this.A = bl5;
        this.B = n2;
        this.C = string13;
        this.D = string14;
        this.E = string15;
    }

    public /* synthetic */ UcAddress(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, double d2, boolean bl, boolean bl2, ArrayList arrayList, NameData nameData, String string9, String string10, boolean bl3, boolean bl4, String string11, String string12, boolean bl5, int n2, String string13, String string14, String string15, int n3, g g2) {
        String string16 = (n3 & 1) != 0 ? "" : string;
        String string17 = (n3 & 2) != 0 ? null : string2;
        String string18 = (n3 & 4) != 0 ? "" : string3;
        String string19 = (n3 & 8) != 0 ? "" : string4;
        String string20 = (n3 & 16) != 0 ? "" : string5;
        String string21 = (n3 & 32) != 0 ? "" : string6;
        String string22 = (n3 & 64) != 0 ? "" : string7;
        String string23 = (n3 & 128) != 0 ? "" : string8;
        double d3 = (n3 & 256) != 0 ? 0.0 : d2;
        boolean bl6 = (n3 & 512) != 0 ? false : bl;
        boolean bl7 = (n3 & 1024) != 0 ? false : bl2;
        ArrayList arrayList2 = (n3 & 2048) != 0 ? new ArrayList() : arrayList;
        NameData nameData2 = (n3 & 4096) != 0 ? null : nameData;
        String string24 = (n3 & 8192) != 0 ? "" : string9;
        String string25 = string24;
        String string26 = (n3 & 16384) != 0 ? "" : string10;
        boolean bl8 = (n3 & 32768) != 0 ? false : bl3;
        boolean bl9 = (n3 & 65536) != 0 ? false : bl4;
        String string27 = (n3 & 131072) != 0 ? null : string11;
        String string28 = (n3 & 262144) != 0 ? null : string12;
        boolean bl10 = (n3 & 524288) != 0 ? false : bl5;
        int n4 = (n3 & 1048576) != 0 ? 0 : n2;
        String string29 = (n3 & 2097152) != 0 ? null : string13;
        String string30 = (n3 & 4194304) != 0 ? null : string14;
        String string31 = (n3 & 8388608) != 0 ? null : string15;
        this(string16, string17, string18, string19, string20, string21, string22, string23, d3, bl6, bl7, (ArrayList<Double>)arrayList2, nameData2, string25, string26, bl8, bl9, string27, string28, bl10, n4, string29, string30, string31);
    }

    public final boolean A() {
        return this.k;
    }

    public final boolean B(Object object, Object object2) {
        return object == null && object2 == null || object != null && object2 != null && l.c((Object)object, (Object)object2);
    }

    public final void C(double d2) {
        this.i = d2;
    }

    public final void D(String string) {
        this.e = string;
    }

    public final void E(String string) {
        this.u = string;
    }

    public final void F(String string) {
        this.v = string;
    }

    public final void G(boolean bl) {
        this.j = bl;
    }

    public final void H(String string) {
        this.c = string;
    }

    public final void I(String string) {
        this.h = string;
    }

    public final void J(boolean bl) {
        this.w = bl;
    }

    public final void K(boolean bl) {
        this.A = bl;
    }

    public final void N(String string) {
        this.z = string;
    }

    public final void O(String string) {
        this.d = string;
    }

    public final void P(int n2) {
        this.B = n2;
    }

    public final void Q(double d2) {
    }

    public final void R(double d2) {
    }

    public final void S(String string) {
        this.f = string;
    }

    public final void T(String string) {
        this.b = string;
    }

    public final void U(NameData nameData) {
        this.t = nameData;
    }

    public final void V(String string) {
        this.g = string;
    }

    public final void W(boolean bl) {
        this.k = bl;
    }

    public final void X(ArrayList<Double> arrayList) {
        this.s = arrayList;
    }

    public final void Y(boolean bl) {
        this.x = bl;
    }

    public final void Z(String string) {
        this.y = string;
    }

    public final double a() {
        return this.i;
    }

    public final void a0(String string) {
        this.a = string;
    }

    public final String b() {
        return this.e;
    }

    public final String c() {
        return this.u;
    }

    public final String d() {
        return this.v;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.c;
    }

    public boolean equals(Object object) {
        if (!(object instanceof UcAddress)) {
            return false;
        }
        UcAddress ucAddress = (UcAddress)object;
        boolean bl = this.B(this.e, ucAddress.e);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.B(this.f, ucAddress.f);
            bl2 = false;
            if (bl3) {
                boolean bl4 = this.B(this.c, ucAddress.c);
                bl2 = false;
                if (bl4) {
                    boolean bl5 = this.B(this.d, ucAddress.d);
                    bl2 = false;
                    if (bl5) {
                        boolean bl6 = this.B(this.h, ucAddress.h);
                        bl2 = false;
                        if (bl6) {
                            boolean bl7 = this.B(this.b, ucAddress.b);
                            bl2 = false;
                            if (bl7) {
                                boolean bl8 = this.B(this.a, ucAddress.a);
                                bl2 = false;
                                if (bl8) {
                                    boolean bl9 = this.B(this.l(), ucAddress.l());
                                    bl2 = false;
                                    if (bl9) {
                                        boolean bl10 = this.B(this.m(), ucAddress.m());
                                        bl2 = false;
                                        if (bl10) {
                                            boolean bl11 = this.B(this.g, ucAddress.g);
                                            bl2 = false;
                                            if (bl11) {
                                                bl2 = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return bl2;
    }

    public final String f() {
        return this.h;
    }

    public final String g() {
        if (!TextUtils.isEmpty((CharSequence)this.b)) {
            return this.b;
        }
        return F;
    }

    public final String h() {
        return this.z;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string3 = this.c;
        int n6 = string3 != null ? string3.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string4 = this.d;
        int n8 = string4 != null ? string4.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        String string5 = this.e;
        int n10 = string5 != null ? string5.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        String string6 = this.f;
        int n12 = string6 != null ? string6.hashCode() : 0;
        int n13 = 31 * (n11 + n12);
        String string7 = this.g;
        int n14 = string7 != null ? string7.hashCode() : 0;
        int n15 = 31 * (n13 + n14);
        String string8 = this.h;
        int n16 = string8 != null ? string8.hashCode() : 0;
        int n17 = 31 * (31 * (31 * (31 * (n15 + n16) + c.a(this.i)) + b.a(this.j)) + b.a(this.k));
        ArrayList<Double> arrayList = this.s;
        int n18 = arrayList != null ? arrayList.hashCode() : 0;
        int n19 = 31 * (n17 + n18);
        NameData nameData = this.t;
        int n20 = nameData != null ? nameData.hashCode() : 0;
        int n21 = 31 * (31 * (31 * (n19 + n20) + b.a(this.w)) + F.hashCode());
        String string9 = this.y;
        int n22 = string9 != null ? string9.hashCode() : 0;
        int n23 = 31 * (n21 + n22);
        String string10 = this.z;
        int n24 = string10 != null ? string10.hashCode() : 0;
        int n25 = 31 * (31 * (31 * (31 * (31 * (31 * (n23 + n24) + b.a(this.A)) + this.B) + c.a(this.l())) + c.a(this.m())) + b.a(this.x));
        String string11 = this.u;
        int n26 = string11 != null ? string11.hashCode() : 0;
        int n27 = 31 * (n25 + n26);
        String string12 = this.v;
        int n28 = string12 != null ? string12.hashCode() : 0;
        int n29 = 31 * (n27 + n28);
        String string13 = this.C;
        int n30 = string13 != null ? string13.hashCode() : 0;
        int n31 = 31 * (n29 + n30);
        String string14 = this.D;
        int n32 = string14 != null ? string14.hashCode() : 0;
        int n33 = 31 * (n31 + n32);
        String string15 = this.E;
        int n34 = 0;
        if (string15 != null) {
            n34 = string15.hashCode();
        }
        return n33 + n34;
    }

    public final String i() {
        return this.d;
    }

    public final String j() {
        return this.C;
    }

    public final int k() {
        return this.B;
    }

    public final double l() {
        Double d2;
        ArrayList<Double> arrayList = this.s;
        if (arrayList != null && (d2 = (Double)arrayList.get(1)) != null) {
            return d2;
        }
        return 0.0;
    }

    public final double m() {
        Double d2;
        ArrayList<Double> arrayList = this.s;
        if (arrayList != null && (d2 = (Double)arrayList.get(0)) != null) {
            return d2;
        }
        return 0.0;
    }

    public final String n() {
        return this.f;
    }

    public final String o() {
        return this.b;
    }

    public final NameData p() {
        return this.t;
    }

    public final String q() {
        return this.D;
    }

    public final String r() {
        return this.g;
    }

    public final ArrayList<Double> s() {
        return this.s;
    }

    public final boolean t() {
        return this.x;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UcAddress(_id=");
        stringBuilder.append(this.a);
        stringBuilder.append(", name=");
        stringBuilder.append(this.b);
        stringBuilder.append(", city=");
        stringBuilder.append(this.c);
        stringBuilder.append(", googlePlaceId=");
        stringBuilder.append(this.d);
        stringBuilder.append(", address=");
        stringBuilder.append(this.e);
        stringBuilder.append(", locality=");
        stringBuilder.append(this.f);
        stringBuilder.append(", pinCode=");
        stringBuilder.append(this.g);
        stringBuilder.append(", cityKey=");
        stringBuilder.append(this.h);
        stringBuilder.append(", accuracy=");
        stringBuilder.append(this.i);
        stringBuilder.append(", isAutoDetected=");
        stringBuilder.append(this.j);
        stringBuilder.append(", isPinCorrected=");
        stringBuilder.append(this.k);
        stringBuilder.append(", point=");
        stringBuilder.append(this.s);
        stringBuilder.append(", nameData=");
        stringBuilder.append((Object)this.t);
        stringBuilder.append(", addressPhoneNumber=");
        stringBuilder.append(this.u);
        stringBuilder.append(", addressPhoneNumberWithISD=");
        stringBuilder.append(this.v);
        stringBuilder.append(", isDefault=");
        stringBuilder.append(this.w);
        stringBuilder.append(", showMap=");
        stringBuilder.append(this.x);
        stringBuilder.append(", tempUniqueId=");
        stringBuilder.append(this.y);
        stringBuilder.append(", errorMessage=");
        stringBuilder.append(this.z);
        stringBuilder.append(", isError=");
        stringBuilder.append(this.A);
        stringBuilder.append(", itemTypeInList=");
        stringBuilder.append(this.B);
        stringBuilder.append(", houseAddress=");
        stringBuilder.append(this.C);
        stringBuilder.append(", optionalInstructions=");
        stringBuilder.append(this.D);
        stringBuilder.append(", geoProofingLocality=");
        stringBuilder.append(this.E);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final String u() {
        return this.y;
    }

    public final String v() {
        return this.a;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeDouble(this.i);
        parcel.writeInt((int)this.j);
        parcel.writeInt((int)this.k);
        parcel.writeList(this.s);
        parcel.writeParcelable((Parcelable)this.t, 0);
        parcel.writeString(this.u);
        parcel.writeString(this.v);
        parcel.writeInt((int)this.w);
        parcel.writeInt((int)this.x);
        parcel.writeString(this.y);
        parcel.writeString(this.z);
        parcel.writeInt((int)this.A);
        parcel.writeInt(this.B);
        parcel.writeString(this.C);
        parcel.writeString(this.D);
        parcel.writeString(this.E);
    }

    public final boolean x() {
        return this.j;
    }

    public final boolean y() {
        return this.w;
    }

    public final boolean z() {
        return this.A;
    }
}

