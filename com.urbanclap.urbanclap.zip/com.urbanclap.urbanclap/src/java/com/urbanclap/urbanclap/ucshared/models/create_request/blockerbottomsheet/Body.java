/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Body$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Body;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class Body
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="subtitle_bold")
    private final String b;
    @SerializedName(value="subtitle_regular")
    private final String c;
    @SerializedName(value="background_image")
    private final String d;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public Body(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        String string3 = parcel.readString();
        l.f((Object)string3, (String)"parcel.readString()");
        String string4 = parcel.readString();
        l.f((Object)string4, (String)"parcel.readString()");
        this(string, string2, string3, string4);
    }

    public Body(String string, String string2, String string3, String string4) {
        l.g((Object)string, (String)"title");
        l.g((Object)string2, (String)"subtitleBold");
        l.g((Object)string3, (String)"subtitleRegular");
        l.g((Object)string4, (String)"backgroundImage");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Body)) break block3;
                Body body = (Body)object;
                if (l.c((Object)this.a, (Object)body.a) && l.c((Object)this.b, (Object)body.b) && l.c((Object)this.c, (Object)body.c) && l.c((Object)this.d, (Object)body.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string3 = this.c;
        int n6 = string3 != null ? string3.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string4 = this.d;
        int n8 = 0;
        if (string4 != null) {
            n8 = string4.hashCode();
        }
        return n7 + n8;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Body(title=");
        stringBuilder.append(this.a);
        stringBuilder.append(", subtitleBold=");
        stringBuilder.append(this.b);
        stringBuilder.append(", subtitleRegular=");
        stringBuilder.append(this.c);
        stringBuilder.append(", backgroundImage=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
    }
}

