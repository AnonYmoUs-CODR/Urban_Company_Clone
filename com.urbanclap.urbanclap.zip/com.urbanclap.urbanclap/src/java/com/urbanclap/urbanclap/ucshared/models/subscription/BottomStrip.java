/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.subscription.BottomStrip$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.subscription.BottomStrip;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class BottomStrip
implements KParcelable {
    public static final a CREATOR;
    public static final String d = "{{DISCOUNT}}";
    public static final String e = "PERSISTENT";
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="action_text")
    private final String b;
    @SerializedName(value="bg_gradiant_colors")
    private final List<String> c;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public BottomStrip(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), (List<String>)parcel.createStringArrayList());
    }

    public BottomStrip(String string, String string2, List<String> list) {
        this.a = string;
        this.b = string2;
        this.c = list;
    }

    public static final /* synthetic */ String a() {
        return d;
    }

    public static final /* synthetic */ String b() {
        return e;
    }

    public final String c() {
        return this.b;
    }

    public final List<String> d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.a;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof BottomStrip)) break block3;
                BottomStrip bottomStrip = (BottomStrip)object;
                if (l.c((Object)this.a, (Object)bottomStrip.a) && l.c((Object)this.b, (Object)bottomStrip.b) && l.c(this.c, bottomStrip.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        List<String> list = this.c;
        int n6 = 0;
        if (list != null) {
            n6 = list.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("BottomStrip(type=");
        stringBuilder.append(this.a);
        stringBuilder.append(", actionText=");
        stringBuilder.append(this.b);
        stringBuilder.append(", bgGradientColors=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeStringList(this.c);
    }
}

