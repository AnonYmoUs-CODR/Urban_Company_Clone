/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

public final class UserType
extends Enum<UserType> {
    private static final /* synthetic */ UserType[] $VALUES;
    public static final /* enum */ UserType EXPIRED_HIGH_SAVINGS;
    public static final /* enum */ UserType EXPIRED_LOW_SAVINGS;
    public static final /* enum */ UserType EXPIRED_MEDIUM_SAVINGS;
    public static final /* enum */ UserType NEVER_SUBSCRIBED;
    public static final /* enum */ UserType SR_HIGH_SAVINGS;
    public static final /* enum */ UserType SR_LOW_SAVINGS;
    public static final /* enum */ UserType SR_MEDIUM_SAVINGS;
    public static final /* enum */ UserType SUBSCRIBED_NON_RENEWAL;

    public static {
        UserType userType;
        UserType userType2;
        UserType userType3;
        UserType userType4;
        UserType userType5;
        UserType userType6;
        UserType userType7;
        UserType userType8;
        UserType[] arruserType = new UserType[8];
        NEVER_SUBSCRIBED = userType = new UserType();
        arruserType[0] = userType;
        SR_LOW_SAVINGS = userType7 = new UserType();
        arruserType[1] = userType7;
        SR_MEDIUM_SAVINGS = userType6 = new UserType();
        arruserType[2] = userType6;
        SR_HIGH_SAVINGS = userType3 = new UserType();
        arruserType[3] = userType3;
        EXPIRED_LOW_SAVINGS = userType8 = new UserType();
        arruserType[4] = userType8;
        EXPIRED_MEDIUM_SAVINGS = userType4 = new UserType();
        arruserType[5] = userType4;
        EXPIRED_HIGH_SAVINGS = userType5 = new UserType();
        arruserType[6] = userType5;
        SUBSCRIBED_NON_RENEWAL = userType2 = new UserType();
        arruserType[7] = userType2;
        $VALUES = arruserType;
    }

    public static UserType valueOf(String string) {
        return (UserType)Enum.valueOf(UserType.class, (String)string);
    }

    public static UserType[] values() {
        return (UserType[])$VALUES.clone();
    }
}

