/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.PaymentSummary
 *  com.urbanclap.urbanclap.ucshared.models.PaymentSummarySplit$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummary;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummarySplit;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class PaymentSummarySplit
extends PaymentSummary {
    public static final a CREATOR;
    @SerializedName(value="subtext")
    private String y;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PaymentSummarySplit(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.y = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public final String q() {
        return this.y;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeString(this.y);
    }
}

