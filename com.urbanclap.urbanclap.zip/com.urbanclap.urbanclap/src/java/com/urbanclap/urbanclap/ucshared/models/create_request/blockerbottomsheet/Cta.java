/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Cta$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.Cta;
import com.urbanclap.urbanclap.ucshared.models.create_request.blockerbottomsheet.CtaItem;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class Cta
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="primary")
    private final CtaItem a;
    @SerializedName(value="secondary")
    private final CtaItem b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public Cta(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(CtaItem.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ct\u2026::class.java.classLoader)");
        CtaItem ctaItem = (CtaItem)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(CtaItem.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Ct\u2026::class.java.classLoader)");
        this(ctaItem, (CtaItem)parcelable2);
    }

    public Cta(CtaItem ctaItem, CtaItem ctaItem2) {
        l.g((Object)ctaItem, (String)"primary");
        l.g((Object)ctaItem2, (String)"secondary");
        this.a = ctaItem;
        this.b = ctaItem2;
    }

    public final CtaItem a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Cta)) break block3;
                Cta cta = (Cta)object;
                if (l.c((Object)this.a, (Object)cta.a) && l.c((Object)this.b, (Object)cta.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        CtaItem ctaItem = this.a;
        int n2 = ctaItem != null ? ctaItem.hashCode() : 0;
        int n3 = n2 * 31;
        CtaItem ctaItem2 = this.b;
        int n4 = 0;
        if (ctaItem2 != null) {
            n4 = ctaItem2.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cta(primary=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", secondary=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n2);
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

