/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.SummaryCtaTapAction;
import i2.a0.d.l;

public final class CtaInfo
implements Parcelable {
    public static final Parcelable.Creator<CtaInfo> CREATOR = new Parcelable.Creator<CtaInfo>(){

        public CtaInfo a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new CtaInfo(parcel);
        }

        public CtaInfo[] b(int n) {
            return new CtaInfo[n];
        }
    };
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="text_color")
    private final String b;
    @SerializedName(value="bg_color")
    private final String c;
    @SerializedName(value="border_color")
    private final String d;
    @SerializedName(value="action")
    private final SummaryCtaTapAction e;

    public CtaInfo(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), (SummaryCtaTapAction)parcel.readParcelable(SummaryCtaTapAction.class.getClassLoader()));
    }

    public CtaInfo(String string, String string2, String string3, String string4, SummaryCtaTapAction summaryCtaTapAction) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = summaryCtaTapAction;
    }

    public final String a() {
        return this.c;
    }

    public final String b() {
        return this.d;
    }

    public final SummaryCtaTapAction c() {
        return this.e;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CtaInfo)) break block3;
                CtaInfo ctaInfo = (CtaInfo)object;
                if (l.c((Object)this.a, (Object)ctaInfo.a) && l.c((Object)this.b, (Object)ctaInfo.b) && l.c((Object)this.c, (Object)ctaInfo.c) && l.c((Object)this.d, (Object)ctaInfo.d) && l.c((Object)this.e, (Object)ctaInfo.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.d;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        SummaryCtaTapAction summaryCtaTapAction = this.e;
        int n9 = 0;
        if (summaryCtaTapAction != null) {
            n9 = summaryCtaTapAction.hashCode();
        }
        return n8 + n9;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CtaInfo(text=");
        stringBuilder.append(this.a);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.c);
        stringBuilder.append(", borderColor=");
        stringBuilder.append(this.d);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeParcelable((Parcelable)this.e, 0);
    }

}

