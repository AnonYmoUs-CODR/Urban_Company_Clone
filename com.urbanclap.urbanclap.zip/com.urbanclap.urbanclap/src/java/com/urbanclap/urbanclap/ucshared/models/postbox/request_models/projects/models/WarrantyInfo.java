/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class WarrantyInfo
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="text_info")
    private final TextModel a;
    @SerializedName(value="bg_color")
    private final String b;
    @SerializedName(value="icon")
    private final PictureObject c;

    public WarrantyInfo(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel = (TextModel)parcelable;
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        Parcelable parcelable2 = parcel.readParcelable(PictureObject.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Pi\u2026::class.java.classLoader)");
        this(textModel, string, (PictureObject)parcelable2);
    }

    public WarrantyInfo(TextModel textModel, String string, PictureObject pictureObject) {
        l.g((Object)textModel, (String)"textInfo");
        l.g((Object)string, (String)"bgColor");
        l.g((Object)pictureObject, (String)"icon");
        this.a = textModel;
        this.b = string;
        this.c = pictureObject;
    }

    public final String a() {
        return this.b;
    }

    public final PictureObject b() {
        return this.c;
    }

    public final TextModel c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof WarrantyInfo)) break block3;
                WarrantyInfo warrantyInfo = (WarrantyInfo)object;
                if (l.c((Object)this.a, (Object)warrantyInfo.a) && l.c((Object)this.b, (Object)warrantyInfo.b) && l.c((Object)this.c, (Object)warrantyInfo.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        TextModel textModel = this.a;
        int n = textModel != null ? textModel.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        PictureObject pictureObject = this.c;
        int n5 = 0;
        if (pictureObject != null) {
            n5 = pictureObject.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WarrantyInfo(textInfo=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", icon=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
    }

    public static final class a
    implements Parcelable.Creator<WarrantyInfo> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public WarrantyInfo a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new WarrantyInfo(parcel);
        }

        public WarrantyInfo[] b(int n) {
            return new WarrantyInfo[n];
        }
    }

}

