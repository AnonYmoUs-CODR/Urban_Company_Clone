/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class MyReview
implements Parcelable {
    public static final Parcelable.Creator<MyReview> CREATOR = new Parcelable.Creator<MyReview>(){

        public MyReview a(Parcel parcel) {
            return new MyReview(parcel);
        }

        public MyReview[] b(int n) {
            return new MyReview[n];
        }
    };
    @SerializedName(value="comment")
    private String a;
    @SerializedName(value="rating")
    private float b;

    public MyReview() {
    }

    public MyReview(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readFloat();
    }

    public String a() {
        return this.a;
    }

    public float b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeFloat(this.b);
    }

}

