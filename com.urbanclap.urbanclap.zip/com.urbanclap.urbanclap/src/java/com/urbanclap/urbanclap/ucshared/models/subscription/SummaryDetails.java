/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import com.urbanclap.urbanclap.ucshared.models.subscription.Cta;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class SummaryDetails
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="heading")
    private final String b;
    @SerializedName(value="title")
    private final TextModel c;
    @SerializedName(value="sub_title")
    private final TextModel d;
    @SerializedName(value="header")
    private final TextModel e;
    @SerializedName(value="sub_title_prefix")
    private final String f;
    @SerializedName(value="sub_title_suffix")
    private final String g;
    @SerializedName(value="icon")
    private final PictureObject h;
    @SerializedName(value="cta")
    private final Cta i;
    @SerializedName(value="background_color")
    private final ArrayList<String> j;
    @SerializedName(value="center_right_image")
    private final PictureObject k;

    public SummaryDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        TextModel textModel = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        TextModel textModel2 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        TextModel textModel3 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        String string3 = parcel.readString();
        String string4 = parcel.readString();
        PictureObject pictureObject = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        Cta cta = (Cta)parcel.readParcelable(Cta.class.getClassLoader());
        ArrayList arrayList = parcel.readArrayList(String.class.getClassLoader());
        if (!(arrayList instanceof ArrayList)) {
            arrayList = null;
        }
        this(string, string2, textModel, textModel2, textModel3, string3, string4, pictureObject, cta, (ArrayList<String>)arrayList, (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader()));
    }

    public SummaryDetails(String string, String string2, TextModel textModel, TextModel textModel2, TextModel textModel3, String string3, String string4, PictureObject pictureObject, Cta cta, ArrayList<String> arrayList, PictureObject pictureObject2) {
        this.a = string;
        this.b = string2;
        this.c = textModel;
        this.d = textModel2;
        this.e = textModel3;
        this.f = string3;
        this.g = string4;
        this.h = pictureObject;
        this.i = cta;
        this.j = arrayList;
        this.k = pictureObject2;
    }

    public final ArrayList<String> a() {
        return this.j;
    }

    public final Cta b() {
        return this.i;
    }

    public final TextModel c() {
        return this.e;
    }

    public final PictureObject d() {
        return this.h;
    }

    public int describeContents() {
        return 0;
    }

    public final TextModel e() {
        return this.d;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SummaryDetails)) break block3;
                SummaryDetails summaryDetails = (SummaryDetails)object;
                if (l.c((Object)this.a, (Object)summaryDetails.a) && l.c((Object)this.b, (Object)summaryDetails.b) && l.c((Object)this.c, (Object)summaryDetails.c) && l.c((Object)this.d, (Object)summaryDetails.d) && l.c((Object)this.e, (Object)summaryDetails.e) && l.c((Object)this.f, (Object)summaryDetails.f) && l.c((Object)this.g, (Object)summaryDetails.g) && l.c((Object)this.h, (Object)summaryDetails.h) && l.c((Object)this.i, (Object)summaryDetails.i) && l.c(this.j, summaryDetails.j) && l.c((Object)this.k, (Object)summaryDetails.k)) break block2;
            }
            return false;
        }
        return true;
    }

    public final TextModel f() {
        return this.c;
    }

    public final String g() {
        return this.a;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        TextModel textModel = this.c;
        int n5 = textModel != null ? textModel.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        TextModel textModel2 = this.d;
        int n7 = textModel2 != null ? textModel2.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        TextModel textModel3 = this.e;
        int n9 = textModel3 != null ? textModel3.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        String string3 = this.f;
        int n11 = string3 != null ? string3.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string4 = this.g;
        int n13 = string4 != null ? string4.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        PictureObject pictureObject = this.h;
        int n15 = pictureObject != null ? pictureObject.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        Cta cta = this.i;
        int n17 = cta != null ? cta.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        ArrayList<String> arrayList = this.j;
        int n19 = arrayList != null ? arrayList.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        PictureObject pictureObject2 = this.k;
        int n21 = 0;
        if (pictureObject2 != null) {
            n21 = pictureObject2.hashCode();
        }
        return n20 + n21;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SummaryDetails(type=");
        stringBuilder.append(this.a);
        stringBuilder.append(", heading=");
        stringBuilder.append(this.b);
        stringBuilder.append(", title=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", subtitle=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", header=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", subtitlePrefix=");
        stringBuilder.append(this.f);
        stringBuilder.append(", subtitleSuffix=");
        stringBuilder.append(this.g);
        stringBuilder.append(", icon=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", cta=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", backgroundColor=");
        stringBuilder.append(this.j);
        stringBuilder.append(", centerRightImage=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeParcelable((Parcelable)this.e, n);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeParcelable((Parcelable)this.i, n);
        parcel.writeList(this.j);
        parcel.writeParcelable((Parcelable)this.k, n);
    }

    public static final class a
    implements Parcelable.Creator<SummaryDetails> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SummaryDetails a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SummaryDetails(parcel);
        }

        public SummaryDetails[] b(int n) {
            return new SummaryDetails[n];
        }
    }

}

