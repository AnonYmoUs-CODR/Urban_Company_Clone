/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.Cta
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.Cta;
import i2.a0.d.l;

public final class SelectedOrUnselectedModel
implements Parcelable {
    public static final Parcelable.Creator<SelectedOrUnselectedModel> CREATOR = new Parcelable.Creator<SelectedOrUnselectedModel>(){

        public SelectedOrUnselectedModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new SelectedOrUnselectedModel(parcel);
        }

        public SelectedOrUnselectedModel[] b(int n) {
            return new SelectedOrUnselectedModel[n];
        }
    };
    @SerializedName(value="cta")
    private final Cta a;
    @SerializedName(value="heading_text")
    private final String b;
    @SerializedName(value="sub_heading_text")
    private final String c;
    @SerializedName(value="bg_color")
    private final String d;

    public SelectedOrUnselectedModel(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        Parcelable parcelable = parcel.readParcelable(Cta.class.getClassLoader());
        l.f((Object)parcelable, (String)"source.readParcelable<Ct\u2026::class.java.classLoader)");
        Cta cta = (Cta)parcelable;
        String string = parcel.readString();
        l.f((Object)string, (String)"source.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"source.readString()");
        String string3 = parcel.readString();
        l.f((Object)string3, (String)"source.readString()");
        this(cta, string, string2, string3);
    }

    public SelectedOrUnselectedModel(Cta cta, String string, String string2, String string3) {
        l.g((Object)cta, (String)"cta");
        l.g((Object)string, (String)"heading_text");
        l.g((Object)string2, (String)"sub_heading_text");
        l.g((Object)string3, (String)"bgColor");
        this.a = cta;
        this.b = string;
        this.c = string2;
        this.d = string3;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SelectedOrUnselectedModel)) break block3;
                SelectedOrUnselectedModel selectedOrUnselectedModel = (SelectedOrUnselectedModel)object;
                if (l.c((Object)this.a, (Object)selectedOrUnselectedModel.a) && l.c((Object)this.b, (Object)selectedOrUnselectedModel.b) && l.c((Object)this.c, (Object)selectedOrUnselectedModel.c) && l.c((Object)this.d, (Object)selectedOrUnselectedModel.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Cta cta = this.a;
        int n = cta != null ? cta.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string3 = this.d;
        int n7 = 0;
        if (string3 != null) {
            n7 = string3.hashCode();
        }
        return n6 + n7;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SelectedOrUnselectedModel(cta=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", heading_text=");
        stringBuilder.append(this.b);
        stringBuilder.append(", sub_heading_text=");
        stringBuilder.append(this.c);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, 0);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
    }

}

