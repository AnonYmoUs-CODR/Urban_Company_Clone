/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.extras.EventData
 *  com.urbanclap.urbanclap.ucshared.extras.TrialSubscriptionBottomSheetData
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.extras.EventData;
import com.urbanclap.urbanclap.ucshared.extras.TrialSubscriptionBottomSheetData;
import i2.a0.d.l;

public final class SummaryCtaActionData
implements Parcelable {
    public static final Parcelable.Creator<SummaryCtaActionData> CREATOR = new Parcelable.Creator<SummaryCtaActionData>(){

        public SummaryCtaActionData a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new SummaryCtaActionData(parcel);
        }

        public SummaryCtaActionData[] b(int n) {
            return new SummaryCtaActionData[n];
        }
    };
    @SerializedName(value="plan_id")
    private final String a;
    @SerializedName(value="subscription_type")
    private final String b;
    @SerializedName(value="category_key")
    private final String c;
    @SerializedName(value="is_auto_added")
    private final boolean d;
    @SerializedName(value="event_data")
    private final EventData e;
    @SerializedName(value="bottom_sheet_data")
    private final TrialSubscriptionBottomSheetData f;

    public SummaryCtaActionData(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        boolean bl = 1 == parcel.readInt();
        this(string, string2, string3, bl, (EventData)parcel.readParcelable(EventData.class.getClassLoader()), (TrialSubscriptionBottomSheetData)parcel.readParcelable(TrialSubscriptionBottomSheetData.class.getClassLoader()));
    }

    public SummaryCtaActionData(String string, String string2, String string3, boolean bl, EventData eventData, TrialSubscriptionBottomSheetData trialSubscriptionBottomSheetData) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = bl;
        this.e = eventData;
        this.f = trialSubscriptionBottomSheetData;
    }

    public final TrialSubscriptionBottomSheetData a() {
        return this.f;
    }

    public final EventData b() {
        return this.e;
    }

    public final String c() {
        return this.a;
    }

    public final boolean d() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SummaryCtaActionData)) break block3;
                SummaryCtaActionData summaryCtaActionData = (SummaryCtaActionData)object;
                if (l.c((Object)this.a, (Object)summaryCtaActionData.a) && l.c((Object)this.b, (Object)summaryCtaActionData.b) && l.c((Object)this.c, (Object)summaryCtaActionData.c) && this.d == summaryCtaActionData.d && l.c((Object)this.e, (Object)summaryCtaActionData.e) && l.c((Object)this.f, (Object)summaryCtaActionData.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        int n7 = this.d ? 1 : 0;
        if (n7 != 0) {
            n7 = 1;
        }
        int n8 = 31 * (n6 + n7);
        EventData eventData = this.e;
        int n9 = eventData != null ? eventData.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        TrialSubscriptionBottomSheetData trialSubscriptionBottomSheetData = this.f;
        int n11 = 0;
        if (trialSubscriptionBottomSheetData != null) {
            n11 = trialSubscriptionBottomSheetData.hashCode();
        }
        return n10 + n11;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SummaryCtaActionData(planId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", subscriptionType=");
        stringBuilder.append(this.b);
        stringBuilder.append(", categoryKey=");
        stringBuilder.append(this.c);
        stringBuilder.append(", isAutoAdded=");
        stringBuilder.append(this.d);
        stringBuilder.append(", eventData=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", bottomsheetData=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeInt((int)this.d);
        parcel.writeParcelable((Parcelable)this.e, 0);
        parcel.writeParcelable((Parcelable)this.f, 0);
    }

}

