/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  androidx.annotation.Nullable
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import com.google.gson.annotations.SerializedName;

public class WalletDiscountModel
implements Parcelable {
    public static final Parcelable.Creator<WalletDiscountModel> CREATOR = new Parcelable.Creator<WalletDiscountModel>(){

        public WalletDiscountModel a(Parcel parcel) {
            return new WalletDiscountModel(parcel);
        }

        public WalletDiscountModel[] b(int n) {
            return new WalletDiscountModel[n];
        }
    };
    @SerializedName(value="applicable")
    @Nullable
    private Boolean a;
    @SerializedName(value="text")
    @Nullable
    private String b;

    public WalletDiscountModel(Parcel parcel) {
        Boolean bl;
        boolean bl2 = parcel.readByte();
        if (!bl2) {
            bl = null;
        } else {
            boolean bl3 = true;
            if (bl2 != bl3) {
                bl3 = false;
            }
            bl = bl3;
        }
        this.a = bl;
        this.b = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        Boolean bl = this.a;
        byte by = bl == null ? (byte)0 : (bl != false ? (byte)1 : 2);
        parcel.writeByte(by);
        parcel.writeString(this.b);
    }

}

