/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.Boolean
 */
package com.urbanclap.urbanclap.ucshared.models.request_models.claim_voucher.response;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

public final class ClaimVoucherResponseModel
extends ResponseBaseModel {
    @SerializedName(value="success")
    private Boolean e = Boolean.FALSE;
}

