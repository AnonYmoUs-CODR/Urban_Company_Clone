/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

public final class CardTypes
extends Enum<CardTypes> {
    private static final /* synthetic */ CardTypes[] $VALUES;
    public static final /* enum */ CardTypes booking_ask_cancel_card;
    public static final /* enum */ CardTypes booking_ask_cancel_option_card;
    public static final /* enum */ CardTypes booking_cancel_button_card;
    public static final /* enum */ CardTypes booking_cancel_request_card;
    public static final /* enum */ CardTypes booking_details_card;
    public static final /* enum */ CardTypes booking_has_service_completed_card;
    public static final /* enum */ CardTypes booking_has_the_professional_arrived_card;
    public static final /* enum */ CardTypes booking_profile_card;
    public static final /* enum */ CardTypes booking_request_placed_card;
    public static final /* enum */ CardTypes booking_review_card;
    public static final /* enum */ CardTypes booking_service_delivered;
    public static final /* enum */ CardTypes booking_summary_card;
    public static final /* enum */ CardTypes non_booking_ask_cancel_card;
    public static final /* enum */ CardTypes non_booking_browse_profiles_card;
    public static final /* enum */ CardTypes non_booking_cancel_request_card;
    public static final /* enum */ CardTypes non_booking_details_card;
    public static final /* enum */ CardTypes non_booking_hired_anyone_card;
    public static final /* enum */ CardTypes non_booking_hired_person_card;
    public static final /* enum */ CardTypes non_booking_more_responses_expected_card;
    public static final /* enum */ CardTypes non_booking_reasons_card;
    public static final /* enum */ CardTypes non_booking_request_placed_card;
    public static final /* enum */ CardTypes non_booking_response_card;
    public static final /* enum */ CardTypes non_booking_review_card;
    public static final /* enum */ CardTypes non_booking_sorry_card;
    public static final /* enum */ CardTypes provider_in_popUp;
    public static final /* enum */ CardTypes view_details_and_cancel_card;
    public static final /* enum */ CardTypes view_details_card;
    public static final /* enum */ CardTypes waveview_non_booking_card;

    public static {
        CardTypes cardTypes;
        CardTypes cardTypes2;
        CardTypes cardTypes3;
        CardTypes cardTypes4;
        CardTypes cardTypes5;
        CardTypes cardTypes6;
        CardTypes cardTypes7;
        CardTypes cardTypes8;
        CardTypes cardTypes9;
        CardTypes cardTypes10;
        CardTypes cardTypes11;
        CardTypes cardTypes12;
        CardTypes cardTypes13;
        CardTypes cardTypes14;
        CardTypes cardTypes15;
        CardTypes cardTypes16;
        CardTypes cardTypes17;
        CardTypes cardTypes18;
        CardTypes cardTypes19;
        CardTypes cardTypes20;
        CardTypes cardTypes21;
        CardTypes cardTypes22;
        CardTypes cardTypes23;
        CardTypes cardTypes24;
        CardTypes cardTypes25;
        CardTypes cardTypes26;
        CardTypes cardTypes27;
        CardTypes cardTypes28;
        booking_request_placed_card = cardTypes2 = new CardTypes();
        booking_summary_card = cardTypes15 = new CardTypes();
        booking_details_card = cardTypes12 = new CardTypes();
        booking_profile_card = cardTypes24 = new CardTypes();
        booking_cancel_request_card = cardTypes22 = new CardTypes();
        booking_review_card = cardTypes11 = new CardTypes();
        booking_has_the_professional_arrived_card = cardTypes25 = new CardTypes();
        booking_ask_cancel_option_card = cardTypes19 = new CardTypes();
        booking_ask_cancel_card = cardTypes7 = new CardTypes();
        booking_cancel_button_card = cardTypes28 = new CardTypes();
        booking_service_delivered = cardTypes6 = new CardTypes();
        booking_has_service_completed_card = cardTypes18 = new CardTypes();
        non_booking_request_placed_card = cardTypes9 = new CardTypes();
        non_booking_details_card = cardTypes27 = new CardTypes();
        non_booking_more_responses_expected_card = cardTypes16 = new CardTypes();
        non_booking_hired_anyone_card = cardTypes5 = new CardTypes();
        non_booking_reasons_card = cardTypes20 = new CardTypes();
        non_booking_sorry_card = cardTypes10 = new CardTypes();
        non_booking_browse_profiles_card = cardTypes26 = new CardTypes();
        non_booking_review_card = cardTypes13 = new CardTypes();
        non_booking_response_card = cardTypes17 = new CardTypes();
        non_booking_hired_person_card = cardTypes = new CardTypes();
        non_booking_cancel_request_card = cardTypes14 = new CardTypes();
        non_booking_ask_cancel_card = cardTypes23 = new CardTypes();
        view_details_card = cardTypes4 = new CardTypes();
        view_details_and_cancel_card = cardTypes21 = new CardTypes();
        provider_in_popUp = cardTypes3 = new CardTypes();
        waveview_non_booking_card = cardTypes8 = new CardTypes();
        $VALUES = new CardTypes[]{cardTypes2, cardTypes15, cardTypes12, cardTypes24, cardTypes22, cardTypes11, cardTypes25, cardTypes19, cardTypes7, cardTypes28, cardTypes6, cardTypes18, cardTypes9, cardTypes27, cardTypes16, cardTypes5, cardTypes20, cardTypes10, cardTypes26, cardTypes13, cardTypes17, cardTypes, cardTypes14, cardTypes23, cardTypes4, cardTypes21, cardTypes3, cardTypes8};
    }

    public static CardTypes valueOf(String string) {
        return (CardTypes)Enum.valueOf(CardTypes.class, (String)string);
    }

    public static CardTypes[] values() {
        return (CardTypes[])$VALUES.clone();
    }
}

