/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class Rewards
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="booking_price_discount_percentage")
    private final Integer a;

    public Rewards(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (!(object instanceof Integer)) {
            object = null;
        }
        this((Integer)object);
    }

    public Rewards(Integer n) {
        this.a = n;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Rewards)) break block3;
                Rewards rewards = (Rewards)object;
                if (l.c((Object)this.a, (Object)rewards.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Integer n = this.a;
        if (n != null) {
            return n.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Rewards(percentage=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeValue((Object)this.a);
    }

    public static final class a
    implements Parcelable.Creator<Rewards> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public Rewards a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new Rewards(parcel);
        }

        public Rewards[] b(int n) {
            return new Rewards[n];
        }
    }

}

