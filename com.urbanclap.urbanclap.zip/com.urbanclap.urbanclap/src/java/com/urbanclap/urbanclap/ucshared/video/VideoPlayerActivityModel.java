/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.ucshared.models.VideoDetailModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.video;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.ucshared.models.VideoDetailModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

public final class VideoPlayerActivityModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    public final VideoDetailModel a;

    public VideoPlayerActivityModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(VideoDetailModel.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.VideoDetailModel");
        this((VideoDetailModel)parcelable);
    }

    public VideoPlayerActivityModel(VideoDetailModel videoDetailModel) {
        l.g((Object)videoDetailModel, (String)"videoModel");
        this.a = videoDetailModel;
    }

    public final VideoDetailModel a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof VideoPlayerActivityModel)) break block3;
                VideoPlayerActivityModel videoPlayerActivityModel = (VideoPlayerActivityModel)object;
                if (l.c((Object)this.a, (Object)videoPlayerActivityModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        VideoDetailModel videoDetailModel = this.a;
        if (videoDetailModel != null) {
            return videoDetailModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("VideoPlayerActivityModel(videoModel=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
    }

    public static final class a
    implements Parcelable.Creator<VideoPlayerActivityModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public VideoPlayerActivityModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new VideoPlayerActivityModel(parcel);
        }

        public VideoPlayerActivityModel[] b(int n) {
            return new VideoPlayerActivityModel[n];
        }
    }

}

