/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.GeneratedAdapter
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.MethodCallsLogger
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.subscription;

import androidx.lifecycle.GeneratedAdapter;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MethodCallsLogger;
import com.urbanclap.urbanclap.ucshared.subscription.SubscriberAnimationView;

public class SubscriberAnimationView_LifecycleAdapter
implements GeneratedAdapter {
    public final SubscriberAnimationView a;

    public SubscriberAnimationView_LifecycleAdapter(SubscriberAnimationView subscriberAnimationView) {
        this.a = subscriberAnimationView;
    }

    public void callMethods(LifecycleOwner lifecycleOwner, Lifecycle.Event event, boolean bl, MethodCallsLogger methodCallsLogger) {
        boolean bl2 = methodCallsLogger != null;
        if (bl) {
            return;
        }
        if (event == Lifecycle.Event.ON_DESTROY && (!bl2 || methodCallsLogger.approveCall("onDestroy", 1))) {
            this.a.onDestroy();
        }
    }
}

