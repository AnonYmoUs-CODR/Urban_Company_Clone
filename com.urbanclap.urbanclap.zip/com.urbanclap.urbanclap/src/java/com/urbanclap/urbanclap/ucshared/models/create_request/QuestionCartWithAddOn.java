/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$Data$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$InfoBoxModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$RateCard
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn$Section
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$CartModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$SectionItemModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.j
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.p$a
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.CartWithAddonPrefillModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCartWithAddOn;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import i2.a0.d.g;
import i2.a0.d.l;
import i2.j;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import t1.r.k.n.m;
import t1.r.k.n.p;

/*
 * Exception performing whole class analysis.
 */
public class QuestionCartWithAddOn
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private final MetaData G;

    public QuestionCartWithAddOn(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.G = parcel.readParcelable(j.class.getClassLoader());
    }

    public CartWithAddonPrefillModel A() {
        QuestionNewPackageModel.CartModel cartModel;
        Data data;
        HashMap hashMap = new HashMap();
        MetaData metaData = this.G;
        ArrayList arrayList = metaData != null && (data = metaData.a()) != null && (cartModel = data.b()) != null ? cartModel.q() : null;
        l.e(arrayList);
        for (QuestionNewPackageModel.SectionItemModel sectionItemModel : arrayList) {
            l.f((Object)sectionItemModel, (String)"section");
            String string = sectionItemModel.o();
            l.f((Object)string, (String)"section.sectionKey");
            ArrayList arrayList2 = sectionItemModel.q();
            l.f((Object)arrayList2, (String)"section.stepperSectionItemList");
            hashMap.put((Object)string, (Object)arrayList2);
        }
        return new CartWithAddonPrefillModel((HashMap<String, ArrayList<ArrayList<String>>>)hashMap);
    }

    public final void B() {
        Data data;
        MetaData metaData;
        ArrayList arrayList;
        MetaData metaData2 = this.G;
        if (metaData2 != null) {
            metaData2.c(new ArrayList());
        }
        if ((metaData = this.G) != null && (data = metaData.a()) != null && (arrayList = data.f()) != null) {
            for (QuestionNewPackageModel.SectionItemModel sectionItemModel : arrayList) {
                ArrayList arrayList2;
                l.f((Object)sectionItemModel, (String)"it");
                ArrayList arrayList3 = sectionItemModel.q();
                if (arrayList3 == null) continue;
                boolean bl = arrayList3 == null || arrayList3.isEmpty();
                if (bl || (arrayList2 = this.G.b()) == null) continue;
                ArrayList arrayList4 = sectionItemModel.q();
                l.f((Object)arrayList4, (String)"it.stepperSectionItemList");
                String string = sectionItemModel.o();
                l.f((Object)string, (String)"it.sectionKey");
                arrayList2.add((Object)new /* Unavailable Anonymous Inner Class!! */);
            }
        }
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void t(Object object) {
        QuestionNewPackageModel.CartModel cartModel;
        Data data;
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.CartWithAddonPrefillModel");
        CartWithAddonPrefillModel cartWithAddonPrefillModel = (CartWithAddonPrefillModel)((Object)object);
        MetaData metaData = this.G;
        ArrayList arrayList = metaData != null && (data = metaData.a()) != null && (cartModel = data.b()) != null ? cartModel.q() : null;
        l.e(arrayList);
        for (QuestionNewPackageModel.SectionItemModel sectionItemModel : arrayList) {
            HashMap<String, ArrayList<ArrayList<String>>> hashMap = cartWithAddonPrefillModel.a();
            l.f((Object)sectionItemModel, (String)"section");
            ArrayList arrayList2 = (ArrayList)hashMap.get((Object)sectionItemModel.o());
            if (arrayList2 == null) continue;
            sectionItemModel.u(arrayList2);
        }
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return true;
    }

    public t1.r.k.n.q0.q.l y(int n2, float f2, String string) {
        ArrayList arrayList;
        MetaData metaData;
        this.B();
        if (this.s() && (metaData = this.G) != null && (arrayList = metaData.b()) != null) {
            boolean bl = arrayList == null || arrayList.isEmpty();
            if (bl) {
                t1.r.k.n.q0.q.l l2 = new t1.r.k.n.q0.q.l();
                l2.d(false);
                l2.c(p.d.a().getString(m.k));
                return l2;
            }
        }
        t1.r.k.n.q0.q.l l3 = new t1.r.k.n.q0.q.l();
        l3.d(true);
        return l3;
    }

    public final MetaData z() {
        return this.G;
    }

    /*
     * Exception performing whole class analysis.
     */
    public static final class Data
    extends QuestionNewPackageModel.DataItem {
        public static final a CREATOR;
        @SerializedName(value="info_box")
        private final InfoBoxModel f;
        @SerializedName(value="rate_card")
        private final RateCard g;

        public static {
            CREATOR = new /* Unavailable Anonymous Inner Class!! */;
        }

        public Data(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            super(parcel);
            this.f = parcel.readParcelable(InfoBoxModel.class.getClassLoader());
            this.g = parcel.readParcelable(RateCard.class.getClassLoader());
        }

        public int describeContents() {
            return 0;
        }

        public final InfoBoxModel g() {
            return this.f;
        }

        public final RateCard h() {
            return this.g;
        }

        public void writeToParcel(Parcel parcel, int n2) {
            l.g((Object)parcel, (String)"parcel");
            super.writeToParcel(parcel, n2);
            parcel.writeParcelable((Parcelable)this.f, n2);
            parcel.writeParcelable((Parcelable)this.g, n2);
        }
    }

}

