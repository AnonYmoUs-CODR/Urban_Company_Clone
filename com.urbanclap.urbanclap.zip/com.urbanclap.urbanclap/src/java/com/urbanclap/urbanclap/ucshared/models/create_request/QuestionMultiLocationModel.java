/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiLocationModel$DataModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiLocationModel$Location
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiLocationModel$LocationDataModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiLocationModel$MetaData
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiLocationModel;
import java.util.ArrayList;
import java.util.Iterator;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

public class QuestionMultiLocationModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionMultiLocationModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public MetaData A() {
        return this.G;
    }

    public final boolean B() {
        ArrayList arrayList = this.A().a().a();
        if (arrayList != null && arrayList.size() > 0) {
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                if (!(iterator.next()).h()) continue;
                return true;
            }
        }
        return false;
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return this.A().b();
    }

    public l y(int n2, float f2, String string) {
        ArrayList arrayList;
        l l2 = new l();
        if (this.s() && this.B() && (arrayList = this.A().a().a()) != null && arrayList.size() > 0) {
            for (Location location : arrayList) {
                if (!location.h() || location.c() != null) continue;
                l2.d(false);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("\"");
                stringBuilder.append(location.e());
                stringBuilder.append("\" ");
                stringBuilder.append(p.b.getString(m.p));
                l2.c(stringBuilder.toString());
                return l2;
            }
        }
        l2.d(true);
        return l2;
    }

    public ArrayList<Location> z() {
        return this.A().a().a();
    }
}

