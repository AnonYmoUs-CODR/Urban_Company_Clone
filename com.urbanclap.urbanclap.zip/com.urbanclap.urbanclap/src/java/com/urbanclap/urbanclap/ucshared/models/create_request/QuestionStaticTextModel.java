/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionStaticTextModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionStaticTextModel$MetaData
 *  java.lang.ClassLoader
 *  java.lang.String
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionStaticTextModel;
import t1.r.k.n.q0.q.l;

public class QuestionStaticTextModel
extends QuestionBaseModel
implements Parcelable {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionStaticTextModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public MetaData A() {
        return this.G;
    }

    public boolean B() {
        return this.A().a().b();
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return false;
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        l2.d(true);
        return l2;
    }

    public String z() {
        return this.A().a().a();
    }
}

