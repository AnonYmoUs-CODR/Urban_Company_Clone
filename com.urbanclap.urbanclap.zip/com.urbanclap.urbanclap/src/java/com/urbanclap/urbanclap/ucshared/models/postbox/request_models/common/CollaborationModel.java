/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common.CollaborationModel$a
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common.CollaborationModel;
import i2.a0.d.l;

public final class CollaborationModel
implements KParcelable {
    public static final Parcelable.Creator<CollaborationModel> CREATOR = new a();
    @SerializedName(value="offer_url")
    private String a;
    @SerializedName(value="loading_title")
    private String b;
    @SerializedName(value="loaded_title")
    private String c;
    @SerializedName(value="is_login_required")
    private boolean d;
    @SerializedName(value="offer_type")
    private String e;

    public CollaborationModel() {
        this.d = true;
    }

    public CollaborationModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        boolean bl = parcel.readInt() != 0;
        this.d = bl;
        this.e = parcel.readString();
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeInt((int)this.d);
        parcel.writeString(this.e);
    }
}

