/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.DayLevelSurgeDetailsModel
 *  com.urbanclap.urbanclap.ucshared.models.SlotModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AdvancePaymentModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.DateDetailsModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.DayLevelSurgeDetailsModel;
import com.urbanclap.urbanclap.ucshared.models.SlotModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.AdvancePaymentModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.DateDetailsModel;
import java.util.ArrayList;
import java.util.List;

public class SlotsDayModel
implements Parcelable {
    public static final Parcelable.Creator<SlotsDayModel> CREATOR = new Parcelable.Creator<SlotsDayModel>(){

        public SlotsDayModel a(Parcel parcel) {
            return new SlotsDayModel(parcel);
        }

        public SlotsDayModel[] b(int n) {
            return new SlotsDayModel[n];
        }
    };
    @SerializedName(value="date")
    private String a;
    @SerializedName(value="date_iso")
    private String b;
    @SerializedName(value="is_day_blocked")
    private boolean c;
    @SerializedName(value="date_details")
    private DateDetailsModel d;
    @SerializedName(value="slots")
    private ArrayList<SlotModel> e;
    @SerializedName(value="reason")
    private String f;
    @SerializedName(value="advance_payment_details")
    private AdvancePaymentModel g;
    @SerializedName(value="day_level_surge_details")
    private DayLevelSurgeDetailsModel h;
    @SerializedName(value="is_capacity_calculated")
    private boolean i;
    public boolean j;

    public SlotsDayModel() {
    }

    public SlotsDayModel(Parcel parcel) {
        ArrayList arrayList;
        this.a = parcel.readString();
        this.b = parcel.readString();
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.c = bl2;
        this.d = (DateDetailsModel)parcel.readParcelable(DateDetailsModel.class.getClassLoader());
        this.e = arrayList = new ArrayList();
        parcel.readList((List)arrayList, SlotModel.class.getClassLoader());
        this.f = parcel.readString();
        boolean bl3 = parcel.readByte() != 0;
        this.j = bl3;
        this.g = (AdvancePaymentModel)parcel.readParcelable(AdvancePaymentModel.class.getClassLoader());
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.i = bl;
        this.h = (DayLevelSurgeDetailsModel)parcel.readParcelable(DayLevelSurgeDetailsModel.class.getClassLoader());
    }

    public AdvancePaymentModel a() {
        return this.g;
    }

    public DateDetailsModel b() {
        return this.d;
    }

    public String c() {
        return this.b;
    }

    public DayLevelSurgeDetailsModel d() {
        return this.h;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.f;
    }

    public ArrayList<SlotModel> f() {
        return this.e;
    }

    public boolean g() {
        return this.i;
    }

    public boolean h() {
        return this.c;
    }

    public boolean i() {
        return this.j;
    }

    public void j(boolean bl) {
        this.j = bl;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeByte((byte)this.c);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeList(this.e);
        parcel.writeString(this.f);
        parcel.writeByte((byte)this.j);
        parcel.writeParcelable((Parcelable)this.g, n);
        parcel.writeByte((byte)this.i);
        parcel.writeParcelable((Parcelable)this.h, n);
    }

}

