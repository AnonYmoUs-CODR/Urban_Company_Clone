/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseIntArray
 *  android.view.View
 *  androidx.databinding.DataBinderMapper
 *  androidx.databinding.DataBindingComponent
 *  androidx.databinding.ViewDataBinding
 *  androidx.databinding.library.baseAdapters.DataBinderMapperImpl
 *  com.urbanclap.urbanclap.ucshared.DataBinderMapperImpl$a
 *  com.urbanclap.urbanclap.ucshared.DataBinderMapperImpl$b
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  t1.r.k.n.g0.d
 *  t1.r.k.n.l
 */
package com.urbanclap.urbanclap.ucshared;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.urbanclap.urbanclap.ucshared.DataBinderMapperImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import t1.r.k.n.g0.d;
import t1.r.k.n.l;

public class DataBinderMapperImpl
extends DataBinderMapper {
    public static final SparseIntArray a;

    public static {
        SparseIntArray sparseIntArray;
        a = sparseIntArray = new SparseIntArray(1);
        sparseIntArray.put(l.i, 1);
    }

    public List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(1);
        arrayList.add((Object)new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        return arrayList;
    }

    public String convertBrIdToString(int n2) {
        return (String)a.a.get(n2);
    }

    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int n2) {
        int n3 = a.get(n2);
        if (n3 > 0) {
            Object object = view.getTag();
            if (object != null) {
                if (n3 == 1) {
                    if ("layout/generic_data_binding_holder_0".equals(object)) {
                        return new d(dataBindingComponent, view);
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The tag for generic_data_binding_holder is invalid. Received: ");
                    stringBuilder.append(object);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            } else {
                throw new RuntimeException("view must have a tag");
            }
        }
        return null;
    }

    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] arrview, int n2) {
        if (arrview != null) {
            if (arrview.length == 0) {
                return null;
            }
            if (a.get(n2) > 0) {
                if (arrview[0].getTag() != null) {
                    return null;
                }
                throw new RuntimeException("view must have a tag");
            }
        }
        return null;
    }

    public int getLayoutId(String string) {
        if (string == null) {
            return 0;
        }
        Integer n2 = (Integer)b.a.get((Object)string);
        if (n2 == null) {
            return 0;
        }
        return n2;
    }
}

