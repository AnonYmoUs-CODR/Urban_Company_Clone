/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionExtraModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionExtraModel$MetaData
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionExtraModel;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

/*
 * Exception performing whole class analysis ignored.
 */
public class QuestionExtraModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionExtraModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public int A() {
        return DataItem.a(this.z().b());
    }

    public String B() {
        return this.z().b().c();
    }

    public String C() {
        return this.z().b().d();
    }

    public void D(String string) {
        this.z().b().e(string);
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return MetaData.a(this.z());
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        if (!this.s() && this.A() <= 0) {
            l2.d(true);
            return l2;
        }
        if (TextUtils.isEmpty((CharSequence)this.C())) {
            l2.d(false);
            l2.c(p.b.getString(m.w));
            return l2;
        }
        if (this.C().length() < this.A()) {
            l2.d(false);
            Context context = p.b;
            int n3 = m.g;
            Object[] arrobject = new Object[]{this.A()};
            l2.c(context.getString(n3, arrobject));
            return l2;
        }
        l2.d(true);
        return l2;
    }

    public MetaData z() {
        return this.G;
    }
}

