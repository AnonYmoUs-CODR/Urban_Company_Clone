/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.l;

public final class SubscriberAnimationDetail
implements Parcelable {
    public static final Parcelable.Creator<SubscriberAnimationDetail> CREATOR = new Parcelable.Creator<SubscriberAnimationDetail>(){

        public SubscriberAnimationDetail a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new SubscriberAnimationDetail(parcel);
        }

        public SubscriberAnimationDetail[] b(int n) {
            return new SubscriberAnimationDetail[n];
        }
    };
    @SerializedName(value="title")
    private final TextModel a;
    @SerializedName(value="subtitle")
    private final TextModel b;
    @SerializedName(value="subscription_type")
    private final String c;

    public SubscriberAnimationDetail(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this((TextModel)parcel.readParcelable(TextModel.class.getClassLoader()), (TextModel)parcel.readParcelable(TextModel.class.getClassLoader()), parcel.readString());
    }

    public SubscriberAnimationDetail(TextModel textModel, TextModel textModel2, String string) {
        this.a = textModel;
        this.b = textModel2;
        this.c = string;
    }

    public final String a() {
        return this.c;
    }

    public final TextModel b() {
        return this.b;
    }

    public final TextModel c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SubscriberAnimationDetail)) break block3;
                SubscriberAnimationDetail subscriberAnimationDetail = (SubscriberAnimationDetail)object;
                if (l.c((Object)this.a, (Object)subscriberAnimationDetail.a) && l.c((Object)this.b, (Object)subscriberAnimationDetail.b) && l.c((Object)this.c, (Object)subscriberAnimationDetail.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        TextModel textModel = this.a;
        int n = textModel != null ? textModel.hashCode() : 0;
        int n2 = n * 31;
        TextModel textModel2 = this.b;
        int n3 = textModel2 != null ? textModel2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string = this.c;
        int n5 = 0;
        if (string != null) {
            n5 = string.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SubscriberAnimationDetail(title=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", subtitle=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", subscriptionType=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeString(this.c);
    }

}

