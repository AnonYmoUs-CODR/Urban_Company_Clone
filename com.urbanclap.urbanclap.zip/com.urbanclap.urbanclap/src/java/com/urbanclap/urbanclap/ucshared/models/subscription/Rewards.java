/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.subscription.Rewards$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.subscription.Rewards;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class Rewards
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="discount_percentage")
    private final int a;
    @SerializedName(value="max_discount")
    private final Integer b;
    @SerializedName(value="fixed_discount")
    private final Integer c;
    @SerializedName(value="type")
    private final String d;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public Rewards(int n2, Integer n3, Integer n4, String string) {
        l.g((Object)string, (String)"type");
        this.a = n2;
        this.b = n3;
        this.c = n4;
        this.d = string;
    }

    public Rewards(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Class class_ = Integer.TYPE;
        Object object = parcel.readValue(class_.getClassLoader());
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
        int n2 = (Integer)object;
        Object object2 = parcel.readValue(class_.getClassLoader());
        if (!(object2 instanceof Integer)) {
            object2 = null;
        }
        Integer n3 = (Integer)object2;
        Object object3 = parcel.readValue(class_.getClassLoader());
        Object object4 = !(object3 instanceof Integer) ? null : object3;
        Integer n4 = (Integer)object4;
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(n2, n3, n4, string);
    }

    public final int a() {
        return this.a;
    }

    public final Integer b() {
        return this.c;
    }

    public final Integer c() {
        return this.b;
    }

    public final String d() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Rewards)) break block3;
                Rewards rewards = (Rewards)object;
                if (this.a == rewards.a && l.c((Object)this.b, (Object)rewards.b) && l.c((Object)this.c, (Object)rewards.c) && l.c((Object)this.d, (Object)rewards.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int n2 = 31 * this.a;
        Integer n3 = this.b;
        int n4 = n3 != null ? n3.hashCode() : 0;
        int n5 = 31 * (n2 + n4);
        Integer n6 = this.c;
        int n7 = n6 != null ? n6.hashCode() : 0;
        int n8 = 31 * (n5 + n7);
        String string = this.d;
        int n9 = 0;
        if (string != null) {
            n9 = string.hashCode();
        }
        return n8 + n9;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Rewards(discountPercentage=");
        stringBuilder.append(this.a);
        stringBuilder.append(", maxDiscount=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", fixedDiscount=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", type=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeValue((Object)this.a);
        parcel.writeValue((Object)this.b);
        parcel.writeValue((Object)this.c);
        parcel.writeString(this.d);
    }
}

