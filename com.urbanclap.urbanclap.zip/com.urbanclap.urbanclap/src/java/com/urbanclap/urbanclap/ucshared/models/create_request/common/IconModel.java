/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.common.IconModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.common.IconModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

public final class IconModel
implements KParcelable {
    public static final Parcelable.Creator<IconModel> CREATOR = new a();
    @SerializedName(value="icon_text")
    private final String a;
    @SerializedName(value="icon_color")
    private final String b;

    public IconModel(Parcel parcel) {
        this(parcel.readString(), parcel.readString());
    }

    public /* synthetic */ IconModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public IconModel(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        Class class_ = object != null ? object.getClass() : null;
        if (true ^ l.c(IconModel.class, (Object)class_)) {
            return false;
        }
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.common.IconModel");
        IconModel iconModel = (IconModel)object;
        if (true ^ l.c((Object)this.a, (Object)iconModel.a)) {
            return false;
        }
        return !(true ^ l.c((Object)this.b, (Object)iconModel.b));
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = 0;
        if (string2 != null) {
            n4 = string2.hashCode();
        }
        return n3 + n4;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }
}

