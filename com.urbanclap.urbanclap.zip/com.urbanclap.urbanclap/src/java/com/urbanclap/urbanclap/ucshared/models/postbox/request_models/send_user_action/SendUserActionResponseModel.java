/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action.SendUserActionResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action.UserActionBottomSheetModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action.SendUserActionResponseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.send_user_action.UserActionBottomSheetModel;
import i2.a0.d.l;

public final class SendUserActionResponseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<SendUserActionResponseModel> CREATOR = new a();
    @SerializedName(value="message")
    private String e;
    @SerializedName(value="bottom_sheet")
    private UserActionBottomSheetModel f;

    public SendUserActionResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.e = "";
        boolean bl = parcel.readInt() != 0;
        this.d(bl);
    }

    public int describeContents() {
        return 0;
    }

    public final UserActionBottomSheetModel e() {
        return this.f;
    }

    public final String f() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeInt((int)this.c());
    }
}

