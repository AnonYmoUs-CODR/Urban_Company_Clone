/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.happy_hour;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class HappyHourCartModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="sub_title")
    private final String a;

    public HappyHourCartModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString());
    }

    public HappyHourCartModel(String string) {
        this.a = string;
    }

    public final String a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HappyHourCartModel)) break block3;
                HappyHourCartModel happyHourCartModel = (HappyHourCartModel)object;
                if (l.c((Object)this.a, (Object)happyHourCartModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        if (string != null) {
            return string.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HappyHourCartModel(subTitle=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
    }

    public static final class a
    implements Parcelable.Creator<HappyHourCartModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public HappyHourCartModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new HappyHourCartModel(parcel);
        }

        public HappyHourCartModel[] b(int n) {
            return new HappyHourCartModel[n];
        }
    }

}

