/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class ReminderSubOption
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="delay_hours")
    private final Integer a;
    @SerializedName(value="heading")
    private final String b;
    @SerializedName(value="sub_heading")
    private final String c;

    public ReminderSubOption(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (!(object instanceof Integer)) {
            object = null;
        }
        this((Integer)object, parcel.readString(), parcel.readString());
    }

    public ReminderSubOption(Integer n, String string, String string2) {
        this.a = n;
        this.b = string;
        this.c = string2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ReminderSubOption)) break block3;
                ReminderSubOption reminderSubOption = (ReminderSubOption)object;
                if (l.c((Object)this.a, (Object)reminderSubOption.a) && l.c((Object)this.b, (Object)reminderSubOption.b) && l.c((Object)this.c, (Object)reminderSubOption.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Integer n = this.a;
        int n2 = n != null ? n.hashCode() : 0;
        int n3 = n2 * 31;
        String string = this.b;
        int n4 = string != null ? string.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string2 = this.c;
        int n6 = 0;
        if (string2 != null) {
            n6 = string2.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ReminderSubOption(delayHours=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", heading=");
        stringBuilder.append(this.b);
        stringBuilder.append(", subHeading=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeValue((Object)this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

    public static final class a
    implements Parcelable.Creator<ReminderSubOption> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ReminderSubOption a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ReminderSubOption(parcel);
        }

        public ReminderSubOption[] b(int n) {
            return new ReminderSubOption[n];
        }
    }

}

