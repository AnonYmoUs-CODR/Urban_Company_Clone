/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.StatusBarType;
import i2.a0.d.l;

public final class StatusBarTheme
implements Parcelable {
    public static final Parcelable.Creator<StatusBarTheme> CREATOR = new a();
    @SerializedName(value="type")
    private final StatusBarType a;
    @SerializedName(value="color")
    private final String b;

    public StatusBarTheme(StatusBarType statusBarType, String string) {
        l.g((Object)((Object)statusBarType), (String)"type");
        l.g((Object)string, (String)"color");
        this.a = statusBarType;
        this.b = string;
    }

    public final String a() {
        return this.b;
    }

    public final StatusBarType b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof StatusBarTheme)) break block3;
                StatusBarTheme statusBarTheme = (StatusBarTheme)object;
                if (l.c((Object)((Object)this.a), (Object)((Object)statusBarTheme.a)) && l.c((Object)this.b, (Object)statusBarTheme.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        StatusBarType statusBarType = this.a;
        int n = statusBarType != null ? statusBarType.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = 0;
        if (string != null) {
            n3 = string.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StatusBarTheme(type=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", color=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a.name());
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<StatusBarTheme> {
        public final StatusBarTheme a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new StatusBarTheme((StatusBarType)Enum.valueOf(StatusBarType.class, (String)parcel.readString()), parcel.readString());
        }

        public final StatusBarTheme[] b(int n) {
            return new StatusBarTheme[n];
        }
    }

}

