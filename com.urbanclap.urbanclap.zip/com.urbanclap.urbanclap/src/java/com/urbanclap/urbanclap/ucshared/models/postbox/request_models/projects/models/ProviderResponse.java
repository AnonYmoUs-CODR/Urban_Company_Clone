/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  java.io.Serializable
 *  java.lang.ClassLoader
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.ChatModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.MyReview;
import java.io.Serializable;

public class ProviderResponse
implements Parcelable {
    public static final Parcelable.Creator<ProviderResponse> CREATOR = new Parcelable.Creator<ProviderResponse>(){

        public ProviderResponse a(Parcel parcel) {
            return new ProviderResponse(parcel);
        }

        public ProviderResponse[] b(int n) {
            return new ProviderResponse[n];
        }
    };
    @SerializedName(value="provider_id")
    private String a;
    @SerializedName(value="provider_image")
    private PictureObject b;
    @SerializedName(value="provider_name")
    private String c;
    @SerializedName(value="is_reviewed")
    private boolean d;
    @SerializedName(value="rating")
    private Number e;
    @SerializedName(value="review_count")
    private int f;
    @SerializedName(value="is_hired")
    private boolean g;
    @SerializedName(value="phone")
    private String h;
    @SerializedName(value="chat")
    private ChatModel i;
    @SerializedName(value="my_review")
    private MyReview j = new MyReview();

    public ProviderResponse() {
    }

    public ProviderResponse(Parcel parcel) {
        this.a = parcel.readString();
        this.b = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        this.c = parcel.readString();
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.d = bl2;
        this.e = (Number)parcel.readSerializable();
        this.f = parcel.readInt();
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.g = bl;
        this.h = parcel.readString();
        this.i = (ChatModel)parcel.readParcelable(ChatModel.class.getClassLoader());
        this.j = (MyReview)parcel.readParcelable(MyReview.class.getClassLoader());
    }

    public ChatModel a() {
        return this.i;
    }

    public MyReview b() {
        return this.j;
    }

    public String c() {
        return this.a;
    }

    public PictureObject d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.c;
    }

    public String f() {
        return this.h;
    }

    public Number g() {
        return this.e;
    }

    public int h() {
        return this.f;
    }

    public boolean i() {
        return this.g;
    }

    public boolean j() {
        return this.d;
    }

    public void k(ChatModel chatModel) {
        this.i = chatModel;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeString(this.c);
        parcel.writeByte((byte)this.d);
        parcel.writeSerializable((Serializable)this.e);
        parcel.writeInt(this.f);
        parcel.writeByte((byte)this.g);
        parcel.writeString(this.h);
        parcel.writeParcelable((Parcelable)this.i, n);
        parcel.writeParcelable((Parcelable)this.j, n);
    }

}

