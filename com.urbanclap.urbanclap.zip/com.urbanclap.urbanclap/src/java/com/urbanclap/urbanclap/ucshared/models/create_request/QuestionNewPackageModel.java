/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfo
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfoData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$CartTapAction
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$ConfigModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$FilterCatalogList
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$TapActionData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$CartModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$MetaData
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  t1.r.k.n.c
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.PackageItemCart;
import com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import t1.r.k.n.c;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

/*
 * Exception performing whole class analysis ignored.
 */
public class QuestionNewPackageModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionNewPackageModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public PackageItemCart A() {
        return this.C().c();
    }

    public ArrayList<NewPackageItemModel> B() {
        ArrayList arrayList = new ArrayList();
        for (PackageCartItem packageCartItem : ((CartRepository)CartRepository.l.a()).e()) {
            if (!TextUtils.isEmpty((CharSequence)packageCartItem.c().a())) {
                arrayList.add((Object)packageCartItem.c());
                continue;
            }
            NewPackageItemModel newPackageItemModel = (NewPackageItemModel)this.C().d().b().m().get((Object)packageCartItem.id());
            if (newPackageItemModel == null) continue;
            if (packageCartItem.c() != null) {
                newPackageItemModel.K(packageCartItem.c().i());
            }
            arrayList.add((Object)newPackageItemModel);
        }
        return arrayList;
    }

    public MetaData C() {
        return this.G;
    }

    public boolean D(PackageCartItem packageCartItem, String string) {
        if (packageCartItem.c().F()) {
            List list = packageCartItem.c().E(string);
            if (list != null && packageCartItem.c().A() != null) {
                if (packageCartItem.c().A().a().a().a().d() == null) {
                    return true;
                }
                if (packageCartItem.c().A().a().a().a().d().equals((Object)list)) {
                    return true;
                }
                packageCartItem.c().A().a().a().a().e(list);
                packageCartItem.c().R(true);
            }
            return true;
        }
        List list = packageCartItem.c().t(string);
        if (list != null) {
            if (packageCartItem.c().g() == null) {
                return true;
            }
            if (packageCartItem.c().g().equals((Object)list)) {
                return true;
            }
            for (NewPackageItemModel.FilterCatalogList filterCatalogList : list) {
                if (CartModel.a(DataItem.a(MetaData.b(this.G))).get((Object)filterCatalogList.a) == null) {
                    return false;
                }
                for (CatalogIds catalogIds : filterCatalogList.b) {
                    if (CartModel.b(DataItem.a(MetaData.b(this.G))).get((Object)catalogIds.c()) != null) continue;
                    return false;
                }
            }
            packageCartItem.c().Q(list);
            packageCartItem.c().R(true);
        }
        return true;
    }

    public String a() {
        return null;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return MetaData.a(this.G).size() > 0;
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        ArrayList<NewPackageItemModel> arrayList = this.B();
        if (this.s() && arrayList.size() == 0) {
            l2.d(false);
            l2.c(p.b.getString(m.J));
            if (MetaData.a(this.G) != null) {
                MetaData.a(this.G).clear();
                return l2;
            }
        } else {
            if (this.s() && ((CartRepository)CartRepository.l.a()).A()) {
                l2.d(true);
                this.G.f(arrayList);
                return l2;
            }
            if (this.s() && (float)n2 > f2) {
                l2.d(false);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(p.b.getString(m.I));
                stringBuilder.append(c.q((String)String.valueOf((int)n2), (String)string));
                l2.c(stringBuilder.toString());
                return l2;
            }
            l2.d(true);
            this.G.f(arrayList);
        }
        return l2;
    }

    public boolean z(String string) {
        return this.C() != null && this.C().d() != null && this.C().d().b() != null && this.C().d().b().m() != null && this.C().d().b().m().containsKey((Object)string);
    }
}

