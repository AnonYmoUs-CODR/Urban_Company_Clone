/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common.Category
 *  java.util.ArrayList
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.view_all_categories.response;

import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.common.Category;
import java.util.ArrayList;

public final class ViewAllCategoriesResponseModel
extends ResponseBaseModel {
    public ArrayList<Category> e;

    public final ArrayList<Category> e() {
        return this.e;
    }

    public final void f(ArrayList<Category> arrayList) {
        this.e = arrayList;
    }
}

