/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.SummaryCtaAction;
import com.urbanclap.urbanclap.ucshared.models.subscription.SummaryCtaActionData;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

public final class SummaryCtaTapAction
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="type")
    private final SummaryCtaAction a;
    @SerializedName(value="data")
    private final SummaryCtaActionData b;

    public SummaryCtaTapAction(Parcel parcel) {
        SummaryCtaAction summaryCtaAction;
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (object != null) {
            SummaryCtaAction[] arrsummaryCtaAction = SummaryCtaAction.values();
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
            summaryCtaAction = arrsummaryCtaAction[(Integer)object];
        } else {
            summaryCtaAction = null;
        }
        this(summaryCtaAction, (SummaryCtaActionData)parcel.readParcelable(SummaryCtaActionData.class.getClassLoader()));
    }

    public SummaryCtaTapAction(SummaryCtaAction summaryCtaAction, SummaryCtaActionData summaryCtaActionData) {
        this.a = summaryCtaAction;
        this.b = summaryCtaActionData;
    }

    public final SummaryCtaActionData a() {
        return this.b;
    }

    public final SummaryCtaAction b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SummaryCtaTapAction)) break block3;
                SummaryCtaTapAction summaryCtaTapAction = (SummaryCtaTapAction)object;
                if (l.c((Object)((Object)this.a), (Object)((Object)summaryCtaTapAction.a)) && l.c((Object)this.b, (Object)summaryCtaTapAction.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        SummaryCtaAction summaryCtaAction = this.a;
        int n = summaryCtaAction != null ? summaryCtaAction.hashCode() : 0;
        int n2 = n * 31;
        SummaryCtaActionData summaryCtaActionData = this.b;
        int n3 = 0;
        if (summaryCtaActionData != null) {
            n3 = summaryCtaActionData.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SummaryCtaTapAction(actionType=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", actionData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        SummaryCtaAction summaryCtaAction = this.a;
        Integer n2 = summaryCtaAction != null ? Integer.valueOf((int)summaryCtaAction.ordinal()) : null;
        parcel.writeValue((Object)n2);
        parcel.writeParcelable((Parcelable)this.b, n);
    }

    public static final class a
    implements Parcelable.Creator<SummaryCtaTapAction> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SummaryCtaTapAction a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SummaryCtaTapAction(parcel);
        }

        public SummaryCtaTapAction[] b(int n) {
            return new SummaryCtaTapAction[n];
        }
    }

}

