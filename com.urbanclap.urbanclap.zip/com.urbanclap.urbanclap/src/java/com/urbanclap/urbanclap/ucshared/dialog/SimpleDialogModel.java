/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.dialog;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.l;

@SuppressLint(value={"ParcelCreator"})
public final class SimpleDialogModel
extends ResponseBaseModel {
    @SerializedName(value="title")
    private final TextModel e;
    @SerializedName(value="desc")
    private final TextModel f;
    @SerializedName(value="action")
    private final TextModel g;

    public SimpleDialogModel(TextModel textModel, TextModel textModel2, TextModel textModel3) {
        l.g((Object)textModel, (String)"title");
        l.g((Object)textModel3, (String)"action");
        this.e = textModel;
        this.f = textModel2;
        this.g = textModel3;
    }

    public final TextModel e() {
        return this.g;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SimpleDialogModel)) break block3;
                SimpleDialogModel simpleDialogModel = (SimpleDialogModel)((Object)object);
                if (l.c((Object)this.e, (Object)simpleDialogModel.e) && l.c((Object)this.f, (Object)simpleDialogModel.f) && l.c((Object)this.g, (Object)simpleDialogModel.g)) break block2;
            }
            return false;
        }
        return true;
    }

    public final TextModel f() {
        return this.f;
    }

    public final TextModel g() {
        return this.e;
    }

    public int hashCode() {
        TextModel textModel = this.e;
        int n2 = textModel != null ? textModel.hashCode() : 0;
        int n3 = n2 * 31;
        TextModel textModel2 = this.f;
        int n4 = textModel2 != null ? textModel2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        TextModel textModel3 = this.g;
        int n6 = 0;
        if (textModel3 != null) {
            n6 = textModel3.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SimpleDialogModel(title=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", desc=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", action=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

