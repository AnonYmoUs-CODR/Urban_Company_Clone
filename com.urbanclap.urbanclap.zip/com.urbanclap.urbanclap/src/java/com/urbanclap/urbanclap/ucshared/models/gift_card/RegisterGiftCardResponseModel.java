/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  t1.r.k.n.q0.n
 */
package com.urbanclap.urbanclap.ucshared.models.gift_card;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.l;
import java.util.List;
import t1.r.k.n.q0.n;

public final class RegisterGiftCardResponseModel
extends ResponseBaseModel {
    @SerializedName(value="is_valid")
    private final boolean e;
    @SerializedName(value="validation_errors")
    private List<n> f;
    @SerializedName(value="title")
    private final TextModel g;
    @SerializedName(value="desc")
    private final TextModel h;
    @SerializedName(value="action")
    private final TextModel i;
    @SerializedName(value="is_coupon_applied")
    private final boolean j;
    @SerializedName(value="gift_card_id")
    private final String k;

    public final String e() {
        return this.k;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof RegisterGiftCardResponseModel)) break block3;
                RegisterGiftCardResponseModel registerGiftCardResponseModel = (RegisterGiftCardResponseModel)((Object)object);
                if (this.e == registerGiftCardResponseModel.e && l.c(this.f, registerGiftCardResponseModel.f) && l.c((Object)this.g, (Object)registerGiftCardResponseModel.g) && l.c((Object)this.h, (Object)registerGiftCardResponseModel.h) && l.c((Object)this.i, (Object)registerGiftCardResponseModel.i) && this.j == registerGiftCardResponseModel.j && l.c((Object)this.k, (Object)registerGiftCardResponseModel.k)) break block2;
            }
            return false;
        }
        return true;
    }

    public final TextModel f() {
        return this.g;
    }

    public final List<n> g() {
        return this.f;
    }

    public final boolean h() {
        return this.j;
    }

    public int hashCode() {
        int n2 = this.e;
        int n3 = 1;
        if (n2 != 0) {
            n2 = 1;
        }
        int n4 = n2 * 31;
        List<n> list = this.f;
        int n5 = list != null ? list.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        TextModel textModel = this.g;
        int n7 = textModel != null ? textModel.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        TextModel textModel2 = this.h;
        int n9 = textModel2 != null ? textModel2.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        TextModel textModel3 = this.i;
        int n11 = textModel3 != null ? textModel3.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        int n13 = this.j;
        if (n13 == 0) {
            n3 = n13;
        }
        int n14 = 31 * (n12 + n3);
        String string = this.k;
        int n15 = 0;
        if (string != null) {
            n15 = string.hashCode();
        }
        return n14 + n15;
    }

    public final boolean i() {
        return this.e;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RegisterGiftCardResponseModel(isValid=");
        stringBuilder.append(this.e);
        stringBuilder.append(", validationErrors=");
        stringBuilder.append(this.f);
        stringBuilder.append(", title=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", desc=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", action=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", isCouponApplied=");
        stringBuilder.append(this.j);
        stringBuilder.append(", giftCardId=");
        stringBuilder.append(this.k);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

