/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.Number
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

@SuppressLint(value={"ParcelCreator"})
public final class GetProviderMaskedNumberResponseModel
extends ResponseBaseModel {
    @SerializedName(value="phone")
    private Number e;
}

