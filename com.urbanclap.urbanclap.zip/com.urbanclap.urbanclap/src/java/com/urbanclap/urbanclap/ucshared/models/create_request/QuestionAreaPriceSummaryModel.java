/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$AreaModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.String
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import t1.r.k.n.m;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;

public class QuestionAreaPriceSummaryModel
extends QuestionBaseModel {
    public static final Parcelable.Creator<QuestionAreaPriceSummaryModel> CREATOR = new a();
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;
    public Boolean H;

    public QuestionAreaPriceSummaryModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
        boolean bl = parcel.readByte() != 0;
        this.H = bl;
    }

    public AreaModel A() {
        if (this.B() != null && this.B().b() != null) {
            return this.B().b().a();
        }
        return null;
    }

    public MetaData B() {
        return this.G;
    }

    public String C() {
        return this.B().c();
    }

    public boolean D() {
        Boolean bl = this.H;
        if (bl == null) {
            return true;
        }
        return bl;
    }

    public void E(int n2) {
        this.B().d(n2);
    }

    public void F(String string) {
        this.B().e(string);
    }

    public void G(boolean bl) {
        this.H = bl;
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
        Boolean bl = this.H;
        byte by = 1;
        if (bl != null && !bl.booleanValue()) {
            by = 0;
        }
        parcel.writeByte(by);
    }

    public boolean x() {
        return true;
    }

    public l y(int n2, float f2, String string) {
        l l2 = new l();
        if (TextUtils.isEmpty((CharSequence)this.C())) {
            l2.c(p.b.getString(m.D));
            return l2;
        }
        l2.d(true);
        return l2;
    }

    public int z() {
        return this.B().a();
    }
}

