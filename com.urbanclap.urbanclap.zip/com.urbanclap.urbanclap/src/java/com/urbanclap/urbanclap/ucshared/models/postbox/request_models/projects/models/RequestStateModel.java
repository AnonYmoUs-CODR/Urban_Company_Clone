/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class RequestStateModel
implements Parcelable {
    public static final Parcelable.Creator<RequestStateModel> CREATOR = new Parcelable.Creator<RequestStateModel>(){

        public RequestStateModel a(Parcel parcel) {
            return new RequestStateModel(parcel, null);
        }

        public RequestStateModel[] b(int n) {
            return new RequestStateModel[n];
        }
    };
    @SerializedName(value="state")
    private String a;
    @SerializedName(value="description")
    private String b;

    public RequestStateModel(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
    }

    public /* synthetic */ RequestStateModel(Parcel parcel, a a2) {
        this(parcel);
    }

    public String a() {
        return this.b;
    }

    public String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

}

