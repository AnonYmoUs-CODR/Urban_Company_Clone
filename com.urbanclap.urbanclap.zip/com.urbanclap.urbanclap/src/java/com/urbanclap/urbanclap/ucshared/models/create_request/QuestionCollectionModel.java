/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel$MetaData$Data
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionTypes
 *  i2.a0.d.l
 *  i2.j
 *  i2.t
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Objects
 *  t1.r.k.n.m
 *  t1.r.k.n.p
 *  t1.r.k.n.p$a
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.CollectionPrefillModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionTypes;
import i2.a0.d.l;
import i2.j;
import i2.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Objects;
import t1.r.k.n.m;
import t1.r.k.n.p;

public final class QuestionCollectionModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private final MetaData G;

    public QuestionCollectionModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.G = parcel.readParcelable(j.class.getClassLoader());
    }

    public CollectionPrefillModel A() {
        LinkedHashMap linkedHashMap;
        Data data;
        ArrayList arrayList = new ArrayList();
        MetaData metaData = this.G;
        Collection collection = metaData != null && (data = metaData.a()) != null && (linkedHashMap = data.d()) != null ? linkedHashMap.values() : null;
        l.e(collection);
        for (QuestionBaseModel questionBaseModel : collection) {
            l.f((Object)questionBaseModel, (String)"question");
            Object object = questionBaseModel.l();
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel");
            arrayList.add((Object)((BasePrefillAnswerModel)object));
        }
        return new CollectionPrefillModel((ArrayList<BasePrefillAnswerModel>)arrayList);
    }

    public void B(Object object, Context context) {
        LinkedHashMap linkedHashMap;
        Data data;
        l.g((Object)context, (String)"context");
        MetaData metaData = this.G;
        Collection collection = metaData != null && (data = metaData.a()) != null && (linkedHashMap = data.d()) != null ? linkedHashMap.values() : null;
        l.e(collection);
        for (QuestionBaseModel questionBaseModel : collection) {
            if (questionBaseModel.c != QuestionTypes.DYNAMIC_PRICING) continue;
            questionBaseModel.m(object, context);
        }
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void t(Object object) {
        Data data;
        LinkedHashMap linkedHashMap;
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.create_request.CollectionPrefillModel");
        CollectionPrefillModel collectionPrefillModel = (CollectionPrefillModel)((Object)object);
        int n2 = 0;
        MetaData metaData = this.G;
        Collection collection = metaData != null && (data = metaData.a()) != null && (linkedHashMap = data.d()) != null ? linkedHashMap.values() : null;
        l.e(collection);
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            ((QuestionBaseModel)iterator.next()).t(collectionPrefillModel.a().get(n2));
            ++n2;
        }
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        Data data;
        LinkedHashMap linkedHashMap;
        MetaData metaData = this.G;
        Collection collection = metaData != null && (data = metaData.a()) != null && (linkedHashMap = data.d()) != null ? linkedHashMap.values() : null;
        l.e(collection);
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            (QuestionBaseModel)iterator.next();
            MetaData metaData2 = this.G;
            LinkedHashMap linkedHashMap2 = this.G.a().d();
            Collection collection2 = linkedHashMap2 != null ? linkedHashMap2.values() : null;
            l.e((Object)collection2);
            metaData2.b(new ArrayList(collection2));
        }
        return true;
    }

    public t1.r.k.n.q0.q.l y(int n2, float f2, String string) {
        Data data;
        LinkedHashMap linkedHashMap;
        MetaData metaData = this.G;
        Collection collection = metaData != null && (data = metaData.a()) != null && (linkedHashMap = data.d()) != null ? linkedHashMap.values() : null;
        l.e(collection);
        Iterator iterator = collection.iterator();
        boolean bl = false;
        while (iterator.hasNext()) {
            t1.r.k.n.q0.q.l l2 = ((QuestionBaseModel)iterator.next()).y(n2, f2, string);
            l.f((Object)l2, (String)"questionModel.validateAn\u2026otlaAmount, currencyCode)");
            if (!l2.b()) continue;
            bl = true;
        }
        t1.r.k.n.q0.q.l l3 = new t1.r.k.n.q0.q.l();
        l3.d(bl);
        l3.c(p.d.a().getString(m.B));
        return l3;
    }

    public final MetaData z() {
        return this.G;
    }
}

