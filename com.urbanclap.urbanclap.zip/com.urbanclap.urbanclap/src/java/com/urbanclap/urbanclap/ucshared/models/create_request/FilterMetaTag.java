/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.FilterMetaTag$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.OtherMetaTag
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.FilterMetaTag;
import com.urbanclap.urbanclap.ucshared.models.create_request.OtherMetaTag;

public class FilterMetaTag
extends OtherMetaTag {
    public static final Parcelable.Creator<FilterMetaTag> CREATOR = new a();
    @Expose
    @SerializedName(value="priority")
    public int c;

    public FilterMetaTag(Parcel parcel) {
        super(parcel);
        this.c = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeInt(this.c);
    }
}

