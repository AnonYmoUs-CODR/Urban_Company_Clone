/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import com.google.gson.annotations.SerializedName;

public final class SummaryCtaAction
extends Enum<SummaryCtaAction> {
    private static final /* synthetic */ SummaryCtaAction[] $VALUES;
    @SerializedName(value="add_subscription")
    public static final /* enum */ SummaryCtaAction ADD_SUBSCRIPTION;
    @SerializedName(value="dismiss")
    public static final /* enum */ SummaryCtaAction DISMISS;
    @SerializedName(value="open_subs_webview")
    public static final /* enum */ SummaryCtaAction OPEN_SUBSCRIPTION_WEBVIEW;
    @SerializedName(value="remove_subscription")
    public static final /* enum */ SummaryCtaAction REMOVE_SUBSCRIPTION;
    @SerializedName(value="show_info")
    public static final /* enum */ SummaryCtaAction SHOW_INFO;
    @SerializedName(value="show_plans")
    public static final /* enum */ SummaryCtaAction SHOW_PLANS;

    public static {
        SummaryCtaAction summaryCtaAction;
        SummaryCtaAction summaryCtaAction2;
        SummaryCtaAction summaryCtaAction3;
        SummaryCtaAction summaryCtaAction4;
        SummaryCtaAction summaryCtaAction5;
        SummaryCtaAction summaryCtaAction6;
        SummaryCtaAction[] arrsummaryCtaAction = new SummaryCtaAction[6];
        REMOVE_SUBSCRIPTION = summaryCtaAction = new SummaryCtaAction();
        arrsummaryCtaAction[0] = summaryCtaAction;
        SHOW_PLANS = summaryCtaAction4 = new SummaryCtaAction();
        arrsummaryCtaAction[1] = summaryCtaAction4;
        OPEN_SUBSCRIPTION_WEBVIEW = summaryCtaAction6 = new SummaryCtaAction();
        arrsummaryCtaAction[2] = summaryCtaAction6;
        ADD_SUBSCRIPTION = summaryCtaAction2 = new SummaryCtaAction();
        arrsummaryCtaAction[3] = summaryCtaAction2;
        SHOW_INFO = summaryCtaAction3 = new SummaryCtaAction();
        arrsummaryCtaAction[4] = summaryCtaAction3;
        DISMISS = summaryCtaAction5 = new SummaryCtaAction();
        arrsummaryCtaAction[5] = summaryCtaAction5;
        $VALUES = arrsummaryCtaAction;
    }

    public static SummaryCtaAction valueOf(String string) {
        return (SummaryCtaAction)Enum.valueOf(SummaryCtaAction.class, (String)string);
    }

    public static SummaryCtaAction[] values() {
        return (SummaryCtaAction[])$VALUES.clone();
    }
}

