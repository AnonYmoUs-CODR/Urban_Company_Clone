/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.MutableLiveData
 *  androidx.lifecycle.ViewModel
 *  com.urbanclap.urbanclap.ucshared.gift_card.RegisterGiftCardViewModel$ResponseStatus
 *  com.urbanclap.urbanclap.ucshared.gift_card.RegisterGiftCardViewModel$a
 *  com.urbanclap.urbanclap.ucshared.models.NameData
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  t1.r.h.a.f
 *  t1.r.h.a.j
 *  t1.r.k.n.c
 *  t1.r.k.n.c$b
 *  t1.r.k.n.n0.d
 *  t1.r.k.n.q0.n
 *  t1.r.k.n.q0.r.a
 *  t1.r.k.n.q0.v.c
 *  t1.r.k.n.q0.v.e
 *  t1.r.k.n.q0.v.e$a
 *  t1.r.k.n.s
 *  t1.r.k.n.s$a
 *  t1.r.k.n.u
 *  t1.r.k.n.w0.f
 */
package com.urbanclap.urbanclap.ucshared.gift_card;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.urbanclap.urbanclap.ucshared.gift_card.RegisterGiftCardViewModel;
import com.urbanclap.urbanclap.ucshared.models.NameData;
import com.urbanclap.urbanclap.ucshared.models.gift_card.RegisterGiftCardResponseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.List;
import java.util.Map;
import t1.r.h.a.j;
import t1.r.k.n.c;
import t1.r.k.n.n0.d;
import t1.r.k.n.q0.n;
import t1.r.k.n.q0.v.e;
import t1.r.k.n.s;
import t1.r.k.n.u;
import t1.r.k.n.w0.f;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public final class RegisterGiftCardViewModel
extends ViewModel {
    public static final a j;
    public final NameData a;
    public String b;
    public String c;
    public String d;
    public List<n> e;
    public String f;
    public RegisterGiftCardResponseModel g;
    public final MutableLiveData<ResponseStatus> h;
    public final MutableLiveData<Boolean> i;

    public static {
        j = new /* Unavailable Anonymous Inner Class!! */;
    }

    public RegisterGiftCardViewModel() {
        this.a = new NameData(null, null, 3, null);
        this.c = "";
        this.d = "";
        this.f = "";
        this.h = new MutableLiveData();
        this.i = new MutableLiveData();
    }

    public static final /* synthetic */ void z(RegisterGiftCardViewModel registerGiftCardViewModel, RegisterGiftCardResponseModel registerGiftCardResponseModel) {
        registerGiftCardViewModel.L(registerGiftCardResponseModel);
    }

    public final String A() {
        return this.f;
    }

    public final String B() {
        return this.c;
    }

    public final String C() {
        return this.d;
    }

    public final String E() {
        return this.b;
    }

    public final NameData F() {
        return this.a;
    }

    public final RegisterGiftCardResponseModel G() {
        return this.g;
    }

    public final LiveData<ResponseStatus> H() {
        return this.h;
    }

    public final List<n> I() {
        return this.e;
    }

    public final void K(String string) {
        this.i.setValue((Object)Boolean.FALSE);
        this.h.setValue((Object)ResponseStatus.FAILURE);
        if (string == null) {
            string = "";
        }
        this.f = string;
    }

    public final void L(RegisterGiftCardResponseModel registerGiftCardResponseModel) {
        this.i.setValue((Object)Boolean.FALSE);
        if (!registerGiftCardResponseModel.i()) {
            this.e = registerGiftCardResponseModel.g();
            this.h.postValue((Object)ResponseStatus.INVALID);
            return;
        }
        this.g = registerGiftCardResponseModel;
        this.h.postValue((Object)ResponseStatus.SUCCESS);
    }

    public final LiveData<Boolean> M() {
        return this.i;
    }

    public final void N() {
        this.i.setValue((Object)Boolean.TRUE);
        e.a a2 = new e.a();
        a2.g((j)new u());
        a2.h(s.b.l());
        String string = f.c.b();
        l.e((Object)string);
        NameData nameData = this.a;
        String string2 = this.b;
        String string3 = this.c;
        String string4 = this.d;
        String string5 = d.c.g();
        c.b b2 = c.c;
        t1.r.k.n.q0.r.a a3 = new t1.r.k.n.q0.r.a(string, nameData, string2, string3, string4, string5, b2.t(), b2.o(), b2.n());
        a2.a((t1.r.k.n.q0.v.c)a3);
        a2.j((t1.r.h.a.f)a.a(j, (RegisterGiftCardViewModel)this));
        a2.f().k();
    }

    public final void O(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.c = string;
    }

    public final void P(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.d = string;
    }

    public final void Q(String string) {
        this.b = string;
    }
}

