/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import com.google.gson.annotations.SerializedName;

public final class StatusBarType
extends Enum<StatusBarType> {
    private static final /* synthetic */ StatusBarType[] $VALUES;
    @SerializedName(value="dark")
    public static final /* enum */ StatusBarType DARK;
    @SerializedName(value="light")
    public static final /* enum */ StatusBarType LIGHT;

    public static {
        StatusBarType statusBarType;
        StatusBarType statusBarType2;
        StatusBarType[] arrstatusBarType = new StatusBarType[2];
        LIGHT = statusBarType = new StatusBarType();
        arrstatusBarType[0] = statusBarType;
        DARK = statusBarType2 = new StatusBarType();
        arrstatusBarType[1] = statusBarType2;
        $VALUES = arrstatusBarType;
    }

    public static StatusBarType valueOf(String string) {
        return (StatusBarType)Enum.valueOf(StatusBarType.class, (String)string);
    }

    public static StatusBarType[] values() {
        return (StatusBarType[])$VALUES.clone();
    }
}

