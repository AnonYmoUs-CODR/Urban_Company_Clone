/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  androidx.annotation.Nullable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ProviderAvailability
 *  java.lang.Boolean
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.k.n.m
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.create_request.ProviderAvailability;
import com.urbanclap.urbanclap.ucshared.models.create_request.SlotsDayModel;
import java.util.ArrayList;
import java.util.List;
import t1.r.k.n.m;
import t1.r.k.n.p;

public class ReBookingProviderModel
implements Parcelable {
    public static final Parcelable.Creator<ReBookingProviderModel> CREATOR = new Parcelable.Creator<ReBookingProviderModel>(){

        public ReBookingProviderModel a(Parcel parcel) {
            return new ReBookingProviderModel(parcel);
        }

        public ReBookingProviderModel[] b(int n) {
            return new ReBookingProviderModel[n];
        }
    };
    @Expose
    @SerializedName(value="display_msg")
    private String a = p.b.getString(m.E);
    @Expose
    @SerializedName(value="provider_id")
    private String b;
    @Expose
    @SerializedName(value="metadata")
    private MetaData c;
    @Expose
    @SerializedName(value="provider_slot")
    private ArrayList<SlotsDayModel> d;
    @Expose
    @SerializedName(value="is_selected")
    private boolean e;

    public ReBookingProviderModel(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = (MetaData)parcel.readParcelable(MetaData.class.getClassLoader());
        this.d = parcel.createTypedArrayList(SlotsDayModel.CREATOR);
        boolean bl = parcel.readByte() != 0;
        this.e = bl;
    }

    public String a() {
        return this.a;
    }

    public MetaData b() {
        return this.c;
    }

    public String c() {
        return this.b;
    }

    public ArrayList<SlotsDayModel> d() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public boolean e() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeTypedList(this.d);
        parcel.writeByte((byte)(this.e ? 1 : 0));
    }

    public static class MetaData
    implements Parcelable {
        public static final Parcelable.Creator<MetaData> CREATOR = new Parcelable.Creator<MetaData>(){

            public MetaData a(Parcel parcel) {
                return new MetaData(parcel);
            }

            public MetaData[] b(int n) {
                return new MetaData[n];
            }
        };
        @SerializedName(value="name")
        private String a;
        @SerializedName(value="rating")
        private int b;
        @SerializedName(value="profile_pic")
        private PictureObject c;
        @SerializedName(value="availability")
        @Nullable
        private ProviderAvailability d;
        @SerializedName(value="provider_tag")
        @Nullable
        private String e;
        @SerializedName(value="vaccination_tag")
        @Nullable
        private VaccinationTag f;
        @SerializedName(value="overlay_image")
        private PictureObject g;
        @SerializedName(value="is_ucplus_provider")
        private boolean h;
        @SerializedName(value="description")
        private String i;

        public MetaData(Parcel parcel) {
            this.a = parcel.readString();
            this.b = parcel.readInt();
            this.c = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
            this.d = (ProviderAvailability)parcel.readParcelable(ProviderAvailability.class.getClassLoader());
            this.e = parcel.readString();
            this.f = (VaccinationTag)parcel.readParcelable(VaccinationTag.class.getClassLoader());
            this.g = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
            boolean bl = parcel.readByte() != 0;
            this.h = bl;
            this.i = parcel.readString();
        }

        public String a() {
            return this.i;
        }

        @Nullable
        public PictureObject b() {
            return this.g;
        }

        public PictureObject c() {
            return this.c;
        }

        @Nullable
        public ProviderAvailability d() {
            return this.d;
        }

        public int describeContents() {
            return 0;
        }

        public String e() {
            return this.a;
        }

        public String f() {
            return this.e;
        }

        public int g() {
            return this.b;
        }

        @Nullable
        public VaccinationTag h() {
            return this.f;
        }

        public boolean i() {
            return this.h;
        }

        public void writeToParcel(Parcel parcel, int n) {
            parcel.writeString(this.a);
            parcel.writeInt(this.b);
            parcel.writeParcelable((Parcelable)this.c, n);
            parcel.writeParcelable((Parcelable)this.d, n);
            parcel.writeString(this.e);
            parcel.writeParcelable((Parcelable)this.f, n);
            parcel.writeParcelable((Parcelable)this.g, n);
            parcel.writeByte((byte)this.h);
            parcel.writeString(this.i);
        }

        public static class VaccinationTag
        implements Parcelable {
            public static final Parcelable.Creator<VaccinationTag> CREATOR = new Parcelable.Creator<VaccinationTag>(){

                public VaccinationTag a(Parcel parcel) {
                    return new VaccinationTag(parcel);
                }

                public VaccinationTag[] b(int n) {
                    return new VaccinationTag[n];
                }
            };
            @SerializedName(value="is_visible")
            @Nullable
            private Boolean a;
            @SerializedName(value="text")
            @Nullable
            private String b;

            public VaccinationTag(Parcel parcel) {
                Boolean bl;
                boolean bl2 = parcel.readByte();
                if (!bl2) {
                    bl = null;
                } else {
                    boolean bl3 = true;
                    if (bl2 != bl3) {
                        bl3 = false;
                    }
                    bl = bl3;
                }
                this.a = bl;
                this.b = parcel.readString();
            }

            public String a() {
                return this.b;
            }

            public Boolean b() {
                return this.a;
            }

            public int describeContents() {
                return 0;
            }

            public void writeToParcel(Parcel parcel, int n) {
                Boolean bl = this.a;
                byte by = bl == null ? (byte)0 : (bl != false ? (byte)1 : 2);
                parcel.writeByte(by);
                parcel.writeString(this.b);
            }

        }

    }

}

