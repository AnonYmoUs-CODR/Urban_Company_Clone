/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import com.google.gson.annotations.SerializedName;

public final class SubMediaType
extends Enum<SubMediaType> {
    private static final /* synthetic */ SubMediaType[] $VALUES;
    @SerializedName(value="image")
    public static final /* enum */ SubMediaType IMAGE;
    @SerializedName(value="video")
    public static final /* enum */ SubMediaType VIDEO;

    public static {
        SubMediaType subMediaType;
        SubMediaType subMediaType2;
        SubMediaType[] arrsubMediaType = new SubMediaType[2];
        IMAGE = subMediaType = new SubMediaType();
        arrsubMediaType[0] = subMediaType;
        VIDEO = subMediaType2 = new SubMediaType();
        arrsubMediaType[1] = subMediaType2;
        $VALUES = arrsubMediaType;
    }

    public static SubMediaType valueOf(String string) {
        return (SubMediaType)Enum.valueOf(SubMediaType.class, (String)string);
    }

    public static SubMediaType[] values() {
        return (SubMediaType[])$VALUES.clone();
    }
}

