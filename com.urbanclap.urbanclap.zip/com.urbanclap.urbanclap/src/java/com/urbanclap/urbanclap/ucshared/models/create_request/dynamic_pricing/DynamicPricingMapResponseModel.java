/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.q0.q.h
 */
package com.urbanclap.urbanclap.ucshared.models.create_request.dynamic_pricing;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.q0.q.h;

public final class DynamicPricingMapResponseModel
extends ResponseBaseModel {
    @SerializedName(value="pricing_config")
    private final h e;

    public DynamicPricingMapResponseModel() {
        this(null, 1, null);
    }

    public DynamicPricingMapResponseModel(h h2) {
        this.e = h2;
    }

    public /* synthetic */ DynamicPricingMapResponseModel(h h2, int n2, g g2) {
        if ((n2 & 1) != 0) {
            h2 = null;
        }
        this(h2);
    }

    public final h e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DynamicPricingMapResponseModel)) break block3;
                DynamicPricingMapResponseModel dynamicPricingMapResponseModel = (DynamicPricingMapResponseModel)((Object)object);
                if (l.c((Object)this.e, (Object)dynamicPricingMapResponseModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        h h2 = this.e;
        if (h2 != null) {
            return h2.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DynamicPricingMapResponseModel(mpricingConfig=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

