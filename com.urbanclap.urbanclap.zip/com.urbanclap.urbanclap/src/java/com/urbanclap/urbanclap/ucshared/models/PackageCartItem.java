/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartItem$ItemType
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartItem$ServiceItemSubtype
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartItem$a
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartItem$b
 *  com.urbanclap.urbanclap.ucshared.models.create_request.Media
 *  com.urbanclap.urbanclap.ucshared.models.create_request.MediaType
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$MetaData
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.n.o0.a
 *  t1.r.k.n.o0.c
 *  t1.r.k.n.o0.g
 *  t1.r.k.n.o0.g$a
 *  t1.r.k.n.q0.a
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.Media;
import com.urbanclap.urbanclap.ucshared.models.create_request.MediaType;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import t1.r.k.n.o0.c;
import t1.r.k.n.o0.g;

public class PackageCartItem
implements PackageCartBaseItem {
    public static final Parcelable.Creator<PackageCartItem> CREATOR = new a();
    public NewPackageItemModel a;
    public String b;
    public String c;
    public boolean d;
    public boolean e;

    public PackageCartItem(Parcel parcel) {
        this.a = (NewPackageItemModel)parcel.readParcelable(NewPackageItemModel.class.getClassLoader());
        this.b = parcel.readString();
        this.c = parcel.readString();
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.d = bl2;
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.e = bl;
    }

    public PackageCartItem(String string, NewPackageItemModel newPackageItemModel, String string2, boolean bl) {
        this.a = newPackageItemModel;
        this.b = string;
        this.c = string2;
        this.d = bl;
    }

    public static /* synthetic */ String e() {
        return "CART_ITEM_TYPE_NULL";
    }

    public String a() {
        return this.c;
    }

    public String b() {
        return this.b;
    }

    public NewPackageItemModel c() {
        return this.a;
    }

    public boolean d() {
        return this.d;
    }

    public int d0() {
        if (this.a.l() == null) {
            this.f();
            return -1;
        }
        int n2 = b.c[this.a.l().ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        if (n2 != 5) {
                            return -1;
                        }
                        if (this.a.x() == null) {
                            this.f();
                            return -1;
                        }
                        int n3 = b.b[this.a.x().ordinal()];
                        if (n3 != 1) {
                            if (n3 != 2) {
                                if (n3 != 3) {
                                    return -1;
                                }
                                if (this.a.o().h().b() == null) {
                                    this.f();
                                    return -1;
                                }
                                int n4 = b.a[this.a.o().h().b().ordinal()];
                                if (n4 != 1) {
                                    if (n4 != 2) {
                                        if (n4 != 3) {
                                            return -1;
                                        }
                                        return 16;
                                    }
                                    return 14;
                                }
                                return 15;
                            }
                            if (this.a.o().h().b() == null) {
                                this.f();
                                return -1;
                            }
                            int n5 = b.a[this.a.o().h().b().ordinal()];
                            if (n5 != 1) {
                                if (n5 != 2) {
                                    return 22;
                                }
                                return 20;
                            }
                            return 21;
                        }
                        if (this.a.o().h().b() == null) {
                            this.f();
                            return -1;
                        }
                        int n6 = b.a[this.a.o().h().b().ordinal()];
                        if (n6 != 1) {
                            if (n6 != 2) {
                                return 19;
                            }
                            return 17;
                        }
                        return 18;
                    }
                    return 12;
                }
                return 13;
            }
            return 11;
        }
        return 1;
    }

    public int describeContents() {
        return 0;
    }

    public final void f() {
        g g2 = new g("Cart item type is null");
        g2.g("itemKey");
        g2.h(this.a.k());
        g2.f((g.a)t1.r.k.n.q0.a.a);
        c.d((Object)this, (t1.r.k.n.o0.a)g2);
    }

    public void g(boolean bl) {
        this.e = bl;
    }

    public String id() {
        return this.a.k();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeParcelable((Parcelable)this.a, n2);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeByte((byte)this.d);
        parcel.writeByte((byte)this.e);
    }
}

