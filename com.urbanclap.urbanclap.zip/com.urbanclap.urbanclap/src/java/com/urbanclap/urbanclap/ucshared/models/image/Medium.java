/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.image;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Medium
implements Parcelable {
    public static final Parcelable.Creator<Medium> CREATOR = new Parcelable.Creator<Medium>(){

        public Medium a(Parcel parcel) {
            return new Medium(parcel, null);
        }

        public Medium[] b(int n) {
            return new Medium[n];
        }
    };
    @SerializedName(value="low_res")
    private String a;
    @SerializedName(value="medium_res")
    private String b;
    @SerializedName(value="high_res")
    private String c;

    public Medium(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
    }

    public /* synthetic */ Medium(Parcel parcel, a a2) {
        this(parcel);
    }

    public Medium(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public String a() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (!(object instanceof Medium)) {
            return false;
        }
        Medium medium = (Medium)object;
        boolean bl = this.c.equals((Object)medium.c);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.b.equals((Object)medium.b);
            bl2 = false;
            if (bl3) {
                boolean bl4 = this.a.equals((Object)medium.a);
                bl2 = false;
                if (bl4) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

}

