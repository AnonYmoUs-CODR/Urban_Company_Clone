/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.subscription.DiscountDetails$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.subscription.DiscountDetails;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class DiscountDetails
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="percentage")
    private final int a;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public DiscountDetails(int n2) {
        this.a = n2;
    }

    public DiscountDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
        this((Integer)object);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DiscountDetails)) break block3;
                DiscountDetails discountDetails = (DiscountDetails)object;
                if (this.a == discountDetails.a) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.a;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DiscountDetails(percentage=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeValue((Object)this.a);
    }
}

