/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.wallet.initiate_wallet_linking.response;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

@SuppressLint(value={"ParcelCreator"})
public class InitiateWalletLinkingResponseModel
extends ResponseBaseModel {
    @SerializedName(value="id")
    private String e;
    @SerializedName(value="object")
    private String f;
    @SerializedName(value="wallet")
    private String g;
    @SerializedName(value="mobile_number")
    private String h;
    @SerializedName(value="token")
    private String i;
    @SerializedName(value="current_balance")
    private Double j;
    @SerializedName(value="linked")
    private Boolean k;
    @SerializedName(value="last_refreshed")
    private String s;
    @SerializedName(value="status")
    private String t;
    @SerializedName(value="responseCode")
    private String u;
    @SerializedName(value="message")
    private String v;

    public String e() {
        return this.e;
    }
}

