/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.ReminderSubOption;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class ReminderOption
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="delay_hours")
    private final Integer b;
    @SerializedName(value="heading")
    private final String c;
    @SerializedName(value="sub_options_list")
    private final List<ReminderSubOption> d;

    public ReminderOption(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (!(object instanceof Integer)) {
            object = null;
        }
        this(string, (Integer)object, parcel.readString(), (List<ReminderSubOption>)parcel.createTypedArrayList((Parcelable.Creator)ReminderSubOption.CREATOR));
    }

    public ReminderOption(String string, Integer n, String string2, List<ReminderSubOption> list) {
        this.a = string;
        this.b = n;
        this.c = string2;
        this.d = list;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ReminderOption)) break block3;
                ReminderOption reminderOption = (ReminderOption)object;
                if (l.c((Object)this.a, (Object)reminderOption.a) && l.c((Object)this.b, (Object)reminderOption.b) && l.c((Object)this.c, (Object)reminderOption.c) && l.c(this.d, reminderOption.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        Integer n3 = this.b;
        int n4 = n3 != null ? n3.hashCode() : 0;
        int n5 = 31 * (n2 + n4);
        String string2 = this.c;
        int n6 = string2 != null ? string2.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        List<ReminderSubOption> list = this.d;
        int n8 = 0;
        if (list != null) {
            n8 = list.hashCode();
        }
        return n7 + n8;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ReminderOption(type=");
        stringBuilder.append(this.a);
        stringBuilder.append(", delayHours=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", heading=");
        stringBuilder.append(this.c);
        stringBuilder.append(", subOptions=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeValue((Object)this.b);
        parcel.writeString(this.c);
        parcel.writeTypedList(this.d);
    }

    public static final class a
    implements Parcelable.Creator<ReminderOption> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ReminderOption a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ReminderOption(parcel);
        }

        public ReminderOption[] b(int n) {
            return new ReminderOption[n];
        }
    }

}

