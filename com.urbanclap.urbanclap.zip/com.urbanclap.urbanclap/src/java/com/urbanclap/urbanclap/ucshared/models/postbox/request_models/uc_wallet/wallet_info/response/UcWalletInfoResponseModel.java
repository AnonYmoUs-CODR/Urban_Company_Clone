/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$Faqs
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$Ledger
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$UcCash
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$UcReferrals
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$UcRewards
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class UcWalletInfoResponseModel
extends ResponseBaseModel {
    public static final a CREATOR;
    @SerializedName(value="total")
    private final Double e;
    @SerializedName(value="uc_cash")
    private final UcCash f;
    @SerializedName(value="uc_rewards")
    private final UcRewards g;
    @SerializedName(value="faqs")
    private final Faqs h;
    @SerializedName(value="ledger")
    private final Ledger i;
    @SerializedName(value="uc_referrals")
    private final UcReferrals j;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public UcWalletInfoResponseModel() {
        this(null, null, null, null, null, null, 63, null);
    }

    public UcWalletInfoResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Double.TYPE.getClassLoader());
        if (!(object instanceof Double)) {
            object = null;
        }
        Double d2 = (Double)object;
        Parcelable parcelable = parcel.readParcelable(UcCash.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel.UcCash");
        UcCash ucCash = parcelable;
        Parcelable parcelable2 = parcel.readParcelable(UcRewards.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel.UcRewards");
        UcRewards ucRewards = parcelable2;
        Parcelable parcelable3 = parcel.readParcelable(Faqs.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable3, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel.Faqs");
        Faqs faqs = parcelable3;
        Parcelable parcelable4 = parcel.readParcelable(Ledger.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable4, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel.Ledger");
        Ledger ledger = parcelable4;
        Parcelable parcelable5 = parcel.readParcelable(UcReferrals.class.getClassLoader());
        Objects.requireNonNull((Object)parcelable5, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.models.postbox.request_models.uc_wallet.wallet_info.response.UcWalletInfoResponseModel.UcReferrals");
        this(d2, ucCash, ucRewards, faqs, ledger, parcelable5);
    }

    public UcWalletInfoResponseModel(Double d2, UcCash ucCash, UcRewards ucRewards, Faqs faqs, Ledger ledger, UcReferrals ucReferrals) {
        this.e = d2;
        this.f = ucCash;
        this.g = ucRewards;
        this.h = faqs;
        this.i = ledger;
        this.j = ucReferrals;
    }

    public /* synthetic */ UcWalletInfoResponseModel(Double d2, UcCash ucCash, UcRewards ucRewards, Faqs faqs, Ledger ledger, UcReferrals ucReferrals, int n2, g g2) {
        Double d3 = (n2 & 1) != 0 ? null : d2;
        UcCash ucCash2 = (n2 & 2) != 0 ? null : ucCash;
        UcRewards ucRewards2 = (n2 & 4) != 0 ? null : ucRewards;
        Faqs faqs2 = (n2 & 8) != 0 ? null : faqs;
        Ledger ledger2 = (n2 & 16) != 0 ? null : ledger;
        UcReferrals ucReferrals2 = (n2 & 32) != 0 ? null : ucReferrals;
        this(d3, ucCash2, ucRewards2, faqs2, ledger2, ucReferrals2);
    }

    public int describeContents() {
        return 0;
    }

    public final Faqs e() {
        return this.h;
    }

    public final Ledger f() {
        return this.i;
    }

    public final Double g() {
        return this.e;
    }

    public final UcCash h() {
        return this.f;
    }

    public final UcReferrals i() {
        return this.j;
    }

    public final UcRewards j() {
        return this.g;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeValue((Object)this.e);
        parcel.writeParcelable((Parcelable)this.f, n2);
        parcel.writeParcelable((Parcelable)this.g, n2);
        parcel.writeParcelable((Parcelable)this.h, n2);
        parcel.writeParcelable((Parcelable)this.i, n2);
        parcel.writeParcelable((Parcelable)this.j, n2);
    }
}

