/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.q0.m
 */
package com.urbanclap.urbanclap.ucshared.models;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import t1.r.k.n.q0.m;

public final class UserDetail
extends ResponseBaseModel {
    @SerializedName(value="basic_details")
    private final m e;

    public final m e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof UserDetail)) break block3;
                UserDetail userDetail = (UserDetail)((Object)object);
                if (l.c((Object)this.e, (Object)userDetail.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        m m2 = this.e;
        if (m2 != null) {
            return m2.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UserDetail(userDetailModel=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

