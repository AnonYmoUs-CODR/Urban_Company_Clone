/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.juspay_logger.response;

import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;

public final class JuspayLoggerResponseModel
extends ResponseBaseModel {
}

