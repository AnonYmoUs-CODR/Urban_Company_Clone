/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class VariantPrices
implements Parcelable {
    public static final Parcelable.Creator<VariantPrices> CREATOR = new a();
    @SerializedName(value="current_price")
    private double a;
    @SerializedName(value="striked_off_price")
    private double b;

    public VariantPrices(double d2, double d3) {
        this.a = d2;
        this.b = d3;
    }

    public final double a() {
        return this.a;
    }

    public final double b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof VariantPrices)) break block3;
                VariantPrices variantPrices = (VariantPrices)object;
                if (Double.compare((double)this.a, (double)variantPrices.a) == 0 && Double.compare((double)this.b, (double)variantPrices.b) == 0) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        return 31 * c.a(this.a) + c.a(this.b);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("VariantPrices(currentPrice=");
        stringBuilder.append(this.a);
        stringBuilder.append(", strikedOffPrice=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeDouble(this.a);
        parcel.writeDouble(this.b);
    }

    public static final class a
    implements Parcelable.Creator<VariantPrices> {
        public final VariantPrices a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new VariantPrices(parcel.readDouble(), parcel.readDouble());
        }

        public final VariantPrices[] b(int n) {
            return new VariantPrices[n];
        }
    }

}

