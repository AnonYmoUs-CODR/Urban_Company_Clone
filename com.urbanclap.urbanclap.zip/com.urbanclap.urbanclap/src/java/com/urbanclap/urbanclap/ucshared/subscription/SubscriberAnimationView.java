/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.view.View
 *  android.view.Window
 *  android.view.animation.AlphaAnimation
 *  android.view.animation.Animation
 *  android.view.animation.Animation$AnimationListener
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.urbanclap.urbanclap.ucshared.models.subscription.SubscriberAnimationDetail
 *  com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionAnimationType
 *  com.urbanclap.urbanclap.ucshared.subscription.SubscriberAnimationView$a
 *  com.urbanclap.urbanclap.widgetstore.BouncingImageView
 *  com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 *  java.util.Objects
 *  t1.r.k.n.c
 *  t1.r.k.n.c$b
 *  t1.r.k.n.i
 *  t1.r.k.n.j
 *  t1.r.k.n.k
 *  t1.r.k.n.l
 *  t1.r.k.n.n
 *  t1.r.k.n.u0.c
 *  t1.r.k.p.b
 */
package com.urbanclap.urbanclap.ucshared.subscription;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriberAnimationDetail;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionAnimationType;
import com.urbanclap.urbanclap.ucshared.subscription.SubscriberAnimationView;
import com.urbanclap.urbanclap.widgetstore.BouncingImageView;
import com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView;
import i2.a0.d.l;
import java.util.Locale;
import java.util.Objects;
import t1.r.k.n.c;
import t1.r.k.n.i;
import t1.r.k.n.j;
import t1.r.k.n.k;
import t1.r.k.n.n;
import t1.r.k.p.b;

public final class SubscriberAnimationView
implements b,
LifecycleObserver {
    public View a;
    public Dialog b;
    public BouncingImageView c;
    public UCTextView d;
    public UCTextView e;
    public final LifecycleOwner f;
    public final SubscriberAnimationDetail g;

    public SubscriberAnimationView(LifecycleOwner lifecycleOwner, SubscriberAnimationDetail subscriberAnimationDetail) {
        l.g((Object)lifecycleOwner, (String)"lifecycleOwner");
        l.g((Object)subscriberAnimationDetail, (String)"subscriberAnimationDetail");
        this.f = lifecycleOwner;
        this.g = subscriberAnimationDetail;
        lifecycleOwner.getLifecycle().addObserver((LifecycleObserver)this);
    }

    public static final /* synthetic */ void d(SubscriberAnimationView subscriberAnimationView) {
        subscriberAnimationView.e();
    }

    public void b() {
        TextModel textModel;
        UCTextView uCTextView;
        UCTextView uCTextView2;
        TextModel textModel2 = this.g.c();
        if (textModel2 != null && (uCTextView2 = this.d) != null) {
            uCTextView2.setVisibility(0);
            uCTextView2.setText((CharSequence)textModel2.c());
            c.b b2 = c.c;
            b2.Q0(textModel2.b(), uCTextView2);
            b2.O0(textModel2.d(), uCTextView2);
            b2.R0(Integer.valueOf((int)textModel2.a()), uCTextView2);
        }
        if ((textModel = this.g.b()) != null && (uCTextView = this.e) != null) {
            uCTextView.setVisibility(0);
            uCTextView.setText((CharSequence)textModel.c());
            c.b b3 = c.c;
            b3.Q0(textModel.b(), uCTextView);
            b3.O0(textModel.d(), uCTextView);
            b3.R0(Integer.valueOf((int)textModel.a()), uCTextView);
        }
    }

    public void c() {
        View view = this.a;
        if (view != null) {
            this.f(view);
        }
    }

    public final void e() {
        Dialog dialog = this.b;
        if (dialog != null) {
            if (dialog != null) {
                dialog.dismiss();
            }
            this.b = null;
            BouncingImageView bouncingImageView = this.c;
            if (bouncingImageView != null) {
                bouncingImageView.u();
            }
            this.c = null;
        }
        this.f.getLifecycle().removeObserver((LifecycleObserver)this);
    }

    public final void f(View view) {
        l.g((Object)view, (String)"view");
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(500L);
        view.setAnimation((Animation)alphaAnimation);
        view.startAnimation((Animation)alphaAnimation);
        alphaAnimation.setAnimationListener((Animation.AnimationListener)new a(this));
    }

    public final int g(String string) {
        String string2;
        if (string != null) {
            Locale locale = Locale.ENGLISH;
            l.f((Object)locale, (String)"Locale.ENGLISH");
            Objects.requireNonNull((Object)string, (String)"null cannot be cast to non-null type java.lang.String");
            string2 = string.toUpperCase(locale);
            l.f((Object)string2, (String)"(this as java.lang.String).toUpperCase(locale)");
        } else {
            string2 = null;
        }
        if (l.c(string2, (Object)SubscriptionAnimationType.GOLD.name())) {
            return j.i;
        }
        if (l.c(string2, (Object)SubscriptionAnimationType.PRIVILEGE.name())) {
            return j.k;
        }
        if (l.c((Object)string2, (Object)SubscriptionAnimationType.HOMECARE.name())) {
            return j.j;
        }
        if (l.c((Object)string2, (Object)SubscriptionAnimationType.WELLNESS.name())) {
            return j.m;
        }
        if (l.c((Object)string2, (Object)SubscriptionAnimationType.UCPLUS.name())) {
            return j.l;
        }
        return j.m;
    }

    public final void h() {
        BouncingImageView bouncingImageView = this.c;
        if (bouncingImageView != null) {
            if (bouncingImageView != null) {
                bouncingImageView.v();
                return;
            }
        } else {
            this.c();
        }
    }

    public final void i(Activity activity, boolean bl) {
        l.g((Object)activity, (String)"context");
        t1.r.k.n.u0.c.c.d(this.g.a());
        if (this.b == null) {
            Dialog dialog;
            Dialog dialog2;
            Dialog dialog3;
            Dialog dialog4;
            Dialog dialog5;
            Window window;
            Window window2;
            Dialog dialog6;
            Dialog dialog7;
            Dialog dialog8;
            this.b = dialog4 = new Dialog((Context)activity, n.b);
            if (dialog4 != null) {
                dialog4.requestWindowFeature(1);
            }
            if ((dialog6 = this.b) != null && (window = dialog6.getWindow()) != null) {
                window.setBackgroundDrawableResource(i.d);
            }
            if ((dialog2 = this.b) != null && (window2 = dialog2.getWindow()) != null) {
                window2.clearFlags(1024);
            }
            if ((dialog3 = this.b) != null) {
                dialog3.setContentView(t1.r.k.n.l.r);
            }
            BouncingImageView bouncingImageView = (dialog = this.b) != null ? (BouncingImageView)dialog.findViewById(k.p) : null;
            Objects.requireNonNull((Object)bouncingImageView, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.widgetstore.BouncingImageView");
            this.c = bouncingImageView;
            if (bouncingImageView != null) {
                bouncingImageView.x(this.g(this.g.a()), (b)this);
            }
            UCTextView uCTextView = (dialog7 = this.b) != null ? (UCTextView)dialog7.findViewById(k.F0) : null;
            Objects.requireNonNull((Object)uCTextView, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView");
            this.d = uCTextView;
            Dialog dialog9 = this.b;
            UCTextView uCTextView2 = dialog9 != null ? (UCTextView)dialog9.findViewById(k.E0) : null;
            Objects.requireNonNull((Object)uCTextView2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.widgetstore.uc_font.UCTextView");
            this.e = uCTextView2;
            Dialog dialog10 = this.b;
            View view = null;
            if (dialog10 != null) {
                view = dialog10.findViewById(k.I);
            }
            Objects.requireNonNull(view, (String)"null cannot be cast to non-null type android.view.View");
            this.a = view;
            Dialog dialog11 = this.b;
            if (dialog11 != null) {
                dialog11.setCancelable(bl);
            }
            if ((dialog5 = this.b) != null) {
                dialog5.setCanceledOnTouchOutside(bl);
            }
            if ((dialog8 = this.b) != null) {
                dialog8.show();
            }
        }
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public final void onDestroy() {
        this.e();
    }
}

