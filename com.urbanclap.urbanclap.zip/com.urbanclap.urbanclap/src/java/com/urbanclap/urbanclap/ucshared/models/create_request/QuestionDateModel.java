/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDateModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDateModel$MetaData
 *  java.lang.ClassLoader
 *  java.lang.String
 *  t1.r.k.n.c
 *  t1.r.k.n.q0.c
 *  t1.r.k.n.q0.q.l
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDateModel;
import t1.r.k.n.c;
import t1.r.k.n.q0.q.l;

/*
 * Exception performing whole class analysis ignored.
 */
public class QuestionDateModel
extends QuestionBaseModel {
    @Expose
    @SerializedName(value="meta_data")
    private MetaData G;

    public QuestionDateModel(Parcel parcel) {
        super(parcel);
        this.G = parcel.readParcelable(MetaData.class.getClassLoader());
    }

    public int A() {
        return this.B().b().g();
    }

    public MetaData B() {
        return this.G;
    }

    public int C() {
        return DataItem.e(this.B().b());
    }

    public String D() {
        return DataItem.c(this.B().b());
    }

    public void E(String string) {
        DataItem.d(this.B().b(), (String)string);
    }

    public String a() {
        return null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.G, n2);
    }

    public boolean x() {
        return MetaData.a(this.B());
    }

    public l y(int n2, float f2, String string) {
        t1.r.k.n.q0.c c2;
        l l2 = new l();
        if (DataItem.a(this.B().b()) == null) {
            DataItem.b(this.B().b(), (String)"");
        }
        if (!(c2 = c.A((String)DataItem.c(this.B().b()), (int)this.C(), (int)this.A())).b() && this.s()) {
            l2.d(false);
            l2.c(c2.a());
            return l2;
        }
        l2.d(true);
        return l2;
    }

    public String z() {
        return this.B().b().f();
    }
}

