/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

public final class RewardType
extends Enum<RewardType> {
    private static final /* synthetic */ RewardType[] $VALUES;
    public static final /* enum */ RewardType FIXED_AMOUNT;
    public static final /* enum */ RewardType PERCENTAGE;
    public static final /* enum */ RewardType PERCENTAGE_WITH_LIMIT;

    public static {
        RewardType rewardType;
        RewardType rewardType2;
        RewardType rewardType3;
        RewardType[] arrrewardType = new RewardType[3];
        PERCENTAGE = rewardType2 = new RewardType();
        arrrewardType[0] = rewardType2;
        FIXED_AMOUNT = rewardType = new RewardType();
        arrrewardType[1] = rewardType;
        PERCENTAGE_WITH_LIMIT = rewardType3 = new RewardType();
        arrrewardType[2] = rewardType3;
        $VALUES = arrrewardType;
    }

    public static RewardType valueOf(String string) {
        return (RewardType)Enum.valueOf(RewardType.class, (String)string);
    }

    public static RewardType[] values() {
        return (RewardType[])$VALUES.clone();
    }
}

