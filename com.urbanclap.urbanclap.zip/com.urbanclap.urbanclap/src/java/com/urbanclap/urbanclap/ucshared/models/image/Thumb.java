/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.image;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Thumb
implements Parcelable {
    public static final Parcelable.Creator<Thumb> CREATOR = new Parcelable.Creator<Thumb>(){

        public Thumb a(Parcel parcel) {
            return new Thumb(parcel, null);
        }

        public Thumb[] b(int n) {
            return new Thumb[n];
        }
    };
    @SerializedName(value="low_res")
    private String a;
    @SerializedName(value="medium_res")
    private String b;
    @SerializedName(value="high_res")
    private String c;

    public Thumb(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
    }

    public /* synthetic */ Thumb(Parcel parcel, a a2) {
        this(parcel);
    }

    public Thumb(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public String a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        if (!(object instanceof Thumb)) {
            return false;
        }
        Thumb thumb = (Thumb)object;
        boolean bl = this.c.equals((Object)thumb.c);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.b.equals((Object)thumb.b);
            bl2 = false;
            if (bl3) {
                boolean bl4 = this.a.equals((Object)thumb.a);
                bl2 = false;
                if (bl4) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

}

