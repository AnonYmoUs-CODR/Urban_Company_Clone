/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.SelectedOrUnselectedModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class SummaryDetails
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="selected_mode")
    private final SelectedOrUnselectedModel a;
    @SerializedName(value="unselected_mode")
    private final SelectedOrUnselectedModel b;

    public SummaryDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(SelectedOrUnselectedModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Se\u2026::class.java.classLoader)");
        SelectedOrUnselectedModel selectedOrUnselectedModel = (SelectedOrUnselectedModel)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(SelectedOrUnselectedModel.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Se\u2026::class.java.classLoader)");
        this(selectedOrUnselectedModel, (SelectedOrUnselectedModel)parcelable2);
    }

    public SummaryDetails(SelectedOrUnselectedModel selectedOrUnselectedModel, SelectedOrUnselectedModel selectedOrUnselectedModel2) {
        l.g((Object)selectedOrUnselectedModel, (String)"selected_mode");
        l.g((Object)selectedOrUnselectedModel2, (String)"unselected_mode");
        this.a = selectedOrUnselectedModel;
        this.b = selectedOrUnselectedModel2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SummaryDetails)) break block3;
                SummaryDetails summaryDetails = (SummaryDetails)object;
                if (l.c((Object)this.a, (Object)summaryDetails.a) && l.c((Object)this.b, (Object)summaryDetails.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        SelectedOrUnselectedModel selectedOrUnselectedModel = this.a;
        int n = selectedOrUnselectedModel != null ? selectedOrUnselectedModel.hashCode() : 0;
        int n2 = n * 31;
        SelectedOrUnselectedModel selectedOrUnselectedModel2 = this.b;
        int n3 = 0;
        if (selectedOrUnselectedModel2 != null) {
            n3 = selectedOrUnselectedModel2.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SummaryDetails(selected_mode=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", unselected_mode=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
    }

    public static final class a
    implements Parcelable.Creator<SummaryDetails> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SummaryDetails a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SummaryDetails(parcel);
        }

        public SummaryDetails[] b(int n) {
            return new SummaryDetails[n];
        }
    }

}

