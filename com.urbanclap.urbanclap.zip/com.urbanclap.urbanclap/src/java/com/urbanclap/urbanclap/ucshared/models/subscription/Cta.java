/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.subscription.CtaInfo;
import i2.a0.d.l;

public final class Cta
implements Parcelable {
    public static final Parcelable.Creator<Cta> CREATOR = new Parcelable.Creator<Cta>(){

        public Cta a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new Cta(parcel);
        }

        public Cta[] b(int n) {
            return new Cta[n];
        }
    };
    @SerializedName(value="primary_cta")
    private final CtaInfo a;
    @SerializedName(value="secondary_cta")
    private final CtaInfo b;
    @SerializedName(value="ribbon_text")
    private final String c;
    @SerializedName(value="scroll_to_template")
    private final String d;

    public Cta(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this((CtaInfo)parcel.readParcelable(CtaInfo.class.getClassLoader()), (CtaInfo)parcel.readParcelable(CtaInfo.class.getClassLoader()), parcel.readString(), parcel.readString());
    }

    public Cta(CtaInfo ctaInfo, CtaInfo ctaInfo2, String string, String string2) {
        this.a = ctaInfo;
        this.b = ctaInfo2;
        this.c = string;
        this.d = string2;
    }

    public final CtaInfo a() {
        return this.a;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.d;
    }

    public final CtaInfo d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Cta)) break block3;
                Cta cta = (Cta)object;
                if (l.c((Object)this.a, (Object)cta.a) && l.c((Object)this.b, (Object)cta.b) && l.c((Object)this.c, (Object)cta.c) && l.c((Object)this.d, (Object)cta.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        CtaInfo ctaInfo = this.a;
        int n = ctaInfo != null ? ctaInfo.hashCode() : 0;
        int n2 = n * 31;
        CtaInfo ctaInfo2 = this.b;
        int n3 = ctaInfo2 != null ? ctaInfo2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string = this.c;
        int n5 = string != null ? string.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string2 = this.d;
        int n7 = 0;
        if (string2 != null) {
            n7 = string2.hashCode();
        }
        return n6 + n7;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cta(primaryCta=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", secondaryCta=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", ribbonText=");
        stringBuilder.append(this.c);
        stringBuilder.append(", scrollToTemplate=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
    }

}

