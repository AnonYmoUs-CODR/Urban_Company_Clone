/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

public final class SubscriptionType
extends Enum<SubscriptionType> {
    private static final /* synthetic */ SubscriptionType[] $VALUES;
    public static final /* enum */ SubscriptionType DUBAI_CLEANING_BUCKET;
    public static final /* enum */ SubscriptionType HOMECARE_BUCKET;
    public static final /* enum */ SubscriptionType WELLNESS_BUCKET;

    public static {
        SubscriptionType subscriptionType;
        SubscriptionType subscriptionType2;
        SubscriptionType subscriptionType3;
        SubscriptionType[] arrsubscriptionType = new SubscriptionType[3];
        WELLNESS_BUCKET = subscriptionType2 = new SubscriptionType();
        arrsubscriptionType[0] = subscriptionType2;
        HOMECARE_BUCKET = subscriptionType3 = new SubscriptionType();
        arrsubscriptionType[1] = subscriptionType3;
        DUBAI_CLEANING_BUCKET = subscriptionType = new SubscriptionType();
        arrsubscriptionType[2] = subscriptionType;
        $VALUES = arrsubscriptionType;
    }

    public static SubscriptionType valueOf(String string) {
        return (SubscriptionType)Enum.valueOf(SubscriptionType.class, (String)string);
    }

    public static SubscriptionType[] values() {
        return (SubscriptionType[])$VALUES.clone();
    }
}

