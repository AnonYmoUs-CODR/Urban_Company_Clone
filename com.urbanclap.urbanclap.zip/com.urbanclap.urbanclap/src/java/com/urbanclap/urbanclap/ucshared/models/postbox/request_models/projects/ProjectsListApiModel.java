/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.ProjectsListApiModel$a
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.RequestedProject
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.ProjectsListApiModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.projects.models.RequestedProject;
import java.util.ArrayList;
import java.util.List;

public class ProjectsListApiModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<ProjectsListApiModel> CREATOR = new a();
    @SerializedName(value="customer_requests")
    private ArrayList<RequestedProject> e;

    public ProjectsListApiModel() {
    }

    public ProjectsListApiModel(Parcel parcel) {
        this.e = parcel.createTypedArrayList(RequestedProject.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public ArrayList<RequestedProject> e() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeTypedList(this.e);
    }
}

