/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.create_request.ReminderOption;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class ReminderModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="heading")
    private final String a;
    @SerializedName(value="options_list")
    private final List<ReminderOption> b;
    @SerializedName(value="reminder_type")
    private final String c;

    public ReminderModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), (List<ReminderOption>)parcel.createTypedArrayList((Parcelable.Creator)ReminderOption.CREATOR), parcel.readString());
    }

    public ReminderModel(String string, List<ReminderOption> list, String string2) {
        this.a = string;
        this.b = list;
        this.c = string2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ReminderModel)) break block3;
                ReminderModel reminderModel = (ReminderModel)object;
                if (l.c((Object)this.a, (Object)reminderModel.a) && l.c(this.b, reminderModel.b) && l.c((Object)this.c, (Object)reminderModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        List<ReminderOption> list = this.b;
        int n3 = list != null ? list.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = 0;
        if (string2 != null) {
            n5 = string2.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ReminderModel(heading=");
        stringBuilder.append(this.a);
        stringBuilder.append(", reminderOptions=");
        stringBuilder.append(this.b);
        stringBuilder.append(", reminderType=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeTypedList(this.b);
        parcel.writeString(this.c);
    }

    public static final class a
    implements Parcelable.Creator<ReminderModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ReminderModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ReminderModel(parcel);
        }

        public ReminderModel[] b(int n) {
            return new ReminderModel[n];
        }
    }

}

