/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.TextModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class TextModel
implements KParcelable {
    public static final Parcelable.Creator<TextModel> CREATOR = new a();
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="text_color")
    private final String b;
    @SerializedName(value="font_weight")
    private final String c;
    @SerializedName(value="font_size")
    private int d;

    public TextModel(Parcel parcel) {
        this(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt());
    }

    public /* synthetic */ TextModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public TextModel(String string, String string2, String string3, int n2) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = n2;
    }

    public /* synthetic */ TextModel(String string, String string2, String string3, int n2, int n3, g g2) {
        if ((n3 & 8) != 0) {
            n2 = 0;
        }
        this(string, string2, string3, n2);
    }

    public final int a() {
        return this.d;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.a;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof TextModel)) break block3;
                TextModel textModel = (TextModel)object;
                if (l.c((Object)this.a, (Object)textModel.a) && l.c((Object)this.b, (Object)textModel.b) && l.c((Object)this.c, (Object)textModel.c) && this.d == textModel.d) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string3 = this.c;
        int n6 = 0;
        if (string3 != null) {
            n6 = string3.hashCode();
        }
        return 31 * (n5 + n6) + this.d;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("TextModel(text=");
        stringBuilder.append(this.a);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", fontWeight=");
        stringBuilder.append(this.c);
        stringBuilder.append(", fontSize=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeInt(this.d);
    }
}

