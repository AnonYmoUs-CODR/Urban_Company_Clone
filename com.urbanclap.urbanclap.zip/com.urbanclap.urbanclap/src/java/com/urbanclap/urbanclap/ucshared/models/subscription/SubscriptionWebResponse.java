/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Keep;
import i2.a0.d.g;
import i2.a0.d.l;

@Keep
public final class SubscriptionWebResponse
implements Parcelable {
    public static final Parcelable.Creator<SubscriptionWebResponse> CREATOR;
    public static final b Companion;
    private String dismissMessage;
    private boolean isNoPlanSelected;
    private boolean isPlanIdUpdated;
    private boolean isSubscriptionExtended;
    private boolean isVoucherIdUpdated;
    private String planId;
    private boolean refreshScreen;
    private String type;
    private String voucherId;

    public static {
        Companion = new b(null);
        CREATOR = new Parcelable.Creator<SubscriptionWebResponse>(){

            public SubscriptionWebResponse a(Parcel parcel) {
                l.g((Object)parcel, (String)"source");
                return new SubscriptionWebResponse(parcel);
            }

            public SubscriptionWebResponse[] b(int n) {
                return new SubscriptionWebResponse[n];
            }
        };
    }

    public SubscriptionWebResponse(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        String string = parcel.readString();
        String string2 = parcel.readString();
        boolean bl = 1 == parcel.readInt();
        boolean bl2 = 1 == parcel.readInt();
        boolean bl3 = 1 == parcel.readInt();
        String string3 = parcel.readString();
        boolean bl4 = 1 == parcel.readInt();
        String string4 = parcel.readString();
        boolean bl5 = 1 == parcel.readInt();
        this(string, string2, bl, bl2, bl3, string3, bl4, string4, bl5);
    }

    public SubscriptionWebResponse(String string, String string2, boolean bl, boolean bl2, boolean bl3, String string3, boolean bl4, String string4, boolean bl5) {
        this.planId = string;
        this.dismissMessage = string2;
        this.isSubscriptionExtended = bl;
        this.isPlanIdUpdated = bl2;
        this.refreshScreen = bl3;
        this.voucherId = string3;
        this.isVoucherIdUpdated = bl4;
        this.type = string4;
        this.isNoPlanSelected = bl5;
    }

    public /* synthetic */ SubscriptionWebResponse(String string, String string2, boolean bl, boolean bl2, boolean bl3, String string3, boolean bl4, String string4, boolean bl5, int n, g g2) {
        String string5 = (n & 128) != 0 ? null : string4;
        boolean bl6 = (n & 256) != 0 ? false : bl5;
        this(string, string2, bl, bl2, bl3, string3, bl4, string5, bl6);
    }

    public static /* synthetic */ SubscriptionWebResponse copy$default(SubscriptionWebResponse subscriptionWebResponse, String string, String string2, boolean bl, boolean bl2, boolean bl3, String string3, boolean bl4, String string4, boolean bl5, int n, Object object) {
        String string5 = (n & 1) != 0 ? subscriptionWebResponse.planId : string;
        String string6 = (n & 2) != 0 ? subscriptionWebResponse.dismissMessage : string2;
        boolean bl6 = (n & 4) != 0 ? subscriptionWebResponse.isSubscriptionExtended : bl;
        boolean bl7 = (n & 8) != 0 ? subscriptionWebResponse.isPlanIdUpdated : bl2;
        boolean bl8 = (n & 16) != 0 ? subscriptionWebResponse.refreshScreen : bl3;
        String string7 = (n & 32) != 0 ? subscriptionWebResponse.voucherId : string3;
        boolean bl9 = (n & 64) != 0 ? subscriptionWebResponse.isVoucherIdUpdated : bl4;
        String string8 = (n & 128) != 0 ? subscriptionWebResponse.type : string4;
        boolean bl10 = (n & 256) != 0 ? subscriptionWebResponse.isNoPlanSelected : bl5;
        return subscriptionWebResponse.copy(string5, string6, bl6, bl7, bl8, string7, bl9, string8, bl10);
    }

    public final String component1() {
        return this.planId;
    }

    public final String component2() {
        return this.dismissMessage;
    }

    public final boolean component3() {
        return this.isSubscriptionExtended;
    }

    public final boolean component4() {
        return this.isPlanIdUpdated;
    }

    public final boolean component5() {
        return this.refreshScreen;
    }

    public final String component6() {
        return this.voucherId;
    }

    public final boolean component7() {
        return this.isVoucherIdUpdated;
    }

    public final String component8() {
        return this.type;
    }

    public final boolean component9() {
        return this.isNoPlanSelected;
    }

    public final SubscriptionWebResponse copy(String string, String string2, boolean bl, boolean bl2, boolean bl3, String string3, boolean bl4, String string4, boolean bl5) {
        SubscriptionWebResponse subscriptionWebResponse = new SubscriptionWebResponse(string, string2, bl, bl2, bl3, string3, bl4, string4, bl5);
        return subscriptionWebResponse;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SubscriptionWebResponse)) break block3;
                SubscriptionWebResponse subscriptionWebResponse = (SubscriptionWebResponse)object;
                if (l.c((Object)this.planId, (Object)subscriptionWebResponse.planId) && l.c((Object)this.dismissMessage, (Object)subscriptionWebResponse.dismissMessage) && this.isSubscriptionExtended == subscriptionWebResponse.isSubscriptionExtended && this.isPlanIdUpdated == subscriptionWebResponse.isPlanIdUpdated && this.refreshScreen == subscriptionWebResponse.refreshScreen && l.c((Object)this.voucherId, (Object)subscriptionWebResponse.voucherId) && this.isVoucherIdUpdated == subscriptionWebResponse.isVoucherIdUpdated && l.c((Object)this.type, (Object)subscriptionWebResponse.type) && this.isNoPlanSelected == subscriptionWebResponse.isNoPlanSelected) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getDismissMessage() {
        return this.dismissMessage;
    }

    public final String getPlanId() {
        return this.planId;
    }

    public final boolean getRefreshScreen() {
        return this.refreshScreen;
    }

    public final String getType() {
        return this.type;
    }

    public final String getVoucherId() {
        return this.voucherId;
    }

    public int hashCode() {
        String string = this.planId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.dismissMessage;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        int n5 = this.isSubscriptionExtended;
        int n6 = 1;
        if (n5 != 0) {
            n5 = 1;
        }
        int n7 = 31 * (n4 + n5);
        int n8 = this.isPlanIdUpdated ? 1 : 0;
        if (n8 != 0) {
            n8 = 1;
        }
        int n9 = 31 * (n7 + n8);
        int n10 = this.refreshScreen ? 1 : 0;
        if (n10 != 0) {
            n10 = 1;
        }
        int n11 = 31 * (n9 + n10);
        String string3 = this.voucherId;
        int n12 = string3 != null ? string3.hashCode() : 0;
        int n13 = 31 * (n11 + n12);
        int n14 = this.isVoucherIdUpdated ? 1 : 0;
        if (n14 != 0) {
            n14 = 1;
        }
        int n15 = 31 * (n13 + n14);
        String string4 = this.type;
        int n16 = 0;
        if (string4 != null) {
            n16 = string4.hashCode();
        }
        int n17 = 31 * (n15 + n16);
        int n18 = this.isNoPlanSelected;
        if (n18 == 0) {
            n6 = n18;
        }
        return n17 + n6;
    }

    public final boolean isNoPlanSelected() {
        return this.isNoPlanSelected;
    }

    public final boolean isPlanIdUpdated() {
        return this.isPlanIdUpdated;
    }

    public final boolean isSubscriptionExtended() {
        return this.isSubscriptionExtended;
    }

    public final boolean isVoucherIdUpdated() {
        return this.isVoucherIdUpdated;
    }

    public final void setDismissMessage(String string) {
        this.dismissMessage = string;
    }

    public final void setNoPlanSelected(boolean bl) {
        this.isNoPlanSelected = bl;
    }

    public final void setPlanId(String string) {
        this.planId = string;
    }

    public final void setPlanIdUpdated(boolean bl) {
        this.isPlanIdUpdated = bl;
    }

    public final void setRefreshScreen(boolean bl) {
        this.refreshScreen = bl;
    }

    public final void setSubscriptionExtended(boolean bl) {
        this.isSubscriptionExtended = bl;
    }

    public final void setType(String string) {
        this.type = string;
    }

    public final void setVoucherId(String string) {
        this.voucherId = string;
    }

    public final void setVoucherIdUpdated(boolean bl) {
        this.isVoucherIdUpdated = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SubscriptionWebResponse(planId=");
        stringBuilder.append(this.planId);
        stringBuilder.append(", dismissMessage=");
        stringBuilder.append(this.dismissMessage);
        stringBuilder.append(", isSubscriptionExtended=");
        stringBuilder.append(this.isSubscriptionExtended);
        stringBuilder.append(", isPlanIdUpdated=");
        stringBuilder.append(this.isPlanIdUpdated);
        stringBuilder.append(", refreshScreen=");
        stringBuilder.append(this.refreshScreen);
        stringBuilder.append(", voucherId=");
        stringBuilder.append(this.voucherId);
        stringBuilder.append(", isVoucherIdUpdated=");
        stringBuilder.append(this.isVoucherIdUpdated);
        stringBuilder.append(", type=");
        stringBuilder.append(this.type);
        stringBuilder.append(", isNoPlanSelected=");
        stringBuilder.append(this.isNoPlanSelected);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.planId);
        parcel.writeString(this.dismissMessage);
        parcel.writeInt((int)this.isSubscriptionExtended);
        parcel.writeInt((int)this.isPlanIdUpdated);
        parcel.writeInt((int)this.refreshScreen);
        parcel.writeString(this.voucherId);
        parcel.writeInt((int)this.isVoucherIdUpdated);
        parcel.writeString(this.type);
        parcel.writeInt((int)this.isNoPlanSelected);
    }

    public static final class b {
        public b() {
        }

        public /* synthetic */ b(g g2) {
            this();
        }
    }

}

