/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response.ActionBottomSheetResponseBaseModel$a
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.post_request.response.ActionBottomSheetResponseBaseModel;
import i2.a0.d.l;

public final class ActionBottomSheetResponseBaseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<ActionBottomSheetResponseBaseModel> CREATOR = new a();
    @SerializedName(value="message")
    private String e;

    public ActionBottomSheetResponseBaseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        super(parcel);
        this.e = "";
        boolean bl = parcel.readInt() != 0;
        this.d(bl);
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeInt((int)this.c());
    }
}

