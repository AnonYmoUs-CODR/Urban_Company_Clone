/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public final class SelectedSkuDetails
implements Parcelable {
    public static final a CREATOR = new a(null);
    public int a;
    public int b;
    public int c;

    public SelectedSkuDetails() {
        this(0, 0, 0, 7, null);
    }

    public SelectedSkuDetails(int n, int n2, int n3) {
        this.a = n;
        this.b = n2;
        this.c = n3;
    }

    public /* synthetic */ SelectedSkuDetails(int n, int n2, int n3, int n4, g g2) {
        if ((n4 & 1) != 0) {
            n = 0;
        }
        if ((n4 & 2) != 0) {
            n2 = 0;
        }
        if ((n4 & 4) != 0) {
            n3 = 0;
        }
        this(n, n2, n3);
    }

    public SelectedSkuDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readInt(), parcel.readInt(), parcel.readInt());
    }

    public final int a() {
        return this.b;
    }

    public final int b() {
        return this.c;
    }

    public final int c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SelectedSkuDetails)) break block3;
                SelectedSkuDetails selectedSkuDetails = (SelectedSkuDetails)object;
                if (this.a == selectedSkuDetails.a && this.b == selectedSkuDetails.b && this.c == selectedSkuDetails.c) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        return 31 * (31 * this.a + this.b) + this.c;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SelectedSkuDetails(selectedSkuQuantity=");
        stringBuilder.append(this.a);
        stringBuilder.append(", discountedPriceOfSku=");
        stringBuilder.append(this.b);
        stringBuilder.append(", originalPriceofSku=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeInt(this.a);
        parcel.writeInt(this.b);
        parcel.writeInt(this.c);
    }

    public static final class a
    implements Parcelable.Creator<SelectedSkuDetails> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SelectedSkuDetails a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SelectedSkuDetails(parcel);
        }

        public SelectedSkuDetails[] b(int n) {
            return new SelectedSkuDetails[n];
        }
    }

}

