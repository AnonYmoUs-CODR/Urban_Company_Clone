/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.room.Database
 *  androidx.room.RoomDatabase
 *  androidx.room.TypeConverters
 *  androidx.room.migration.Migration
 *  androidx.sqlite.db.SupportSQLiteDatabase
 *  com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase$a$a
 *  i2.a0.c.l
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.n.b0.g
 *  t1.r.k.n.q0.u.a.c
 *  t1.r.k.n.q0.u.b.a
 *  t1.r.k.n.q0.u.c.b.a
 *  t1.r.k.n.q0.u.d.b.a
 *  t1.r.k.n.q0.x.f.a
 */
package com.urbanclap.urbanclap.ucshared.models.uccart;

import android.content.Context;
import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase;

@Database(entities={"Lt1/r/k/n/q0/x/g/b;", "Lt1/r/k/n/q0/x/g/a;", "Lt1/r/k/n/q0/u/d/c/a;", "Lt1/r/k/n/q0/u/c/c/a;", "Lt1/r/k/n/q0/u/a/e;", "Lt1/r/k/n/q0/u/b/c;"}, exportSchema=false, version=8)
@TypeConverters(value={"Lt1/r/k/n/q0/x/b;"})
public abstract class UCDatabase
extends RoomDatabase {
    public static final Migration a;
    public static final Migration b;
    public static final Migration c;
    public static final Migration d;
    public static final Migration e;
    public static final Migration f;
    public static final Migration g;
    public static final Migration h;
    public static final Migration i;
    public static final Migration j;
    public static final Migration k;
    public static final a l;

    public static {
        l = new a(null);
        a = new Migration(1, 2){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WebResourceTable` (`resourceKey` TEXT NOT NULL, `fileHash` TEXT NOT NULL, `mimeType` TEXT NOT NULL, PRIMARY KEY(`resourceKey`))");
            }
        };
        b = new Migration(1, 3){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WebResourceTable` (`resourceKey` TEXT NOT NULL, `fileHash` TEXT NOT NULL, `mimeType` TEXT NOT NULL, PRIMARY KEY(`resourceKey`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `VideoSeenRequests` (`requestId` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`requestId`))");
            }
        };
        c = new Migration(2, 3){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `VideoSeenRequests` (`requestId` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`requestId`))");
            }
        };
        d = new Migration(3, 4){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("ALTER TABLE `packageItems` ADD COLUMN `metaDataJson` TEXT");
            }
        };
        e = new Migration(3, 4){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `VideoSeenRequests` (`requestId` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`requestId`))");
                supportSQLiteDatabase.execSQL("ALTER TABLE `packageItems` ADD COLUMN `metaDataJson` TEXT");
            }
        };
        f = new Migration(3, 4){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WebResourceTable` (`resourceKey` TEXT NOT NULL, `fileHash` TEXT NOT NULL, `mimeType` TEXT NOT NULL, PRIMARY KEY(`resourceKey`))");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `VideoSeenRequests` (`requestId` TEXT NOT NULL, `status` TEXT NOT NULL, PRIMARY KEY(`requestId`))");
                supportSQLiteDatabase.execSQL("ALTER TABLE `packageItems` ADD COLUMN `metaDataJson` TEXT");
            }
        };
        g = new Migration(4, 5){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `TaskTable` (`taskId` TEXT NOT NULL, `taskType` INTEGER NOT NULL, `serializedMetaData` BLOB, PRIMARY KEY(`taskId`))");
            }
        };
        h = new Migration(4, 6){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `TaskTable` (`taskId` TEXT NOT NULL, `taskType` INTEGER NOT NULL, `serializedMetaData` BLOB, PRIMARY KEY(`taskId`))");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `HomeScreen`");
            }
        };
        i = new Migration(5, 6){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `HomeScreen`");
            }
        };
        j = new Migration(6, 7){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `SearchTable` (`_id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `cityKey` TEXT NOT NULL, `image` TEXT, `imageShape` TEXT, `title` TEXT NOT NULL, `subtitles` TEXT, `tapAction` TEXT NOT NULL)");
            }
        };
        k = new Migration(7, 8){

            public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
                i2.a0.d.l.g((Object)supportSQLiteDatabase, (String)"database");
                supportSQLiteDatabase.execSQL("ALTER TABLE `SearchTable` ADD COLUMN `analytics` TEXT");
            }
        };
    }

    public abstract t1.r.k.n.q0.u.a.c l();

    public abstract t1.r.k.n.q0.x.f.a m();

    public abstract t1.r.k.n.q0.u.b.a n();

    public abstract t1.r.k.n.q0.u.c.b.a o();

    public abstract t1.r.k.n.q0.u.d.b.a p();

    public static final class com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase$a
    extends t1.r.k.n.b0.g<UCDatabase, Context> {
        public com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase$a() {
            super((i2.a0.c.l)a.a);
        }

        public /* synthetic */ com.urbanclap.urbanclap.ucshared.models.uccart.UCDatabase$a(i2.a0.d.g g2) {
            this();
        }

        public final Migration c() {
            return a;
        }

        public final Migration d() {
            return b;
        }

        public final Migration e() {
            return f;
        }

        public final Migration f() {
            return c;
        }

        public final Migration g() {
            return e;
        }

        public final Migration h() {
            return d;
        }

        public final Migration i() {
            return g;
        }

        public final Migration j() {
            return h;
        }

        public final Migration k() {
            return i;
        }

        public final Migration l() {
            return j;
        }

        public final Migration m() {
            return k;
        }
    }

}

