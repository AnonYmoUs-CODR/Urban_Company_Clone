/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.subscription.PlanDetails$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.ucshared.models.subscription;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.subscription.PlanDetails;
import com.urbanclap.urbanclap.ucshared.models.subscription.Rewards;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class PlanDetails
implements KParcelable {
    public static final a CREATOR;
    @SerializedName(value="plan_id")
    private final String a;
    @SerializedName(value="name_text")
    private final String b;
    @SerializedName(value="duration_text")
    private final String c;
    @SerializedName(value="price_text")
    private final String d;
    @SerializedName(value="membership_discount_text")
    private final String e;
    @SerializedName(value="price")
    private final Integer f;
    @SerializedName(value="rewards")
    private final Rewards g;
    @SerializedName(value="selected_text")
    private final String h;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PlanDetails(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        String string4 = parcel.readString();
        String string5 = parcel.readString();
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
        this(string, string2, string3, string4, string5, (Integer)object, (Rewards)parcel.readParcelable(Rewards.class.getClassLoader()), parcel.readString());
    }

    public PlanDetails(String string, String string2, String string3, String string4, String string5, Integer n2, Rewards rewards, String string6) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = n2;
        this.g = rewards;
        this.h = string6;
    }

    public final String a() {
        return this.e;
    }

    public final String b() {
        return this.a;
    }

    public final Integer c() {
        return this.f;
    }

    public final Rewards d() {
        return this.g;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PlanDetails)) break block3;
                PlanDetails planDetails = (PlanDetails)object;
                if (l.c((Object)this.a, (Object)planDetails.a) && l.c((Object)this.b, (Object)planDetails.b) && l.c((Object)this.c, (Object)planDetails.c) && l.c((Object)this.d, (Object)planDetails.d) && l.c((Object)this.e, (Object)planDetails.e) && l.c((Object)this.f, (Object)planDetails.f) && l.c((Object)this.g, (Object)planDetails.g) && l.c((Object)this.h, (Object)planDetails.h)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.b;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string3 = this.c;
        int n6 = string3 != null ? string3.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string4 = this.d;
        int n8 = string4 != null ? string4.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        String string5 = this.e;
        int n10 = string5 != null ? string5.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        Integer n12 = this.f;
        int n13 = n12 != null ? n12.hashCode() : 0;
        int n14 = 31 * (n11 + n13);
        Rewards rewards = this.g;
        int n15 = rewards != null ? rewards.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        String string6 = this.h;
        int n17 = 0;
        if (string6 != null) {
            n17 = string6.hashCode();
        }
        return n16 + n17;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PlanDetails(planId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", nameText=");
        stringBuilder.append(this.b);
        stringBuilder.append(", durationText=");
        stringBuilder.append(this.c);
        stringBuilder.append(", priceText=");
        stringBuilder.append(this.d);
        stringBuilder.append(", memberShipDiscountText=");
        stringBuilder.append(this.e);
        stringBuilder.append(", price=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", rewards=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", selectedText=");
        stringBuilder.append(this.h);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeValue((Object)this.f);
        parcel.writeParcelable((Parcelable)this.g, n2);
        parcel.writeString(this.h);
    }
}

