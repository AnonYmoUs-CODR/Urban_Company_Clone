/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.DynamicPricingPrefillModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.DynamicPricingPrefillModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/*
 * Exception performing whole class analysis.
 */
public final class DynamicPricingPrefillModel
extends BasePrefillAnswerModel {
    public static final a CREATOR;
    public final HashMap<String, ArrayList<ArrayList<Double>>> a;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public DynamicPricingPrefillModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((HashMap<String, ArrayList<ArrayList<Double>>>)((HashMap)parcel.readSerializable()));
    }

    public DynamicPricingPrefillModel(HashMap<String, ArrayList<ArrayList<Double>>> hashMap) {
        this.a = hashMap;
    }

    public final HashMap<String, ArrayList<ArrayList<Double>>> a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DynamicPricingPrefillModel)) break block3;
                DynamicPricingPrefillModel dynamicPricingPrefillModel = (DynamicPricingPrefillModel)((Object)object);
                if (l.c(this.a, dynamicPricingPrefillModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        HashMap<String, ArrayList<ArrayList<Double>>> hashMap = this.a;
        if (hashMap != null) {
            return hashMap.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DynamicPricingPrefillModel(priceMap=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeSerializable(this.a);
    }
}

