/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucshared.models.create_request;

import android.os.Parcel;
import android.os.Parcelable;

public class TimeSlot
implements Parcelable {
    public static final Parcelable.Creator<TimeSlot> CREATOR = new Parcelable.Creator<TimeSlot>(){

        public TimeSlot a(Parcel parcel) {
            return new TimeSlot(parcel);
        }

        public TimeSlot[] b(int n) {
            return new TimeSlot[n];
        }
    };
    public String a;
    public boolean b;
    public boolean c;

    public TimeSlot(Parcel parcel) {
        this.a = parcel.readString();
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.b = bl2;
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.c = bl;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeByte((byte)(this.b ? 1 : 0));
        parcel.writeByte((byte)(this.c ? 1 : 0));
    }

}

