/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.CtaModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardTemplateData;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class RateCardDisplayData
implements KParcelable {
    public static final Parcelable.Creator<RateCardDisplayData> CREATOR = new a();
    public final String a;
    public final CtaModel b;
    public final ArrayList<RateCardTemplateData> c;

    public RateCardDisplayData(Parcel parcel) {
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        Parcelable parcelable = parcel.readParcelable(CtaModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ct\u2026::class.java.classLoader)");
        CtaModel ctaModel = (CtaModel)parcelable;
        ArrayList arrayList = parcel.readArrayList(RateCardTemplateData.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardTemplateData> /* = java.util.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardTemplateData> */");
        this(string, ctaModel, (ArrayList<RateCardTemplateData>)arrayList);
    }

    public /* synthetic */ RateCardDisplayData(Parcel parcel, g g2) {
        this(parcel);
    }

    public RateCardDisplayData(String string, CtaModel ctaModel, ArrayList<RateCardTemplateData> arrayList) {
        l.g((Object)string, (String)"rateCardType");
        l.g((Object)ctaModel, (String)"cta");
        l.g(arrayList, (String)"templates");
        this.a = string;
        this.b = ctaModel;
        this.c = arrayList;
    }

    public final CtaModel a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public final ArrayList<RateCardTemplateData> c() {
        return this.c;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeTypedList(this.c);
    }
}

