/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionData
 *  com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionType
 *  com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.SaveModuleDataQnaResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionData;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionType;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.SaveModuleDataQnaResponseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;

public final class SaveModuleDataQnaResponseModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<SaveModuleDataQnaResponseModel> CREATOR = new a();
    @SerializedName(value="pre_request_id")
    private final String e;
    @SerializedName(value="action_type")
    private final ActionType f;
    @SerializedName(value="action_data")
    private final ActionData g;

    public SaveModuleDataQnaResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this(parcel.readString(), ActionType.values()[parcel.readInt()], (ActionData)parcel.readParcelable(ActionData.class.getClassLoader()));
    }

    public SaveModuleDataQnaResponseModel(String string, ActionType actionType, ActionData actionData) {
        l.g((Object)actionType, (String)"actionType");
        this.e = string;
        this.f = actionType;
        this.g = actionData;
    }

    public int describeContents() {
        return 0;
    }

    public final ActionData e() {
        return this.g;
    }

    public final ActionType f() {
        return this.f;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.e);
        parcel.writeInt(this.f.ordinal());
        parcel.writeParcelable((Parcelable)this.g, 0);
    }
}

