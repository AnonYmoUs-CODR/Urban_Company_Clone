/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSectionItem$a
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.screens.fragments.packages_list.SectionNavigatorItemModel
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DescriptionModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$TitleModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.e.b.c.f
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSectionItem;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.screens.fragments.packages_list.SectionNavigatorItemModel;
import com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import t1.r.e.b.c.f;

public class PackageSectionItem
implements PackageCartBaseItem,
f<SectionNavigatorItemModel> {
    public static final Parcelable.Creator<PackageSectionItem> CREATOR = new a();
    public String a;
    public SectionNavigatorItemModel b;
    public QuestionNewPackageModel.TitleModel c;
    public QuestionNewPackageModel.DescriptionModel d;
    public boolean e;

    public PackageSectionItem(Parcel parcel) {
        this.a = parcel.readString();
        this.b = (SectionNavigatorItemModel)parcel.readParcelable(SectionNavigatorItemModel.class.getClassLoader());
        this.c = parcel.readParcelable(QuestionNewPackageModel.TitleModel.class.getClassLoader());
        this.d = parcel.readParcelable(QuestionNewPackageModel.DescriptionModel.class.getClassLoader());
        boolean bl = parcel.readByte() != 0;
        this.e = bl;
    }

    public PackageSectionItem(String string, SectionNavigatorItemModel sectionNavigatorItemModel, QuestionNewPackageModel.TitleModel titleModel, QuestionNewPackageModel.DescriptionModel descriptionModel, boolean bl) {
        this.a = string;
        this.b = sectionNavigatorItemModel;
        this.c = titleModel;
        this.d = descriptionModel;
        this.e = bl;
    }

    public String a() {
        return this.a;
    }

    public int b() {
        return 0;
    }

    public QuestionNewPackageModel.DescriptionModel d() {
        return this.d;
    }

    public int d0() {
        return 0;
    }

    public int describeContents() {
        return 0;
    }

    public SectionNavigatorItemModel e() {
        return this.b;
    }

    public QuestionNewPackageModel.TitleModel f() {
        return this.c;
    }

    public boolean g() {
        return this.e;
    }

    public String id() {
        return this.a;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeParcelable((Parcelable)this.d, n2);
        parcel.writeByte((byte)(this.e ? 1 : 0));
    }
}

