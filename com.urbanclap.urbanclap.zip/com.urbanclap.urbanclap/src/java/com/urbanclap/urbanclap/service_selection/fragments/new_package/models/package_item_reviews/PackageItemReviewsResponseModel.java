/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.PackageItemReviewsResponseModel$a
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.RatingsModel
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.ReviewsModel
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.ReviewsModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.PackageItemReviewsResponseModel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.RatingsModel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_reviews.ReviewsModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class PackageItemReviewsResponseModel
extends ResponseBaseModel {
    public static final a CREATOR;
    @SerializedName(value="ratings")
    private final RatingsModel e;
    @SerializedName(value="reviews")
    private final List<ReviewsModel> f;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PackageItemReviewsResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((RatingsModel)parcel.readParcelable(RatingsModel.class.getClassLoader()), (List<ReviewsModel>)parcel.createTypedArrayList((Parcelable.Creator)ReviewsModel.CREATOR));
    }

    public PackageItemReviewsResponseModel(RatingsModel ratingsModel, List<ReviewsModel> list) {
        this.e = ratingsModel;
        this.f = list;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PackageItemReviewsResponseModel)) break block3;
                PackageItemReviewsResponseModel packageItemReviewsResponseModel = (PackageItemReviewsResponseModel)((Object)object);
                if (l.c((Object)this.e, (Object)packageItemReviewsResponseModel.e) && l.c(this.f, packageItemReviewsResponseModel.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        RatingsModel ratingsModel = this.e;
        int n2 = ratingsModel != null ? ratingsModel.hashCode() : 0;
        int n3 = n2 * 31;
        List<ReviewsModel> list = this.f;
        int n4 = 0;
        if (list != null) {
            n4 = list.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PackageItemReviewsResponseModel(ratings=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", reviews=");
        stringBuilder.append(this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.e, n2);
        parcel.writeTypedList(this.f);
    }
}

