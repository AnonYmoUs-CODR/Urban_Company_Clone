/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.EditPackageModel$a
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.EditableItemDetailVariantBody
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.Duration
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$FilterCatalogList
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$IconModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$PriceModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.EditPackageModel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.EditableItemDetailVariantBody;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.Duration;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import i2.a0.d.l;
import java.util.Iterator;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class EditPackageModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<EditPackageModel> CREATOR;
    @SerializedName(value="duration")
    private final Duration e;
    @SerializedName(value="filter_catalog_list")
    private final List<NewPackageItemModel.FilterCatalogList> f;
    @SerializedName(value="variants")
    private final List<EditableItemDetailVariantBody> g;
    @SerializedName(value="save_icon")
    private final NewPackageItemModel.IconModel h;
    @SerializedName(value="price")
    private final NewPackageItemModel.PriceModel i;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public EditPackageModel(Duration duration, List<? extends NewPackageItemModel.FilterCatalogList> list, List<EditableItemDetailVariantBody> list2, NewPackageItemModel.IconModel iconModel, NewPackageItemModel.PriceModel priceModel) {
        l.g((Object)duration, (String)"duration");
        l.g((Object)iconModel, (String)"saveIcon");
        l.g((Object)priceModel, (String)"priceModel");
        this.e = duration;
        this.f = list;
        this.g = list2;
        this.h = iconModel;
        this.i = priceModel;
    }

    public final Duration e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof EditPackageModel)) break block3;
                EditPackageModel editPackageModel = (EditPackageModel)((Object)object);
                if (l.c((Object)this.e, (Object)editPackageModel.e) && l.c(this.f, editPackageModel.f) && l.c(this.g, editPackageModel.g) && l.c((Object)this.h, (Object)editPackageModel.h) && l.c((Object)this.i, (Object)editPackageModel.i)) break block2;
            }
            return false;
        }
        return true;
    }

    public final List<NewPackageItemModel.FilterCatalogList> f() {
        return this.f;
    }

    public final NewPackageItemModel.PriceModel g() {
        return this.i;
    }

    public final NewPackageItemModel.IconModel h() {
        return this.h;
    }

    public int hashCode() {
        Duration duration = this.e;
        int n2 = duration != null ? duration.hashCode() : 0;
        int n3 = n2 * 31;
        List<NewPackageItemModel.FilterCatalogList> list = this.f;
        int n4 = list != null ? list.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        List<EditableItemDetailVariantBody> list2 = this.g;
        int n6 = list2 != null ? list2.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        NewPackageItemModel.IconModel iconModel = this.h;
        int n8 = iconModel != null ? iconModel.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        NewPackageItemModel.PriceModel priceModel = this.i;
        int n10 = 0;
        if (priceModel != null) {
            n10 = priceModel.hashCode();
        }
        return n9 + n10;
    }

    public final List<EditableItemDetailVariantBody> i() {
        return this.g;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EditPackageModel(duration=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", filterCatalogList=");
        stringBuilder.append(this.f);
        stringBuilder.append(", variants=");
        stringBuilder.append(this.g);
        stringBuilder.append(", saveIcon=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", priceModel=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        List<EditableItemDetailVariantBody> list;
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.e, n2);
        List<NewPackageItemModel.FilterCatalogList> list2 = this.f;
        if (list2 != null) {
            parcel.writeInt(1);
            parcel.writeInt(list2.size());
            Iterator iterator = list2.iterator();
            while (iterator.hasNext()) {
                parcel.writeParcelable((Parcelable)((NewPackageItemModel.FilterCatalogList)iterator.next()), n2);
            }
        } else {
            parcel.writeInt(0);
        }
        if ((list = this.g) != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((EditableItemDetailVariantBody)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.h, n2);
        parcel.writeParcelable((Parcelable)this.i, n2);
    }
}

