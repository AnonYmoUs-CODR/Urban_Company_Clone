/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class RateCardRowItemModel
implements KParcelable {
    public static final Parcelable.Creator<RateCardRowItemModel> CREATOR = new a();
    @SerializedName(value="title")
    private final TextModel a;
    @SerializedName(value="description")
    private final TextModel b;
    @SerializedName(value="bg_color")
    private final String c;
    @SerializedName(value="bullets")
    private final ArrayList<BulletRowItemModel> d;

    public RateCardRowItemModel(Parcel parcel) {
        TextModel textModel = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        TextModel textModel2 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        String string = parcel.readString();
        ArrayList arrayList = parcel.readArrayList(BulletRowItemModel.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel> /* = java.util.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel> */");
        this(textModel, textModel2, string, (ArrayList<BulletRowItemModel>)arrayList);
    }

    public /* synthetic */ RateCardRowItemModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public RateCardRowItemModel(TextModel textModel, TextModel textModel2, String string, ArrayList<BulletRowItemModel> arrayList) {
        l.g(arrayList, (String)"bullets");
        this.a = textModel;
        this.b = textModel2;
        this.c = string;
        this.d = arrayList;
    }

    public final String a() {
        return this.c;
    }

    public final ArrayList<BulletRowItemModel> b() {
        return this.d;
    }

    public final TextModel c() {
        return this.b;
    }

    public final TextModel d() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, n2);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeString(this.c);
        parcel.writeTypedList(this.d);
    }
}

