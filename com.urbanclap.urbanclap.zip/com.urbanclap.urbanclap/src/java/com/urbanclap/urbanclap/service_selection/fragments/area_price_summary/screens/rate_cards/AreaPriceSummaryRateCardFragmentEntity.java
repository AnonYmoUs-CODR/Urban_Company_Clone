/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.AreaPriceSummaryRateCardFragmentEntity$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$AreaModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.AreaPriceSummaryRateCardFragmentEntity;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class AreaPriceSummaryRateCardFragmentEntity
implements KParcelable {
    public static final Parcelable.Creator<AreaPriceSummaryRateCardFragmentEntity> CREATOR = new a();
    public final float a;
    public final ArrayList<RateCardDisplayData> b;
    public final QuestionAreaPriceSummaryModel.AreaModel c;
    public boolean d;
    public final String e;

    public AreaPriceSummaryRateCardFragmentEntity(float f2, ArrayList<RateCardDisplayData> arrayList, QuestionAreaPriceSummaryModel.AreaModel areaModel, boolean bl, String string) {
        l.g(arrayList, (String)"rateCards");
        l.g((Object)string, (String)"categoryKey");
        this.a = f2;
        this.b = arrayList;
        this.c = areaModel;
        this.d = bl;
        this.e = string;
    }

    public AreaPriceSummaryRateCardFragmentEntity(Parcel parcel) {
        float f2 = parcel.readFloat();
        ArrayList arrayList = parcel.readArrayList(RateCardDisplayData.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData> /* = java.util.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData> */");
        QuestionAreaPriceSummaryModel.AreaModel areaModel = parcel.readParcelable(QuestionAreaPriceSummaryModel.AreaModel.class.getClassLoader());
        boolean bl = parcel.readInt() != 0;
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(f2, (ArrayList<RateCardDisplayData>)arrayList, areaModel, bl, string);
    }

    public /* synthetic */ AreaPriceSummaryRateCardFragmentEntity(Parcel parcel, g g2) {
        this(parcel);
    }

    public final float a() {
        return this.a;
    }

    public final QuestionAreaPriceSummaryModel.AreaModel b() {
        return this.c;
    }

    public final ArrayList<RateCardDisplayData> c() {
        return this.b;
    }

    public final boolean d() {
        return this.d;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public final void e(boolean bl) {
        this.d = bl;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeFloat(this.a);
        parcel.writeTypedList(this.b);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeInt((int)this.d);
        parcel.writeString(this.e);
    }
}

