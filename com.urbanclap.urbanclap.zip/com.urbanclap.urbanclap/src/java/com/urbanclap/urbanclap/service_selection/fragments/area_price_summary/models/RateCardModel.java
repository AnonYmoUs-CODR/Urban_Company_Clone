/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardModel$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.CtaModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.TemplateModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class RateCardModel
implements KParcelable {
    public static final Parcelable.Creator<RateCardModel> CREATOR = new a();
    @SerializedName(value="rate_card_type")
    private final String a;
    @SerializedName(value="templates")
    private final ArrayList<TemplateModel> b;
    @SerializedName(value="cta")
    private final CtaModel c;

    public RateCardModel(Parcel parcel) {
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        ArrayList arrayList = parcel.readArrayList(TemplateModel.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.TemplateModel> /* = java.util.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.TemplateModel> */");
        Parcelable parcelable = parcel.readParcelable(CtaModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ct\u2026::class.java.classLoader)");
        this(string, (ArrayList<TemplateModel>)arrayList, (CtaModel)parcelable);
    }

    public /* synthetic */ RateCardModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public RateCardModel(String string, ArrayList<TemplateModel> arrayList, CtaModel ctaModel) {
        l.g((Object)string, (String)"rateCardType");
        l.g(arrayList, (String)"templates");
        l.g((Object)ctaModel, (String)"cta");
        this.a = string;
        this.b = arrayList;
        this.c = ctaModel;
    }

    public final CtaModel a() {
        return this.c;
    }

    public final String b() {
        return this.a;
    }

    public final ArrayList<TemplateModel> c() {
        return this.b;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeTypedList(this.b);
        parcel.writeParcelable((Parcelable)this.c, n2);
    }
}

