/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.CtaModel$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.CtaModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public final class CtaModel
implements KParcelable {
    public static final Parcelable.Creator<CtaModel> CREATOR = new a();
    @SerializedName(value="is_enabled")
    private final boolean a;
    @SerializedName(value="title")
    private final String b;

    public CtaModel(Parcel parcel) {
        boolean bl = parcel.readInt() != 0;
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(bl, string);
    }

    public /* synthetic */ CtaModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public CtaModel(boolean bl, String string) {
        l.g((Object)string, (String)"title");
        this.a = bl;
        this.b = string;
    }

    public final String a() {
        return this.b;
    }

    public final boolean b() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeInt((int)this.a);
        parcel.writeString(this.b);
    }
}

