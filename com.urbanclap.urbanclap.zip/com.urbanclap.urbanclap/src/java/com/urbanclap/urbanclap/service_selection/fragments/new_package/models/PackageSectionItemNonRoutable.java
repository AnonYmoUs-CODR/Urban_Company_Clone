/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSectionItemNonRoutable$a
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DescriptionModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$TitleModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSectionItemNonRoutable;
import com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;

public class PackageSectionItemNonRoutable
implements PackageCartBaseItem {
    public static final Parcelable.Creator<PackageSectionItemNonRoutable> CREATOR = new a();
    public String a;
    public QuestionNewPackageModel.TitleModel b;
    public QuestionNewPackageModel.DescriptionModel c;
    public boolean d;

    public PackageSectionItemNonRoutable(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readParcelable(QuestionNewPackageModel.TitleModel.class.getClassLoader());
        this.c = parcel.readParcelable(QuestionNewPackageModel.DescriptionModel.class.getClassLoader());
        boolean bl = parcel.readByte() != 0;
        this.d = bl;
    }

    public PackageSectionItemNonRoutable(String string, QuestionNewPackageModel.TitleModel titleModel, QuestionNewPackageModel.DescriptionModel descriptionModel, boolean bl) {
        this.a = string;
        this.b = titleModel;
        this.c = descriptionModel;
        this.d = bl;
    }

    public QuestionNewPackageModel.DescriptionModel a() {
        return this.c;
    }

    public QuestionNewPackageModel.TitleModel b() {
        return this.b;
    }

    public boolean c() {
        return this.d;
    }

    public int d0() {
        return 0;
    }

    public int describeContents() {
        return 0;
    }

    public String id() {
        return this.a;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeByte((byte)(this.d ? 1 : 0));
    }
}

