/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.common.IconModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class BulletRowItemModel
implements KParcelable {
    public static final Parcelable.Creator<BulletRowItemModel> CREATOR = new a();
    @SerializedName(value="icon")
    private final IconModel a;
    @SerializedName(value="text")
    private final TextModel b;

    public BulletRowItemModel(Parcel parcel) {
        Parcelable parcelable = parcel.readParcelable(IconModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ic\u2026::class.java.classLoader)");
        IconModel iconModel = (IconModel)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        this(iconModel, (TextModel)parcelable2);
    }

    public /* synthetic */ BulletRowItemModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public BulletRowItemModel(IconModel iconModel, TextModel textModel) {
        l.g((Object)iconModel, (String)"icon");
        l.g((Object)textModel, (String)"text");
        this.a = iconModel;
        this.b = textModel;
    }

    public final IconModel a() {
        return this.a;
    }

    public final TextModel b() {
        return this.b;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, n2);
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

