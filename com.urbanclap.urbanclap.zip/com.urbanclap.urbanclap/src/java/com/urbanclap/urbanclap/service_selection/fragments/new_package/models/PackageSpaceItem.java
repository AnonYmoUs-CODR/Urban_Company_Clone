/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSpaceItem$a
 *  com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models;

import android.os.Parcel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PackageSpaceItem;
import com.urbanclap.urbanclap.ucshared.models.PackageCartBaseItem;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class PackageSpaceItem
implements PackageCartBaseItem {
    public static final a CREATOR;
    public final long a;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PackageSpaceItem() {
        this.a = System.currentTimeMillis();
    }

    public PackageSpaceItem(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
    }

    public int d0() {
        return 10;
    }

    public int describeContents() {
        return 0;
    }

    public String id() {
        return String.valueOf((long)this.a);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
    }
}

