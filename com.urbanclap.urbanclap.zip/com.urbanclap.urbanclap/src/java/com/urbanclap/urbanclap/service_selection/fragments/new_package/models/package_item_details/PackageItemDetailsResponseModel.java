/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  t1.r.k.k.y.m.k.d.a
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models.package_item_details;

import android.annotation.SuppressLint;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.List;
import t1.r.k.k.y.m.k.d.a;

@SuppressLint(value={"ParcelCreator"})
public final class PackageItemDetailsResponseModel
extends ResponseBaseModel {
    public final List<a> e;

    public PackageItemDetailsResponseModel(List<a> list) {
        l.g(list, (String)"packageItemDetails");
        this.e = list;
    }

    public final List<a> e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PackageItemDetailsResponseModel)) break block3;
                PackageItemDetailsResponseModel packageItemDetailsResponseModel = (PackageItemDetailsResponseModel)((Object)object);
                if (l.c(this.e, packageItemDetailsResponseModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        List<a> list = this.e;
        if (list != null) {
            return list.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PackageItemDetailsResponseModel(packageItemDetails=");
        stringBuilder.append(this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

