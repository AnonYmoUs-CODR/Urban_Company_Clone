/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card.helpers.bottom_sheet.ChangeAreaBottomSheetDialogFragmentEntity$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel$AreaModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card.helpers.bottom_sheet;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card.helpers.bottom_sheet.ChangeAreaBottomSheetDialogFragmentEntity;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionAreaPriceSummaryModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class ChangeAreaBottomSheetDialogFragmentEntity
implements KParcelable {
    public static final Parcelable.Creator<ChangeAreaBottomSheetDialogFragmentEntity> CREATOR = new a();
    public final float a;
    public final QuestionAreaPriceSummaryModel.AreaModel b;

    public ChangeAreaBottomSheetDialogFragmentEntity(float f2, QuestionAreaPriceSummaryModel.AreaModel areaModel) {
        l.g((Object)areaModel, (String)"areaModel");
        this.a = f2;
        this.b = areaModel;
    }

    public ChangeAreaBottomSheetDialogFragmentEntity(Parcel parcel) {
        float f2 = parcel.readFloat();
        Parcelable parcelable = parcel.readParcelable(QuestionAreaPriceSummaryModel.AreaModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Qu\u2026::class.java.classLoader)");
        this(f2, parcelable);
    }

    public /* synthetic */ ChangeAreaBottomSheetDialogFragmentEntity(Parcel parcel, g g2) {
        this(parcel);
    }

    public final QuestionAreaPriceSummaryModel.AreaModel a() {
        return this.b;
    }

    public final float b() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeFloat(this.a);
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

