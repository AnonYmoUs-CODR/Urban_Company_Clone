/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.DismissData
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceDetailModel$a
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceModelItem
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceTrackingData
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.urbanclap.urbanclap.service_selection.fragments.new_package.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.DismissData;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceDetailModel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceModelItem;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.models.PreferenceTrackingData;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Exception performing whole class analysis.
 */
public final class PreferenceDetailModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<PreferenceDetailModel> CREATOR;
    @SerializedName(value="pages")
    private final ArrayList<PreferenceModelItem> e;
    @SerializedName(value="dismiss_data")
    private final DismissData f;
    @SerializedName(value="tracking_data")
    private final PreferenceTrackingData g;
    @SerializedName(value="source")
    private final String h;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PreferenceDetailModel(ArrayList<PreferenceModelItem> arrayList, DismissData dismissData, PreferenceTrackingData preferenceTrackingData, String string) {
        l.g(arrayList, (String)"pages");
        this.e = arrayList;
        this.f = dismissData;
        this.g = preferenceTrackingData;
        this.h = string;
    }

    public final ArrayList<PreferenceModelItem> e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PreferenceDetailModel)) break block3;
                PreferenceDetailModel preferenceDetailModel = (PreferenceDetailModel)((Object)object);
                if (l.c(this.e, preferenceDetailModel.e) && l.c((Object)this.f, (Object)preferenceDetailModel.f) && l.c((Object)this.g, (Object)preferenceDetailModel.g) && l.c((Object)this.h, (Object)preferenceDetailModel.h)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.h;
    }

    public final PreferenceTrackingData g() {
        return this.g;
    }

    public int hashCode() {
        ArrayList<PreferenceModelItem> arrayList = this.e;
        int n2 = arrayList != null ? arrayList.hashCode() : 0;
        int n3 = n2 * 31;
        DismissData dismissData = this.f;
        int n4 = dismissData != null ? dismissData.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        PreferenceTrackingData preferenceTrackingData = this.g;
        int n6 = preferenceTrackingData != null ? preferenceTrackingData.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string = this.h;
        int n8 = 0;
        if (string != null) {
            n8 = string.hashCode();
        }
        return n7 + n8;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PreferenceDetailModel(pages=");
        stringBuilder.append(this.e);
        stringBuilder.append(", dismissData=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", trackingData=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", source=");
        stringBuilder.append(this.h);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        ArrayList<PreferenceModelItem> arrayList = this.e;
        parcel.writeInt(arrayList.size());
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            ((PreferenceModelItem)iterator.next()).writeToParcel(parcel, 0);
        }
        DismissData dismissData = this.f;
        if (dismissData != null) {
            parcel.writeInt(1);
            dismissData.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        PreferenceTrackingData preferenceTrackingData = this.g;
        if (preferenceTrackingData != null) {
            parcel.writeInt(1);
            preferenceTrackingData.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.h);
    }
}

