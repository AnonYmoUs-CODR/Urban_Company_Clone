/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.Observer
 *  androidx.lifecycle.OnLifecycleEvent
 *  com.urbanclap.urbanclap.ucshared.models.ModifiedPackageItemFields
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfo
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfoData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$CartTapAction
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$PriceModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$TapActionData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$VariantUiInfo
 *  i2.a0.d.l
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.urbanclap.urbanclap.service_selection.helpers;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.OnLifecycleEvent;
import com.urbanclap.urbanclap.ucshared.models.ModifiedPackageItemFields;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Exception performing whole class analysis.
 */
public final class PackageItemUpdateHandler
implements LifecycleObserver {
    public final Observer<List<ModifiedPackageItemFields>> a;
    public final LifecycleOwner b;
    public final HashMap<String, NewPackageItemModel> c;

    public PackageItemUpdateHandler(LifecycleOwner lifecycleOwner, HashMap<String, NewPackageItemModel> hashMap) {
        l.g((Object)lifecycleOwner, (String)"lifecycleOwner");
        l.g(hashMap, (String)"items");
        this.b = lifecycleOwner;
        this.c = hashMap;
        lifecycleOwner.getLifecycle().addObserver((LifecycleObserver)this);
        this.a = }
    java.lang.IllegalStateException: Inner class got unexpected class file - revert this change
    
    