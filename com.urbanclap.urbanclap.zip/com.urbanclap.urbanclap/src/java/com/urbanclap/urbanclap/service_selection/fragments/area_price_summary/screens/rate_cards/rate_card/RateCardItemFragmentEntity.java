/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card.RateCardItemFragmentEntity$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardDisplayData;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.screens.rate_cards.rate_card.RateCardItemFragmentEntity;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public final class RateCardItemFragmentEntity
implements KParcelable {
    public static final Parcelable.Creator<RateCardItemFragmentEntity> CREATOR = new a();
    public final RateCardDisplayData a;

    public RateCardItemFragmentEntity(Parcel parcel) {
        Parcelable parcelable = parcel.readParcelable(RateCardDisplayData.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable<Ra\u2026::class.java.classLoader)");
        this((RateCardDisplayData)parcelable);
    }

    public /* synthetic */ RateCardItemFragmentEntity(Parcel parcel, g g2) {
        this(parcel);
    }

    public RateCardItemFragmentEntity(RateCardDisplayData rateCardDisplayData) {
        l.g((Object)rateCardDisplayData, (String)"rateCardData");
        this.a = rateCardDisplayData;
    }

    public final RateCardDisplayData a() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeParcelable((Parcelable)this.a, n2);
    }
}

