/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.os.Handler
 *  android.text.TextUtils
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.google.gson.Gson
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  com.urbanclap.urbanclap.service_selection.CreateRequestActivityModel
 *  com.urbanclap.urbanclap.service_selection.fragments.new_package.helpers.Source
 *  com.urbanclap.urbanclap.service_selection.helpers.CreateRequestPresenter$VariantSelectionType
 *  com.urbanclap.urbanclap.service_selection.helpers.CreateRequestPresenter$b
 *  com.urbanclap.urbanclap.service_selection.helpers.CreateRequestPresenter$d
 *  com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionData
 *  com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionType
 *  com.urbanclap.urbanclap.ucshared.common.ActivityScreenSource
 *  com.urbanclap.urbanclap.ucshared.constants.UCApps
 *  com.urbanclap.urbanclap.ucshared.extras.EventData
 *  com.urbanclap.urbanclap.ucshared.extras.PageLoad
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.CategoryQuestions
 *  com.urbanclap.urbanclap.ucshared.models.SaveQnaMetaDeta
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingContext
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingFlow
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingsModel
 *  com.urbanclap.urbanclap.ucshared.models.ServiceItemPitchContext
 *  com.urbanclap.urbanclap.ucshared.models.appconfig.UcInfoBottomSheetOrDialogModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AvailableVoucher
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds
 *  com.urbanclap.urbanclap.ucshared.models.create_request.DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfo
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$BottomSheetInfoData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$CartTapAction
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$PriceModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$TapActionData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$VariantUiInfo
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NudgeLevel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NudgeModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NudgeType
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel$MetaData$Data
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$CartModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$DataItem
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$PackageModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$SectionItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel$TitleModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.QuestionTypes
 *  com.urbanclap.urbanclap.ucshared.models.create_request.SingleSelectAndMultiSelectOptionModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.VoucherDetails
 *  com.urbanclap.urbanclap.ucshared.models.happy_hour.HappyHourCartModel
 *  com.urbanclap.urbanclap.ucshared.models.persistance.download_task.DownloadMetaData
 *  com.urbanclap.urbanclap.ucshared.models.subscription.BottomStrip$a
 *  com.urbanclap.urbanclap.ucshared.models.subscription.RewardType
 *  com.urbanclap.urbanclap.ucshared.models.subscription.SubscriberAnimationDetail
 *  com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionDetailsModel
 *  i2.a0.c.a
 *  i2.a0.c.p
 *  i2.t
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  t1.r.b.b.a
 *  t1.r.b.b.d.b
 *  t1.r.b.c.f
 *  t1.r.h.a.f
 *  t1.r.h.a.j
 *  t1.r.h.a.k
 *  t1.r.k.k.a0.a.a.a
 *  t1.r.k.k.a0.a.a.b
 *  t1.r.k.k.a0.a.a.c
 *  t1.r.k.k.a0.a.a.d
 *  t1.r.k.k.a0.a.a.e
 *  t1.r.k.k.a0.a.a.f
 *  t1.r.k.k.c
 *  t1.r.k.k.h
 *  t1.r.k.k.l
 *  t1.r.k.k.v
 *  t1.r.k.k.z.a
 *  t1.r.k.k.z.d
 *  t1.r.k.k.z.e
 *  t1.r.k.k.z.h
 *  t1.r.k.n.a0.a
 *  t1.r.k.n.c
 *  t1.r.k.n.d0.e
 *  t1.r.k.n.d0.n
 *  t1.r.k.n.d0.q.a
 *  t1.r.k.n.f0.a
 *  t1.r.k.n.f0.d
 *  t1.r.k.n.g
 *  t1.r.k.n.i0.b
 *  t1.r.k.n.l0.a
 *  t1.r.k.n.n0.a
 *  t1.r.k.n.n0.c
 *  t1.r.k.n.o0.c
 *  t1.r.k.n.q0.d
 *  t1.r.k.n.q0.j
 *  t1.r.k.n.q0.q.l
 *  t1.r.k.n.q0.s.a
 *  t1.r.k.n.q0.u.a.a
 *  t1.r.k.n.q0.v.c
 *  t1.r.k.n.q0.v.e
 *  t1.r.k.n.q0.v.e$a
 *  t1.r.k.n.q0.w.a
 *  t1.r.k.n.q0.x.d
 *  t1.r.k.n.u0.c
 *  t1.r.k.n.w0.b
 *  t1.r.k.n.w0.c
 *  t1.r.k.n.y0.a
 */
package com.urbanclap.urbanclap.service_selection.helpers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.gson.Gson;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import com.urbanclap.urbanclap.service_selection.CreateRequestActivityModel;
import com.urbanclap.urbanclap.service_selection.fragments.new_package.helpers.Source;
import com.urbanclap.urbanclap.service_selection.helpers.CreateRequestPresenter;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionData;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.ActionType;
import com.urbanclap.urbanclap.service_selection.postoffice.savemoduledata.response.SaveModuleDataQnaResponseModel;
import com.urbanclap.urbanclap.ucshared.common.ActivityScreenSource;
import com.urbanclap.urbanclap.ucshared.constants.UCApps;
import com.urbanclap.urbanclap.ucshared.extras.EventData;
import com.urbanclap.urbanclap.ucshared.extras.PageLoad;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.CategoryQuestions;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.SaveQnaMetaDeta;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingContext;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingFlow;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingsModel;
import com.urbanclap.urbanclap.ucshared.models.ServiceItemPitchContext;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import com.urbanclap.urbanclap.ucshared.models.appconfig.UcInfoBottomSheetOrDialogModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.AvailableVoucher;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.CatalogIds;
import com.urbanclap.urbanclap.ucshared.models.create_request.DataItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.NudgeLevel;
import com.urbanclap.urbanclap.ucshared.models.create_request.NudgeModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.NudgeType;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionBaseModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionDynamicPricingModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionExtraModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionMultiSelectModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionNewPackageModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionSingleSelectModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionStaticTextBulletModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionStaticTextModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionTypes;
import com.urbanclap.urbanclap.ucshared.models.create_request.SingleSelectAndMultiSelectOptionModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.VoucherDetails;
import com.urbanclap.urbanclap.ucshared.models.happy_hour.HappyHourCartModel;
import com.urbanclap.urbanclap.ucshared.models.persistance.download_task.DownloadMetaData;
import com.urbanclap.urbanclap.ucshared.models.subscription.BottomStrip;
import com.urbanclap.urbanclap.ucshared.models.subscription.PlanDetails;
import com.urbanclap.urbanclap.ucshared.models.subscription.RewardType;
import com.urbanclap.urbanclap.ucshared.models.subscription.Rewards;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriberAnimationDetail;
import com.urbanclap.urbanclap.ucshared.models.subscription.SubscriptionDetailsModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import i2.t;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import t1.r.h.a.f;
import t1.r.h.a.j;
import t1.r.h.a.k;
import t1.r.k.k.h;
import t1.r.k.k.v;
import t1.r.k.n.d0.e;
import t1.r.k.n.d0.n;
import t1.r.k.n.g;
import t1.r.k.n.p;
import t1.r.k.n.q0.q.l;
import t1.r.k.n.q0.v.e;

public class CreateRequestPresenter
implements t1.r.k.k.z.c,
t1.r.k.k.z.b {
    public t1.r.k.k.z.d a;
    public CreateRequestActivityModel b;
    public CategoryQuestions c;
    public ArrayList<Integer> d = new ArrayList();
    public int e = 0;
    @SuppressLint(value={"UseSparseArrays"})
    public HashMap<Integer, ArrayList<String>> f = new HashMap();
    public boolean g;
    public t1.r.b.c.l h;
    public t1.r.k.n.n0.a i;
    public t1.r.k.n.w0.c j;
    public t1.r.k.n.q0.x.d k;
    public t1.r.k.n.y0.a s;
    public t1.r.k.k.z.h t;
    public float u = 0.0f;
    public float v = 0.0f;
    public boolean w = false;
    public boolean x = false;
    public boolean y = false;
    public t1.r.k.n.i0.b z;

    public CreateRequestPresenter(@NonNull t1.r.k.k.z.d d2, @NonNull CreateRequestActivityModel createRequestActivityModel, @NonNull t1.r.k.n.n0.a a2, @NonNull t1.r.k.n.w0.c c2, @NonNull t1.r.b.c.l l2, @NonNull t1.r.k.n.q0.x.d d3, @NonNull t1.r.k.n.y0.a a3, @NonNull t1.r.k.k.z.h h2, @NonNull t1.r.k.n.i0.b b2) {
        this.a = d2;
        this.c = new CategoryQuestions();
        this.z = b2;
        this.i = a2;
        this.j = c2;
        this.h = l2;
        this.k = d3;
        this.s = a3;
        this.t = h2;
        this.b = createRequestActivityModel;
        this.r1();
    }

    public static n<CreateRequestPresenter, SaveModuleDataQnaResponseModel> P3(CreateRequestPresenter createRequestPresenter) {
        return new n<CreateRequestPresenter, SaveModuleDataQnaResponseModel>(createRequestPresenter){

            public void b(SaveModuleDataQnaResponseModel saveModuleDataQnaResponseModel) {
                CreateRequestPresenter.j((CreateRequestPresenter)this.a().get(), saveModuleDataQnaResponseModel);
            }

            public void d(k k2) {
                if (this.a() != null && this.a().get() != null) {
                    String string = k2 != null && !t1.r.k.n.c.y((CharSequence)k2.e()) ? k2.e() : CreateRequestPresenter.m((CreateRequestPresenter)this.a().get()).getString(h.M);
                    CreateRequestPresenter.t((CreateRequestPresenter)this.a().get(), string);
                }
            }
        };
    }

    public static /* synthetic */ void j(CreateRequestPresenter createRequestPresenter, SaveModuleDataQnaResponseModel saveModuleDataQnaResponseModel) {
        createRequestPresenter.c4(saveModuleDataQnaResponseModel);
    }

    private /* synthetic */ t k4() {
        this.L3();
        return t.a;
    }

    public static /* synthetic */ t1.r.k.n.i0.b m(CreateRequestPresenter createRequestPresenter) {
        return createRequestPresenter.z;
    }

    public static /* synthetic */ void t(CreateRequestPresenter createRequestPresenter, String string) {
        createRequestPresenter.b4(string);
    }

    public static void t4(Integer[] arrinteger, int n2, int n3) {
        if (arrinteger != null) {
            if (arrinteger.length == 0) {
                return;
            }
            if (n2 >= n3) {
                return;
            }
            int n4 = arrinteger[n2 + (n3 - n2) / 2];
            int n5 = n2;
            int n6 = n3;
            while (n5 <= n6) {
                while (arrinteger[n5] < n4) {
                    ++n5;
                }
                while (arrinteger[n6] > n4) {
                    --n6;
                }
                if (n5 > n6) continue;
                int n7 = arrinteger[n5];
                arrinteger[n5] = arrinteger[n6];
                arrinteger[n6] = n7;
                ++n5;
                --n6;
            }
            if (n2 < n6) {
                CreateRequestPresenter.t4(arrinteger, n2, n6);
            }
            if (n3 > n5) {
                CreateRequestPresenter.t4(arrinteger, n5, n3);
            }
        }
    }

    @Override
    public void A0(NewPackageItemModel newPackageItemModel, String string, String string2, String string3, String string4) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsIncreaseQuantityClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        f2.V(this.b.h());
        l2.D0(analyticsTriggers, f2);
        ArrayList arrayList = new ArrayList();
        for (CatalogIds catalogIds : newPackageItemModel.c()) {
            arrayList.add((Object)new t1.r.k.n.q0.d(catalogIds.c(), String.valueOf((int)catalogIds.e())));
        }
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.s("product_details");
        f3.U(0);
        f3.E(0);
        f3.F("product_details", (Object)new Gson().s((Object)new t1.r.k.n.q0.j(newPackageItemModel.k(), (List)arrayList, string2, string4)));
        f3.i(this.a());
        f3.N(string3);
        f3.j(this.A3());
        this.h.D0(AnalyticsTriggers.AddedProductClicked, f3);
        t1.r.b.b.d.b.c.h("added_product", (Map)f3);
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.AddToCart;
        t1.r.b.c.f f4 = t1.r.b.c.f.a();
        f4.i(this.a());
        f4.D(this.j.a());
        f4.X(this.j.j());
        l3.D0(analyticsTriggers2, f4);
    }

    public final String A3() {
        CategoryQuestions categoryQuestions = this.c;
        if (categoryQuestions != null) {
            return categoryQuestions.c();
        }
        return "";
    }

    public final <T> void A4(ArrayList<T> arrayList) {
        this.F0(arrayList);
        this.a.A7(true);
        this.a.e0(false);
    }

    @Override
    public void B0(AnalyticsTriggers analyticsTriggers) {
        if (this.c.r() != null) {
            SubscriptionDetailsModel subscriptionDetailsModel = this.c.r();
            t1.r.b.c.l l2 = this.h;
            t1.r.b.c.f f2 = t1.r.b.c.f.a();
            f2.R(subscriptionDetailsModel.p());
            f2.B(this.r().l());
            f2.p(this.j.b());
            f2.i(this.a());
            f2.B(this.r().l());
            f2.K(this.i.f());
            f2.N("NA");
            f2.j("NA");
            l2.D0(analyticsTriggers, f2);
            t1.r.b.c.l l3 = this.h;
            t1.r.b.c.f f3 = t1.r.b.c.f.a();
            f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
            f3.F("program_type", (Object)this.r().l());
            f3.i(this.a());
            f3.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
            f3.j(this.A3());
            l3.D0(analyticsTriggers, f3);
        }
    }

    @Override
    public void B1(NewPackageItemModel newPackageItemModel, NewPackageItemModel.VariantUiInfo variantUiInfo, String string, String string2, String string3, String string4) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ProductDetailsSelectedProductVariantVariantsListClicked;
        VariantSelectionType variantSelectionType = VariantSelectionType.INCREMENT;
        this.y4(analyticsTriggers, variantSelectionType, newPackageItemModel, variantUiInfo, string, string2, string3, string4);
        this.y4(AnalyticsTriggers.ProductDetailsAddedProductVariantsListClicked, variantSelectionType, newPackageItemModel, variantUiInfo, string, string2, string3, string4);
    }

    public final ArrayList<Integer> B3(String string) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < this.c.m().size(); ++i2) {
            QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(i2);
            if (questionBaseModel.b() == null || questionBaseModel.b().size() <= 0 || !questionBaseModel.b().contains((Object)string)) continue;
            arrayList.add((Object)i2);
        }
        return arrayList;
    }

    public final void B4() {
        this.v4();
        this.c.x(String.valueOf((int)((int)this.u)));
        this.P2().b("Checkout", this.a(), "Place Request", 0L);
        int n2 = this.H3(this.c.j());
        for (QuestionBaseModel questionBaseModel : this.c.l()) {
            if (questionBaseModel.o() != QuestionTypes.NEW_PACKAGES) continue;
            questionBaseModel.y(n2, this.u, t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
        }
        this.q4();
    }

    @Override
    public void C(AnalyticsTriggers analyticsTriggers, String string) {
        String string2 = this.c.r() != null ? this.c.r().l() : "NA";
        t1.r.b.c.l l2 = this.h;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
        f2.B(string2);
        f2.V(this.b.l());
        f2.p(this.j.b());
        f2.i(this.a());
        f2.N(this.Y2());
        f2.R(string);
        l2.D0(analyticsTriggers, f2);
    }

    public final float C3() {
        if (this.E2(this.e)) {
            return this.u + (float)this.S3() - this.U3();
        }
        return this.u + (float)this.S3() - this.U3() + this.X3();
    }

    public void C4() {
    }

    public final int D(int n2, SubscriptionDetailsModel subscriptionDetailsModel) {
        Rewards rewards = subscriptionDetailsModel.e().d();
        int n3 = d.b[RewardType.valueOf((String)rewards.d()).ordinal()];
        if (n3 != 1) {
            if (n3 != 2) {
                if (n3 != 3) {
                    return n2;
                }
                return n2 - Math.min((int)(n2 - (int)t1.r.k.n.c.e((float)n2, (float)rewards.a())), (int)rewards.c());
            }
            return n2 - rewards.b();
        }
        return (int)t1.r.k.n.c.e((float)n2, (float)rewards.a());
    }

    public final void D2() {
        if (this.c.r() != null) {
            t1.r.k.k.l l2 = t1.r.k.k.l.b;
            String string = t1.r.k.n.c.p((Context)this.a.e1());
            String string2 = this.a();
            String string3 = this.i.g();
            String string4 = this.c.r().f() != null ? this.c.r().f().b() : "";
            String string5 = l2.m(string, string2, string3, string4, "qna", false, null, "");
            t1.r.k.n.w0.b.b((Context)this.a.e1(), (String)String.valueOf((int)string5.hashCode()));
            l2.o(string5, t1.r.k.n.d0.q.a.b((Context)this.a.e1(), (t1.r.k.n.q0.u.a.a)new t1.r.k.n.q0.u.a.a(new DownloadMetaData("subscription-html", string5))));
        }
    }

    @Nullable
    public final t1.r.k.n.q0.s.a D3() {
        if (this.t.c()) {
            return new t1.r.k.n.q0.s.a(Boolean.valueOf((boolean)this.t.c()));
        }
        return null;
    }

    public final void D4() {
        if (((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).o() == QuestionTypes.NEW_PACKAGES) {
            this.a.B7(0);
            return;
        }
        this.a.B7(4);
    }

    @Override
    public void E1(NewPackageItemModel newPackageItemModel, String string, String string2, String string3, String string4) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsDecreaseQuantityClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        f2.V(this.b.h());
        l2.D0(analyticsTriggers, f2);
        ArrayList arrayList = new ArrayList();
        for (CatalogIds catalogIds : newPackageItemModel.c()) {
            arrayList.add((Object)new t1.r.k.n.q0.d(catalogIds.c(), String.valueOf((int)catalogIds.e())));
        }
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.RemovedProductClicked;
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.s("product_details");
        f3.U(0);
        f3.E(0);
        f3.F("product_details", (Object)new Gson().s((Object)new t1.r.k.n.q0.j(newPackageItemModel.k(), (List)arrayList, string2, string4)));
        f3.i(this.a());
        f3.N(string3);
        f3.j(this.A3());
        l3.D0(analyticsTriggers2, f3);
    }

    @Override
    public boolean E2(int n2) {
        return this.K3(n2) == QuestionTypes.NEW_PACKAGES;
    }

    public final String E3() {
        ScheduledBookingContext scheduledBookingContext = this.b.g();
        if (scheduledBookingContext != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(scheduledBookingContext.e());
            stringBuilder.append(";");
            stringBuilder.append(scheduledBookingContext.a());
            return stringBuilder.toString();
        }
        return "";
    }

    public final void E4(int n2) {
        QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(n2);
        if (questionBaseModel.o() == QuestionTypes.SINGLE_SELECT) {
            ((QuestionSingleSelectModel)questionBaseModel).C();
            return;
        }
        if (questionBaseModel.o() == QuestionTypes.MULTI_SELECT) {
            ((QuestionMultiSelectModel)questionBaseModel).D();
        }
    }

    public final <T> void F0(ArrayList<T> arrayList) {
        Map<String, Integer> map = this.N8(arrayList);
        int n2 = (Integer)map.get((Object)"price");
        int n3 = (Integer)map.get((Object)"quantity");
        this.H4(n2, n3);
    }

    public float F2() {
        return this.C3() + this.W3() + (float)this.Z3();
    }

    public final t1.r.k.k.a0.a.a.c F3() {
        return new t1.r.k.k.a0.a.a.c(t1.r.k.n.n0.c.b(), new t1.r.k.k.a0.a.a.b((double)t1.r.k.n.n0.c.g(), (double)t1.r.k.n.n0.c.n()), t1.r.k.n.a0.a.b.b());
    }

    public final void F4() {
        int n2;
        int n3;
        if (((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).r() && !this.j.d()) {
            this.a.S8(this.x);
            return;
        }
        int n4 = this.d.size() - 1;
        if (n4 == (n3 = this.e)) {
            this.x4(true, (Integer)this.d.get(n3), -1);
            this.B4();
            return;
        }
        if (!(!((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(1 + this.e)).intValue())).r() || this.j.d() && ((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(1 + this.e)).intValue())).r())) {
            this.a.S8(this.x);
            return;
        }
        this.a.M7();
        this.e = n2 = 1 + this.e;
        this.x4(true, (Integer)this.d.get(n2 - 1), (Integer)this.d.get(this.e));
        this.p4();
        this.D4();
        this.a.s2(this.e);
        this.m4();
        this.I4();
        this.a4((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue()));
    }

    @Override
    public void G0(String string, String string2, Source source) {
        String string3 = source != null ? source.getValue() : "NA";
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsLoadPageLoaded;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.B(string);
        f2.i(this.a());
        f2.N(string2);
        f2.j(this.A3());
        f2.V(string3);
        l2.D0(analyticsTriggers, f2);
    }

    public int G3() {
        return this.c.j();
    }

    @Override
    public void G4(String string, String string2) {
        if (string != null) {
            this.R0(this.B3(string), string);
        }
        if (string2 != null) {
            this.K0(this.B3(string2), string2);
        }
    }

    @Override
    public boolean H() {
        return this.y;
    }

    public final int H3(int n2) {
        SubscriptionDetailsModel subscriptionDetailsModel = this.r();
        if (subscriptionDetailsModel != null && subscriptionDetailsModel.s()) {
            n2 = this.D(n2, subscriptionDetailsModel);
        }
        return n2;
    }

    public final void H4(float f2, int n2) {
        block16 : {
            block10 : {
                boolean bl;
                block11 : {
                    int n3;
                    String string;
                    block13 : {
                        int n4;
                        block15 : {
                            block14 : {
                                block12 : {
                                    this.u = f2;
                                    if (!(f2 >= 0.0f)) break block10;
                                    bl = f2 >= (float)this.c.j() && n2 > 0;
                                    if (!this.E2(this.e)) break block11;
                                    string = this.E2(this.e) && this.h4() ? "Summary" : "Continue";
                                    if (this.c.r() == null || !this.c.r().q() || !this.c.r().s()) break block12;
                                    int n5 = this.c.r().f().c() - this.c.r().d();
                                    if (this.c.r().e().d().d().equals((Object)"FIXED_AMOUNT") && !this.Z0(this.u, this.c.r().d())) {
                                        n5 = this.c.r().f().c();
                                    }
                                    if (n5 < 0) {
                                        n5 = 0;
                                    }
                                    if (this.c.r().e().d().d().equals((Object)"FIXED_AMOUNT") && !this.Z0(this.u, this.c.r().d())) {
                                        n5 = this.c.r().f().c();
                                    }
                                    n3 = n5 + this.c.j();
                                    break block13;
                                }
                                if (this.c.r() == null || !this.c.r().s() || !(this.u > 0.0f)) break block14;
                                n4 = this.c.r().d();
                                if (!this.c.r().e().d().d().equals((Object)"FIXED_AMOUNT") || this.Z0(this.u, n4)) break block15;
                            }
                            n4 = 0;
                        }
                        n3 = this.c.j() - n4;
                    }
                    this.v = n3;
                    this.n4(n2, string, true);
                    break block16;
                }
                this.a.l9(bl);
                break block16;
            }
            if (((CartRepository)CartRepository.l.a()).A()) {
                t1.r.k.k.z.d d2 = this.a;
                boolean bl = n2 > 0;
                d2.l9(bl);
            }
        }
        if (this.c.r() != null && this.c.r().s() && (this.c.r().e().d().d().equalsIgnoreCase(RewardType.FIXED_AMOUNT.name()) || this.c.r().e().d().d().equalsIgnoreCase(RewardType.PERCENTAGE_WITH_LIMIT.name())) && this.u > 0.0f && this.L5()) {
            this.a.h6(true);
        } else {
            this.a.h6(false);
        }
        if (this.c.r() != null && this.c.r().b() != null && !this.c.r().s() && this.L5() && n2 > 0) {
            this.a.M3(true, this.o2(), this.c.r().l());
            return;
        }
        this.a.M3(false, null, null);
    }

    public float I3() {
        ArrayList<QuestionBaseModel> arrayList = this.u();
        float f2 = 0.0f;
        if (arrayList != null) {
            block0 : for (QuestionBaseModel questionBaseModel : arrayList) {
                int n2 = d.c[questionBaseModel.o().ordinal()];
                Object object = n2 != 1 ? (n2 != 2 ? null : ((QuestionMultiSelectModel)questionBaseModel).B()) : ((QuestionSingleSelectModel)questionBaseModel).A();
                if (object == null || object.size() <= 0) continue;
                for (SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel : object) {
                    if (!singleSelectAndMultiSelectOptionModel.t() || singleSelectAndMultiSelectOptionModel.n() <= -1) continue;
                    f2 += (float)singleSelectAndMultiSelectOptionModel.n();
                    if (questionBaseModel.o() != QuestionTypes.SINGLE_SELECT) continue;
                    continue block0;
                }
            }
        }
        return f2;
    }

    public final void I4() {
        if (!this.g) {
            int n2 = this.e;
            int n3 = this.d.size();
            if (n2 == n3 - 1) {
                ++n2;
            }
            int n4 = (int)Math.ceil((double)(100.0f * ((float)n2 / (float)n3)));
            this.a.i6(n4);
        }
    }

    public void J(String string) {
        this.S();
    }

    @Override
    public boolean J1() {
        return this.b.h() != null && this.b.h().equals((Object)ActivityScreenSource.UC_ESSENTIALS.getValue());
    }

    public final t1.r.k.k.a0.a.a.d J3() {
        return new t1.r.k.k.a0.a.a.d(this.c.c(), (List)t1.r.k.n.l0.a.a((ArrayList)this.c.l()));
    }

    public final void K0(ArrayList<Integer> arrayList, String string) {
        Context context = this.a.e1();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("For answer tag :: ");
        stringBuilder.append(string);
        t1.r.k.n.o0.c.b((Object)context, (String)stringBuilder.toString());
        this.s4("AnswerTag HashMap before addition");
        int n2 = 1 + this.e;
        if (arrayList != null && arrayList.size() > 0 && !TextUtils.isEmpty((CharSequence)string)) {
            Iterator iterator = arrayList.iterator();
            boolean bl = false;
            while (iterator.hasNext()) {
                Integer n3 = (Integer)iterator.next();
                Context context2 = this.a.e1();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Iterating for index :: ");
                stringBuilder2.append((Object)n3);
                t1.r.k.n.o0.c.b((Object)context2, (String)stringBuilder2.toString());
                if (this.f.containsKey((Object)n3)) {
                    ArrayList arrayList2 = (ArrayList)this.f.get((Object)n3);
                    if (arrayList2 == null || arrayList2.size() == 0 || !arrayList2.contains((Object)string)) {
                        if (arrayList2 == null) {
                            arrayList2 = new ArrayList();
                        }
                        arrayList2.add((Object)string);
                    }
                } else {
                    ArrayList arrayList3 = new ArrayList();
                    arrayList3.add((Object)string);
                    this.f.put((Object)n3, (Object)arrayList3);
                }
                this.s4("AnswerTag HashMap after addition");
                if (!this.d.contains((Object)n3)) {
                    this.d.add(n2, (Object)n3);
                    ++n2;
                    bl = true;
                }
                this.m4();
            }
            if (bl) {
                ArrayList<Integer> arrayList4 = this.d;
                Object[] arrobject = (Integer[])arrayList4.toArray((Object[])new Integer[arrayList4.size()]);
                CreateRequestPresenter.t4((Integer[])arrobject, 1 + this.e, this.d.size() - 1);
                this.d.clear();
                this.d.addAll((Collection)Arrays.asList((Object[])arrobject));
                this.a.x3(this.M3());
            }
        }
    }

    public final QuestionTypes K3(int n2) {
        ArrayList<Integer> arrayList;
        QuestionTypes questionTypes = QuestionTypes.DEFAULT;
        CategoryQuestions categoryQuestions = this.c;
        if (categoryQuestions != null && categoryQuestions.m() != null && this.c.m().size() > 0 && (arrayList = this.d) != null && arrayList.size() > n2 && this.c.m().size() > (Integer)this.d.get(n2)) {
            return ((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(n2)).intValue())).o();
        }
        return questionTypes;
    }

    public final void L3() {
        if (g.a.a()) {
            if (this.J1()) {
                this.a.x(true, t1.r.k.k.c.A);
            } else {
                this.a.R8(true);
            }
            t1.r.k.k.z.e.a((Context)this.a.e1(), (String)this.a(), (String)this.b.e(), (String)this.b.i(), (String)this.b.h(), (ScheduledBookingContext)this.b.g(), (String)this.b.a(), (f)t1.r.k.k.z.e.b((t1.r.k.k.z.b)this));
            return;
        }
        this.a.I6(h.w);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean L5() {
        if (this.c.r() == null) return false;
        QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue());
        boolean bl = questionBaseModel.j() != null && questionBaseModel.j().b() == NudgeType.SUBSCRIPTION && questionBaseModel.j().a() == NudgeLevel.QUESTION_LEVEL && questionBaseModel.j().c();
        QuestionTypes questionTypes = this.K3(this.e);
        int n2 = this.z6(this.c.r().e().d().d());
        boolean bl2 = n2 > 0;
        int n3 = d.c[questionTypes.ordinal()];
        if (n3 != 5) {
            float f2;
            if (n3 != 6) {
                if (!bl2 || !bl || !(this.I3() > 0.0f) || !this.Z0(this.I3(), n2)) return false;
                do {
                    return true;
                    break;
                } while (true);
            }
            if (!(this.c.r().g() != null && this.c.r().g() != false ? bl2 && this.u > 0.0f : bl2 && (f2 = this.u) > 0.0f && this.Z0(f2, n2))) return false;
            return true;
        }
        boolean bl3 = !this.c.r().s() && !this.c.r().t() || this.I3() != 0.0f;
        if (!(bl2 && this.c.r().r() && bl3)) return false;
        return true;
    }

    public final ArrayList<QuestionBaseModel> M3() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.d.iterator();
        while (iterator.hasNext()) {
            int n2 = (Integer)iterator.next();
            arrayList.add(this.c.m().get(n2));
        }
        return arrayList;
    }

    public final ArrayList<Integer> N3() {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < this.c.m().size(); ++i2) {
            QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(i2);
            if (questionBaseModel.b() != null && questionBaseModel.b().size() != 0) continue;
            arrayList.add((Object)i2);
        }
        return arrayList;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public <T> Map<String, Integer> N8(ArrayList<T> var1_1) {
        block8 : {
            block9 : {
                block6 : {
                    block7 : {
                        var2_2 = 0;
                        if (var1_1 == null || var1_1.size() <= 0) break block6;
                        if (!(var1_1.get(0) instanceof DataItem)) break block7;
                        var15_3 = var1_1.iterator();
                        var3_4 = 0;
                        while (var15_3.hasNext()) {
                            var16_5 = (DataItem)var15_3.next();
                            var2_2 += var16_5.a() * var16_5.b();
                            var3_4 += var16_5.b();
                        }
                        break block8;
                    }
                    if (!(var1_1.get(0) instanceof PackageCartItem)) break block6;
                    var7_6 = var1_1.iterator();
                    var8_7 = 0;
                    break block9;
                }
                var3_4 = 0;
                break block8;
            }
            while (var7_6.hasNext()) {
                block10 : {
                    var10_8 = (PackageCartItem)var7_6.next();
                    if (!this.t.c()) break block10;
                    var11_9 = var10_8.c().q().a();
                    var12_10 = this.k.a(var10_8.id(), var10_8.c().a());
                    ** GOTO lbl33
                }
                if (this.i4(var10_8)) {
                    var13_11 = var10_8.c().q().b();
                } else {
                    var11_9 = var10_8.c().q().b();
                    var12_10 = this.k.a(var10_8.id(), var10_8.c().a());
lbl33: // 2 sources:
                    var13_11 = var11_9 * var12_10;
                }
                var8_7 += var13_11;
                if (var10_8.c().F()) {
                    var14_12 = var10_8.c().A().a().a().a().d().iterator();
                    while (var14_12.hasNext()) {
                        var2_2 += ((NewPackageItemModel.VariantUiInfo)var14_12.next()).f();
                    }
                    continue;
                }
                var2_2 += this.k.a(var10_8.id(), var10_8.c().a());
            }
            var9_13 = var8_7;
            var3_4 = var2_2;
            var2_2 = var9_13;
        }
        var4_14 = new HashMap();
        var4_14.put((Object)"price", (Object)var2_2);
        var4_14.put((Object)"quantity", (Object)var3_4);
        return var4_14;
    }

    public final t1.r.k.k.a0.a.a.f O3() {
        if (!TextUtils.isEmpty((CharSequence)this.b.e())) {
            return new t1.r.k.k.a0.a.a.f(this.b.e());
        }
        return null;
    }

    @Override
    public void O5(AnalyticsTriggers analyticsTriggers) {
        String string;
        SubscriptionDetailsModel subscriptionDetailsModel = this.c.r();
        String string2 = "NA";
        if (subscriptionDetailsModel != null) {
            String string3 = this.c.r().l();
            if (this.c.r().c() != null && this.c.r().c().g() != null) {
                string2 = this.c.r().c().g();
            }
            String string4 = string2;
            string2 = string3;
            string = string4;
        } else {
            string = string2;
        }
        t1.r.b.c.l l2 = this.h;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.s("product_selection");
        f2.F("plan_id", (Object)string2);
        f2.G("plan_bucket", (Object)string2);
        f2.R(string);
        f2.i(this.a());
        f2.N(this.Y2());
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    public final t1.r.b.b.a P2() {
        return t1.r.k.k.l.b.g();
    }

    public final SaveQnaMetaDeta Q3() {
        return new SaveQnaMetaDeta(this.b.h(), this.b.a());
    }

    @Override
    public Map<String, BasePrefillAnswerModel> Q7() {
        return this.b.d();
    }

    @Override
    public ScheduledBookingContext Q8() {
        return this.b.g();
    }

    @Override
    public void R() {
        if (this.k1()) {
            this.a.M3(true, this.o2(), this.c.r().l());
        }
    }

    public final void R0(ArrayList<Integer> arrayList, String string) {
        Context context = this.a.e1();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("For answer tag :: ");
        stringBuilder.append(string);
        t1.r.k.n.o0.c.b((Object)context, (String)stringBuilder.toString());
        this.s4("AnswerTag HashMap before removal");
        if (arrayList != null && arrayList.size() > 0 && !TextUtils.isEmpty((CharSequence)string)) {
            Iterator iterator = arrayList.iterator();
            boolean bl = false;
            while (iterator.hasNext()) {
                ArrayList arrayList2;
                Integer n2 = (Integer)iterator.next();
                Context context2 = this.a.e1();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Iterating for index :: ");
                stringBuilder2.append((Object)n2);
                t1.r.k.n.o0.c.b((Object)context2, (String)stringBuilder2.toString());
                this.u4(n2);
                if (!this.f.containsKey((Object)n2) || (arrayList2 = (ArrayList)this.f.get((Object)n2)) == null || arrayList2.size() <= 0 || !arrayList2.contains((Object)string)) continue;
                arrayList2.remove((Object)string);
                this.s4("AnswerTag HashMap after removal");
                if (arrayList2.size() == 0) {
                    this.f.remove((Object)n2);
                    if (this.d.contains((Object)n2)) {
                        this.E4(n2);
                        if (this.K3(this.d.indexOf((Object)n2)) == QuestionTypes.NEW_PACKAGES) {
                            QuestionNewPackageModel questionNewPackageModel = (QuestionNewPackageModel)((Object)this.c.m().get(n2.intValue()));
                            for (PackageCartItem packageCartItem : this.k.e()) {
                                if (!questionNewPackageModel.z(packageCartItem.c().k())) continue;
                                this.k.g(packageCartItem.c().k(), packageCartItem.c().a());
                            }
                        }
                        this.d.remove((Object)n2);
                        bl = true;
                    }
                    this.s4("AnswerTag HashMap after complete removal");
                }
                this.m4();
            }
            if (bl) {
                ArrayList<Integer> arrayList3 = this.d;
                Object[] arrobject = (Integer[])arrayList3.toArray((Object[])new Integer[arrayList3.size()]);
                CreateRequestPresenter.t4((Integer[])arrobject, 1 + this.e, this.d.size() - 1);
                this.d.clear();
                this.d.addAll((Collection)Arrays.asList((Object[])arrobject));
                this.a.x3(this.M3());
            }
        }
    }

    public final ScheduledBookingContext R3() {
        return this.c.p();
    }

    public void S() {
        if (this.d.size() > 0) {
            int n2 = this.e;
            if (n2 == 0) {
                this.x4(false, -1, (Integer)this.d.get(n2));
                t1.r.b.b.a a2 = this.P2();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.a());
                stringBuilder.append("");
                a2.d("Click on Abort", stringBuilder.toString(), "Place Request", 0.0, "", 0, "QUESTIONNAIRE", "", 0, 0, "", "", true, "");
                this.a.da();
            } else {
                int n3;
                this.a.M7();
                t1.r.b.c.l l2 = this.h;
                AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.QnaFlowClickBackClicked;
                t1.r.b.c.f f2 = t1.r.b.c.f.a();
                f2.R(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).o().getName());
                f2.i(this.a());
                f2.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
                f2.j(this.A3());
                l2.D0(analyticsTriggers, f2);
                t1.r.b.c.l l3 = this.h;
                AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.DismissedQuestionClicked;
                t1.r.b.c.f f3 = t1.r.b.c.f.a();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("dismissed_");
                stringBuilder.append(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
                f3.r(stringBuilder.toString());
                f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
                f3.i(this.a());
                f3.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
                f3.j(this.A3());
                l3.D0(analyticsTriggers2, f3);
                this.e = n3 = this.e - 1;
                this.x4(false, (Integer)this.d.get(n3), (Integer)this.d.get(1 + this.e));
                this.p4();
                this.a.l9(true);
                this.a.s2(this.e);
                this.m4();
                this.D4();
            }
        }
        this.I4();
    }

    public int S3() {
        if (this.c.r() != null && this.c.r().t()) {
            return this.c.r().f().c();
        }
        return 0;
    }

    @Override
    public void T(String string) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsQuestionClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.y(this.u);
        f2.i(this.a());
        f2.N(string);
        f2.j(this.A3());
        String string2 = this.t.c() ? "happy_hours" : "regular_hours";
        f2.V(string2);
        l2.D0(analyticsTriggers, f2);
    }

    public final t1.r.k.n.q0.w.a T3() {
        if (this.c.r() != null && !TextUtils.isEmpty((CharSequence)this.c.r().k())) {
            return new t1.r.k.n.q0.w.a(this.c.r().k());
        }
        return null;
    }

    @Override
    public ArrayList<QuestionNewPackageModel.PackageModel> T5() {
        ArrayList arrayList = new ArrayList();
        if (this.c.m().get(this.e) instanceof QuestionNewPackageModel) {
            ArrayList<NewPackageItemModel> arrayList2 = ((QuestionNewPackageModel)((Object)this.c.m().get(this.e))).B();
            arrayList = ((QuestionNewPackageModel)((Object)this.c.m().get(this.e))).C().e(arrayList2);
        }
        return arrayList;
    }

    public float U3() {
        int n2;
        if (this.c.r() != null && (this.c.r().t() || this.c.r().s()) && this.u > 0.0f && this.Z0(this.u, n2 = this.z6(this.c.r().e().d().d()))) {
            return n2;
        }
        return 0.0f;
    }

    public int V3() {
        if (this.c.r() != null && this.c.r().e() != null && this.c.r().e().d() != null) {
            return (int)Math.ceil((double)(this.u * (float)this.c.r().e().d().a() / 100.0f));
        }
        return 0;
    }

    @Override
    public void V4(int n2, int n3) {
        if (this.K3(this.e) == QuestionTypes.SINGLE_SELECT) {
            QuestionSingleSelectModel questionSingleSelectModel = (QuestionSingleSelectModel)((Object)this.c.m().get(((Integer)this.d.get(this.e)).intValue()));
            if (n2 > -1 && -1 + questionSingleSelectModel.A().size() >= n2) {
                String string = ((SingleSelectAndMultiSelectOptionModel)questionSingleSelectModel.A().get(n2)).a();
                this.R0(this.B3(string), string);
            }
            if (n3 > -1 && -1 + questionSingleSelectModel.A().size() >= n3) {
                String string = ((SingleSelectAndMultiSelectOptionModel)questionSingleSelectModel.A().get(n3)).a();
                this.K0(this.B3(string), string);
            }
            this.a4(questionSingleSelectModel);
        }
    }

    @Override
    public void V6() {
        if (this.w) {
            this.w = false;
            this.B4();
        }
    }

    @Override
    public void W0(String string, String string2) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsHygieneRatingClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.B(string);
        f2.i(this.a());
        f2.N(string2);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.SelectedHygieneRatingsClicked;
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.U(0);
        f3.F("package_id", (Object)string);
        f3.i(this.a());
        f3.N(string2);
        f3.j(this.A3());
        l3.D0(analyticsTriggers2, f3);
    }

    public float W3() {
        return 0.0f;
    }

    public void X(boolean bl) {
        this.a.X(bl);
    }

    @Override
    public void X2() {
        this.a.e0(true);
        this.a.A7(false);
        Context context = this.a.e1();
        int n2 = h.v;
        String string = context.getString(n2);
        if (this.K3(this.e) != QuestionTypes.DEFAULT) {
            QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue());
            if (!TextUtils.isEmpty((CharSequence)questionBaseModel.g())) {
                string = questionBaseModel.g();
            } else if (this.h4() && !this.j4() && this.j.d()) {
                string = this.a.e1().getString(n2);
            }
        }
        this.a.r1(string);
    }

    public float X3() {
        return 0.0f;
    }

    @Override
    public void X6(int n2, boolean bl) {
        if (this.K3(this.e) == QuestionTypes.MULTI_SELECT) {
            ArrayList<Integer> arrayList;
            String string;
            QuestionMultiSelectModel questionMultiSelectModel = (QuestionMultiSelectModel)((Object)this.c.m().get(((Integer)this.d.get(this.e)).intValue()));
            if (-1 + questionMultiSelectModel.B().size() >= n2 && (arrayList = this.B3(string = ((SingleSelectAndMultiSelectOptionModel)questionMultiSelectModel.B().get(n2)).a())) != null && arrayList.size() > 0) {
                if (bl) {
                    this.K0(arrayList, string);
                } else {
                    this.R0(arrayList, string);
                }
            }
            this.a4(questionMultiSelectModel);
        }
    }

    @Override
    public void Y0(String string) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2LoadPageLoaded;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.V(this.b.f());
        f2.i(this.a());
        f2.N(string);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    @Override
    public String Y2() {
        return ((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).o().getName();
    }

    public final TrackingData Y3() {
        TrackingData trackingData = new TrackingData("", null, null, null, null, null, null, null, null, null, null, this.b.h(), ActivityScreenSource.QNA.getValue(), this.E3(), null, null, null, null);
        return trackingData;
    }

    public final boolean Z0(float f2, int n2) {
        return f2 - (float)n2 > 0.0f;
    }

    public final int Z3() {
        if (this.d9() != null && this.d9().a() != null) {
            return this.d9().b();
        }
        return 0;
    }

    @Override
    public boolean Z7(String string, int n2) {
        Rewards rewards = this.c.r().e().d();
        return RewardType.valueOf((String)string) == RewardType.PERCENTAGE_WITH_LIMIT && n2 == rewards.c();
    }

    @Nullable
    @Override
    public ServiceItemPitchContext Z9() {
        if (this.J1()) {
            return new ServiceItemPitchContext(this.b.c(), this.b.h());
        }
        return null;
    }

    @Override
    public String a() {
        CategoryQuestions categoryQuestions = this.c;
        if (categoryQuestions != null && !t1.r.k.n.c.y((CharSequence)categoryQuestions.d())) {
            return this.c.d();
        }
        return this.b.b();
    }

    public final void a4(QuestionBaseModel questionBaseModel) {
        if (this.c.r() != null && questionBaseModel.j() != null) {
            if (questionBaseModel.j().b() == NudgeType.SUBSCRIPTION && questionBaseModel.j().a() == NudgeLevel.QUESTION_LEVEL && questionBaseModel.j().c() && this.I3() > 0.0f) {
                SubscriptionDetailsModel subscriptionDetailsModel = this.c.r();
                if (!subscriptionDetailsModel.s() && !subscriptionDetailsModel.t()) {
                    this.a.M3(true, this.o2(), subscriptionDetailsModel.l());
                    t1.r.k.k.z.d d2 = this.a;
                    d2.r1(d2.e1().getString(h.v));
                    return;
                }
                this.a.h6(true);
                return;
            }
            this.X2();
            this.a.h6(false);
            this.a.M3(false, null, null);
        }
    }

    public final void b4(String string) {
        if (string == null) {
            string = this.z.getString(h.M);
        }
        this.a.K0();
        this.z.g(string);
    }

    @Override
    public CategoryQuestions b5() {
        return this.c;
    }

    @Override
    public String c() {
        return this.c.e();
    }

    public final void c4(SaveModuleDataQnaResponseModel saveModuleDataQnaResponseModel) {
        int n2 = d.a[saveModuleDataQnaResponseModel.f().ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        return;
                    }
                    if (saveModuleDataQnaResponseModel.e() == null) {
                        this.b4(this.z.getString(h.M));
                        return;
                    }
                    this.a.r8(saveModuleDataQnaResponseModel.e());
                    this.a.K0();
                    return;
                }
                this.a.q5();
                return;
            }
            if (saveModuleDataQnaResponseModel.e() == null) {
                this.b4(this.z.getString(h.M));
                return;
            }
            this.a.q7(saveModuleDataQnaResponseModel.e());
            this.a.K0();
            return;
        }
        if (saveModuleDataQnaResponseModel.e() != null && saveModuleDataQnaResponseModel.e().d() != null) {
            this.e4(saveModuleDataQnaResponseModel.e().d());
            return;
        }
        this.b4(this.z.getString(h.M));
    }

    @Override
    public void c8(boolean bl) {
        this.x = bl;
    }

    @Override
    public void d(k k2) {
        this.a.R8(false);
        this.a.I6(h.M);
        this.a.da();
    }

    @Override
    public void d1(String string, String string2, String string3, Source source) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2OpenViewDetailsClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
        int n2 = d.d[source.ordinal()];
        if (n2 != 1) {
            if (n2 != 3) {
                return;
            }
            t1.r.b.c.l l3 = this.h;
            AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.SelectedProductDetailsClicked;
            t1.r.b.c.f f3 = t1.r.b.c.f.a();
            f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
            f3.U(0);
            f3.E(0);
            f3.F("package_id", (Object)string2);
            f3.i(this.a());
            f3.N(string3);
            f3.j(this.A3());
            l3.D0(analyticsTriggers2, f3);
            return;
        }
        t1.r.b.c.l l4 = this.h;
        AnalyticsTriggers analyticsTriggers3 = AnalyticsTriggers.SelectedRatingsReviewsClicked;
        t1.r.b.c.f f4 = t1.r.b.c.f.a();
        f4.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
        f4.U(0);
        f4.E(0);
        f4.F("package_id", (Object)string2);
        f4.i(this.a());
        f4.N(string3);
        f4.j(this.A3());
        l4.D0(analyticsTriggers3, f4);
    }

    @Override
    public void d3(int n2) {
        this.u = n2;
    }

    public final void d4() {
        ArrayList arrayList = new ArrayList();
        for (QuestionBaseModel questionBaseModel : this.c.m()) {
            if (questionBaseModel.o() == QuestionTypes.NEW_PACKAGES) {
                for (QuestionNewPackageModel.SectionItemModel sectionItemModel : ((QuestionNewPackageModel)questionBaseModel).C().d().f()) {
                    String string = sectionItemModel.r() != null && !TextUtils.isEmpty((CharSequence)sectionItemModel.r().b()) ? sectionItemModel.r().b() : "NA";
                    Iterator iterator = sectionItemModel.l().iterator();
                    while (iterator.hasNext()) {
                        arrayList.add((Object)new PackageCartItem(string, (NewPackageItemModel)iterator.next(), sectionItemModel.o(), false));
                    }
                }
                this.k.d(arrayList, (i2.a0.c.p)new i2.a0.c.p<PackageCartItem, String, Boolean>(this, questionBaseModel){
                    public final /* synthetic */ QuestionBaseModel a;
                    {
                        this.a = questionBaseModel;
                    }

                    public Boolean a(PackageCartItem packageCartItem, String string) {
                        return ((QuestionNewPackageModel)this.a).D(packageCartItem, string);
                    }
                });
            }
            if (questionBaseModel.o() != QuestionTypes.COLLECTIVE) continue;
            ArrayList arrayList2 = new ArrayList();
            QuestionCollectionModel questionCollectionModel = (QuestionCollectionModel)questionBaseModel;
            for (String string : questionCollectionModel.z().a().d().keySet()) {
                QuestionBaseModel questionBaseModel2 = (QuestionBaseModel)questionCollectionModel.z().a().d().get((Object)string);
                if (questionBaseModel2.o() != QuestionTypes.DYNAMIC_PRICING) continue;
                arrayList2.add((Object)((QuestionDynamicPricingModel)questionBaseModel2));
            }
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                for (QuestionNewPackageModel.SectionItemModel sectionItemModel : ((QuestionDynamicPricingModel)((Object)iterator.next())).B().a().f()) {
                    String string = sectionItemModel.r() != null && !TextUtils.isEmpty((CharSequence)sectionItemModel.r().b()) ? sectionItemModel.r().b() : "NA";
                    Iterator iterator2 = sectionItemModel.l().iterator();
                    while (iterator2.hasNext()) {
                        arrayList.add((Object)new PackageCartItem(string, (NewPackageItemModel)iterator2.next(), sectionItemModel.o(), false));
                    }
                }
                this.k.d(arrayList, null);
            }
        }
    }

    @Override
    public VoucherDetails d9() {
        return this.c.t();
    }

    @Override
    public void e(CategoryQuestions categoryQuestions) {
        CategoryQuestions categoryQuestions2;
        if (!this.J1()) {
            this.a.R8(false);
        }
        if ((categoryQuestions2 = this.c) != null && !TextUtils.isEmpty((CharSequence)categoryQuestions2.d()) && this.c.d().equals((Object)categoryQuestions.d())) {
            return;
        }
        this.c = categoryQuestions;
        if (categoryQuestions != null && !categoryQuestions.v()) {
            this.a.setTitle(categoryQuestions.b());
            this.t.f(this.c.i());
            this.d = this.N3();
            this.m4();
            this.d4();
            this.a.m4(this.M3());
            this.p4();
            this.D4();
            this.o4();
            this.I4();
            this.z2();
            this.w4("QA_START", false, this.a(), null, this.c.h(), this.c.o(), null, null, 0);
            this.x4(true, -1, (Integer)this.d.get(this.e));
            t1.r.b.c.l l2 = this.h;
            AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.QNAStart;
            t1.r.b.c.f f2 = t1.r.b.c.f.a();
            f2.i(this.a());
            f2.D(this.j.a());
            f2.X(this.j.j());
            l2.D0(analyticsTriggers, f2);
            t1.r.b.c.l l3 = this.h;
            AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.StartedQnaAuto;
            t1.r.b.c.f f3 = t1.r.b.c.f.a();
            f3.i(this.a());
            f3.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
            f3.j(this.A3());
            l3.D0(analyticsTriggers2, f3);
            t1.r.b.b.d.b b2 = t1.r.b.b.d.b.c;
            t1.r.b.c.f f4 = t1.r.b.c.f.a();
            f4.i(this.a());
            f4.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
            f4.j(this.A3());
            b2.h("viewed_qna", (Map)f4);
            this.D2();
            return;
        }
        CategoryQuestions categoryQuestions3 = this.c;
        if (categoryQuestions3 != null && !TextUtils.isEmpty((CharSequence)categoryQuestions3.g())) {
            this.a.g(this.c.g());
        } else {
            this.a.I6(h.M);
        }
        this.a.da();
    }

    public void e0(boolean bl) {
        this.a.e0(bl);
    }

    public final void e4(String string) {
        if (string == null) {
            this.b4(this.z.getString(h.M));
            return;
        }
        this.a.H4(string);
        new Handler().postDelayed((Runnable)new b(this), 200L);
    }

    @Override
    public void f3(String string) {
        if (this.c.r() != null) {
            if (!TextUtils.isEmpty((CharSequence)string)) {
                for (PlanDetails planDetails : this.c.r().a()) {
                    if (!planDetails.b().equals((Object)string)) continue;
                    this.c.r().u(planDetails);
                    this.c.r().v(planDetails);
                    this.c.r().y(true);
                    this.c.r().x(true);
                    this.a.M3(false, "", null);
                    if (!this.c.r().e().d().d().equalsIgnoreCase(RewardType.FIXED_AMOUNT.name()) && !this.c.r().e().d().d().equalsIgnoreCase(RewardType.PERCENTAGE_WITH_LIMIT.name())) continue;
                    this.a.h6(true);
                }
            } else {
                if (this.c.r().f() != null) {
                    this.c.r().v(null);
                    this.c.r().y(false);
                    this.c.r().x(false);
                }
                this.a.M3(true, this.o2(), this.c.r().l());
            }
            this.a.m9();
            this.p4();
        }
    }

    public final boolean f4(int n2) {
        return this.K3(n2) == QuestionTypes.COLLECTIVE;
    }

    @Override
    public <T> ArrayList<T> f7() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.d.iterator();
        while (iterator.hasNext()) {
            int n2 = (Integer)iterator.next();
            if (((QuestionBaseModel)this.c.m().get(n2)).o() != QuestionTypes.NEW_PACKAGES) continue;
            QuestionNewPackageModel questionNewPackageModel = (QuestionNewPackageModel)((Object)this.c.m().get(n2));
            ArrayList arrayList2 = new ArrayList();
            for (PackageCartItem packageCartItem : this.k.e()) {
                if (this.k.f(packageCartItem.id(), packageCartItem.c().a()).equals((Object)this.a()) && !TextUtils.isEmpty((CharSequence)packageCartItem.c().a())) {
                    arrayList2.add((Object)new PackageCartItem(packageCartItem.b(), packageCartItem.c(), packageCartItem.a(), false));
                    continue;
                }
                if (!this.k.f(packageCartItem.id(), packageCartItem.c().a()).equals((Object)this.a()) || !questionNewPackageModel.z(packageCartItem.id())) continue;
                NewPackageItemModel newPackageItemModel = (NewPackageItemModel)questionNewPackageModel.C().d().b().m().get((Object)packageCartItem.id());
                if (packageCartItem.c().q() != null) {
                    newPackageItemModel.P(packageCartItem.c().q());
                }
                arrayList2.add((Object)new PackageCartItem("", newPackageItemModel, "", false));
            }
            arrayList.addAll((Collection)arrayList2);
        }
        return arrayList;
    }

    @Override
    public boolean f9() {
        return this.b.j() != null && t1.r.k.n.u0.c.c.c(this.b.j().a());
    }

    public final boolean g4(int n2) {
        return this.K3(n2) == QuestionTypes.DYNAMIC_PRICING;
    }

    public final boolean h1(int n2, SubscriptionDetailsModel subscriptionDetailsModel) {
        Rewards rewards = subscriptionDetailsModel.e().d();
        if (rewards.d().equals((Object)RewardType.FIXED_AMOUNT.name())) {
            return this.Z0(n2, rewards.b());
        }
        return true;
    }

    public boolean h4() {
        return this.e == this.d.size() - 1;
    }

    @Override
    public void i0(NewPackageItemModel newPackageItemModel, String string, String string2) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ProductDetailsViewedVariantsListVariantsListViewed;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.F("package_id", (Object)string);
        f2.i(this.a());
        f2.N(string2);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    public final boolean i4(PackageCartItem packageCartItem) {
        if (this.c.m().get(this.e) instanceof QuestionNewPackageModel) {
            return ((QuestionNewPackageModel)((Object)this.c.m().get(this.e))).C().g(packageCartItem.c());
        }
        return false;
    }

    @Override
    public void j0(NewPackageItemModel newPackageItemModel, NewPackageItemModel.VariantUiInfo variantUiInfo, String string, String string2, String string3, String string4) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ProductDetailsDeselectedProductVariantVariantsListClicked;
        VariantSelectionType variantSelectionType = VariantSelectionType.DECREMENT;
        this.y4(analyticsTriggers, variantSelectionType, newPackageItemModel, variantUiInfo, string, string2, string3, string4);
        this.y4(AnalyticsTriggers.ProductDetailsAddedProductVariantsListClicked, variantSelectionType, newPackageItemModel, variantUiInfo, string, string2, string3, string4);
    }

    public boolean j4() {
        CategoryQuestions categoryQuestions = this.c;
        return categoryQuestions != null && !TextUtils.isEmpty((CharSequence)categoryQuestions.k()) && !"no".equalsIgnoreCase(this.c.k());
    }

    @Override
    public void k() {
        this.p4();
    }

    public final boolean k1() {
        return this.c.r() != null && this.c.r().b() != null && this.c.r().b().e().equalsIgnoreCase(BottomStrip.CREATOR.c()) && this.c.r().f() == null && this.E2(this.e);
    }

    public void l(boolean bl) {
        this.a.l(bl);
    }

    @Override
    public void l0(String string, String string2, String string3) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsClickBackClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.V(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    public /* synthetic */ t l4() {
        return this.k4();
    }

    @Override
    public void l6(boolean bl) {
        this.y = bl;
    }

    @Override
    public String l7() {
        return this.b.i();
    }

    public final void m4() {
        Context context = this.a.e1();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Current Index : ");
        stringBuilder.append(this.e);
        t1.r.k.n.o0.c.b((Object)context, (String)stringBuilder.toString());
        Context context2 = this.a.e1();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Current QuestionEntity Index : ");
        stringBuilder2.append(this.d.get(this.e));
        t1.r.k.n.o0.c.b((Object)context2, (String)stringBuilder2.toString());
        Context context3 = this.a.e1();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("Questions To Be Answered : ");
        stringBuilder3.append(Arrays.toString((Object[])this.d.toArray()));
        t1.r.k.n.o0.c.b((Object)context3, (String)stringBuilder3.toString());
    }

    public void n0() {
        this.r4();
    }

    @Override
    public void n1(String string, String string2) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageDetailsRatingReviewsViewed;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.B(string);
        f2.i(this.a());
        f2.N(string2);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.ViewedRatingsSummaryViewed;
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.U(0);
        f3.F("package_id", (Object)string);
        f3.i(this.a());
        f3.N(string2);
        f3.j(this.A3());
        l3.D0(analyticsTriggers2, f3);
        t1.r.b.c.l l4 = this.h;
        AnalyticsTriggers analyticsTriggers3 = AnalyticsTriggers.ViewedRatingsReviewsViewed;
        t1.r.b.c.f f4 = t1.r.b.c.f.a();
        f4.U(0);
        f4.F("package_id", (Object)string);
        f4.i(this.a());
        f4.N(string2);
        f4.j(this.A3());
        l4.D0(analyticsTriggers3, f4);
    }

    public void n4(int n2, String string, boolean bl) {
        String string2;
        int n3 = this.G3();
        int n4 = (int)this.x3();
        SubscriptionDetailsModel subscriptionDetailsModel = this.r();
        if (subscriptionDetailsModel != null && subscriptionDetailsModel.s() && this.h1(n4, subscriptionDetailsModel)) {
            n3 = this.D(n3, subscriptionDetailsModel);
            n4 = this.D(n4, subscriptionDetailsModel);
        }
        int n5 = this.S3();
        String string3 = null;
        if (this.E2(this.o6()) && n5 > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("(+ ");
            stringBuilder.append(t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
            stringBuilder.append(n5);
            stringBuilder.append(" ");
            stringBuilder.append(p.b.getString(h.s));
            stringBuilder.append(" )");
            string3 = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
            stringBuilder2.append(n4);
            string2 = stringBuilder2.toString();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
            stringBuilder.append(n5 + n4);
            string2 = stringBuilder.toString();
        }
        String string4 = string2;
        String string5 = string3;
        int n6 = n3 - n4;
        boolean bl2 = n6 <= 0 || ((CartRepository)CartRepository.l.a()).A();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
        stringBuilder.append(n6);
        String string6 = stringBuilder.toString();
        this.a.v4(bl, n2, string4, bl2, string, string5, string6);
    }

    @Override
    public String o2() {
        try {
            String string = this.v2(this.z6(this.c.r().e().d().d()), this.c.r().e().d().a());
            String string2 = this.c.r().b().c().replace((CharSequence)BottomStrip.CREATOR.b(), (CharSequence)string);
            return string2;
        }
        catch (Exception exception) {
            return "";
        }
    }

    public final void o4() {
        if (this.d.size() == 1) {
            this.a.e6();
        }
        Iterator iterator = this.c.m().iterator();
        while (iterator.hasNext()) {
            if (((QuestionBaseModel)iterator.next()).o() != QuestionTypes.NEW_PACKAGES) continue;
            this.g = true;
            this.a.e6();
            break;
        }
    }

    @Override
    public int o6() {
        return this.e;
    }

    @Override
    public void o8() {
        this.a.o0();
        e.a a2 = new e.a();
        a2.g((j)new v());
        t1.r.k.k.a0.a.a.e e2 = new t1.r.k.k.a0.a.a.e(this.z3(), this.F3(), this.J3(), this.T3(), this.O3(), this.D3(), this.R3(), this.Q3(), t1.r.k.n.c.z((String)UCApps.UC_PROVIDER.getPackageName(), (PackageManager)this.a.e1().getPackageManager()), t1.r.k.n.c.p((Context)this.a.e1()), t1.r.k.n.c.k(), t1.r.k.n.c.j());
        a2.d((t1.r.k.n.q0.v.c)e2);
        a2.h(t1.r.k.k.l.b.b());
        a2.j(CreateRequestPresenter.P3(this));
        a2.f().k();
    }

    public void onStart() {
        t1.r.k.n.f0.a.d((t1.r.k.n.f0.d)this);
        if (this.b == null) {
            this.a.da();
            return;
        }
        this.k.b(this.i.g(), this.a());
        if (this.J1()) {
            this.k.c();
        }
        this.z4();
        ((CartRepository)CartRepository.l.a()).n((i2.a0.c.a<t>)new t1.r.k.k.z.a(this));
        if (this.j.d()) {
            t1.r.k.k.l.b.v();
        }
    }

    public void onStop() {
    }

    @Override
    public void p0(String string, String string2, String string3, String string4) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2ClickBackClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string3);
        f2.w(string2);
        f2.V(string);
        f2.i(this.a());
        f2.N(string4);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    @Override
    public void p2() {
        this.P2().b("Click on About", "overflow", "General", 0L);
        t1.r.k.k.l.b.p(this.a.e1());
    }

    public final void p4() {
        if (!this.g4(this.e) && !this.f4(this.e)) {
            if (!this.E2(this.e)) {
                if (!this.L5()) {
                    this.a.M3(false, null, null);
                    this.a.h6(false);
                }
                this.X2();
                return;
            }
            this.A4(this.f7());
            return;
        }
        if (!this.L5()) {
            this.a.M3(false, null, null);
            this.a.h6(false);
        }
    }

    @Override
    public void p9(boolean bl) {
        this.p4();
    }

    @Override
    public t1.r.k.k.z.h q() {
        return this.t;
    }

    public final void q4() {
        if (this.h4() && this.c.q() != null && this.c.q().a() != null) {
            ScheduledBookingsModel scheduledBookingsModel = this.c.q();
            ScheduledBookingFlow scheduledBookingFlow = scheduledBookingsModel.a();
            if (scheduledBookingFlow == ScheduledBookingFlow.OPT_IN) {
                this.a.Y8(scheduledBookingsModel.c(), this.y3(), this.f7().size(), this.c.b());
                return;
            }
            if (scheduledBookingFlow == ScheduledBookingFlow.MODIFY && scheduledBookingsModel.b() != null) {
                this.a.y2(scheduledBookingsModel.b(), this.Y3());
                return;
            }
            this.o8();
            return;
        }
        this.o8();
    }

    @Override
    public SubscriptionDetailsModel r() {
        return this.c.r();
    }

    public final void r1() {
        CreateRequestActivityModel createRequestActivityModel = this.b;
        if (createRequestActivityModel != null && createRequestActivityModel.h() != null && this.b.h().equalsIgnoreCase(ActivityScreenSource.MODIFY_SCHEDULED_BOOKING.name())) {
            this.k.c();
        }
    }

    public void r4() {
        this.a.Y4();
        int n2 = this.H3((int)this.v);
        if (this.K3(this.e) != QuestionTypes.DEFAULT) {
            l l2 = ((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).y(n2, this.F2(), t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
            if (l2.b()) {
                this.C4();
                this.F4();
                return;
            }
            if (this.K3(this.e) == QuestionTypes.DATE) {
                this.a.W7(l2.a());
                return;
            }
            this.a.g(l2.a());
        }
    }

    @Override
    public void ra(NewPackageItemModel newPackageItemModel) {
        this.p4();
    }

    @Override
    public void s1(NewPackageItemModel newPackageItemModel, String string, String string2, String string3, String string4) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2IncreaseQuantityClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        f2.w(string4);
        l2.D0(analyticsTriggers, f2);
        ArrayList arrayList = new ArrayList();
        for (CatalogIds catalogIds : newPackageItemModel.c()) {
            arrayList.add((Object)new t1.r.k.n.q0.d(catalogIds.c(), String.valueOf((int)catalogIds.e())));
        }
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
        f3.U(0);
        f3.E(0);
        f3.F("product_details", (Object)new Gson().s((Object)new t1.r.k.n.q0.j(newPackageItemModel.k(), (List)arrayList, string2, string4)));
        f3.i(this.a());
        f3.N(string3);
        f3.j(this.A3());
        this.h.D0(AnalyticsTriggers.AddedProductClicked, f3);
        t1.r.b.b.d.b.c.h("added_product", (Map)f3);
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.AddToCart;
        t1.r.b.c.f f4 = t1.r.b.c.f.a();
        f4.i(this.a());
        f4.D(this.j.a());
        f4.X(this.j.j());
        l3.D0(analyticsTriggers2, f4);
    }

    public final void s4(String string) {
        t1.r.k.n.o0.c.b((Object)this.a.e1(), (String)string);
        for (Integer n2 : this.f.keySet()) {
            Context context = this.a.e1();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)n2);
            stringBuilder.append(" = > ");
            stringBuilder.append(this.f.get((Object)n2));
            t1.r.k.n.o0.c.b((Object)context, (String)stringBuilder.toString());
        }
    }

    public void s7(boolean bl) {
        this.a.A7(bl);
    }

    @Override
    public ArrayList<QuestionBaseModel> u() {
        ArrayList<Integer> arrayList;
        ArrayList arrayList2 = new ArrayList();
        CategoryQuestions categoryQuestions = this.c;
        if (categoryQuestions != null && categoryQuestions.m() != null && (arrayList = this.d) != null && arrayList.size() > this.e && this.c.m().size() > (Integer)this.d.get(this.e)) {
            for (int i2 = 0; i2 <= this.e; ++i2) {
                arrayList2.add(this.c.m().get(((Integer)this.d.get(i2)).intValue()));
            }
        }
        return arrayList2;
    }

    public final void u4(int n2) {
        ArrayList<String> arrayList;
        QuestionBaseModel questionBaseModel = (QuestionBaseModel)this.c.m().get(n2);
        if (questionBaseModel.o() == QuestionTypes.SINGLE_SELECT) {
            String string = ((QuestionSingleSelectModel)questionBaseModel).a();
            if (!TextUtils.isEmpty((CharSequence)string)) {
                this.R0(this.B3(string), string);
                return;
            }
        } else if (questionBaseModel.o() == QuestionTypes.MULTI_SELECT && (arrayList = ((QuestionMultiSelectModel)questionBaseModel).z()) != null && arrayList.size() > 0) {
            for (String string : arrayList) {
                this.R0(this.B3(string), string);
            }
        }
    }

    @Override
    public String v2(int n2, int n3) {
        if (n2 > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(t1.r.k.n.c.n((String)this.c(), (Context)this.a.e1()));
            stringBuilder.append(n2);
            return stringBuilder.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n3);
        stringBuilder.append("%");
        return stringBuilder.toString();
    }

    public void v4() {
        this.c.E(this.u());
    }

    @Override
    public void w0() {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ScrollStaticBulletsScrolled;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.p(this.j.b());
        f2.i(this.a());
        f2.N(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).n());
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    public final void w4(String string, boolean bl, String string2, String string3, int n2, int n3, String string4, String string5, int n4) {
        String string6 = string3 == null ? "NA" : string3;
        this.s.a(string, bl, string2, string6, n2, n3, string4, string5, n4, null, null);
        String string7 = this.a().equals((Object)"salon_at_home") ? "START_QA_SALON" : string;
        if (this.a().equals((Object)"ac_service_repair")) {
            string7 = "START_QA_AC";
        }
        String string8 = string7;
        this.s.a(string8, false, this.a(), null, 0, 0, string4, string5, n4, null, null);
    }

    @Override
    public ArrayList<Integer> x1() {
        return this.c.f();
    }

    public float x3() {
        return this.u + this.W3();
    }

    public final void x4(boolean bl, int n2, int n3) {
        String string;
        QuestionBaseModel questionBaseModel;
        String string2;
        QuestionBaseModel questionBaseModel2;
        String string3;
        QuestionTypes questionTypes;
        QuestionTypes questionTypes2;
        QuestionTypes questionTypes3 = QuestionTypes.DEFAULT;
        if (n2 > -1) {
            questionBaseModel = (QuestionBaseModel)this.c.m().get(n2);
            String string4 = questionBaseModel.p();
            questionTypes2 = questionBaseModel.o();
            string = questionBaseModel.n();
            questionBaseModel.a();
            questionBaseModel.k();
            string3 = string4;
        } else {
            questionTypes2 = questionTypes3;
            string3 = string = "";
            questionBaseModel = null;
        }
        if (n3 > -1) {
            questionBaseModel2 = (QuestionBaseModel)this.c.m().get(n3);
            questionBaseModel2.n();
            questionTypes = questionBaseModel2.o();
            questionBaseModel2.k();
            string2 = questionBaseModel2.p();
        } else {
            questionTypes = questionTypes3;
            string2 = "";
            questionBaseModel2 = null;
        }
        if (n3 > -1) {
            t1.r.b.c.l l2 = this.h;
            AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.QnaFlowViewQuestionLoaded;
            t1.r.b.c.f f2 = t1.r.b.c.f.a();
            f2.i(this.a());
            f2.R(questionBaseModel2.o().getName());
            String string5 = questionBaseModel2 != null ? questionBaseModel2.n() : null;
            f2.N(string5);
            f2.O(questionBaseModel2.q());
            f2.j(this.A3());
            l2.D0(analyticsTriggers, f2);
            t1.r.b.c.l l3 = this.h;
            AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.ViewedQuestionViewed;
            t1.r.b.c.f f3 = t1.r.b.c.f.a();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("viewed_");
            stringBuilder.append(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
            f3.r(stringBuilder.toString());
            f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
            f3.i(this.a());
            String string6 = questionBaseModel2 != null ? questionBaseModel2.n() : null;
            f3.N(string6);
            f3.j(this.A3());
            l3.D0(analyticsTriggers2, f3);
        }
        t1.r.b.b.a a2 = this.P2();
        String string7 = bl ? "Click on next" : "CLICK_ON_PREVIOUS";
        a2.d(string7, this.a(), "Place Request", (double)n3, string2, 0, "QUESTIONNAIRE", string3, n2, n3, questionTypes2.toString(), questionTypes.toString(), true, "Normal");
        if (bl && questionBaseModel != null) {
            StringBuilder stringBuilder;
            t1.r.b.c.f f4 = t1.r.b.c.f.a();
            f4.i(this.a());
            f4.R(questionBaseModel.o().getName());
            f4.N(questionBaseModel.n());
            f4.j(this.A3());
            f4.O(questionTypes2.getName());
            f4.g(null);
            f4.y(this.u);
            t1.r.b.c.f f5 = t1.r.b.c.f.a();
            f5.s(questionBaseModel.e());
            f5.i(this.a());
            f5.N(questionBaseModel.n());
            f5.j(this.A3());
            int n4 = d.c[questionBaseModel.o().ordinal()];
            String string8 = "NA";
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        if (n4 != 4) {
                            if (n4 == 5) {
                                f5.F("response", (Object)((QuestionStaticTextBulletModel)questionBaseModel).a);
                                f5.g("");
                            }
                        } else {
                            f5.F("response", (Object)((QuestionStaticTextModel)questionBaseModel).a);
                            f5.g("");
                        }
                    } else {
                        f5.F("response", (Object)((QuestionExtraModel)questionBaseModel).a);
                        f5.g("");
                    }
                    stringBuilder = null;
                } else {
                    QuestionMultiSelectModel questionMultiSelectModel = (QuestionMultiSelectModel)questionBaseModel;
                    stringBuilder = new StringBuilder();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    for (SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel : questionMultiSelectModel.B()) {
                        if (!singleSelectAndMultiSelectOptionModel.t()) continue;
                        String string9 = singleSelectAndMultiSelectOptionModel.d() != null && !singleSelectAndMultiSelectOptionModel.d().isEmpty() && singleSelectAndMultiSelectOptionModel.d().get(0) != null ? ((CatalogIds)singleSelectAndMultiSelectOptionModel.d().get(0)).c() : string8;
                        stringBuilder.append(";");
                        stringBuilder.append(singleSelectAndMultiSelectOptionModel.a());
                        stringBuilder2.append(";");
                        stringBuilder2.append(string9);
                    }
                    f4.g(stringBuilder.toString());
                    f4.B(stringBuilder2.toString());
                    f5.F("response", (Object)stringBuilder2.toString().replace((CharSequence)";", (CharSequence)"|"));
                    f5.g(stringBuilder.toString());
                }
            } else {
                QuestionSingleSelectModel questionSingleSelectModel = (QuestionSingleSelectModel)questionBaseModel;
                stringBuilder = new StringBuilder();
                StringBuilder stringBuilder3 = new StringBuilder();
                for (SingleSelectAndMultiSelectOptionModel singleSelectAndMultiSelectOptionModel : questionSingleSelectModel.A()) {
                    if (!singleSelectAndMultiSelectOptionModel.t()) continue;
                    StringBuilder stringBuilder4 = new StringBuilder(singleSelectAndMultiSelectOptionModel.a());
                    stringBuilder3 = new StringBuilder(singleSelectAndMultiSelectOptionModel.p());
                    stringBuilder = stringBuilder4;
                    break;
                }
                f4.g(stringBuilder.toString());
                f4.B(stringBuilder3.toString());
                f5.F("response", (Object)stringBuilder3);
                f5.g(stringBuilder.toString());
            }
            this.h.D0(AnalyticsTriggers.QnaFlowAnswerQuestionClicked, f4);
            this.h.D0(AnalyticsTriggers.AnsweredQuestionClicked, f5);
            if (n3 == -1) {
                t1.r.b.c.l l4 = this.h;
                AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.AnsweredLastQna;
                t1.r.b.c.f f6 = t1.r.b.c.f.a();
                f6.k(this.c.o());
                f6.i(this.a());
                f6.N(string);
                if (stringBuilder != null) {
                    string8 = stringBuilder.toString();
                }
                f6.g(string8);
                f6.j(this.A3());
                f6.O(questionTypes2.getName());
                l4.D0(analyticsTriggers, f6);
                t1.r.b.c.l l5 = this.h;
                AnalyticsTriggers analyticsTriggers3 = AnalyticsTriggers.CompletedQnaAuto;
                t1.r.b.c.f f7 = t1.r.b.c.f.a();
                f7.F("last_question", (Object)questionBaseModel.e());
                f7.i(this.a());
                f7.N(string);
                f7.j(this.A3());
                l5.D0(analyticsTriggers3, f7);
                t1.r.k.n.q0.x.d d2 = this.k;
                if (d2 != null) {
                    for (PackageCartItem packageCartItem : d2.e()) {
                        String string10 = this.a();
                        int n5 = this.c.h();
                        int n6 = this.c.o();
                        String string11 = packageCartItem.c() != null && packageCartItem.c().d() != null ? packageCartItem.c().d() : this.i.c();
                        String string12 = t1.r.k.n.c.m((String)string11);
                        String string13 = packageCartItem.c() != null && packageCartItem.c().k() != null ? packageCartItem.c().k() : null;
                        int n7 = packageCartItem.c() != null && packageCartItem.c().q() != null ? packageCartItem.c().q().b() : 0;
                        this.w4("QA_LASTQUESTION_ANSWERED", false, string10, "NA", n5, n6, string12, string13, n7);
                    }
                }
            }
        }
    }

    @Override
    public void y(String string, String string2, String string3, int n2) {
        this.w4(string, false, this.a(), null, this.c.h(), this.c.o(), t1.r.k.n.c.m((String)string2), string3, n2);
    }

    @Override
    public void y0(int n2, String string, String string2, String string3) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2OpenPackageSectionClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.v(n2);
        f2.V(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    @Override
    public void y1(NewPackageItemModel newPackageItemModel, String string, String string2, String string3, String string4) {
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.PackageV2DecreaseQuantityClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        f2.B(string2);
        f2.i(this.a());
        f2.N(string3);
        f2.j(this.A3());
        f2.w(string4);
        l2.D0(analyticsTriggers, f2);
        ArrayList arrayList = new ArrayList();
        for (CatalogIds catalogIds : newPackageItemModel.c()) {
            arrayList.add((Object)new t1.r.k.n.q0.d(catalogIds.c(), String.valueOf((int)catalogIds.e())));
        }
        t1.r.b.c.l l3 = this.h;
        AnalyticsTriggers analyticsTriggers2 = AnalyticsTriggers.RemovedProductClicked;
        t1.r.b.c.f f3 = t1.r.b.c.f.a();
        f3.s(((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue())).e());
        f3.U(0);
        f3.E(0);
        f3.F("product_details", (Object)new Gson().s((Object)new t1.r.k.n.q0.j(newPackageItemModel.k(), (List)arrayList, string2, string4)));
        f3.i(this.a());
        f3.N(string3);
        f3.j(this.A3());
        l3.D0(analyticsTriggers2, f3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public float y3() {
        float f2;
        float f3;
        SubscriptionDetailsModel subscriptionDetailsModel = this.r();
        if (subscriptionDetailsModel != null && subscriptionDetailsModel.s() && this.h1((int)this.u, subscriptionDetailsModel)) {
            f2 = this.W3();
            f3 = this.D((int)this.u, this.r());
            do {
                return f2 + f3;
                break;
            } while (true);
        }
        f2 = this.u;
        f3 = this.W3();
        return f2 + f3;
    }

    public final void y4(AnalyticsTriggers analyticsTriggers, VariantSelectionType variantSelectionType, NewPackageItemModel newPackageItemModel, NewPackageItemModel.VariantUiInfo variantUiInfo, String string, String string2, String string3, String string4) {
        ArrayList arrayList = new ArrayList();
        for (NewPackageItemModel.VariantUiInfo variantUiInfo2 : newPackageItemModel.A().a().a().a().d()) {
            String string5 = variantUiInfo2.c();
            int n2 = variantUiInfo2.f();
            if (variantUiInfo2.c().equals((Object)variantUiInfo.c())) {
                if (variantSelectionType == VariantSelectionType.INCREMENT) {
                    ++n2;
                }
                if (variantSelectionType == VariantSelectionType.DECREMENT) {
                    --n2;
                }
            }
            arrayList.add((Object)new t1.r.k.n.q0.d(string5, String.valueOf((int)n2)));
        }
        t1.r.b.c.l l2 = this.h;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.F("product_details", (Object)new Gson().s((Object)new t1.r.k.n.q0.j(newPackageItemModel.k(), (List)arrayList, string3, string4)));
        f2.G("product_variant", (Object)variantUiInfo.c());
        f2.i(this.a());
        f2.N(string2);
        f2.j(this.A3());
        l2.D0(analyticsTriggers, f2);
    }

    @Override
    public void z() {
        this.a4((QuestionBaseModel)this.c.m().get(((Integer)this.d.get(this.e)).intValue()));
    }

    public final void z2() {
        this.a.fa();
        this.R();
    }

    public final t1.r.k.k.a0.a.a.a z3() {
        return new t1.r.k.k.a0.a.a.a(this.a(), this.b.i());
    }

    public void z4() {
        CategoryQuestions categoryQuestions = this.c;
        QuestionBaseModel questionBaseModel = categoryQuestions != null && categoryQuestions.m().size() > 0 ? (QuestionBaseModel)this.c.m().get(0) : null;
        String string = null;
        if (questionBaseModel != null) {
            string = questionBaseModel.q();
        }
        t1.r.b.c.l l2 = this.h;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.QaLoaded;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        CategoryQuestions categoryQuestions2 = this.c;
        int n2 = 0;
        if (categoryQuestions2 != null) {
            n2 = categoryQuestions2.o();
        }
        f2.k(n2);
        f2.V(this.b.k());
        f2.i(this.a());
        f2.j(this.A3());
        f2.O(string);
        f2.B(this.i.i());
        l2.D0(analyticsTriggers, f2);
    }

    @Override
    public int z6(String string) {
        Rewards rewards = this.c.r().e().d();
        int n2 = d.b[RewardType.valueOf((String)string).ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    return this.V3();
                }
                int n3 = this.V3();
                if (n3 <= rewards.c()) {
                    return n3;
                }
                return rewards.c();
            }
            return rewards.b();
        }
        return this.V3();
    }

    @Override
    public SubscriberAnimationDetail z9() {
        return this.b.j();
    }
}

