/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.AreaPriceSummaryResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.AreaPriceSummaryDataStore;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.AreaPriceSummaryResponseModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*
 * Exception performing whole class analysis.
 */
public final class AreaPriceSummaryResponseModel
extends ResponseBaseModel {
    public static final a CREATOR;
    @SerializedName(value="dataStore")
    private AreaPriceSummaryDataStore e;
    @SerializedName(value="rate_cards")
    private ArrayList<RateCardModel> f;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public AreaPriceSummaryResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(AreaPriceSummaryDataStore.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ar\u2026::class.java.classLoader)");
        AreaPriceSummaryDataStore areaPriceSummaryDataStore = (AreaPriceSummaryDataStore)parcelable;
        ArrayList arrayList = parcel.readArrayList(RateCardModel.class.getClassLoader());
        Objects.requireNonNull((Object)arrayList, (String)"null cannot be cast to non-null type kotlin.collections.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardModel> /* = java.util.ArrayList<com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardModel> */");
        this(areaPriceSummaryDataStore, (ArrayList<RateCardModel>)arrayList);
    }

    public AreaPriceSummaryResponseModel(AreaPriceSummaryDataStore areaPriceSummaryDataStore, ArrayList<RateCardModel> arrayList) {
        l.g((Object)areaPriceSummaryDataStore, (String)"areaPriceSummaryDataStore");
        l.g(arrayList, (String)"rateCards");
        this.e = areaPriceSummaryDataStore;
        this.f = arrayList;
    }

    public int describeContents() {
        return 0;
    }

    public final AreaPriceSummaryDataStore e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof AreaPriceSummaryResponseModel)) break block3;
                AreaPriceSummaryResponseModel areaPriceSummaryResponseModel = (AreaPriceSummaryResponseModel)((Object)object);
                if (l.c((Object)this.e, (Object)areaPriceSummaryResponseModel.e) && l.c(this.f, areaPriceSummaryResponseModel.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final ArrayList<RateCardModel> f() {
        return this.f;
    }

    public int hashCode() {
        AreaPriceSummaryDataStore areaPriceSummaryDataStore = this.e;
        int n2 = areaPriceSummaryDataStore != null ? areaPriceSummaryDataStore.hashCode() : 0;
        int n3 = n2 * 31;
        ArrayList<RateCardModel> arrayList = this.f;
        int n4 = 0;
        if (arrayList != null) {
            n4 = arrayList.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("AreaPriceSummaryResponseModel(areaPriceSummaryDataStore=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", rateCards=");
        stringBuilder.append(this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeParcelable((Parcelable)this.e, n2);
        parcel.writeTypedList(this.f);
    }
}

