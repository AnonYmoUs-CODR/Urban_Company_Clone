/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardTemplateData$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.BulletRowItemModel;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardTemplateData;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class RateCardTemplateData
implements KParcelable {
    public static final Parcelable.Creator<RateCardTemplateData> CREATOR = new a();
    public final String a;
    public final TextModel b;
    public final TextModel c;
    public final String d;
    public final ArrayList<BulletRowItemModel> e;

    public RateCardTemplateData(Parcel parcel) {
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(string, (TextModel)parcel.readParcelable(TextModel.class.getClassLoader()), (TextModel)parcel.readParcelable(TextModel.class.getClassLoader()), parcel.readString(), (ArrayList<BulletRowItemModel>)parcel.readArrayList(BulletRowItemModel.class.getClassLoader()));
    }

    public /* synthetic */ RateCardTemplateData(Parcel parcel, g g2) {
        this(parcel);
    }

    public RateCardTemplateData(String string, TextModel textModel, TextModel textModel2, String string2, ArrayList<BulletRowItemModel> arrayList) {
        l.g((Object)string, (String)"templateType");
        this.a = string;
        this.b = textModel;
        this.c = textModel2;
        this.d = string2;
        this.e = arrayList;
    }

    public final String a() {
        return this.d;
    }

    public final ArrayList<BulletRowItemModel> b() {
        return this.e;
    }

    public final TextModel c() {
        return this.c;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public final TextModel e() {
        return this.b;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n2);
        parcel.writeParcelable((Parcelable)this.c, n2);
        parcel.writeString(this.d);
        parcel.writeTypedList(this.e);
    }
}

