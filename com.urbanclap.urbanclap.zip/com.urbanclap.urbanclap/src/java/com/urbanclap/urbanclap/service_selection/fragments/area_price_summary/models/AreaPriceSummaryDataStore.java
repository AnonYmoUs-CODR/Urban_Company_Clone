/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.AreaPriceSummaryDataStore$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.AreaPriceSummaryDataStore;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public final class AreaPriceSummaryDataStore
implements KParcelable {
    public static final Parcelable.Creator<AreaPriceSummaryDataStore> CREATOR = new a();
    @SerializedName(value="area")
    private final float a;
    @SerializedName(value="bullets")
    private final HashMap<String, RateCardRowItemModel> b;
    @SerializedName(value="deliverables")
    private final HashMap<String, RateCardRowItemModel> c;

    public AreaPriceSummaryDataStore(float f2, HashMap<String, RateCardRowItemModel> hashMap, HashMap<String, RateCardRowItemModel> hashMap2) {
        l.g(hashMap, (String)"bullets");
        l.g(hashMap2, (String)"deliverables");
        this.a = f2;
        this.b = hashMap;
        this.c = hashMap2;
    }

    public AreaPriceSummaryDataStore(Parcel parcel) {
        float f2 = parcel.readFloat();
        HashMap hashMap = parcel.readHashMap(HashMap.class.getClassLoader());
        Objects.requireNonNull((Object)hashMap, (String)"null cannot be cast to non-null type kotlin.collections.HashMap<kotlin.String, com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel> /* = java.util.HashMap<kotlin.String, com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel> */");
        HashMap hashMap2 = parcel.readHashMap(HashMap.class.getClassLoader());
        Objects.requireNonNull((Object)hashMap2, (String)"null cannot be cast to non-null type kotlin.collections.HashMap<kotlin.String, com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel> /* = java.util.HashMap<kotlin.String, com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.RateCardRowItemModel> */");
        this(f2, (HashMap<String, RateCardRowItemModel>)hashMap, (HashMap<String, RateCardRowItemModel>)hashMap2);
    }

    public /* synthetic */ AreaPriceSummaryDataStore(Parcel parcel, g g2) {
        this(parcel);
    }

    public final float a() {
        return this.a;
    }

    public final HashMap<String, RateCardRowItemModel> b() {
        return this.b;
    }

    public final HashMap<String, RateCardRowItemModel> c() {
        return this.c;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeFloat(this.a);
        parcel.writeMap(this.b);
        parcel.writeMap(this.c);
    }
}

