/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.service_selection.viewmodels.prefill.models.SingleSelectPrefillModel$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.service_selection.viewmodels.prefill.models;

import android.os.Parcel;
import com.urbanclap.urbanclap.service_selection.viewmodels.prefill.models.SingleSelectPrefillModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.BasePrefillAnswerModel;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class SingleSelectPrefillModel
extends BasePrefillAnswerModel {
    public static final a CREATOR;
    public final String a;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public SingleSelectPrefillModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(string);
    }

    public SingleSelectPrefillModel(String string) {
        l.g((Object)string, (String)"answerTag");
        this.a = string;
    }

    public final String a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SingleSelectPrefillModel)) break block3;
                SingleSelectPrefillModel singleSelectPrefillModel = (SingleSelectPrefillModel)((Object)object);
                if (l.c((Object)this.a, (Object)singleSelectPrefillModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        if (string != null) {
            return string.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SingleSelectPrefillModel(answerTag=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
    }
}

