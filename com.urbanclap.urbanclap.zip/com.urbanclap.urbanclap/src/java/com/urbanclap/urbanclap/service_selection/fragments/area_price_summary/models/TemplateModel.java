/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.TemplateModel$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.service_selection.fragments.area_price_summary.models.TemplateModel;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public final class TemplateModel
implements KParcelable {
    public static final Parcelable.Creator<TemplateModel> CREATOR = new a();
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="data_store_key")
    private final String b;

    public TemplateModel(Parcel parcel) {
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        this(string, string2);
    }

    public /* synthetic */ TemplateModel(Parcel parcel, g g2) {
        this(parcel);
    }

    public TemplateModel(String string, String string2) {
        l.g((Object)string, (String)"type");
        l.g((Object)string2, (String)"dataStoreKey");
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }
}

