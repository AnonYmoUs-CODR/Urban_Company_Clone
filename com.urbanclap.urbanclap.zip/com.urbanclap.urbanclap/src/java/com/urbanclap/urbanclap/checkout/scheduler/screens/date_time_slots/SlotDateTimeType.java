/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots;

public final class SlotDateTimeType
extends Enum<SlotDateTimeType> {
    private static final /* synthetic */ SlotDateTimeType[] $VALUES;
    public static final /* enum */ SlotDateTimeType TYPE_SLOT_BLOCKED;
    public static final /* enum */ SlotDateTimeType TYPE_SLOT_GROUP_HEADER;
    public static final /* enum */ SlotDateTimeType TYPE_SLOT_NORMAL;
    public static final /* enum */ SlotDateTimeType TYPE_SLOT_SELECTED;

    public static {
        SlotDateTimeType slotDateTimeType;
        SlotDateTimeType slotDateTimeType2;
        SlotDateTimeType slotDateTimeType3;
        SlotDateTimeType slotDateTimeType4;
        SlotDateTimeType[] arrslotDateTimeType = new SlotDateTimeType[4];
        TYPE_SLOT_NORMAL = slotDateTimeType = new SlotDateTimeType();
        arrslotDateTimeType[0] = slotDateTimeType;
        TYPE_SLOT_SELECTED = slotDateTimeType2 = new SlotDateTimeType();
        arrslotDateTimeType[1] = slotDateTimeType2;
        TYPE_SLOT_BLOCKED = slotDateTimeType4 = new SlotDateTimeType();
        arrslotDateTimeType[2] = slotDateTimeType4;
        TYPE_SLOT_GROUP_HEADER = slotDateTimeType3 = new SlotDateTimeType();
        arrslotDateTimeType[3] = slotDateTimeType3;
        $VALUES = arrslotDateTimeType;
    }

    public static SlotDateTimeType valueOf(String string) {
        return (SlotDateTimeType)Enum.valueOf(SlotDateTimeType.class, (String)string);
    }

    public static SlotDateTimeType[] values() {
        return (SlotDateTimeType[])$VALUES.clone();
    }
}

