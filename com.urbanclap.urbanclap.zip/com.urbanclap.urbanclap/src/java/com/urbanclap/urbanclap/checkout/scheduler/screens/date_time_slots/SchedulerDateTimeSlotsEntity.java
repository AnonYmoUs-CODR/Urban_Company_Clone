/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentDisplayModel
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel
 *  com.urbanclap.urbanclap.ucshared.models.checkout.CheckoutInfoStripModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ReminderModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.SlotsDayModel
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.urbanclap.urbanclap.checkout.scheduler.models.BannerInfoModel;
import com.urbanclap.urbanclap.checkout.scheduler.models.HappyHourSchedulerModel;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentDisplayModel;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import com.urbanclap.urbanclap.ucshared.models.checkout.CheckoutInfoStripModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.ReminderModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.SlotsDayModel;
import java.util.ArrayList;
import java.util.List;

public class SchedulerDateTimeSlotsEntity
implements Parcelable {
    public static final Parcelable.Creator<SchedulerDateTimeSlotsEntity> CREATOR = new Parcelable.Creator<SchedulerDateTimeSlotsEntity>(){

        public SchedulerDateTimeSlotsEntity a(Parcel parcel) {
            return new SchedulerDateTimeSlotsEntity(parcel);
        }

        public SchedulerDateTimeSlotsEntity[] b(int n) {
            return new SchedulerDateTimeSlotsEntity[n];
        }
    };
    public ArrayList<SlotsDayModel> a;
    @NonNull
    public String b;
    @NonNull
    public String c;
    @NonNull
    public String d;
    @NonNull
    public String e;
    @NonNull
    public String f;
    @Nullable
    public ReminderModel g;
    @Nullable
    public HappyHourSchedulerModel h;
    @Nullable
    public UcAddress i;
    @Nullable
    public PaymentsItemBaseModel j;
    @Nullable
    public PaymentDisplayModel k;
    @Nullable
    public BannerInfoModel s;
    @Nullable
    public CheckoutInfoStripModel t;
    @Nullable
    public ScheduledBookingInfoModel u;
    @Nullable
    public ScheduledBookingInfoModel v;
    @Nullable
    public String w;

    public SchedulerDateTimeSlotsEntity(Parcel parcel) {
        this.a = parcel.createTypedArrayList(SlotsDayModel.CREATOR);
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readString();
        this.e = parcel.readString();
        this.f = parcel.readString();
        this.g = (ReminderModel)parcel.readParcelable(ReminderModel.class.getClassLoader());
        this.h = (HappyHourSchedulerModel)parcel.readParcelable(HappyHourSchedulerModel.class.getClassLoader());
        this.i = (UcAddress)parcel.readParcelable(UcAddress.class.getClassLoader());
        this.j = (PaymentsItemBaseModel)parcel.readParcelable(PaymentsItemBaseModel.class.getClassLoader());
        this.k = (PaymentDisplayModel)parcel.readParcelable(PaymentDisplayModel.class.getClassLoader());
        this.s = (BannerInfoModel)parcel.readParcelable(BannerInfoModel.class.getClassLoader());
        this.t = (CheckoutInfoStripModel)parcel.readParcelable(CheckoutInfoStripModel.class.getClassLoader());
        this.u = (ScheduledBookingInfoModel)parcel.readParcelable(ScheduledBookingInfoModel.class.getClassLoader());
        this.v = (ScheduledBookingInfoModel)parcel.readParcelable(ScheduledBookingInfoModel.class.getClassLoader());
        this.w = parcel.readString();
    }

    public SchedulerDateTimeSlotsEntity(@NonNull ArrayList<SlotsDayModel> arrayList, @NonNull String string, @NonNull String string2, @NonNull String string3, @NonNull String string4, @NonNull String string5, @Nullable ReminderModel reminderModel, @Nullable HappyHourSchedulerModel happyHourSchedulerModel, @Nullable UcAddress ucAddress, @Nullable PaymentsItemBaseModel paymentsItemBaseModel, @Nullable PaymentDisplayModel paymentDisplayModel, @Nullable BannerInfoModel bannerInfoModel, @Nullable CheckoutInfoStripModel checkoutInfoStripModel, @Nullable ScheduledBookingInfoModel scheduledBookingInfoModel, @Nullable ScheduledBookingInfoModel scheduledBookingInfoModel2, @Nullable String string6) {
        this.a = arrayList;
        this.b = string;
        this.c = string2;
        this.d = string3;
        this.e = string4;
        this.f = string5;
        this.g = reminderModel;
        this.h = happyHourSchedulerModel;
        this.i = ucAddress;
        this.j = paymentsItemBaseModel;
        this.k = paymentDisplayModel;
        this.s = bannerInfoModel;
        this.t = checkoutInfoStripModel;
        this.u = scheduledBookingInfoModel;
        this.v = scheduledBookingInfoModel2;
        this.w = string6;
    }

    @Nullable
    public CheckoutInfoStripModel a() {
        return this.t;
    }

    @NonNull
    public String b() {
        return this.b;
    }

    @NonNull
    public String c() {
        return this.d;
    }

    @Nullable
    public HappyHourSchedulerModel d() {
        return this.h;
    }

    public int describeContents() {
        return 0;
    }

    @Nullable
    public String e() {
        return this.w;
    }

    @Nullable
    public UcAddress f() {
        return this.i;
    }

    @NonNull
    public String g() {
        return this.c;
    }

    @Nullable
    public ReminderModel h() {
        return this.g;
    }

    @Nullable
    public BannerInfoModel i() {
        return this.s;
    }

    @Nullable
    public ScheduledBookingInfoModel j() {
        return this.u;
    }

    @NonNull
    public String k() {
        return this.e;
    }

    @NonNull
    public ArrayList<SlotsDayModel> l() {
        ArrayList<SlotsDayModel> arrayList = this.a;
        if (arrayList != null) {
            return arrayList;
        }
        return new ArrayList();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeTypedList(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeParcelable((Parcelable)this.g, n);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeParcelable((Parcelable)this.i, n);
        parcel.writeParcelable((Parcelable)this.j, n);
        parcel.writeParcelable((Parcelable)this.k, n);
        parcel.writeParcelable((Parcelable)this.s, n);
        parcel.writeParcelable((Parcelable)this.t, n);
        parcel.writeParcelable((Parcelable)this.u, n);
        parcel.writeParcelable((Parcelable)this.v, n);
        parcel.writeString(this.w);
    }

}

