/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  com.urbanclap.urbanclap.ucshared.models.DayLevelSurgeDetailsModel
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots;

import android.content.Context;
import android.text.TextUtils;
import com.urbanclap.urbanclap.ucshared.models.DayLevelSurgeDetailsModel;
import t1.r.k.d.h;
import t1.r.k.n.p;

public class SchedulerDateTimeDateViewData {
    public String a;
    public String b;
    public String c;
    public boolean d;
    public boolean e;
    public String f;
    public DayLevelSurgeDetailsModel g;
    public Type h;
    public boolean i = false;

    public SchedulerDateTimeDateViewData(String string, String string2, String string3, String string4, boolean bl, boolean bl2, String string5, DayLevelSurgeDetailsModel dayLevelSurgeDetailsModel) {
        this.a = string2;
        this.b = string3;
        this.c = string4;
        this.d = bl;
        this.e = bl2;
        this.f = string5;
        this.g = dayLevelSurgeDetailsModel;
        this.h = Type.DEFAULT;
    }

    public String a() {
        return this.c;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.a;
    }

    public DayLevelSurgeDetailsModel d() {
        return this.g;
    }

    public String e() {
        if (TextUtils.isEmpty((CharSequence)this.f)) {
            return p.b.getString(h.s);
        }
        return this.f;
    }

    public Type f() {
        return this.h;
    }

    public boolean g() {
        return this.e;
    }

    public boolean h() {
        return this.i;
    }

    public boolean i() {
        return this.d;
    }

    public void j(boolean bl) {
        this.e = bl;
    }

    public void k(boolean bl) {
        this.i = bl;
    }

    public void l(boolean bl) {
        this.d = bl;
    }

    public void m(Type type) {
        this.h = type;
    }

    public static final class Type
    extends Enum<Type> {
        private static final /* synthetic */ Type[] $VALUES;
        public static final /* enum */ Type ADVANCE_PAYMENT_LOCKED;
        public static final /* enum */ Type ADVANCE_PAYMENT_UNLOCKED;
        public static final /* enum */ Type DEFAULT;
        public static final /* enum */ Type SURGE;

        public static {
            Type type;
            Type type2;
            Type type3;
            Type type4;
            DEFAULT = type4 = new Type();
            ADVANCE_PAYMENT_LOCKED = type2 = new Type();
            ADVANCE_PAYMENT_UNLOCKED = type3 = new Type();
            SURGE = type = new Type();
            $VALUES = new Type[]{type4, type2, type3, type};
        }

        public static Type valueOf(String string) {
            return (Type)Enum.valueOf(Type.class, (String)string);
        }

        public static Type[] values() {
            return (Type[])$VALUES.clone();
        }
    }

}

