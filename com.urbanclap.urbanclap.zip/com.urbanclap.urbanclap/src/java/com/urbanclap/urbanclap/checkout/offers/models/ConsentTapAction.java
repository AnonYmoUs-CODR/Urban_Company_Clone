/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.offers.models.ConsentData;
import i2.a0.d.l;

public final class ConsentTapAction
implements Parcelable {
    public static final Parcelable.Creator<ConsentTapAction> CREATOR = new a();
    @SerializedName(value="data")
    private final ConsentData a;

    public ConsentTapAction(ConsentData consentData) {
        this.a = consentData;
    }

    public final ConsentData a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ConsentTapAction)) break block3;
                ConsentTapAction consentTapAction = (ConsentTapAction)object;
                if (l.c((Object)this.a, (Object)consentTapAction.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        ConsentData consentData = this.a;
        if (consentData != null) {
            return consentData.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ConsentTapAction(data=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        ConsentData consentData = this.a;
        if (consentData != null) {
            parcel.writeInt(1);
            consentData.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<ConsentTapAction> {
        public final ConsentTapAction a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            ConsentData consentData = parcel.readInt() != 0 ? (ConsentData)ConsentData.CREATOR.createFromParcel(parcel) : null;
            return new ConsentTapAction(consentData);
        }

        public final ConsentTapAction[] b(int n) {
            return new ConsentTapAction[n];
        }
    }

}

