/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.ClassLoader
 *  java.lang.Object
 */
package com.urbanclap.urbanclap.checkout.scheduler.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.scheduler.models.SlotsDisplayData;

public class SlotsDisplayDetails
implements Parcelable {
    public static final Parcelable.Creator<SlotsDisplayDetails> CREATOR = new Parcelable.Creator<SlotsDisplayDetails>(){

        public SlotsDisplayDetails a(Parcel parcel) {
            return new SlotsDisplayDetails(parcel);
        }

        public SlotsDisplayDetails[] b(int n) {
            return new SlotsDisplayDetails[n];
        }
    };
    @SerializedName(value="SELECT_DATE_SECTION")
    private SlotsDisplayData a;
    @SerializedName(value="SELECT_SLOT_SECTION")
    private SlotsDisplayData b;
    @SerializedName(value="SELECT_DATE_TIME_SECTION")
    private SlotsDisplayData c;
    @SerializedName(value="SELECT_PROFESSIONAL_SECTION")
    private SlotsDisplayData d;

    public SlotsDisplayDetails(Parcel parcel) {
        this.a = (SlotsDisplayData)parcel.readParcelable(SlotsDisplayData.class.getClassLoader());
        this.b = (SlotsDisplayData)parcel.readParcelable(SlotsDisplayData.class.getClassLoader());
        this.c = (SlotsDisplayData)parcel.readParcelable(SlotsDisplayData.class.getClassLoader());
        this.d = (SlotsDisplayData)parcel.readParcelable(SlotsDisplayData.class.getClassLoader());
    }

    public SlotsDisplayData a() {
        return this.a;
    }

    public SlotsDisplayData b() {
        return this.c;
    }

    public SlotsDisplayData c() {
        return this.d;
    }

    public SlotsDisplayData d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
    }

}

