/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.Spannable
 *  android.text.SpannableString
 *  android.text.SpannableStringBuilder
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  com.urbanclap.urbanclap.checkout.scheduler.models.HappyHourSchedulerModel
 *  com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots.SchedulerDateTimeSlotsEntity
 *  com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots.happy_hour_slot.SchedulerSlotBasedPricingPresenter$SlotGroup
 *  com.urbanclap.urbanclap.ucshared.models.SlotModel
 *  com.urbanclap.urbanclap.ucshared.models.SlotModel$HappyHourSlotModel
 *  com.urbanclap.urbanclap.ucshared.models.SurgeObject
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AdvancePaymentModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.SlotsDayModel
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  java.util.Locale
 *  kotlin.NoWhenBranchMatchedException
 *  t1.r.b.c.f
 *  t1.r.k.d.q.f.c
 *  t1.r.k.d.q.h.a.e
 *  t1.r.k.d.q.h.a.f
 *  t1.r.k.d.q.h.a.j
 *  t1.r.k.d.q.h.a.k
 *  t1.r.k.d.q.h.a.o.a
 *  t1.r.k.d.q.h.a.o.b
 *  t1.r.k.d.q.h.a.o.c
 *  t1.r.k.d.q.h.a.q.b
 *  t1.r.k.d.q.h.a.q.c
 *  t1.r.k.n.i0.a
 *  t1.r.k.n.i0.b
 *  t1.r.k.n.n0.a
 *  t1.r.k.n.w0.c
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots.happy_hour_slot;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import com.urbanclap.urbanclap.checkout.scheduler.models.HappyHourSchedulerModel;
import com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots.SchedulerDateTimeSlotsEntity;
import com.urbanclap.urbanclap.checkout.scheduler.screens.date_time_slots.happy_hour_slot.SchedulerSlotBasedPricingPresenter;
import com.urbanclap.urbanclap.ucshared.models.SlotModel;
import com.urbanclap.urbanclap.ucshared.models.SurgeObject;
import com.urbanclap.urbanclap.ucshared.models.create_request.AdvancePaymentModel;
import com.urbanclap.urbanclap.ucshared.models.create_request.SlotsDayModel;
import i2.a0.d.l;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.NoWhenBranchMatchedException;
import t1.r.b.c.f;
import t1.r.k.d.h;
import t1.r.k.d.q.h.a.e;
import t1.r.k.d.q.h.a.j;
import t1.r.k.d.q.h.a.k;
import t1.r.k.d.q.h.a.q.b;
import t1.r.k.d.q.h.a.q.c;
import t1.r.k.n.i0.a;

public final class SchedulerSlotBasedPricingPresenter
extends c
implements t1.r.k.d.q.h.a.o.a {
    public final WeakReference<t1.r.k.d.q.h.a.o.b> s;

    public SchedulerSlotBasedPricingPresenter(t1.r.k.d.q.h.a.o.b b2, SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity, t1.r.k.d.q.f.c c2, t1.r.k.n.i0.b b3, t1.r.b.c.l l2, t1.r.k.n.n0.a a2, t1.r.k.n.w0.c c3) {
        l.g((Object)b2, (String)"mView");
        l.g((Object)schedulerDateTimeSlotsEntity, (String)"schedulerEntity");
        l.g((Object)c2, (String)"callback");
        l.g((Object)b3, (String)"resources");
        l.g((Object)l2, (String)"analyticsHandler");
        l.g((Object)a2, (String)"locationUtil");
        l.g((Object)c3, (String)"loginUtil");
        super((b)b2, schedulerDateTimeSlotsEntity, c2, b3, l2, a2, c3);
        this.s = new WeakReference((Object)b2);
    }

    private final ArrayList<e> X(String string) {
        t1.r.b.c.l l2 = ((j)this).e;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.QnaFlowChangeSchedulerDate;
        f f2 = f.a();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("T");
        stringBuilder.append(this.l(string));
        f2.B(stringBuilder.toString());
        SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity = ((j)this).b;
        l.f((Object)schedulerDateTimeSlotsEntity, (String)"entity");
        f2.i(schedulerDateTimeSlotsEntity.b());
        SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity2 = ((j)this).b;
        l.f((Object)schedulerDateTimeSlotsEntity2, (String)"entity");
        f2.N(schedulerDateTimeSlotsEntity2.g());
        SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity3 = ((j)this).b;
        l.f((Object)schedulerDateTimeSlotsEntity3, (String)"entity");
        f2.j(schedulerDateTimeSlotsEntity3.c());
        l.f((Object)f2, (String)"AnalyticsProps.create()\n\u2026ntity.categoryQuestionId)");
        l2.D0(analyticsTriggers, f2);
        ArrayList arrayList = new ArrayList();
        SlotsDayModel slotsDayModel = this.t(string);
        if (slotsDayModel != null) {
            Object object = slotsDayModel.f().get(0);
            l.f((Object)object, (String)"dayModel.slots[0]");
            SlotModel.HappyHourSlotModel happyHourSlotModel = ((SlotModel)object).d();
            SlotGroup slotGroup = happyHourSlotModel != null && happyHourSlotModel.a() ? SlotGroup.SLOT_BASED : SlotGroup.DEFAULT;
            SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity4 = ((j)this).b;
            l.f((Object)schedulerDateTimeSlotsEntity4, (String)"entity");
            HappyHourSchedulerModel happyHourSchedulerModel = schedulerDateTimeSlotsEntity4.d();
            Number number = happyHourSchedulerModel != null ? (Number)happyHourSchedulerModel.b() : (Number)null;
            l.e((Object)number);
            SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity5 = ((j)this).b;
            l.f((Object)schedulerDateTimeSlotsEntity5, (String)"entity");
            HappyHourSchedulerModel happyHourSchedulerModel2 = schedulerDateTimeSlotsEntity5.d();
            Number number2 = happyHourSchedulerModel2 != null ? (Number)happyHourSchedulerModel2.a() : (Number)null;
            l.e((Object)number2);
            AdvancePaymentModel advancePaymentModel = slotsDayModel.a();
            Number number3 = advancePaymentModel != null ? (Number)advancePaymentModel.a() : (Number)null;
            arrayList.add((Object)this.F0(slotGroup, number, number2, number3));
            for (SlotModel slotModel : slotsDayModel.f()) {
                l.f((Object)slotModel, (String)"slotModel");
                SlotModel.HappyHourSlotModel happyHourSlotModel2 = slotModel.d();
                if (happyHourSlotModel2 != null && happyHourSlotModel2.a()) {
                    if (slotGroup == SlotGroup.DEFAULT) {
                        slotGroup = SlotGroup.SLOT_BASED;
                        SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity6 = ((j)this).b;
                        l.f((Object)schedulerDateTimeSlotsEntity6, (String)"entity");
                        HappyHourSchedulerModel happyHourSchedulerModel3 = schedulerDateTimeSlotsEntity6.d();
                        Number number4 = happyHourSchedulerModel3 != null ? (Number)happyHourSchedulerModel3.b() : (Number)null;
                        l.e((Object)number4);
                        SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity7 = ((j)this).b;
                        l.f((Object)schedulerDateTimeSlotsEntity7, (String)"entity");
                        HappyHourSchedulerModel happyHourSchedulerModel4 = schedulerDateTimeSlotsEntity7.d();
                        Number number5 = happyHourSchedulerModel4 != null ? (Number)happyHourSchedulerModel4.a() : (Number)null;
                        l.e((Object)number5);
                        AdvancePaymentModel advancePaymentModel2 = slotsDayModel.a();
                        Number number6 = advancePaymentModel2 != null ? (Number)advancePaymentModel2.a() : (Number)null;
                        arrayList.add((Object)this.F0(slotGroup, number4, number5, number6));
                    }
                } else if (slotGroup == SlotGroup.SLOT_BASED) {
                    slotGroup = SlotGroup.DEFAULT;
                    SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity8 = ((j)this).b;
                    l.f((Object)schedulerDateTimeSlotsEntity8, (String)"entity");
                    HappyHourSchedulerModel happyHourSchedulerModel5 = schedulerDateTimeSlotsEntity8.d();
                    Number number7 = happyHourSchedulerModel5 != null ? (Number)happyHourSchedulerModel5.b() : (Number)null;
                    l.e((Object)number7);
                    SchedulerDateTimeSlotsEntity schedulerDateTimeSlotsEntity9 = ((j)this).b;
                    l.f((Object)schedulerDateTimeSlotsEntity9, (String)"entity");
                    HappyHourSchedulerModel happyHourSchedulerModel6 = schedulerDateTimeSlotsEntity9.d();
                    Number number8 = happyHourSchedulerModel6 != null ? (Number)happyHourSchedulerModel6.a() : (Number)null;
                    l.e((Object)number8);
                    AdvancePaymentModel advancePaymentModel3 = slotsDayModel.a();
                    Number number9 = advancePaymentModel3 != null ? (Number)advancePaymentModel3.a() : (Number)null;
                    arrayList.add((Object)this.F0(slotGroup, number7, number8, number9));
                }
                k k2 = new k(slotModel.c(), slotModel.f(), string, false, slotModel.j());
                k2.i(slotModel.i());
                arrayList.add((Object)k2);
            }
        } else {
            t1.r.k.d.q.h.a.o.b b2 = (t1.r.k.d.q.h.a.o.b)this.s.get();
            if (b2 != null) {
                b2.m(((j)this).d.getString(h.r));
            }
        }
        return arrayList;
    }

    public void D() {
        super.D();
    }

    public final t1.r.k.d.q.h.a.f F0(SlotGroup slotGroup, Number number, Number number2, Number number3) {
        int n2 = t1.r.k.d.q.h.a.o.c.a[slotGroup.ordinal()];
        if (n2 != 1) {
            if (n2 == 2) {
                return this.K0(number, number2, number3);
            }
            throw new NoWhenBranchMatchedException();
        }
        return this.n0(number, number3);
    }

    public final t1.r.k.d.q.h.a.f K0(Number number, Number number2, Number number3) {
        SpannableStringBuilder spannableStringBuilder;
        Spannable spannable;
        block5 : {
            block4 : {
                String string = number3 != null ? this.e0(number2, number3) : "";
                String string2 = ((j)this).d.f(Double.valueOf((double)number.doubleValue()), ((j)this).f.c());
                String string3 = ((j)this).d.f(Double.valueOf((double)number2.doubleValue()), ((j)this).f.c());
                t1.r.k.d.q.h.a.o.b b2 = (t1.r.k.d.q.h.a.o.b)this.s.get();
                if (b2 == null) break block4;
                l.f((Object)string3, (String)"postDiscountText");
                spannableStringBuilder = b2.S0(string2, string3, string);
                if (spannableStringBuilder != null) break block5;
            }
            spannableStringBuilder = new SpannableStringBuilder();
        }
        t1.r.k.d.q.h.a.o.b b3 = (t1.r.k.d.q.h.a.o.b)this.s.get();
        if (b3 == null || (spannable = b3.u1(true)) == null) {
            spannable = new SpannableString((CharSequence)"");
        }
        return new t1.r.k.d.q.h.a.f(spannable, (Spannable)spannableStringBuilder);
    }

    public final String e0(Number number, Number number2) {
        int n2 = number.intValue() - number2.intValue();
        String string = ((j)this).d.f(Double.valueOf((double)n2), ((j)this).f.c());
        String string2 = ((j)this).d.f(Double.valueOf((double)number2.doubleValue()), ((j)this).f.c());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        Locale locale = Locale.getDefault();
        String string3 = ((j)this).d.getString(h.x);
        l.f((Object)string3, (String)"resources.getString(R.st\u2026vance_rest_after_service)");
        String string4 = String.format((Locale)locale, (String)string3, (Object[])Arrays.copyOf((Object[])new Object[]{string2, string}, (int)2));
        l.f((Object)string4, (String)"java.lang.String.format(locale, format, *args)");
        stringBuilder.append(string4);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    public final t1.r.k.d.q.h.a.f n0(Number number, Number number2) {
        Spannable spannable;
        SpannableStringBuilder spannableStringBuilder;
        block5 : {
            block4 : {
                String string = number2 != null ? this.e0(number, number2) : "";
                String string2 = ((j)this).d.f(Double.valueOf((double)number.doubleValue()), ((j)this).f.c());
                t1.r.k.d.q.h.a.o.b b2 = (t1.r.k.d.q.h.a.o.b)this.s.get();
                if (b2 == null) break block4;
                l.f((Object)string2, (String)"postDiscountText");
                spannableStringBuilder = b2.S0(null, string2, string);
                if (spannableStringBuilder != null) break block5;
            }
            spannableStringBuilder = new SpannableStringBuilder();
        }
        t1.r.k.d.q.h.a.o.b b3 = (t1.r.k.d.q.h.a.o.b)this.s.get();
        if (b3 == null || (spannable = b3.u1(false)) == null) {
            spannable = new SpannableString((CharSequence)a.l().getString(h.H));
        }
        return new t1.r.k.d.q.h.a.f(spannable, (Spannable)spannableStringBuilder);
    }

    public void v(String string) {
        l.g((Object)string, (String)"iso");
        t1.r.k.d.q.h.a.o.b b2 = (t1.r.k.d.q.h.a.o.b)this.s.get();
        if (b2 != null) {
            b2.a(this.X(string));
        }
    }
}

