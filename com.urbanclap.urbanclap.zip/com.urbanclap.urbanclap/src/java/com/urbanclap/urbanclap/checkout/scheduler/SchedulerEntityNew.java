/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.checkout.scheduler.models.SlotsApiResponseModel
 *  com.urbanclap.urbanclap.checkout.summary.models.response.nextAndInit.SchedulerMetaData
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentDisplayModel
 *  com.urbanclap.urbanclap.ucaddress.AddressEntityNew
 *  com.urbanclap.urbanclap.ucshared.models.LocationModel
 *  com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel
 *  com.urbanclap.urbanclap.ucshared.models.SlotModel
 *  com.urbanclap.urbanclap.ucshared.models.checkout.CheckoutInfoStripModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.checkout.scheduler;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.checkout.scheduler.models.BannerInfoModel;
import com.urbanclap.urbanclap.checkout.scheduler.models.SlotsApiResponseModel;
import com.urbanclap.urbanclap.checkout.scheduler.screens.errorstates.SchedulerErrorStateBottomSheetModel;
import com.urbanclap.urbanclap.checkout.summary.models.response.nextAndInit.SchedulerMetaData;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentDisplayModel;
import com.urbanclap.urbanclap.ucaddress.AddressEntityNew;
import com.urbanclap.urbanclap.ucshared.models.LocationModel;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummarySplit;
import com.urbanclap.urbanclap.ucshared.models.ScheduledBookingInfoModel;
import com.urbanclap.urbanclap.ucshared.models.SlotModel;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import com.urbanclap.urbanclap.ucshared.models.checkout.CheckoutInfoStripModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class SchedulerEntityNew
implements Parcelable {
    public static final a CREATOR = new a(null);
    public final CheckoutInfoStripModel A;
    public final CheckoutInfoStripModel B;
    public UcAddress a;
    public String b;
    public final String c;
    public final String d;
    public final AddressEntityNew e;
    public final String f;
    public final UcAddress g;
    public SlotsApiResponseModel h;
    public PaymentsItemBaseModel i;
    public List<PaymentSummarySplit> j;
    public PaymentDisplayModel k;
    public String s;
    public final SchedulerMetaData t;
    public final UcAddress u;
    public final String v;
    public final SchedulerErrorStateBottomSheetModel w;
    public final BannerInfoModel x;
    public ScheduledBookingInfoModel y;
    public final ScheduledBookingInfoModel z;

    public SchedulerEntityNew(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        Parcelable parcelable = parcel.readParcelable(AddressEntityNew.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ad\u2026::class.java.classLoader)");
        AddressEntityNew addressEntityNew = (AddressEntityNew)parcelable;
        String string3 = parcel.readString();
        l.f((Object)string3, (String)"parcel.readString()");
        this(string, string2, addressEntityNew, string3, (UcAddress)parcel.readParcelable(UcAddress.class.getClassLoader()), (SlotsApiResponseModel)parcel.readParcelable(SlotsApiResponseModel.class.getClassLoader()), (PaymentsItemBaseModel)parcel.readParcelable(PaymentsItemBaseModel.class.getClassLoader()), (List<PaymentSummarySplit>)parcel.readArrayList(PaymentSummarySplit.class.getClassLoader()), (PaymentDisplayModel)parcel.readParcelable(PaymentDisplayModel.class.getClassLoader()), parcel.readString(), (SchedulerMetaData)parcel.readParcelable(SchedulerMetaData.class.getClassLoader()), (UcAddress)parcel.readParcelable(UcAddress.class.getClassLoader()), parcel.readString(), (SchedulerErrorStateBottomSheetModel)parcel.readParcelable(SchedulerErrorStateBottomSheetModel.class.getClassLoader()), (BannerInfoModel)parcel.readParcelable(BannerInfoModel.class.getClassLoader()), (ScheduledBookingInfoModel)parcel.readParcelable(ScheduledBookingInfoModel.class.getClassLoader()), (ScheduledBookingInfoModel)parcel.readParcelable(ScheduledBookingInfoModel.class.getClassLoader()), (CheckoutInfoStripModel)parcel.readParcelable(CheckoutInfoStripModel.class.getClassLoader()), (CheckoutInfoStripModel)parcel.readParcelable(CheckoutInfoStripModel.class.getClassLoader()));
    }

    public SchedulerEntityNew(String string, String string2, AddressEntityNew addressEntityNew, String string3, UcAddress ucAddress, SlotsApiResponseModel slotsApiResponseModel, PaymentsItemBaseModel paymentsItemBaseModel, List<PaymentSummarySplit> list, PaymentDisplayModel paymentDisplayModel, String string4, SchedulerMetaData schedulerMetaData, UcAddress ucAddress2, String string5, SchedulerErrorStateBottomSheetModel schedulerErrorStateBottomSheetModel, BannerInfoModel bannerInfoModel, ScheduledBookingInfoModel scheduledBookingInfoModel, ScheduledBookingInfoModel scheduledBookingInfoModel2, CheckoutInfoStripModel checkoutInfoStripModel, CheckoutInfoStripModel checkoutInfoStripModel2) {
        l.g((Object)string, (String)"categoryKey");
        l.g((Object)string2, (String)"categoryName");
        l.g((Object)addressEntityNew, (String)"addressEntityNew");
        l.g((Object)string3, (String)"preReqId");
        this.c = string;
        this.d = string2;
        this.e = addressEntityNew;
        this.f = string3;
        this.g = ucAddress;
        this.h = slotsApiResponseModel;
        this.i = paymentsItemBaseModel;
        this.j = list;
        this.k = paymentDisplayModel;
        this.s = string4;
        this.t = schedulerMetaData;
        this.u = ucAddress2;
        this.v = string5;
        this.w = schedulerErrorStateBottomSheetModel;
        this.x = bannerInfoModel;
        this.y = scheduledBookingInfoModel;
        this.z = scheduledBookingInfoModel2;
        this.A = checkoutInfoStripModel;
        this.B = checkoutInfoStripModel2;
    }

    public final AddressEntityNew a() {
        return this.e;
    }

    public final String b() {
        return this.s;
    }

    public final CheckoutInfoStripModel c() {
        return this.A;
    }

    public final String d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.d;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof SchedulerEntityNew)) break block3;
                SchedulerEntityNew schedulerEntityNew = (SchedulerEntityNew)object;
                if (l.c((Object)this.c, (Object)schedulerEntityNew.c) && l.c((Object)this.d, (Object)schedulerEntityNew.d) && l.c((Object)this.e, (Object)schedulerEntityNew.e) && l.c((Object)this.f, (Object)schedulerEntityNew.f) && l.c((Object)this.g, (Object)schedulerEntityNew.g) && l.c((Object)this.h, (Object)schedulerEntityNew.h) && l.c((Object)this.i, (Object)schedulerEntityNew.i) && l.c(this.j, schedulerEntityNew.j) && l.c((Object)this.k, (Object)schedulerEntityNew.k) && l.c((Object)this.s, (Object)schedulerEntityNew.s) && l.c((Object)this.t, (Object)schedulerEntityNew.t) && l.c((Object)this.u, (Object)schedulerEntityNew.u) && l.c((Object)this.v, (Object)schedulerEntityNew.v) && l.c((Object)this.w, (Object)schedulerEntityNew.w) && l.c((Object)this.x, (Object)schedulerEntityNew.x) && l.c((Object)this.y, (Object)schedulerEntityNew.y) && l.c((Object)this.z, (Object)schedulerEntityNew.z) && l.c((Object)this.A, (Object)schedulerEntityNew.A) && l.c((Object)this.B, (Object)schedulerEntityNew.B)) break block2;
            }
            return false;
        }
        return true;
    }

    public final CheckoutInfoStripModel f() {
        return this.B;
    }

    public final PaymentDisplayModel g() {
        return this.k;
    }

    public final List<PaymentSummarySplit> h() {
        return this.j;
    }

    public int hashCode() {
        String string = this.c;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.d;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        AddressEntityNew addressEntityNew = this.e;
        int n5 = addressEntityNew != null ? addressEntityNew.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string3 = this.f;
        int n7 = string3 != null ? string3.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        UcAddress ucAddress = this.g;
        int n9 = ucAddress != null ? ucAddress.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        SlotsApiResponseModel slotsApiResponseModel = this.h;
        int n11 = slotsApiResponseModel != null ? slotsApiResponseModel.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        PaymentsItemBaseModel paymentsItemBaseModel = this.i;
        int n13 = paymentsItemBaseModel != null ? paymentsItemBaseModel.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        List<PaymentSummarySplit> list = this.j;
        int n15 = list != null ? list.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        PaymentDisplayModel paymentDisplayModel = this.k;
        int n17 = paymentDisplayModel != null ? paymentDisplayModel.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string4 = this.s;
        int n19 = string4 != null ? string4.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        SchedulerMetaData schedulerMetaData = this.t;
        int n21 = schedulerMetaData != null ? schedulerMetaData.hashCode() : 0;
        int n22 = 31 * (n20 + n21);
        UcAddress ucAddress2 = this.u;
        int n23 = ucAddress2 != null ? ucAddress2.hashCode() : 0;
        int n24 = 31 * (n22 + n23);
        String string5 = this.v;
        int n25 = string5 != null ? string5.hashCode() : 0;
        int n26 = 31 * (n24 + n25);
        SchedulerErrorStateBottomSheetModel schedulerErrorStateBottomSheetModel = this.w;
        int n27 = schedulerErrorStateBottomSheetModel != null ? schedulerErrorStateBottomSheetModel.hashCode() : 0;
        int n28 = 31 * (n26 + n27);
        BannerInfoModel bannerInfoModel = this.x;
        int n29 = bannerInfoModel != null ? bannerInfoModel.hashCode() : 0;
        int n30 = 31 * (n28 + n29);
        ScheduledBookingInfoModel scheduledBookingInfoModel = this.y;
        int n31 = scheduledBookingInfoModel != null ? scheduledBookingInfoModel.hashCode() : 0;
        int n32 = 31 * (n30 + n31);
        ScheduledBookingInfoModel scheduledBookingInfoModel2 = this.z;
        int n33 = scheduledBookingInfoModel2 != null ? scheduledBookingInfoModel2.hashCode() : 0;
        int n34 = 31 * (n32 + n33);
        CheckoutInfoStripModel checkoutInfoStripModel = this.A;
        int n35 = checkoutInfoStripModel != null ? checkoutInfoStripModel.hashCode() : 0;
        int n36 = 31 * (n34 + n35);
        CheckoutInfoStripModel checkoutInfoStripModel2 = this.B;
        int n37 = 0;
        if (checkoutInfoStripModel2 != null) {
            n37 = checkoutInfoStripModel2.hashCode();
        }
        return n36 + n37;
    }

    public final String i() {
        return this.f;
    }

    public final UcAddress j() {
        return this.g;
    }

    public final UcAddress k() {
        return this.u;
    }

    public final PaymentsItemBaseModel l() {
        return this.i;
    }

    public final BannerInfoModel m() {
        return this.x;
    }

    public final ScheduledBookingInfoModel n() {
        return this.y;
    }

    public final ScheduledBookingInfoModel o() {
        return this.z;
    }

    public final SchedulerErrorStateBottomSheetModel p() {
        return this.w;
    }

    public final String q() {
        return this.v;
    }

    public final SchedulerMetaData r() {
        return this.t;
    }

    public final String s() {
        return this.b;
    }

    public final SlotsApiResponseModel t() {
        return this.h;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SchedulerEntityNew(categoryKey=");
        stringBuilder.append(this.c);
        stringBuilder.append(", categoryName=");
        stringBuilder.append(this.d);
        stringBuilder.append(", addressEntityNew=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", preReqId=");
        stringBuilder.append(this.f);
        stringBuilder.append(", preSelectAddress=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", slotsInfo=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", preferredPaymentOption=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", paymentSummaryArray=");
        stringBuilder.append(this.j);
        stringBuilder.append(", paymentDisplayModel=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(", amountPayable=");
        stringBuilder.append(this.s);
        stringBuilder.append(", schedulerMetaData=");
        stringBuilder.append((Object)this.t);
        stringBuilder.append(", preferredAddress=");
        stringBuilder.append((Object)this.u);
        stringBuilder.append(", schedulerInitNode=");
        stringBuilder.append(this.v);
        stringBuilder.append(", schedulerErrorStateBottomSheetModel=");
        stringBuilder.append((Object)this.w);
        stringBuilder.append(", schedulerBannerModel=");
        stringBuilder.append((Object)this.x);
        stringBuilder.append(", schedulerBookingDateInfoModel=");
        stringBuilder.append((Object)this.y);
        stringBuilder.append(", schedulerBookingProviderInfoModel=");
        stringBuilder.append((Object)this.z);
        stringBuilder.append(", bottomInfoStripModel=");
        stringBuilder.append((Object)this.A);
        stringBuilder.append(", infoStripModel=");
        stringBuilder.append((Object)this.B);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final UcAddress u() {
        return this.a;
    }

    public final void v(LocationModel locationModel) {
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeParcelable((Parcelable)this.e, n);
        parcel.writeString(this.f);
        parcel.writeParcelable((Parcelable)this.g, n);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeParcelable((Parcelable)this.i, n);
        parcel.writeTypedList(this.j);
        parcel.writeParcelable((Parcelable)this.k, n);
        parcel.writeString(this.s);
        parcel.writeParcelable((Parcelable)this.t, n);
        parcel.writeParcelable((Parcelable)this.u, n);
        parcel.writeString(this.v);
        parcel.writeParcelable((Parcelable)this.w, n);
        parcel.writeParcelable((Parcelable)this.x, n);
        parcel.writeParcelable((Parcelable)this.y, n);
        parcel.writeParcelable((Parcelable)this.z, n);
        parcel.writeParcelable((Parcelable)this.A, n);
        parcel.writeParcelable((Parcelable)this.B, n);
    }

    public final void x(String string) {
        this.b = string;
    }

    public final void y(SlotModel slotModel) {
    }

    public final void z(UcAddress ucAddress) {
        this.a = ucAddress;
    }

    public static final class a
    implements Parcelable.Creator<SchedulerEntityNew> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public SchedulerEntityNew a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new SchedulerEntityNew(parcel);
        }

        public SchedulerEntityNew[] b(int n) {
            return new SchedulerEntityNew[n];
        }
    }

}

