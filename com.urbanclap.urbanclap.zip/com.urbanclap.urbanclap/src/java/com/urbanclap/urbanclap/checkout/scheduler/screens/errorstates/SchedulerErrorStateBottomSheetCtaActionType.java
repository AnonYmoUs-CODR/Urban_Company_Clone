/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.errorstates;

import i2.a0.d.l;

public final class SchedulerErrorStateBottomSheetCtaActionType
extends Enum<SchedulerErrorStateBottomSheetCtaActionType> {
    private static final /* synthetic */ SchedulerErrorStateBottomSheetCtaActionType[] $VALUES;
    public static final /* enum */ SchedulerErrorStateBottomSheetCtaActionType CHANGE_ADDRESS;
    public static final /* enum */ SchedulerErrorStateBottomSheetCtaActionType DISMISS;
    public static final /* enum */ SchedulerErrorStateBottomSheetCtaActionType SEND_USER_ACTION;
    private String action = "";

    public static {
        SchedulerErrorStateBottomSheetCtaActionType schedulerErrorStateBottomSheetCtaActionType;
        SchedulerErrorStateBottomSheetCtaActionType schedulerErrorStateBottomSheetCtaActionType2;
        SchedulerErrorStateBottomSheetCtaActionType schedulerErrorStateBottomSheetCtaActionType3;
        SchedulerErrorStateBottomSheetCtaActionType[] arrschedulerErrorStateBottomSheetCtaActionType = new SchedulerErrorStateBottomSheetCtaActionType[3];
        DISMISS = schedulerErrorStateBottomSheetCtaActionType = new SchedulerErrorStateBottomSheetCtaActionType("dismiss");
        arrschedulerErrorStateBottomSheetCtaActionType[0] = schedulerErrorStateBottomSheetCtaActionType;
        CHANGE_ADDRESS = schedulerErrorStateBottomSheetCtaActionType3 = new SchedulerErrorStateBottomSheetCtaActionType("change_address");
        arrschedulerErrorStateBottomSheetCtaActionType[1] = schedulerErrorStateBottomSheetCtaActionType3;
        SEND_USER_ACTION = schedulerErrorStateBottomSheetCtaActionType2 = new SchedulerErrorStateBottomSheetCtaActionType("send_user_action");
        arrschedulerErrorStateBottomSheetCtaActionType[2] = schedulerErrorStateBottomSheetCtaActionType2;
        $VALUES = arrschedulerErrorStateBottomSheetCtaActionType;
    }

    private SchedulerErrorStateBottomSheetCtaActionType(String string2) {
        this.action = string2;
    }

    public static SchedulerErrorStateBottomSheetCtaActionType valueOf(String string) {
        return (SchedulerErrorStateBottomSheetCtaActionType)Enum.valueOf(SchedulerErrorStateBottomSheetCtaActionType.class, (String)string);
    }

    public static SchedulerErrorStateBottomSheetCtaActionType[] values() {
        return (SchedulerErrorStateBottomSheetCtaActionType[])$VALUES.clone();
    }

    public final String getAction() {
        return this.action;
    }

    public final void setAction(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.action = string;
    }
}

