/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.checkout.scheduler.models;

import android.os.Parcel;
import android.os.Parcelable;
import i2.a0.d.g;
import i2.a0.d.l;
import java.io.Serializable;
import java.util.Objects;

public final class HappyHourSchedulerModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    public final Number a;
    public final Number b;
    public final String c;

    public HappyHourSchedulerModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Serializable serializable = parcel.readSerializable();
        Objects.requireNonNull((Object)serializable, (String)"null cannot be cast to non-null type kotlin.Number");
        Number number = (Number)serializable;
        Serializable serializable2 = parcel.readSerializable();
        Objects.requireNonNull((Object)serializable2, (String)"null cannot be cast to non-null type kotlin.Number");
        this(number, (Number)serializable2, parcel.readString());
    }

    public HappyHourSchedulerModel(Number number, Number number2, String string) {
        l.g((Object)number, (String)"postDiscountValue");
        l.g((Object)number2, (String)"preDiscountValue");
        this.a = number;
        this.b = number2;
        this.c = string;
    }

    public final Number a() {
        return this.a;
    }

    public final Number b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HappyHourSchedulerModel)) break block3;
                HappyHourSchedulerModel happyHourSchedulerModel = (HappyHourSchedulerModel)object;
                if (l.c((Object)this.a, (Object)happyHourSchedulerModel.a) && l.c((Object)this.b, (Object)happyHourSchedulerModel.b) && l.c((Object)this.c, (Object)happyHourSchedulerModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Number number = this.a;
        int n = number != null ? number.hashCode() : 0;
        int n2 = n * 31;
        Number number2 = this.b;
        int n3 = number2 != null ? number2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string = this.c;
        int n5 = 0;
        if (string != null) {
            n5 = string.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HappyHourSchedulerModel(postDiscountValue=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", preDiscountValue=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", title=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeSerializable((Serializable)this.a);
        parcel.writeSerializable((Serializable)this.b);
        parcel.writeString(this.c);
    }

    public static final class a
    implements Parcelable.Creator<HappyHourSchedulerModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public HappyHourSchedulerModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new HappyHourSchedulerModel(parcel);
        }

        public HappyHourSchedulerModel[] b(int n) {
            return new HappyHourSchedulerModel[n];
        }
    }

}

