/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.Icon
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.offers.models.Consent;
import com.urbanclap.urbanclap.checkout.offers.models.CouponAction;
import com.urbanclap.urbanclap.ucshared.models.Icon;
import i2.a0.d.l;

public final class ItemOfferAndCouponModel
implements Parcelable {
    public static final Parcelable.Creator<ItemOfferAndCouponModel> CREATOR = new a();
    @SerializedName(value="icon")
    private final Icon a;
    @SerializedName(value="title")
    private final String b;
    @SerializedName(value="subtitle")
    private final String c;
    @SerializedName(value="action_cta")
    private final CouponAction d;
    @SerializedName(value="coupon_code")
    private final String e;
    @SerializedName(value="consent")
    private final Consent f;

    public ItemOfferAndCouponModel(Icon icon, String string, String string2, CouponAction couponAction, String string3, Consent consent) {
        l.g((Object)icon, (String)"icon");
        l.g((Object)couponAction, (String)"couponAction");
        this.a = icon;
        this.b = string;
        this.c = string2;
        this.d = couponAction;
        this.e = string3;
        this.f = consent;
    }

    public final Consent a() {
        return this.f;
    }

    public final CouponAction b() {
        return this.d;
    }

    public final String c() {
        return this.e;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public final Icon e() {
        return this.a;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ItemOfferAndCouponModel)) break block3;
                ItemOfferAndCouponModel itemOfferAndCouponModel = (ItemOfferAndCouponModel)object;
                if (l.c((Object)this.a, (Object)itemOfferAndCouponModel.a) && l.c((Object)this.b, (Object)itemOfferAndCouponModel.b) && l.c((Object)this.c, (Object)itemOfferAndCouponModel.c) && l.c((Object)this.d, (Object)itemOfferAndCouponModel.d) && l.c((Object)this.e, (Object)itemOfferAndCouponModel.e) && l.c((Object)this.f, (Object)itemOfferAndCouponModel.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.c;
    }

    public int hashCode() {
        Icon icon = this.a;
        int n = icon != null ? icon.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        CouponAction couponAction = this.d;
        int n7 = couponAction != null ? couponAction.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string3 = this.e;
        int n9 = string3 != null ? string3.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        Consent consent = this.f;
        int n11 = 0;
        if (consent != null) {
            n11 = consent.hashCode();
        }
        return n10 + n11;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ItemOfferAndCouponModel(icon=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", heading=");
        stringBuilder.append(this.b);
        stringBuilder.append(", subHeading=");
        stringBuilder.append(this.c);
        stringBuilder.append(", couponAction=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", couponCode=");
        stringBuilder.append(this.e);
        stringBuilder.append(", consent=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeString(this.e);
        Consent consent = this.f;
        if (consent != null) {
            parcel.writeInt(1);
            consent.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<ItemOfferAndCouponModel> {
        public final ItemOfferAndCouponModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            Icon icon = (Icon)parcel.readParcelable(ItemOfferAndCouponModel.class.getClassLoader());
            String string = parcel.readString();
            String string2 = parcel.readString();
            CouponAction couponAction = (CouponAction)parcel.readParcelable(ItemOfferAndCouponModel.class.getClassLoader());
            String string3 = parcel.readString();
            Consent consent = parcel.readInt() != 0 ? (Consent)Consent.CREATOR.createFromParcel(parcel) : null;
            ItemOfferAndCouponModel itemOfferAndCouponModel = new ItemOfferAndCouponModel(icon, string, string2, couponAction, string3, consent);
            return itemOfferAndCouponModel;
        }

        public final ItemOfferAndCouponModel[] b(int n) {
            return new ItemOfferAndCouponModel[n];
        }
    }

}

