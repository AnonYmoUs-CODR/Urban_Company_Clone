/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.helper;

public final class SchedulerTemplateType
extends Enum<SchedulerTemplateType> {
    private static final /* synthetic */ SchedulerTemplateType[] $VALUES;
    public static final /* enum */ SchedulerTemplateType DEFAULT;
    public static final /* enum */ SchedulerTemplateType SURGE_SLOTS;
    public static final /* enum */ SchedulerTemplateType TIME_BASED_PRICING;
    private final String templateType;

    public static {
        SchedulerTemplateType schedulerTemplateType;
        SchedulerTemplateType schedulerTemplateType2;
        SchedulerTemplateType schedulerTemplateType3;
        DEFAULT = schedulerTemplateType2 = new SchedulerTemplateType("DEFAULT");
        SURGE_SLOTS = schedulerTemplateType3 = new SchedulerTemplateType("SLOTS_WITH_SURGE");
        TIME_BASED_PRICING = schedulerTemplateType = new SchedulerTemplateType("TIME_BASED_PRICING");
        $VALUES = new SchedulerTemplateType[]{schedulerTemplateType2, schedulerTemplateType3, schedulerTemplateType};
    }

    private SchedulerTemplateType(String string2) {
        this.templateType = string2;
    }

    public static SchedulerTemplateType valueOf(String string) {
        return (SchedulerTemplateType)Enum.valueOf(SchedulerTemplateType.class, (String)string);
    }

    public static SchedulerTemplateType[] values() {
        return (SchedulerTemplateType[])$VALUES.clone();
    }

    public String toString() {
        return this.templateType;
    }
}

