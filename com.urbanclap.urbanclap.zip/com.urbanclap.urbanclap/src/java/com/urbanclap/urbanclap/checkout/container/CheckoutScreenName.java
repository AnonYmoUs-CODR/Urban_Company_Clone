/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.container;

public final class CheckoutScreenName
extends Enum<CheckoutScreenName> {
    private static final /* synthetic */ CheckoutScreenName[] $VALUES;
    public static final /* enum */ CheckoutScreenName ADDRESS;
    public static final /* enum */ CheckoutScreenName NONE;
    public static final /* enum */ CheckoutScreenName PAYMENT_OPTIONS;
    public static final /* enum */ CheckoutScreenName REQUEST;
    public static final /* enum */ CheckoutScreenName SCHEDULER;
    public static final /* enum */ CheckoutScreenName SUBSCRIPTION_WEBVIEW;
    public static final /* enum */ CheckoutScreenName SUMMARY;
    private final String key;

    public static {
        CheckoutScreenName checkoutScreenName;
        CheckoutScreenName checkoutScreenName2;
        CheckoutScreenName checkoutScreenName3;
        CheckoutScreenName checkoutScreenName4;
        CheckoutScreenName checkoutScreenName5;
        CheckoutScreenName checkoutScreenName6;
        CheckoutScreenName checkoutScreenName7;
        CheckoutScreenName[] arrcheckoutScreenName = new CheckoutScreenName[7];
        SUMMARY = checkoutScreenName7 = new CheckoutScreenName("summary");
        arrcheckoutScreenName[0] = checkoutScreenName7;
        ADDRESS = checkoutScreenName5 = new CheckoutScreenName("address");
        arrcheckoutScreenName[1] = checkoutScreenName5;
        SCHEDULER = checkoutScreenName6 = new CheckoutScreenName("scheduler");
        arrcheckoutScreenName[2] = checkoutScreenName6;
        PAYMENT_OPTIONS = checkoutScreenName = new CheckoutScreenName("payment_options");
        arrcheckoutScreenName[3] = checkoutScreenName;
        REQUEST = checkoutScreenName3 = new CheckoutScreenName("request");
        arrcheckoutScreenName[4] = checkoutScreenName3;
        SUBSCRIPTION_WEBVIEW = checkoutScreenName4 = new CheckoutScreenName("subscription_webview");
        arrcheckoutScreenName[5] = checkoutScreenName4;
        NONE = checkoutScreenName2 = new CheckoutScreenName("");
        arrcheckoutScreenName[6] = checkoutScreenName2;
        $VALUES = arrcheckoutScreenName;
    }

    private CheckoutScreenName(String string2) {
        this.key = string2;
    }

    public static CheckoutScreenName valueOf(String string) {
        return (CheckoutScreenName)Enum.valueOf(CheckoutScreenName.class, (String)string);
    }

    public static CheckoutScreenName[] values() {
        return (CheckoutScreenName[])$VALUES.clone();
    }

    public final String getKey() {
        return this.key;
    }
}

