/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import i2.a0.d.g;
import i2.a0.d.l;

public class GiftCardItemBaseModel
implements Parcelable {
    public static final a CREATOR = new a(null);

    public GiftCardItemBaseModel() {
    }

    public GiftCardItemBaseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
    }

    public static final class a
    implements Parcelable.Creator<GiftCardItemBaseModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public GiftCardItemBaseModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new GiftCardItemBaseModel(parcel);
        }

        public GiftCardItemBaseModel[] b(int n) {
            return new GiftCardItemBaseModel[n];
        }
    }

}

