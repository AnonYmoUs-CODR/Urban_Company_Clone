/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.checkout.summary.models.response.Text
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.summary.models.response.Text;
import com.urbanclap.urbanclap.common.PictureObject;
import i2.a0.d.g;
import i2.a0.d.l;

public final class BannerInfoModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="icon")
    private final PictureObject a;
    @SerializedName(value="title")
    private final Text b;
    @SerializedName(value="subtitle")
    private final Text c;

    public BannerInfoModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader()), (Text)parcel.readParcelable(Text.class.getClassLoader()), (Text)parcel.readParcelable(Text.class.getClassLoader()));
    }

    public BannerInfoModel(PictureObject pictureObject, Text text, Text text2) {
        this.a = pictureObject;
        this.b = text;
        this.c = text2;
    }

    public final PictureObject a() {
        return this.a;
    }

    public final Text b() {
        return this.c;
    }

    public final Text c() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
    }

    public static final class a
    implements Parcelable.Creator<BannerInfoModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public BannerInfoModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new BannerInfoModel(parcel);
        }

        public BannerInfoModel[] b(int n) {
            return new BannerInfoModel[n];
        }
    }

}

