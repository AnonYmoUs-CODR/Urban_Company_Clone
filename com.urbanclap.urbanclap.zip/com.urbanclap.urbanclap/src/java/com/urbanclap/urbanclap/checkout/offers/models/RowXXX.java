/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.checkout.summary.models.response.BulletX
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.summary.models.response.BulletX;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class RowXXX
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="logo_url")
    private final String a;
    @SerializedName(value="coupon_code")
    private final TextModel b;
    @SerializedName(value="title")
    private final TextModel c;
    @SerializedName(value="description")
    private final TextModel d;
    @SerializedName(value="action_cta")
    private final TextModel e;
    @SerializedName(value="is_disable")
    private final boolean f;
    @SerializedName(value="apply_disable")
    private final boolean g;
    @SerializedName(value="is_applicable")
    private final boolean h;
    @SerializedName(value="dropdown_header")
    private final TextModel i;
    @SerializedName(value="dropdown_points")
    private final ArrayList<BulletX> j;

    public RowXXX(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        Parcelable parcelable = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel = (TextModel)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel2 = (TextModel)parcelable2;
        Parcelable parcelable3 = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable3, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel3 = (TextModel)parcelable3;
        Parcelable parcelable4 = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable4, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel4 = (TextModel)parcelable4;
        byte by = parcel.readByte();
        byte by2 = (byte)(false ? 1 : 0);
        boolean bl = by != by2;
        boolean bl2 = parcel.readByte() != by2;
        boolean bl3 = parcel.readByte() != by2;
        TextModel textModel5 = (TextModel)parcel.readParcelable(TextModel.class.getClassLoader());
        ArrayList arrayList = parcel.readArrayList(String.class.getClassLoader());
        if (!(arrayList instanceof ArrayList)) {
            arrayList = null;
        }
        this(string, textModel, textModel2, textModel3, textModel4, bl, bl2, bl3, textModel5, (ArrayList<BulletX>)arrayList);
    }

    public RowXXX(String string, TextModel textModel, TextModel textModel2, TextModel textModel3, TextModel textModel4, boolean bl, boolean bl2, boolean bl3, TextModel textModel5, ArrayList<BulletX> arrayList) {
        l.g((Object)string, (String)"image");
        l.g((Object)textModel, (String)"couponCode");
        l.g((Object)textModel2, (String)"title");
        l.g((Object)textModel3, (String)"desc");
        l.g((Object)textModel4, (String)"actionCta");
        this.a = string;
        this.b = textModel;
        this.c = textModel2;
        this.d = textModel3;
        this.e = textModel4;
        this.f = bl;
        this.g = bl2;
        this.h = bl3;
        this.i = textModel5;
        this.j = arrayList;
    }

    public final TextModel a() {
        return this.e;
    }

    public final TextModel b() {
        return this.b;
    }

    public final TextModel c() {
        return this.d;
    }

    public final TextModel d() {
        return this.i;
    }

    public int describeContents() {
        return 0;
    }

    public final ArrayList<BulletX> e() {
        return this.j;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof RowXXX)) break block3;
                RowXXX rowXXX = (RowXXX)object;
                if (l.c((Object)this.a, (Object)rowXXX.a) && l.c((Object)this.b, (Object)rowXXX.b) && l.c((Object)this.c, (Object)rowXXX.c) && l.c((Object)this.d, (Object)rowXXX.d) && l.c((Object)this.e, (Object)rowXXX.e) && this.f == rowXXX.f && this.g == rowXXX.g && this.h == rowXXX.h && l.c((Object)this.i, (Object)rowXXX.i) && l.c(this.j, rowXXX.j)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.a;
    }

    public final TextModel g() {
        return this.c;
    }

    public final boolean h() {
        return this.h;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        TextModel textModel = this.b;
        int n3 = textModel != null ? textModel.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        TextModel textModel2 = this.c;
        int n5 = textModel2 != null ? textModel2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        TextModel textModel3 = this.d;
        int n7 = textModel3 != null ? textModel3.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        TextModel textModel4 = this.e;
        int n9 = textModel4 != null ? textModel4.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        int n11 = this.f;
        int n12 = 1;
        if (n11 != 0) {
            n11 = 1;
        }
        int n13 = 31 * (n10 + n11);
        int n14 = this.g ? 1 : 0;
        if (n14 != 0) {
            n14 = 1;
        }
        int n15 = 31 * (n13 + n14);
        int n16 = this.h;
        if (n16 == 0) {
            n12 = n16;
        }
        int n17 = 31 * (n15 + n12);
        TextModel textModel5 = this.i;
        int n18 = textModel5 != null ? textModel5.hashCode() : 0;
        int n19 = 31 * (n17 + n18);
        ArrayList<BulletX> arrayList = this.j;
        int n20 = 0;
        if (arrayList != null) {
            n20 = arrayList.hashCode();
        }
        return n19 + n20;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RowXXX(image=");
        stringBuilder.append(this.a);
        stringBuilder.append(", couponCode=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", title=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", desc=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", actionCta=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", isDisable=");
        stringBuilder.append(this.f);
        stringBuilder.append(", disableApply=");
        stringBuilder.append(this.g);
        stringBuilder.append(", isApplicable=");
        stringBuilder.append(this.h);
        stringBuilder.append(", dropdownHeader=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", dropdownPoints=");
        stringBuilder.append(this.j);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeParcelable((Parcelable)this.e, n);
        parcel.writeByte((byte)this.f);
        parcel.writeByte((byte)this.g);
        parcel.writeByte((byte)this.h);
        parcel.writeParcelable((Parcelable)this.i, n);
        parcel.writeList(this.j);
    }

    public static final class a
    implements Parcelable.Creator<RowXXX> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public RowXXX a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new RowXXX(parcel);
        }

        public RowXXX[] b(int n) {
            return new RowXXX[n];
        }
    }

}

