/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.offers.flat_models;

public final class OfferScreenTemplatesType
extends Enum<OfferScreenTemplatesType> {
    private static final /* synthetic */ OfferScreenTemplatesType[] $VALUES;
    public static final /* enum */ OfferScreenTemplatesType GIFT_CARDS;
    public static final /* enum */ OfferScreenTemplatesType MANUAL_COUPON;
    public static final /* enum */ OfferScreenTemplatesType OTHER_OFFERS;
    public static final /* enum */ OfferScreenTemplatesType PAYMENT_OFFERS;
    public static final /* enum */ OfferScreenTemplatesType SEPARATOR;
    public static final /* enum */ OfferScreenTemplatesType TITLE_CTA;
    private final String key;

    public static {
        OfferScreenTemplatesType offerScreenTemplatesType;
        OfferScreenTemplatesType offerScreenTemplatesType2;
        OfferScreenTemplatesType offerScreenTemplatesType3;
        OfferScreenTemplatesType offerScreenTemplatesType4;
        OfferScreenTemplatesType offerScreenTemplatesType5;
        OfferScreenTemplatesType offerScreenTemplatesType6;
        OfferScreenTemplatesType[] arrofferScreenTemplatesType = new OfferScreenTemplatesType[6];
        SEPARATOR = offerScreenTemplatesType5 = new OfferScreenTemplatesType("seperator");
        arrofferScreenTemplatesType[0] = offerScreenTemplatesType5;
        MANUAL_COUPON = offerScreenTemplatesType3 = new OfferScreenTemplatesType("coupon_code");
        arrofferScreenTemplatesType[1] = offerScreenTemplatesType3;
        PAYMENT_OFFERS = offerScreenTemplatesType = new OfferScreenTemplatesType("payment_offers");
        arrofferScreenTemplatesType[2] = offerScreenTemplatesType;
        GIFT_CARDS = offerScreenTemplatesType4 = new OfferScreenTemplatesType("gift_cards");
        arrofferScreenTemplatesType[3] = offerScreenTemplatesType4;
        OTHER_OFFERS = offerScreenTemplatesType6 = new OfferScreenTemplatesType("other_offers");
        arrofferScreenTemplatesType[4] = offerScreenTemplatesType6;
        TITLE_CTA = offerScreenTemplatesType2 = new OfferScreenTemplatesType("title_cta");
        arrofferScreenTemplatesType[5] = offerScreenTemplatesType2;
        $VALUES = arrofferScreenTemplatesType;
    }

    private OfferScreenTemplatesType(String string2) {
        this.key = string2;
    }

    public static OfferScreenTemplatesType valueOf(String string) {
        return (OfferScreenTemplatesType)Enum.valueOf(OfferScreenTemplatesType.class, (String)string);
    }

    public static OfferScreenTemplatesType[] values() {
        return (OfferScreenTemplatesType[])$VALUES.clone();
    }

    public final String getKey() {
        return this.key;
    }
}

