/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.rebook_provider;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.urbanclap.urbanclap.checkout.scheduler.screens.rebook_provider.RebookProviderEntity;
import java.util.ArrayList;
import java.util.List;

public class SchedulerRebookProviderEntity
implements Parcelable {
    public static final Parcelable.Creator<SchedulerRebookProviderEntity> CREATOR = new Parcelable.Creator<SchedulerRebookProviderEntity>(){

        public SchedulerRebookProviderEntity a(Parcel parcel) {
            return new SchedulerRebookProviderEntity(parcel, null);
        }

        public SchedulerRebookProviderEntity[] b(int n) {
            return new SchedulerRebookProviderEntity[n];
        }
    };
    @NonNull
    public String a;
    @NonNull
    public ArrayList<RebookProviderEntity> b;
    @Nullable
    public RebookProviderEntity c;

    public SchedulerRebookProviderEntity(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.createTypedArrayList(RebookProviderEntity.CREATOR);
        this.c = (RebookProviderEntity)parcel.readParcelable(RebookProviderEntity.class.getClassLoader());
    }

    public /* synthetic */ SchedulerRebookProviderEntity(Parcel parcel, a a2) {
        this(parcel);
    }

    public SchedulerRebookProviderEntity(@NonNull String string, @NonNull ArrayList<RebookProviderEntity> arrayList, @Nullable RebookProviderEntity rebookProviderEntity) {
        this.a = string;
        this.b = arrayList;
        this.c = rebookProviderEntity;
    }

    @NonNull
    public String a() {
        return this.a;
    }

    @NonNull
    public ArrayList<RebookProviderEntity> b() {
        return this.b;
    }

    @Nullable
    public RebookProviderEntity c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeTypedList(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
    }

}

