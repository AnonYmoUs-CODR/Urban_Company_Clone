/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class SlotsDisplayData
implements Parcelable {
    public static final Parcelable.Creator<SlotsDisplayData> CREATOR = new Parcelable.Creator<SlotsDisplayData>(){

        public SlotsDisplayData a(Parcel parcel) {
            return new SlotsDisplayData(parcel);
        }

        public SlotsDisplayData[] b(int n) {
            return new SlotsDisplayData[n];
        }
    };
    @SerializedName(value="heading")
    private String a;

    public SlotsDisplayData(Parcel parcel) {
        this.a = parcel.readString();
    }

    public String a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
    }

}

