/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.checkout.offers.models.ConsentTapAction;
import i2.a0.d.l;

public final class Consent
implements Parcelable {
    public static final Parcelable.Creator<Consent> CREATOR = new a();
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="pre_selected")
    private final Boolean b;
    @SerializedName(value="tap_action")
    private final ConsentTapAction c;

    public Consent(String string, Boolean bl, ConsentTapAction consentTapAction) {
        this.a = string;
        this.b = bl;
        this.c = consentTapAction;
    }

    public final Boolean a() {
        return this.b;
    }

    public final ConsentTapAction b() {
        return this.c;
    }

    public final String c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Consent)) break block3;
                Consent consent = (Consent)object;
                if (l.c((Object)this.a, (Object)consent.a) && l.c((Object)this.b, (Object)consent.b) && l.c((Object)this.c, (Object)consent.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        Boolean bl = this.b;
        int n3 = bl != null ? bl.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        ConsentTapAction consentTapAction = this.c;
        int n5 = 0;
        if (consentTapAction != null) {
            n5 = consentTapAction.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Consent(title=");
        stringBuilder.append(this.a);
        stringBuilder.append(", preSelected=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        Boolean bl = this.b;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        ConsentTapAction consentTapAction = this.c;
        if (consentTapAction != null) {
            parcel.writeInt(1);
            consentTapAction.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<Consent> {
        public final Consent a(Parcel parcel) {
            Boolean bl;
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            if (parcel.readInt() != 0) {
                boolean bl2 = parcel.readInt() != 0;
                bl = bl2;
            } else {
                bl = null;
            }
            int n = parcel.readInt();
            ConsentTapAction consentTapAction = null;
            if (n != 0) {
                consentTapAction = (ConsentTapAction)ConsentTapAction.CREATOR.createFromParcel(parcel);
            }
            return new Consent(string, bl, consentTapAction);
        }

        public final Consent[] b(int n) {
            return new Consent[n];
        }
    }

}

