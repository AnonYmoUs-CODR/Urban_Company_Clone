/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.Icon
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.Icon;
import com.urbanclap.urbanclap.ucshared.models.TextModel;
import i2.a0.d.g;
import i2.a0.d.l;

public final class CouponAction
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="action_icon")
    private final Icon a;
    @SerializedName(value="action_text")
    private final TextModel b;
    @SerializedName(value="action")
    private final String c;
    @SerializedName(value="type")
    private final String d;

    public CouponAction(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        Parcelable parcelable = parcel.readParcelable(Icon.class.getClassLoader());
        l.f((Object)parcelable, (String)"parcel.readParcelable(Ic\u2026::class.java.classLoader)");
        Icon icon = (Icon)parcelable;
        Parcelable parcelable2 = parcel.readParcelable(TextModel.class.getClassLoader());
        l.f((Object)parcelable2, (String)"parcel.readParcelable(Te\u2026::class.java.classLoader)");
        TextModel textModel = (TextModel)parcelable2;
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(icon, textModel, string, parcel.readString());
    }

    public CouponAction(Icon icon, TextModel textModel, String string, String string2) {
        l.g((Object)icon, (String)"actionIcon");
        l.g((Object)textModel, (String)"actionText");
        l.g((Object)string, (String)"action");
        this.a = icon;
        this.b = textModel;
        this.c = string;
        this.d = string2;
    }

    public final String a() {
        return this.c;
    }

    public final Icon b() {
        return this.a;
    }

    public final String c() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CouponAction)) break block3;
                CouponAction couponAction = (CouponAction)object;
                if (l.c((Object)this.a, (Object)couponAction.a) && l.c((Object)this.b, (Object)couponAction.b) && l.c((Object)this.c, (Object)couponAction.c) && l.c((Object)this.d, (Object)couponAction.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Icon icon = this.a;
        int n = icon != null ? icon.hashCode() : 0;
        int n2 = n * 31;
        TextModel textModel = this.b;
        int n3 = textModel != null ? textModel.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string = this.c;
        int n5 = string != null ? string.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string2 = this.d;
        int n7 = 0;
        if (string2 != null) {
            n7 = string2.hashCode();
        }
        return n6 + n7;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CouponAction(actionIcon=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", actionText=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", action=");
        stringBuilder.append(this.c);
        stringBuilder.append(", type=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
    }

    public static final class a
    implements Parcelable.Creator<CouponAction> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public CouponAction a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new CouponAction(parcel);
        }

        public CouponAction[] b(int n) {
            return new CouponAction[n];
        }
    }

}

