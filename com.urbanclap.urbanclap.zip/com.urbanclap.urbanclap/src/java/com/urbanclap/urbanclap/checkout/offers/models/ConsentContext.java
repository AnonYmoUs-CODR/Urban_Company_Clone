/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.offers.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class ConsentContext
implements Parcelable {
    public static final Parcelable.Creator<ConsentContext> CREATOR = new a();
    @SerializedName(value="entity")
    private final String a;
    @SerializedName(value="entity_type")
    private final String b;
    @SerializedName(value="pitch")
    private final String c;

    public ConsentContext(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

    public static final class a
    implements Parcelable.Creator<ConsentContext> {
        public final ConsentContext a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new ConsentContext(parcel.readString(), parcel.readString(), parcel.readString());
        }

        public final ConsentContext[] b(int n) {
            return new ConsentContext[n];
        }
    }

}

