/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ReBookingProviderModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ReBookingProviderModel$MetaData
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ReBookingProviderModel$MetaData$VaccinationTag
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.checkout.scheduler.screens.rebook_provider;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.models.create_request.ReBookingProviderModel;

public class RebookProviderEntity
implements Parcelable {
    public static final Parcelable.Creator<RebookProviderEntity> CREATOR = new Parcelable.Creator<RebookProviderEntity>(){

        public RebookProviderEntity a(Parcel parcel) {
            return new RebookProviderEntity(parcel, null);
        }

        public RebookProviderEntity[] b(int n) {
            return new RebookProviderEntity[n];
        }
    };
    public String a;
    public String b;
    public String c;
    public int d;
    public PictureObject e;
    public boolean f;
    public boolean g;
    public String h;
    public boolean i;
    public ReBookingProviderModel.MetaData.VaccinationTag j;
    public PictureObject k;
    public boolean s;
    public String t;

    public RebookProviderEntity(Parcel parcel) {
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = parcel.readInt();
        this.e = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.f = bl2;
        boolean bl3 = parcel.readByte() != 0;
        this.g = bl3;
        this.h = parcel.readString();
        boolean bl4 = parcel.readByte() != 0;
        this.i = bl4;
        this.j = (ReBookingProviderModel.MetaData.VaccinationTag)parcel.readParcelable(ReBookingProviderModel.MetaData.VaccinationTag.class.getClassLoader());
        this.k = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.s = bl;
        this.t = parcel.readString();
    }

    public /* synthetic */ RebookProviderEntity(Parcel parcel, a a2) {
        this(parcel);
    }

    public RebookProviderEntity(String string, String string2, String string3, int n, PictureObject pictureObject, boolean bl, boolean bl2, String string4, boolean bl3, ReBookingProviderModel.MetaData.VaccinationTag vaccinationTag, PictureObject pictureObject2, boolean bl4, String string5) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = n;
        this.e = pictureObject;
        this.f = bl;
        this.g = bl2;
        this.h = string4;
        this.i = bl3;
        this.j = vaccinationTag;
        this.k = pictureObject2;
        this.s = bl4;
        this.t = string5;
    }

    public String a() {
        return this.t;
    }

    public PictureObject b() {
        return this.k;
    }

    public PictureObject c() {
        return this.e;
    }

    public String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.c;
    }

    public int f() {
        return this.d;
    }

    public String g() {
        return this.h;
    }

    public ReBookingProviderModel.MetaData.VaccinationTag h() {
        return this.j;
    }

    public boolean i() {
        return this.g;
    }

    public boolean j() {
        return this.f;
    }

    public boolean k() {
        return this.i;
    }

    public boolean l() {
        return this.s;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeInt(this.d);
        parcel.writeParcelable((Parcelable)this.e, n);
        parcel.writeByte((byte)this.f);
        parcel.writeByte((byte)this.g);
        parcel.writeString(this.h);
        parcel.writeByte((byte)this.i);
        parcel.writeParcelable((Parcelable)this.j, n);
        parcel.writeParcelable((Parcelable)this.k, n);
        parcel.writeByte((byte)this.s);
        parcel.writeString(this.t);
    }

}

