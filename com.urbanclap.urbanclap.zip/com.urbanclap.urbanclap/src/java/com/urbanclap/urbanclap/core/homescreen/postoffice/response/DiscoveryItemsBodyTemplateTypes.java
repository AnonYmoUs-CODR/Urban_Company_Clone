/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class DiscoveryItemsBodyTemplateTypes
extends Enum<DiscoveryItemsBodyTemplateTypes> {
    private static final /* synthetic */ DiscoveryItemsBodyTemplateTypes[] $VALUES;
    @SerializedName(value="bullets")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes BULLETS;
    @SerializedName(value="carousel")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes CAROUSEL;
    @SerializedName(value="category_collection")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes CATEGORY_COLLECTION;
    @SerializedName(value="category_exposed_grid")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes CATEGORY_EXPOSED_GRID;
    @SerializedName(value="category_list")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes CATEGORY_LIST;
    @SerializedName(value="first_question")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes FIRST_QUESTION;
    @SerializedName(value="grid")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes GRID;
    @SerializedName(value="header_stories")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes HEADER_STORIES;
    @SerializedName(value="image")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes IMAGE;
    @SerializedName(value="info_strip")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes INFO_STRIP;
    @SerializedName(value="light_service_collection")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes LIGHT_SERVICE_COLLECTION;
    @SerializedName(value="list_details")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes LIST_DETAILS;
    @SerializedName(value="marketing")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes MARKETING;
    @SerializedName(value="media_carousel")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes MEDIA_CAROUSEL;
    @SerializedName(value="offer")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes OFFER;
    @SerializedName(value="old_subscription")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes OLD_SUBSCRIPTION;
    @SerializedName(value="rebook_professionals")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes REBOOKING_PROFESSIONAL;
    @SerializedName(value="renewed_marketing_strip")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes RENEWED_MARKETING_STRIP;
    @SerializedName(value="request_info")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes REQUEST_INFO;
    @SerializedName(value="reviews")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes REVIEWS;
    @SerializedName(value="rich_service_collection")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes RICH_SERVICE_COLLECTION;
    @SerializedName(value="search_item")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SEARCH_ITEM;
    @SerializedName(value="search_zero_result_item")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SEARCH_ZERO_RESULT_ITEM;
    @SerializedName(value="section_grid")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SECTIONS_GRID;
    @SerializedName(value="section_grid_carousel")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SECTION_GRID_CAROUSEL;
    @SerializedName(value="service_list")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SERVICE_LIST;
    @SerializedName(value="spotlight")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SPOTLIGHT;
    @SerializedName(value="sticky_view_carousel")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes STICKY_VIEW_CAROUSAL;
    @SerializedName(value="subscription")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SUBSCRIPTION;
    @SerializedName(value="subscription_tiles")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes SUBSCRIPTION_TILES;
    @SerializedName(value="tabs")
    public static final /* enum */ DiscoveryItemsBodyTemplateTypes TABS;

    public static {
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes2;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes3;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes4;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes5;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes6;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes7;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes8;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes9;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes10;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes11;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes12;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes13;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes14;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes15;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes16;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes17;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes18;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes19;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes20;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes21;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes22;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes23;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes24;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes25;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes26;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes27;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes28;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes29;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes30;
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes31;
        DiscoveryItemsBodyTemplateTypes[] arrdiscoveryItemsBodyTemplateTypes = new DiscoveryItemsBodyTemplateTypes[31];
        GRID = discoveryItemsBodyTemplateTypes5 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[0] = discoveryItemsBodyTemplateTypes5;
        IMAGE = discoveryItemsBodyTemplateTypes30 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[1] = discoveryItemsBodyTemplateTypes30;
        CAROUSEL = discoveryItemsBodyTemplateTypes8 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[2] = discoveryItemsBodyTemplateTypes8;
        REBOOKING_PROFESSIONAL = discoveryItemsBodyTemplateTypes7 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[3] = discoveryItemsBodyTemplateTypes7;
        OLD_SUBSCRIPTION = discoveryItemsBodyTemplateTypes28 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[4] = discoveryItemsBodyTemplateTypes28;
        STICKY_VIEW_CAROUSAL = discoveryItemsBodyTemplateTypes9 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[5] = discoveryItemsBodyTemplateTypes9;
        SUBSCRIPTION_TILES = discoveryItemsBodyTemplateTypes2 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[6] = discoveryItemsBodyTemplateTypes2;
        SUBSCRIPTION = discoveryItemsBodyTemplateTypes25 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[7] = discoveryItemsBodyTemplateTypes25;
        CATEGORY_COLLECTION = discoveryItemsBodyTemplateTypes14 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[8] = discoveryItemsBodyTemplateTypes14;
        RENEWED_MARKETING_STRIP = discoveryItemsBodyTemplateTypes22 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[9] = discoveryItemsBodyTemplateTypes22;
        CATEGORY_EXPOSED_GRID = discoveryItemsBodyTemplateTypes11 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[10] = discoveryItemsBodyTemplateTypes11;
        SPOTLIGHT = discoveryItemsBodyTemplateTypes24 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[11] = discoveryItemsBodyTemplateTypes24;
        REQUEST_INFO = discoveryItemsBodyTemplateTypes16 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[12] = discoveryItemsBodyTemplateTypes16;
        SECTIONS_GRID = discoveryItemsBodyTemplateTypes3 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[13] = discoveryItemsBodyTemplateTypes3;
        LIST_DETAILS = discoveryItemsBodyTemplateTypes21 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[14] = discoveryItemsBodyTemplateTypes21;
        BULLETS = discoveryItemsBodyTemplateTypes23 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[15] = discoveryItemsBodyTemplateTypes23;
        CATEGORY_LIST = discoveryItemsBodyTemplateTypes4 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[16] = discoveryItemsBodyTemplateTypes4;
        REVIEWS = discoveryItemsBodyTemplateTypes17 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[17] = discoveryItemsBodyTemplateTypes17;
        FIRST_QUESTION = discoveryItemsBodyTemplateTypes27 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[18] = discoveryItemsBodyTemplateTypes27;
        MARKETING = discoveryItemsBodyTemplateTypes = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[19] = discoveryItemsBodyTemplateTypes;
        HEADER_STORIES = discoveryItemsBodyTemplateTypes19 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[20] = discoveryItemsBodyTemplateTypes19;
        MEDIA_CAROUSEL = discoveryItemsBodyTemplateTypes31 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[21] = discoveryItemsBodyTemplateTypes31;
        SEARCH_ITEM = discoveryItemsBodyTemplateTypes12 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[22] = discoveryItemsBodyTemplateTypes12;
        SEARCH_ZERO_RESULT_ITEM = discoveryItemsBodyTemplateTypes18 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[23] = discoveryItemsBodyTemplateTypes18;
        SECTION_GRID_CAROUSEL = discoveryItemsBodyTemplateTypes6 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[24] = discoveryItemsBodyTemplateTypes6;
        TABS = discoveryItemsBodyTemplateTypes10 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[25] = discoveryItemsBodyTemplateTypes10;
        LIGHT_SERVICE_COLLECTION = discoveryItemsBodyTemplateTypes29 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[26] = discoveryItemsBodyTemplateTypes29;
        RICH_SERVICE_COLLECTION = discoveryItemsBodyTemplateTypes13 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[27] = discoveryItemsBodyTemplateTypes13;
        SERVICE_LIST = discoveryItemsBodyTemplateTypes20 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[28] = discoveryItemsBodyTemplateTypes20;
        OFFER = discoveryItemsBodyTemplateTypes26 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[29] = discoveryItemsBodyTemplateTypes26;
        INFO_STRIP = discoveryItemsBodyTemplateTypes15 = new DiscoveryItemsBodyTemplateTypes();
        arrdiscoveryItemsBodyTemplateTypes[30] = discoveryItemsBodyTemplateTypes15;
        $VALUES = arrdiscoveryItemsBodyTemplateTypes;
    }

    public static DiscoveryItemsBodyTemplateTypes valueOf(String string) {
        return (DiscoveryItemsBodyTemplateTypes)Enum.valueOf(DiscoveryItemsBodyTemplateTypes.class, (String)string);
    }

    public static DiscoveryItemsBodyTemplateTypes[] values() {
        return (DiscoveryItemsBodyTemplateTypes[])$VALUES.clone();
    }
}

