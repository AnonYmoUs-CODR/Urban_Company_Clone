/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.HandlerThread
 *  androidx.lifecycle.LiveData
 *  androidx.work.Constraints
 *  androidx.work.Constraints$Builder
 *  androidx.work.NetworkType
 *  androidx.work.OneTimeWorkRequest
 *  androidx.work.OneTimeWorkRequest$Builder
 *  androidx.work.Operation
 *  androidx.work.WorkManager
 *  androidx.work.WorkRequest
 *  androidx.work.WorkRequest$Builder
 *  b3.a
 *  c3.a
 *  c3.d
 *  com.clevertap.android.sdk.CleverTapAPI
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  com.urbanclap.urbanclap.compass.AddressFetcher
 *  com.urbanclap.urbanclap.core.UCApplication$a
 *  com.urbanclap.urbanclap.core.app_init.ResourceDownloadWorker
 *  com.urbanclap.urbanclap.ucshared.ConfigUtil
 *  com.urbanclap.urbanclap.ucshared.common.UcEvents
 *  i2.a0.c.l
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.Collection
 *  java.util.Map
 *  java.util.concurrent.TimeUnit
 *  n2.b
 *  org.json.JSONException
 *  org.json.JSONObject
 *  t1.h.a.a.a
 *  t1.r.b.b.d.b
 *  t1.r.b.c.c
 *  t1.r.b.c.f
 *  t1.r.d.d
 *  t1.r.h.a.a
 *  t1.r.h.a.k
 *  t1.r.k.f.d
 *  t1.r.k.g.b0.b.b
 *  t1.r.k.g.r
 *  t1.r.k.g.z.b
 *  t1.r.k.g.z.b$a
 *  t1.r.k.n.d0.f
 *  t1.r.k.n.n0.c
 *  t1.r.k.n.o0.c
 *  t1.r.k.n.q0.u.a.f
 *  t1.r.k.n.q0.u.a.f$a
 *  t1.r.k.n.q0.u.c.a
 *  t1.r.k.n.q0.u.c.a$a
 *  t1.r.k.n.q0.u.d.a
 *  t1.r.k.n.q0.u.d.a$a
 *  t1.r.k.n.q0.v.d
 *  t1.r.k.n.q0.v.d$h
 *  t1.r.k.n.r0.a
 *  t1.r.k.n.r0.b
 *  t1.r.k.n.r0.c
 *  t1.r.k.n.w0.e
 *  t1.s.e.e.a.k
 *  t1.s.e.f.c
 *  t1.s.e.f.c$h
 *  t2.c.a.c
 *  tinkle.NotificationConstants
 *  tinkle.NotificationConstants$NotificationDismissSource
 *  tinkle.models.NotificationData
 */
package com.urbanclap.urbanclap.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.HandlerThread;
import androidx.lifecycle.LiveData;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.Operation;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;
import com.clevertap.android.sdk.CleverTapAPI;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import com.urbanclap.urbanclap.compass.AddressFetcher;
import com.urbanclap.urbanclap.core.UCApplication;
import com.urbanclap.urbanclap.core.app_init.ResourceDownloadWorker;
import com.urbanclap.urbanclap.ucshared.ConfigUtil;
import com.urbanclap.urbanclap.ucshared.common.UcEvents;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import i2.a0.c.l;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import n2.b;
import org.json.JSONException;
import org.json.JSONObject;
import t1.r.h.a.k;
import t1.r.k.f.d;
import t1.r.k.g.r;
import t1.r.k.g.z.b;
import t1.r.k.n.n0.c;
import t1.r.k.n.p;
import t1.r.k.n.q0.u.a.f;
import t1.r.k.n.q0.u.c.a;
import t1.r.k.n.q0.u.d.a;
import t1.r.k.n.q0.v.d;
import t1.r.k.n.w0.e;
import t1.s.e.f.c;
import tinkle.NotificationConstants;
import tinkle.models.NotificationData;

public class UCApplication
extends p
implements b3.a,
b.a,
t1.r.h.a.a,
Application.ActivityLifecycleCallbacks {
    public static String h;
    public static String i;
    public static HandlerThread j;
    public t1.r.d.d e;
    public boolean f = false;
    public t1.r.k.n.r0.a g;

    public static Activity j() {
        Map map;
        block8 : {
            Class class_ = Class.forName((String)"android.app.ActivityThread");
            Object object = class_.getMethod("currentActivityThread", new Class[0]).invoke(null, new Object[0]);
            Field field = class_.getDeclaredField("mActivities");
            field.setAccessible(true);
            map = (Map)field.get(object);
            if (map != null) break block8;
            return null;
        }
        try {
            for (Object object : map.values()) {
                Class class_ = object.getClass();
                Field field = class_.getDeclaredField("paused");
                field.setAccessible(true);
                if (field.getBoolean(object)) continue;
                Field field2 = class_.getDeclaredField("activity");
                field2.setAccessible(true);
                Activity activity = (Activity)field2.get(object);
                return activity;
            }
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return null;
        }
        catch (NoSuchFieldException noSuchFieldException) {
            noSuchFieldException.printStackTrace();
            return null;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            noSuchMethodException.printStackTrace();
            return null;
        }
        catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.printStackTrace();
            return null;
        }
        catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        }
        return null;
    }

    public static /* synthetic */ void m(t1.s.e.e.a.k k2) {
        t1.r.k.g.b0.b.b.J0((Context)UCApplication.j(), (boolean)(k2 instanceof c.h), (String)k2.e());
    }

    public void a() {
        j.quitSafely();
    }

    public void b(String string, NotificationData notificationData, JSONObject jSONObject) {
        c3.d.a((Context)this, (String)"DELIVERED", (String)notificationData.l());
        new c3.a((Context)this).a(string, notificationData, jSONObject);
    }

    public void c(String string, String string2, NotificationConstants.NotificationDismissSource notificationDismissSource) {
        t1.r.k.n.r0.b b2;
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.NotificationDismissed;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        t1.r.b.c.c.b((AnalyticsTriggers)analyticsTriggers, (t1.r.b.c.f)f2);
        if (notificationDismissSource == NotificationConstants.NotificationDismissSource.APP) {
            c3.d.a((Context)this, (String)"APP_DISMISSED", (String)string2);
            return;
        }
        c3.d.a((Context)this, (String)"DISMISSED", (String)string2);
        if (string.equals((Object)"responses") && (b2 = t1.r.k.n.r0.b.b).c().getValue() != null) {
            b2.b();
        }
    }

    public void d(String string, String string2, String string3, JSONObject jSONObject, int n2) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.NotificationReceived;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        t1.r.b.c.c.b((AnalyticsTriggers)analyticsTriggers, (t1.r.b.c.f)f2);
        c3.d.a((Context)this, (String)"DELIVERED", (String)string3);
        t2.c.a.c.c().j((Object)new t1.r.k.n.d0.f(UcEvents.REFRESH_VIEW_ONGOING));
        this.p(jSONObject, n2, string, string3);
        this.e.a(string, jSONObject);
        this.o(jSONObject, string3);
    }

    public void e(k k2) {
        t1.r.k.g.b0.b.b.J0((Context)UCApplication.j(), (boolean)(k2 instanceof d.h), (String)k2.e());
    }

    public void f(String string, String string2, String string3) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.NotificationClicked;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.R(string);
        t1.r.b.c.c.b((AnalyticsTriggers)analyticsTriggers, (t1.r.b.c.f)f2);
        c3.d.a((Context)this, (String)"CLICKED", (String)string3);
        this.n(string3);
    }

    public final void k() {
        CleverTapAPI.o1((String)"8W4-98R-484Z", (String)"2bc-40b");
        t1.h.a.a.a.a((Application)this);
        CleverTapAPI.K1((Context)this, (String)"clevertap_notification_channel_id", (CharSequence)this.getString(r.I), (String)"", (int)4, (boolean)true);
    }

    public final void l() {
        t1.r.k.n.q0.u.d.a.b.b((Object)this);
        CartRepository.l.b((Object)this);
        t1.r.k.n.q0.u.c.a.b.b((Object)this);
        f.b.b((Object)this);
        AddressFetcher.g((d)new b());
        this.g = t1.r.k.n.r0.b.b;
        t1.r.b.b.d.b.c.g((Context)this, ConfigUtil.f().n());
    }

    public final void n(String string) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ReceiverReminderClick;
        t1.r.b.c.f f2 = t1.r.b.c.f.a();
        f2.p(e.a());
        f2.m(c.b());
        f2.B(string);
        t1.r.b.c.c.b((AnalyticsTriggers)analyticsTriggers, (t1.r.b.c.f)f2);
    }

    public final void o(JSONObject jSONObject, String string) {
        if (jSONObject.has("trigger_source")) {
            AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.ReceiverReminderLoaded;
            t1.r.b.c.f f2 = t1.r.b.c.f.a();
            f2.p(e.a());
            f2.m(c.b());
            f2.B(string);
            t1.r.b.c.c.b((AnalyticsTriggers)analyticsTriggers, (t1.r.b.c.f)f2);
        }
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    public void onActivityResumed(Activity activity) {
        if (!this.f) {
            Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            OneTimeWorkRequest oneTimeWorkRequest = (OneTimeWorkRequest)((OneTimeWorkRequest.Builder)((OneTimeWorkRequest.Builder)new OneTimeWorkRequest.Builder(ResourceDownloadWorker.class).setConstraints(constraints)).setInitialDelay(2L, TimeUnit.MINUTES)).build();
            WorkManager.getInstance((Context)this).enqueue((WorkRequest)oneTimeWorkRequest);
            this.f = true;
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    /*
     * Exception decompiling
     */
    @Override
    public void onCreate() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl64 : GETSTATIC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void p(JSONObject jSONObject, int n2, String string, String string2) {
        boolean bl;
        if (jSONObject.has("customer_request_id")) {
            try {
                bl = jSONObject.has("is_web_refresh_required") ? jSONObject.getBoolean("is_web_refresh_required") : false;
            }
            catch (JSONException jSONException) {
                t1.r.k.n.o0.c.f((Throwable)jSONException);
                jSONException.printStackTrace();
            }
        }
        return;
        t1.r.k.n.r0.c c2 = new t1.r.k.n.r0.c(jSONObject.getString("customer_request_id"), n2, string, bl, string2);
        this.g.a((l)new a(this, c2));
    }
}

