/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenTemplate
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.util.List
 *  t1.r.k.g.y0.b
 */
package com.urbanclap.urbanclap.core.search_v2;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenTemplate;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import java.util.List;
import t1.r.k.g.y0.b;

public final class CategoriesSearchV2ResponseModel
extends ResponseBaseModel {
    @SerializedName(value="predicted_search")
    private final b e;
    @SerializedName(value="templates")
    private final List<HomeScreenTemplate> f;
    @SerializedName(value="tracking_data")
    private final TrackingData g;

    public final b e() {
        return this.e;
    }

    public final List<HomeScreenTemplate> f() {
        return this.f;
    }

    public final TrackingData g() {
        return this.g;
    }
}

