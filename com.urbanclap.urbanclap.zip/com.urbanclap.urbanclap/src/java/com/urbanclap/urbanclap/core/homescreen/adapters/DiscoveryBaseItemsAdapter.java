/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  androidx.recyclerview.widget.DiffUtil
 *  androidx.recyclerview.widget.DiffUtil$ItemCallback
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.urbanclap.urbanclap.core.homescreen.adapters.DiscoveryBaseItemsAdapter$c
 *  com.urbanclap.urbanclap.core.homescreen.adapters.DiscoveryBaseItemsAdapter$e
 *  com.urbanclap.urbanclap.core.homescreen.adapters.DiscoveryBaseItemsAdapter$g
 *  com.urbanclap.urbanclap.core.homescreen.adapters.DiscoveryBaseItemsAdapter$i
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.BodyDataItem
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.DiscoveryItemsBodyTemplateTypes
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.DiscoveryItemsHeaderTemplateTypes
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.Footer
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.FooterData
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.HeaderData
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBody
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBodyData
 *  com.urbanclap.urbanclap.ucshared.extras.Analytics
 *  com.urbanclap.urbanclap.ucshared.extras.TapAction
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.CallToActionModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  t1.r.k.g.k0.f
 *  t1.r.k.g.k0.s
 *  t1.r.k.g.k0.y.a
 *  t1.r.k.g.k0.z.e.c0
 *  t1.r.k.g.k0.z.e.g
 *  t1.r.k.g.k0.z.e.i
 *  t1.r.k.g.k0.z.e.j
 *  t1.r.k.g.k0.z.e.n0
 *  t1.r.k.g.k0.z.e.p
 *  t1.r.k.g.k0.z.e.p0
 *  t1.r.k.g.k0.z.e.q0
 *  t1.r.k.g.k0.z.e.s
 *  t1.r.k.g.k0.z.e.s0
 *  t1.r.k.g.k0.z.e.u
 *  t1.r.k.g.k0.z.e.v
 *  t1.r.k.g.k0.z.e.w
 *  t1.r.k.g.k0.z.e.x
 *  t1.r.k.g.k0.z.e.y
 *  t1.r.k.g.l0.a
 *  t1.r.k.g.l0.k.b
 *  t1.r.k.g.l0.k.b$a
 *  t1.r.k.g.l0.k.e
 *  t1.r.k.g.l0.k.e$b
 *  t1.r.k.g.l0.k.f
 *  t1.r.k.g.y0.c
 *  t1.r.k.n.b0.l.b
 *  t1.r.k.n.b0.l.d
 */
package com.urbanclap.urbanclap.core.homescreen.adapters;

import android.view.ViewGroup;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.urbanclap.urbanclap.core.homescreen.adapters.DiscoveryBaseItemsAdapter;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.BodyDataItem;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.DiscoveryItemsBodyTemplateTypes;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.DiscoveryItemsHeaderTemplateTypes;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.Footer;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.FooterData;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HeaderData;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBody;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBodyData;
import com.urbanclap.urbanclap.ucshared.extras.Analytics;
import com.urbanclap.urbanclap.ucshared.extras.TapAction;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.CallToActionModel;
import i2.a0.d.l;
import java.util.Objects;
import t1.r.k.g.k0.f;
import t1.r.k.g.k0.s;
import t1.r.k.g.k0.z.e.c0;
import t1.r.k.g.k0.z.e.j;
import t1.r.k.g.k0.z.e.n0;
import t1.r.k.g.k0.z.e.p;
import t1.r.k.g.k0.z.e.p0;
import t1.r.k.g.k0.z.e.q0;
import t1.r.k.g.k0.z.e.s0;
import t1.r.k.g.k0.z.e.u;
import t1.r.k.g.k0.z.e.v;
import t1.r.k.g.k0.z.e.w;
import t1.r.k.g.k0.z.e.x;
import t1.r.k.g.k0.z.e.y;
import t1.r.k.g.l0.a;
import t1.r.k.g.l0.k.b;
import t1.r.k.g.l0.k.e;
import t1.r.k.n.b0.l.d;

/*
 * Exception performing whole class analysis.
 */
public final class DiscoveryBaseItemsAdapter
extends t1.r.k.n.b0.l.a<t1.r.k.g.k0.y.a> {
    public final t1.r.k.n.b0.l.b a;
    public final e.b b;
    public final b.a c;
    public final t1.r.k.g.y0.c d;

    public DiscoveryBaseItemsAdapter(t1.r.k.n.b0.l.b b2, e.b b3, b.a a2, t1.r.k.g.y0.c c2) {
        l.g((Object)b2, (String)"baseItemClickHandler");
        super(new /* Unavailable Anonymous Inner Class!! */);
        this.a = b2;
        this.b = b3;
        this.c = a2;
        this.d = c2;
    }

    public /* synthetic */ DiscoveryBaseItemsAdapter(t1.r.k.n.b0.l.b b2, e.b b3, b.a a2, t1.r.k.g.y0.c c2, int n2, i2.a0.d.g g2) {
        if ((n2 & 2) != 0) {
            b3 = null;
        }
        if ((n2 & 4) != 0) {
            a2 = null;
        }
        if ((n2 & 8) != 0) {
            c2 = null;
        }
        this(b2, b3, a2, c2);
    }

    @Override
    public d<t1.r.k.g.k0.y.a> d(ViewGroup viewGroup, int n2) {
        l.g((Object)viewGroup, (String)"parent");
        return s.a.b(viewGroup, n2, (t1.r.k.n.b0.l.a)this, this.b, this.c, this.d);
    }

    public void f(d<t1.r.k.g.k0.y.a> d2, int n2) {
        l.g(d2, (String)"holder");
        t1.r.k.g.k0.y.a a2 = (t1.r.k.g.k0.y.a)this.getItem(n2);
        l.f((Object)a2, (String)"homeScreenItemBaseModel");
        d2.F((Object)a2, this.a, a2.d(), 0);
    }

    public void g(d<t1.r.k.g.k0.y.a> d2) {
        l.g(d2, (String)"holder");
        if (d2 instanceof i) {
            (d2).K();
        } else if (d2 instanceof e) {
            (d2).K();
        } else if (d2 instanceof t1.r.k.g.l0.k.f) {
            ((t1.r.k.g.l0.k.f)d2).M();
        } else if (d2 instanceof c) {
            (d2).K();
        }
        t1.r.k.g.k0.y.a a2 = (t1.r.k.g.k0.y.a)this.getItem(d2.getAdapterPosition());
        t1.r.k.n.b0.l.b b2 = this.a;
        Objects.requireNonNull((Object)b2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.DiscoveryItemsClickHandler");
        (f)b2;
        String string = a2.c();
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.IMAGE.name()) || l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.MARKETING.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenImageItemBodyData");
            v v2 = (v)a2;
            f f2 = (f)this.a;
            TrackingData trackingData = v2.g().l0();
            TapAction tapAction = v2.g().c0();
            TrackingData trackingData2 = null;
            if (tapAction != null) {
                trackingData2 = tapAction.b();
            }
            f2.Z4(trackingData, trackingData2, a2.d(), v2.h(), v2.g().b());
            return;
        }
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.RENEWED_MARKETING_STRIP.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenStripItemBodyData");
            c0 c02 = (c0)a2;
            f f3 = (f)this.a;
            TrackingData trackingData = c02.g().l0();
            TapAction tapAction = c02.g().c0();
            TrackingData trackingData3 = null;
            if (tapAction != null) {
                trackingData3 = tapAction.b();
            }
            f3.Z4(trackingData, trackingData3, a2.d(), c02.h(), c02.g().b());
            return;
        }
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.GRID.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenGridItemFlatBodyData");
            u u2 = (u)a2;
            f f4 = (f)this.a;
            TrackingData trackingData = u2.g().l0();
            TapAction tapAction = u2.g().c0();
            TrackingData trackingData4 = null;
            if (tapAction != null) {
                trackingData4 = tapAction.b();
            }
            f4.Z4(trackingData, trackingData4, a2.d(), u2.h(), u2.g().b());
            return;
        }
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.CATEGORY_COLLECTION.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenCategoryCollectionFlatItemBodyData");
            t1.r.k.g.k0.z.e.s s2 = (t1.r.k.g.k0.z.e.s)a2;
            f f5 = (f)this.a;
            TrackingData trackingData = s2.g().l0();
            TapAction tapAction = s2.g().c0();
            TrackingData trackingData5 = null;
            if (tapAction != null) {
                trackingData5 = tapAction.b();
            }
            f5.Z4(trackingData, trackingData5, a2.d(), s2.h(), s2.g().b());
            return;
        }
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes = DiscoveryItemsBodyTemplateTypes.OLD_SUBSCRIPTION;
        if (l.c((Object)string, (Object)discoveryItemsBodyTemplateTypes.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenOldSubscriptionItemBodyData");
            y y2 = (y)a2;
            ((f)this.a).p7(y2.i(), y2.g());
            return;
        }
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.SUBSCRIPTION_TILES.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.SubscriptionTilesTemplateData");
            p0 p02 = (p0)a2;
            ((f)this.a).p7(p02.h(), p02.g().b());
            return;
        }
        if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.STICKY_VIEW_CAROUSAL.name())) {
            Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.StickyViewCarousalData");
            n0 n02 = (n0)a2;
            HomeScreenItemBody homeScreenItemBody = n02.g().s();
            DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes2 = homeScreenItemBody != null ? homeScreenItemBody.b() : null;
            if (discoveryItemsBodyTemplateTypes2 == discoveryItemsBodyTemplateTypes) {
                f f6 = (f)this.a;
                HomeScreenItemBody homeScreenItemBody2 = n02.g().s();
                String string2 = null;
                if (homeScreenItemBody2 != null) {
                    HomeScreenItemBodyData homeScreenItemBodyData = homeScreenItemBody2.a();
                    string2 = null;
                    if (homeScreenItemBodyData != null) {
                        string2 = homeScreenItemBodyData.i();
                    }
                }
                f6.p7(string2, n02.g().a());
                return;
            }
        } else {
            if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.HEADER_STORIES.name())) {
                ((a)d2).r();
                return;
            }
            if (l.c((Object)string, (Object)DiscoveryItemsHeaderTemplateTypes.TITLE_SUBTITLE_CTA.name())) {
                Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HeaderTitleSubtitleCtaData");
                p p2 = (p)a2;
                CallToActionModel callToActionModel = p2.g().d();
                TrackingData trackingData = null;
                if (callToActionModel != null) {
                    TapAction tapAction = callToActionModel.h();
                    trackingData = null;
                    if (tapAction != null) {
                        trackingData = tapAction.b();
                    }
                }
                ((f)this.a).Y9(trackingData, a2.d(), a2.a(), p2.g().a());
                return;
            }
            if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.MEDIA_CAROUSEL.name())) {
                if (a2 instanceof t1.r.k.g.k0.z.e.i) {
                    f f7 = (f)this.a;
                    t1.r.k.g.k0.z.e.i i2 = (t1.r.k.g.k0.z.e.i)a2;
                    TrackingData trackingData = i2.g().l0();
                    TapAction tapAction = i2.g().c0();
                    TrackingData trackingData6 = null;
                    if (tapAction != null) {
                        trackingData6 = tapAction.b();
                    }
                    f7.Z4(trackingData, trackingData6, a2.d(), a2.a(), i2.g().b());
                    return;
                }
            } else {
                if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.LIST_DETAILS.name())) {
                    Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.CategoryLandingPageListDetailsData");
                    t1.r.k.g.k0.z.e.g g2 = (t1.r.k.g.k0.z.e.g)a2;
                    f f8 = (f)this.a;
                    TrackingData trackingData = g2.g().l0();
                    TapAction tapAction = g2.g().c0();
                    TrackingData trackingData7 = null;
                    if (tapAction != null) {
                        trackingData7 = tapAction.b();
                    }
                    f8.Z4(trackingData, trackingData7, a2.d(), a2.a(), g2.g().b());
                    return;
                }
                if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.INFO_STRIP.name())) {
                    Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenInfoStripFlatItemBodyData");
                    w w2 = (w)a2;
                    f f9 = (f)this.a;
                    TrackingData trackingData = w2.g().l0();
                    TapAction tapAction = w2.g().c0();
                    TrackingData trackingData8 = null;
                    if (tapAction != null) {
                        trackingData8 = tapAction.b();
                    }
                    f9.Z4(trackingData, trackingData8, a2.d(), a2.a(), w2.g().b());
                    return;
                }
                if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.OFFER.name())) {
                    Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenOfferFlatItemBodyData");
                    x x2 = (x)a2;
                    f f10 = (f)this.a;
                    TrackingData trackingData = x2.g().l0();
                    TapAction tapAction = x2.g().c0();
                    TrackingData trackingData9 = null;
                    if (tapAction != null) {
                        trackingData9 = tapAction.b();
                    }
                    f10.Z4(trackingData, trackingData9, a2.d(), a2.a(), x2.g().b());
                    return;
                }
                if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.LIGHT_SERVICE_COLLECTION.name())) {
                    Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.UcEssentialsLightServiceCollectionData");
                    q0 q02 = (q0)a2;
                    f f11 = (f)this.a;
                    TrackingData trackingData = q02.h().l0();
                    TapAction tapAction = q02.h().c0();
                    TrackingData trackingData10 = tapAction != null ? tapAction.b() : null;
                    f11.Z4(trackingData, trackingData10, a2.d(), a2.a(), q02.h().b());
                    if (q02.j() != null) {
                        f f12 = (f)this.a;
                        TrackingData trackingData11 = q02.j().l0();
                        TapAction tapAction2 = q02.j().c0();
                        TrackingData trackingData12 = null;
                        if (tapAction2 != null) {
                            trackingData12 = tapAction2.b();
                        }
                        f12.Z4(trackingData11, trackingData12, a2.d(), a2.a(), q02.j().b());
                        return;
                    }
                } else {
                    if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.SERVICE_LIST.name())) {
                        Objects.requireNonNull((Object)a2, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.UcEssentialsServiceListItemData");
                        s0 s02 = (s0)a2;
                        f f13 = (f)this.a;
                        TrackingData trackingData = s02.g().l0();
                        TapAction tapAction = s02.g().c0();
                        TrackingData trackingData13 = null;
                        if (tapAction != null) {
                            trackingData13 = tapAction.b();
                        }
                        f13.Z4(trackingData, trackingData13, a2.d(), s02.h(), s02.g().b());
                        return;
                    }
                    if (l.c((Object)string, (Object)DiscoveryItemsBodyTemplateTypes.REVIEWS.name())) {
                        if (a2 instanceof j) {
                            f f14 = (f)this.a;
                            j j2 = (j)a2;
                            TrackingData trackingData = j2.g().l0();
                            TapAction tapAction = j2.g().c0();
                            TrackingData trackingData14 = null;
                            if (tapAction != null) {
                                trackingData14 = tapAction.b();
                            }
                            f14.Z4(trackingData, trackingData14, a2.d(), j2.h(), j2.g().b());
                            return;
                        }
                    } else if (a2 instanceof Footer) {
                        Footer footer = (Footer)a2;
                        FooterData footerData = footer.g();
                        TrackingData trackingData = footerData != null ? footerData.f() : null;
                        f f15 = (f)this.a;
                        int n2 = a2.d();
                        int n3 = a2.a();
                        FooterData footerData2 = footer.g();
                        Analytics analytics = null;
                        if (footerData2 != null) {
                            analytics = footerData2.a();
                        }
                        f15.T3(trackingData, n2, n3, analytics);
                    }
                }
            }
        }
    }

    public int getItemViewType(int n2) {
        s s2 = s.a;
        Object object = this.getItem(n2);
        l.f((Object)object, (String)"getItem(position)");
        return s2.a((t1.r.k.g.k0.y.a)object);
    }

    public void h(d<t1.r.k.g.k0.y.a> d2) {
        l.g(d2, (String)"holder");
        if (d2 instanceof i) {
            (d2).J();
            return;
        }
        if (d2 instanceof e) {
            (d2).J();
            return;
        }
        if (d2 instanceof t1.r.k.g.l0.k.f) {
            ((t1.r.k.g.l0.k.f)d2).L();
            return;
        }
        if (d2 instanceof c) {
            (d2).J();
        }
    }
}

