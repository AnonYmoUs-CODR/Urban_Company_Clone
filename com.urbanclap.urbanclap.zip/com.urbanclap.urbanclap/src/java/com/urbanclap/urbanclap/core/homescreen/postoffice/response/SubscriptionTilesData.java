/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.BodyItemDecoration
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.BodyItemDecoration;
import i2.a0.d.l;

public final class SubscriptionTilesData
implements Parcelable {
    public static final Parcelable.Creator<SubscriptionTilesData> CREATOR = new a();
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="subtitle")
    private final String b;
    @SerializedName(value="bg_color")
    private final String c;
    public BodyItemDecoration d;

    public SubscriptionTilesData(String string, String string2, String string3, BodyItemDecoration bodyItemDecoration) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = bodyItemDecoration;
    }

    public final String a() {
        return this.c;
    }

    public final BodyItemDecoration b() {
        return this.d;
    }

    public final String c() {
        return this.b;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final void e(BodyItemDecoration bodyItemDecoration) {
        this.d = bodyItemDecoration;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeParcelable((Parcelable)this.d, n);
    }

    public static final class a
    implements Parcelable.Creator<SubscriptionTilesData> {
        public final SubscriptionTilesData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new SubscriptionTilesData(parcel.readString(), parcel.readString(), parcel.readString(), (BodyItemDecoration)parcel.readParcelable(SubscriptionTilesData.class.getClassLoader()));
        }

        public final SubscriptionTilesData[] b(int n) {
            return new SubscriptionTilesData[n];
        }
    }

}

