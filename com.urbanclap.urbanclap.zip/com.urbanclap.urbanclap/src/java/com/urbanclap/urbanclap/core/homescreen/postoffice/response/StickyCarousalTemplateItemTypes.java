/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

public final class StickyCarousalTemplateItemTypes
extends Enum<StickyCarousalTemplateItemTypes> {
    private static final /* synthetic */ StickyCarousalTemplateItemTypes[] $VALUES;
    public static final /* enum */ StickyCarousalTemplateItemTypes SUBSCRIPTION_STICKY_VIEW_ITEM;

    public static {
        StickyCarousalTemplateItemTypes stickyCarousalTemplateItemTypes;
        StickyCarousalTemplateItemTypes[] arrstickyCarousalTemplateItemTypes = new StickyCarousalTemplateItemTypes[1];
        SUBSCRIPTION_STICKY_VIEW_ITEM = stickyCarousalTemplateItemTypes = new StickyCarousalTemplateItemTypes();
        arrstickyCarousalTemplateItemTypes[0] = stickyCarousalTemplateItemTypes;
        $VALUES = arrstickyCarousalTemplateItemTypes;
    }

    public static StickyCarousalTemplateItemTypes valueOf(String string) {
        return (StickyCarousalTemplateItemTypes)Enum.valueOf(StickyCarousalTemplateItemTypes.class, (String)string);
    }

    public static StickyCarousalTemplateItemTypes[] values() {
        return (StickyCarousalTemplateItemTypes[])$VALUES.clone();
    }
}

