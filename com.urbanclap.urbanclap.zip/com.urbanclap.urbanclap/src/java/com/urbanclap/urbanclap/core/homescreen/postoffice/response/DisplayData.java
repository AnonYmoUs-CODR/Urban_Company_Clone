/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.ucshared.extras.Analytics
 *  com.urbanclap.urbanclap.ucshared.extras.TapAction
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.Icon
 *  com.urbanclap.urbanclap.ucshared.models.PriceModel
 *  com.urbanclap.urbanclap.ucshared.models.ProgressInfoModel
 *  com.urbanclap.urbanclap.ucshared.models.TagModel
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucshared.extras.Analytics;
import com.urbanclap.urbanclap.ucshared.extras.TapAction;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.Icon;
import com.urbanclap.urbanclap.ucshared.models.PriceModel;
import com.urbanclap.urbanclap.ucshared.models.ProgressInfoModel;
import com.urbanclap.urbanclap.ucshared.models.TagModel;
import i2.a0.d.l;

public final class DisplayData
implements Parcelable {
    public static final Parcelable.Creator<DisplayData> CREATOR = new a();
    @SerializedName(alternate={"image_url"}, value="image")
    private final PictureObject a;
    @SerializedName(value="icon")
    private final PictureObject b;
    @SerializedName(value="icon_font")
    private final Icon c;
    @SerializedName(value="text")
    private final String d;
    @SerializedName(value="subtext")
    private final String e;
    @SerializedName(value="amount_text")
    private final String f;
    @SerializedName(value="title")
    private final String g;
    @SerializedName(value="amount")
    private final PriceModel h;
    @SerializedName(value="subtitle")
    private final String i;
    @SerializedName(value="cta_title")
    private final String j;
    @SerializedName(value="tap_action")
    private final TapAction k;
    @SerializedName(value="tracking_data")
    private final TrackingData s;
    @SerializedName(value="tag")
    private final TagModel t;
    @SerializedName(value="progress_info")
    private final ProgressInfoModel u;
    @SerializedName(value="analytics")
    private final Analytics v;
    @SerializedName(value="bg_color")
    private final String w;

    public DisplayData(PictureObject pictureObject, PictureObject pictureObject2, Icon icon, String string, String string2, String string3, String string4, PriceModel priceModel, String string5, String string6, TapAction tapAction, TrackingData trackingData, TagModel tagModel, ProgressInfoModel progressInfoModel, Analytics analytics, String string7) {
        this.a = pictureObject;
        this.b = pictureObject2;
        this.c = icon;
        this.d = string;
        this.e = string2;
        this.f = string3;
        this.g = string4;
        this.h = priceModel;
        this.i = string5;
        this.j = string6;
        this.k = tapAction;
        this.s = trackingData;
        this.t = tagModel;
        this.u = progressInfoModel;
        this.v = analytics;
        this.w = string7;
    }

    public final PriceModel a() {
        return this.h;
    }

    public final String b() {
        return this.f;
    }

    public final Analytics c() {
        return this.v;
    }

    public final String d() {
        return this.w;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.j;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DisplayData)) break block3;
                DisplayData displayData = (DisplayData)object;
                if (l.c((Object)this.a, (Object)displayData.a) && l.c((Object)this.b, (Object)displayData.b) && l.c((Object)this.c, (Object)displayData.c) && l.c((Object)this.d, (Object)displayData.d) && l.c((Object)this.e, (Object)displayData.e) && l.c((Object)this.f, (Object)displayData.f) && l.c((Object)this.g, (Object)displayData.g) && l.c((Object)this.h, (Object)displayData.h) && l.c((Object)this.i, (Object)displayData.i) && l.c((Object)this.j, (Object)displayData.j) && l.c((Object)this.k, (Object)displayData.k) && l.c((Object)this.s, (Object)displayData.s) && l.c((Object)this.t, (Object)displayData.t) && l.c((Object)this.u, (Object)displayData.u) && l.c((Object)this.v, (Object)displayData.v) && l.c((Object)this.w, (Object)displayData.w)) break block2;
            }
            return false;
        }
        return true;
    }

    public final PictureObject f() {
        return this.b;
    }

    public final Icon g() {
        return this.c;
    }

    public final PictureObject h() {
        return this.a;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        PictureObject pictureObject2 = this.b;
        int n3 = pictureObject2 != null ? pictureObject2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Icon icon = this.c;
        int n5 = icon != null ? icon.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string = this.d;
        int n7 = string != null ? string.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string2 = this.e;
        int n9 = string2 != null ? string2.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        String string3 = this.f;
        int n11 = string3 != null ? string3.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string4 = this.g;
        int n13 = string4 != null ? string4.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        PriceModel priceModel = this.h;
        int n15 = priceModel != null ? priceModel.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        String string5 = this.i;
        int n17 = string5 != null ? string5.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string6 = this.j;
        int n19 = string6 != null ? string6.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        TapAction tapAction = this.k;
        int n21 = tapAction != null ? tapAction.hashCode() : 0;
        int n22 = 31 * (n20 + n21);
        TrackingData trackingData = this.s;
        int n23 = trackingData != null ? trackingData.hashCode() : 0;
        int n24 = 31 * (n22 + n23);
        TagModel tagModel = this.t;
        int n25 = tagModel != null ? tagModel.hashCode() : 0;
        int n26 = 31 * (n24 + n25);
        ProgressInfoModel progressInfoModel = this.u;
        int n27 = progressInfoModel != null ? progressInfoModel.hashCode() : 0;
        int n28 = 31 * (n26 + n27);
        Analytics analytics = this.v;
        int n29 = analytics != null ? analytics.hashCode() : 0;
        int n30 = 31 * (n28 + n29);
        String string7 = this.w;
        int n31 = 0;
        if (string7 != null) {
            n31 = string7.hashCode();
        }
        return n30 + n31;
    }

    public final ProgressInfoModel i() {
        return this.u;
    }

    public final String j() {
        return this.i;
    }

    public final String k() {
        return this.e;
    }

    public final TagModel l() {
        return this.t;
    }

    public final TapAction m() {
        return this.k;
    }

    public final String n() {
        return this.d;
    }

    public final String o() {
        return this.g;
    }

    public final TrackingData p() {
        return this.s;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DisplayData(image=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", icon=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", iconFont=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", text=");
        stringBuilder.append(this.d);
        stringBuilder.append(", subtext=");
        stringBuilder.append(this.e);
        stringBuilder.append(", amountText=");
        stringBuilder.append(this.f);
        stringBuilder.append(", title=");
        stringBuilder.append(this.g);
        stringBuilder.append(", amount=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", subsTitle=");
        stringBuilder.append(this.i);
        stringBuilder.append(", ctaTitle=");
        stringBuilder.append(this.j);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(", trackingData=");
        stringBuilder.append((Object)this.s);
        stringBuilder.append(", tag=");
        stringBuilder.append((Object)this.t);
        stringBuilder.append(", progressInfo=");
        stringBuilder.append((Object)this.u);
        stringBuilder.append(", analytics=");
        stringBuilder.append((Object)this.v);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.w);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeString(this.i);
        parcel.writeString(this.j);
        parcel.writeParcelable((Parcelable)this.k, n);
        parcel.writeParcelable((Parcelable)this.s, n);
        parcel.writeParcelable((Parcelable)this.t, n);
        parcel.writeParcelable((Parcelable)this.u, n);
        parcel.writeParcelable((Parcelable)this.v, n);
        parcel.writeString(this.w);
    }

    public static final class a
    implements Parcelable.Creator<DisplayData> {
        public final DisplayData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            DisplayData displayData = new DisplayData((PictureObject)parcel.readParcelable(DisplayData.class.getClassLoader()), (PictureObject)parcel.readParcelable(DisplayData.class.getClassLoader()), (Icon)parcel.readParcelable(DisplayData.class.getClassLoader()), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), (PriceModel)parcel.readParcelable(DisplayData.class.getClassLoader()), parcel.readString(), parcel.readString(), (TapAction)parcel.readParcelable(DisplayData.class.getClassLoader()), (TrackingData)parcel.readParcelable(DisplayData.class.getClassLoader()), (TagModel)parcel.readParcelable(DisplayData.class.getClassLoader()), (ProgressInfoModel)parcel.readParcelable(DisplayData.class.getClassLoader()), (Analytics)parcel.readParcelable(DisplayData.class.getClassLoader()), parcel.readString());
            return displayData;
        }

        public final DisplayData[] b(int n) {
            return new DisplayData[n];
        }
    }

}

