/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

public final class HomeScreenSpotLightTemplateTypes
extends Enum<HomeScreenSpotLightTemplateTypes> {
    private static final /* synthetic */ HomeScreenSpotLightTemplateTypes[] $VALUES;
    public static final /* enum */ HomeScreenSpotLightTemplateTypes SPOTLIGHT_IMAGE;
    public static final /* enum */ HomeScreenSpotLightTemplateTypes SPOTLIGHT_IMAGE_LIST;

    public static {
        HomeScreenSpotLightTemplateTypes homeScreenSpotLightTemplateTypes;
        HomeScreenSpotLightTemplateTypes homeScreenSpotLightTemplateTypes2;
        HomeScreenSpotLightTemplateTypes[] arrhomeScreenSpotLightTemplateTypes = new HomeScreenSpotLightTemplateTypes[2];
        SPOTLIGHT_IMAGE_LIST = homeScreenSpotLightTemplateTypes2 = new HomeScreenSpotLightTemplateTypes();
        arrhomeScreenSpotLightTemplateTypes[0] = homeScreenSpotLightTemplateTypes2;
        SPOTLIGHT_IMAGE = homeScreenSpotLightTemplateTypes = new HomeScreenSpotLightTemplateTypes();
        arrhomeScreenSpotLightTemplateTypes[1] = homeScreenSpotLightTemplateTypes;
        $VALUES = arrhomeScreenSpotLightTemplateTypes;
    }

    public static HomeScreenSpotLightTemplateTypes valueOf(String string) {
        return (HomeScreenSpotLightTemplateTypes)Enum.valueOf(HomeScreenSpotLightTemplateTypes.class, (String)string);
    }

    public static HomeScreenSpotLightTemplateTypes[] values() {
        return (HomeScreenSpotLightTemplateTypes[])$VALUES.clone();
    }
}

