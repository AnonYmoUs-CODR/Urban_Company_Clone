/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class DiscoveryItemsFooterTemplateTypes
extends Enum<DiscoveryItemsFooterTemplateTypes> {
    private static final /* synthetic */ DiscoveryItemsFooterTemplateTypes[] $VALUES;
    @SerializedName(value="view_all")
    public static final /* enum */ DiscoveryItemsFooterTemplateTypes VIEW_ALL;

    public static {
        DiscoveryItemsFooterTemplateTypes discoveryItemsFooterTemplateTypes;
        DiscoveryItemsFooterTemplateTypes[] arrdiscoveryItemsFooterTemplateTypes = new DiscoveryItemsFooterTemplateTypes[1];
        VIEW_ALL = discoveryItemsFooterTemplateTypes = new DiscoveryItemsFooterTemplateTypes();
        arrdiscoveryItemsFooterTemplateTypes[0] = discoveryItemsFooterTemplateTypes;
        $VALUES = arrdiscoveryItemsFooterTemplateTypes;
    }

    public static DiscoveryItemsFooterTemplateTypes valueOf(String string) {
        return (DiscoveryItemsFooterTemplateTypes)Enum.valueOf(DiscoveryItemsFooterTemplateTypes.class, (String)string);
    }

    public static DiscoveryItemsFooterTemplateTypes[] values() {
        return (DiscoveryItemsFooterTemplateTypes[])$VALUES.clone();
    }
}

