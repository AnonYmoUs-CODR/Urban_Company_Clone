/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

public final class OldSubscriptionItemType
extends Enum<OldSubscriptionItemType> {
    private static final /* synthetic */ OldSubscriptionItemType[] $VALUES;
    public static final /* enum */ OldSubscriptionItemType CTA;
    public static final /* enum */ OldSubscriptionItemType DESC;
    public static final /* enum */ OldSubscriptionItemType IMAGE;
    public static final /* enum */ OldSubscriptionItemType PLAN_DETAILS;
    public static final /* enum */ OldSubscriptionItemType TITLE;
    private final String key;

    public static {
        OldSubscriptionItemType oldSubscriptionItemType;
        OldSubscriptionItemType oldSubscriptionItemType2;
        OldSubscriptionItemType oldSubscriptionItemType3;
        OldSubscriptionItemType oldSubscriptionItemType4;
        OldSubscriptionItemType oldSubscriptionItemType5;
        OldSubscriptionItemType[] arroldSubscriptionItemType = new OldSubscriptionItemType[5];
        IMAGE = oldSubscriptionItemType5 = new OldSubscriptionItemType("IMAGE");
        arroldSubscriptionItemType[0] = oldSubscriptionItemType5;
        DESC = oldSubscriptionItemType3 = new OldSubscriptionItemType("DESC");
        arroldSubscriptionItemType[1] = oldSubscriptionItemType3;
        TITLE = oldSubscriptionItemType = new OldSubscriptionItemType("TITLE");
        arroldSubscriptionItemType[2] = oldSubscriptionItemType;
        CTA = oldSubscriptionItemType2 = new OldSubscriptionItemType("CTA");
        arroldSubscriptionItemType[3] = oldSubscriptionItemType2;
        PLAN_DETAILS = oldSubscriptionItemType4 = new OldSubscriptionItemType("PLAN_DETAILS");
        arroldSubscriptionItemType[4] = oldSubscriptionItemType4;
        $VALUES = arroldSubscriptionItemType;
    }

    private OldSubscriptionItemType(String string2) {
        this.key = string2;
    }

    public static OldSubscriptionItemType valueOf(String string) {
        return (OldSubscriptionItemType)Enum.valueOf(OldSubscriptionItemType.class, (String)string);
    }

    public static OldSubscriptionItemType[] values() {
        return (OldSubscriptionItemType[])$VALUES.clone();
    }

    public final String getKey() {
        return this.key;
    }
}

