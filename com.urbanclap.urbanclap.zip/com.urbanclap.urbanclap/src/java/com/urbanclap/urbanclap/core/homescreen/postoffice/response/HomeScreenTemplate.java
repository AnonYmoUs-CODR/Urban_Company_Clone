/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.Footer
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.Footer;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.Header;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBody;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.SeparatorStyle;
import i2.a0.d.g;
import i2.a0.d.l;
import java.io.Serializable;

public final class HomeScreenTemplate
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="id")
    private final String a;
    @SerializedName(value="header")
    private final Header b;
    @SerializedName(value="body")
    private final HomeScreenItemBody c;
    @SerializedName(value="footer")
    private final Footer d;
    @SerializedName(value="show_separator_below")
    private final Boolean e;
    @SerializedName(value="separator_style")
    private final SeparatorStyle f;

    public HomeScreenTemplate(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        Header header = (Header)parcel.readParcelable(Header.class.getClassLoader());
        HomeScreenItemBody homeScreenItemBody = (HomeScreenItemBody)parcel.readParcelable(HomeScreenItemBody.class.getClassLoader());
        Footer footer = (Footer)parcel.readParcelable(Footer.class.getClassLoader());
        Object object = parcel.readValue(Boolean.TYPE.getClassLoader());
        if (!(object instanceof Boolean)) {
            object = null;
        }
        this(string, header, homeScreenItemBody, footer, (Boolean)object, (SeparatorStyle)parcel.readSerializable());
    }

    public HomeScreenTemplate(String string, Header header, HomeScreenItemBody homeScreenItemBody, Footer footer, Boolean bl, SeparatorStyle separatorStyle) {
        this.a = string;
        this.b = header;
        this.c = homeScreenItemBody;
        this.d = footer;
        this.e = bl;
        this.f = separatorStyle;
    }

    public final Footer a() {
        return this.d;
    }

    public final Header b() {
        return this.b;
    }

    public final HomeScreenItemBody c() {
        return this.c;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final SeparatorStyle e() {
        return this.f;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HomeScreenTemplate)) break block3;
                HomeScreenTemplate homeScreenTemplate = (HomeScreenTemplate)object;
                if (l.c((Object)this.a, (Object)homeScreenTemplate.a) && l.c((Object)this.b, (Object)homeScreenTemplate.b) && l.c((Object)this.c, (Object)homeScreenTemplate.c) && l.c((Object)this.d, (Object)homeScreenTemplate.d) && l.c((Object)this.e, (Object)homeScreenTemplate.e) && l.c((Object)((Object)this.f), (Object)((Object)homeScreenTemplate.f))) break block2;
            }
            return false;
        }
        return true;
    }

    public final Boolean f() {
        return this.e;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        Header header = this.b;
        int n3 = header != null ? header.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        HomeScreenItemBody homeScreenItemBody = this.c;
        int n5 = homeScreenItemBody != null ? homeScreenItemBody.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        Footer footer = this.d;
        int n7 = footer != null ? footer.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        Boolean bl = this.e;
        int n9 = bl != null ? bl.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        SeparatorStyle separatorStyle = this.f;
        int n11 = 0;
        if (separatorStyle != null) {
            n11 = separatorStyle.hashCode();
        }
        return n10 + n11;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HomeScreenTemplate(id=");
        stringBuilder.append(this.a);
        stringBuilder.append(", header=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", homeScreenItemBody=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", footer=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", showSeparatorBelow=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", separatorStyle=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeValue((Object)this.e);
        parcel.writeSerializable((Serializable)this.f);
    }

    public static final class a
    implements Parcelable.Creator<HomeScreenTemplate> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public HomeScreenTemplate a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new HomeScreenTemplate(parcel);
        }

        public HomeScreenTemplate[] b(int n) {
            return new HomeScreenTemplate[n];
        }
    }

}

