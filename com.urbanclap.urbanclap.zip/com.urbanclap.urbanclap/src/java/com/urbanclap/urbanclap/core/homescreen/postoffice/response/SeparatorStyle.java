/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class SeparatorStyle
extends Enum<SeparatorStyle> {
    private static final /* synthetic */ SeparatorStyle[] $VALUES;
    @SerializedName(value="large")
    public static final /* enum */ SeparatorStyle LARGE;
    @SerializedName(value="medium")
    public static final /* enum */ SeparatorStyle MEDIUM;
    @SerializedName(value="small")
    public static final /* enum */ SeparatorStyle SMALL;

    public static {
        SeparatorStyle separatorStyle;
        SeparatorStyle separatorStyle2;
        SeparatorStyle separatorStyle3;
        SeparatorStyle[] arrseparatorStyle = new SeparatorStyle[3];
        SMALL = separatorStyle = new SeparatorStyle();
        arrseparatorStyle[0] = separatorStyle;
        MEDIUM = separatorStyle3 = new SeparatorStyle();
        arrseparatorStyle[1] = separatorStyle3;
        LARGE = separatorStyle2 = new SeparatorStyle();
        arrseparatorStyle[2] = separatorStyle2;
        $VALUES = arrseparatorStyle;
    }

    public static SeparatorStyle valueOf(String string) {
        return (SeparatorStyle)Enum.valueOf(SeparatorStyle.class, (String)string);
    }

    public static SeparatorStyle[] values() {
        return (SeparatorStyle[])$VALUES.clone();
    }
}

