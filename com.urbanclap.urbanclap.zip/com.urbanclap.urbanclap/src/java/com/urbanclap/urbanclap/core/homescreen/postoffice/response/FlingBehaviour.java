/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class FlingBehaviour
extends Enum<FlingBehaviour> {
    private static final /* synthetic */ FlingBehaviour[] $VALUES;
    @SerializedName(value="free_flow")
    public static final /* enum */ FlingBehaviour FREE_FLOW;
    @SerializedName(value="snap")
    public static final /* enum */ FlingBehaviour SNAP;

    public static {
        FlingBehaviour flingBehaviour;
        FlingBehaviour flingBehaviour2;
        FlingBehaviour[] arrflingBehaviour = new FlingBehaviour[2];
        SNAP = flingBehaviour = new FlingBehaviour();
        arrflingBehaviour[0] = flingBehaviour;
        FREE_FLOW = flingBehaviour2 = new FlingBehaviour();
        arrflingBehaviour[1] = flingBehaviour2;
        $VALUES = arrflingBehaviour;
    }

    public static FlingBehaviour valueOf(String string) {
        return (FlingBehaviour)Enum.valueOf(FlingBehaviour.class, (String)string);
    }

    public static FlingBehaviour[] values() {
        return (FlingBehaviour[])$VALUES.clone();
    }
}

