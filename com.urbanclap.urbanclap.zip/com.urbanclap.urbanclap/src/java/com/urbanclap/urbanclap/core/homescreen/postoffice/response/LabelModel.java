/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class LabelModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="background_color")
    private final String b;

    public LabelModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        this(string, parcel.readString());
    }

    public LabelModel(String string, String string2) {
        l.g((Object)string, (String)"title");
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof LabelModel)) break block3;
                LabelModel labelModel = (LabelModel)object;
                if (l.c((Object)this.a, (Object)labelModel.a) && l.c((Object)this.b, (Object)labelModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = 0;
        if (string2 != null) {
            n3 = string2.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LabelModel(title=");
        stringBuilder.append(this.a);
        stringBuilder.append(", backgroundColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<LabelModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public LabelModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new LabelModel(parcel);
        }

        public LabelModel[] b(int n) {
            return new LabelModel[n];
        }
    }

}

