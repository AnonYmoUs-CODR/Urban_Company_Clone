/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.warranty.TermsAndConditionModel
 *  com.urbanclap.urbanclap.ucshared.models.warranty.WarrantyCta
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  t1.r.k.g.d1.d
 *  t1.r.k.g.d1.e
 */
package com.urbanclap.urbanclap.core.ucwarranty;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.warranty.TermsAndConditionModel;
import com.urbanclap.urbanclap.ucshared.models.warranty.WarrantyCta;
import i2.a0.d.l;
import java.util.ArrayList;
import t1.r.k.g.d1.d;
import t1.r.k.g.d1.e;

@SuppressLint(value={"ParcelCreator"})
public final class WarrantyResponseViewModel
extends ResponseBaseModel {
    @SerializedName(value="header")
    private final e e;
    @SerializedName(value="feature")
    private final ArrayList<d> f;
    @SerializedName(value="cta")
    private final WarrantyCta g;
    @SerializedName(value="terms_condition")
    private final TermsAndConditionModel h;

    public final ArrayList<d> e() {
        return this.f;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof WarrantyResponseViewModel)) break block3;
                WarrantyResponseViewModel warrantyResponseViewModel = (WarrantyResponseViewModel)((Object)object);
                if (l.c((Object)this.e, (Object)warrantyResponseViewModel.e) && l.c(this.f, warrantyResponseViewModel.f) && l.c((Object)this.g, (Object)warrantyResponseViewModel.g) && l.c((Object)this.h, (Object)warrantyResponseViewModel.h)) break block2;
            }
            return false;
        }
        return true;
    }

    public final e f() {
        return this.e;
    }

    public final TermsAndConditionModel g() {
        return this.h;
    }

    public final WarrantyCta h() {
        return this.g;
    }

    public int hashCode() {
        e e2 = this.e;
        int n2 = e2 != null ? e2.hashCode() : 0;
        int n3 = n2 * 31;
        ArrayList<d> arrayList = this.f;
        int n4 = arrayList != null ? arrayList.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        WarrantyCta warrantyCta = this.g;
        int n6 = warrantyCta != null ? warrantyCta.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        TermsAndConditionModel termsAndConditionModel = this.h;
        int n8 = 0;
        if (termsAndConditionModel != null) {
            n8 = termsAndConditionModel.hashCode();
        }
        return n7 + n8;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WarrantyResponseViewModel(header=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", feature=");
        stringBuilder.append(this.f);
        stringBuilder.append(", warrantyCta=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", tncModel=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

