/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.extras.TapAction
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.RequestData;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.RequestType;
import com.urbanclap.urbanclap.ucshared.extras.TapAction;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

public final class RequestModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="type")
    private final RequestType a;
    @SerializedName(value="data")
    private final RequestData b;
    @SerializedName(value="tap_action")
    private final TapAction c;

    public RequestModel(Parcel parcel) {
        RequestType requestType;
        l.g((Object)parcel, (String)"parcel");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (object != null) {
            RequestType[] arrrequestType = RequestType.values();
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
            requestType = arrrequestType[(Integer)object];
        } else {
            requestType = null;
        }
        this(requestType, (RequestData)parcel.readParcelable(RequestData.class.getClassLoader()), (TapAction)parcel.readParcelable(TapAction.class.getClassLoader()));
    }

    public RequestModel(RequestType requestType, RequestData requestData, TapAction tapAction) {
        this.a = requestType;
        this.b = requestData;
        this.c = tapAction;
    }

    public final RequestData a() {
        return this.b;
    }

    public final TapAction b() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof RequestModel)) break block3;
                RequestModel requestModel = (RequestModel)object;
                if (l.c((Object)((Object)this.a), (Object)((Object)requestModel.a)) && l.c((Object)this.b, (Object)requestModel.b) && l.c((Object)this.c, (Object)requestModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        RequestType requestType = this.a;
        int n = requestType != null ? requestType.hashCode() : 0;
        int n2 = n * 31;
        RequestData requestData = this.b;
        int n3 = requestData != null ? requestData.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        TapAction tapAction = this.c;
        int n5 = 0;
        if (tapAction != null) {
            n5 = tapAction.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RequestModel(type=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", data=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        RequestType requestType = this.a;
        Integer n2 = requestType != null ? Integer.valueOf((int)requestType.ordinal()) : null;
        parcel.writeValue((Object)n2);
        parcel.writeParcelable((Parcelable)this.b, 0);
        parcel.writeParcelable((Parcelable)this.c, 0);
    }

    public static final class a
    implements Parcelable.Creator<RequestModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public RequestModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new RequestModel(parcel);
        }

        public RequestModel[] b(int n) {
            return new RequestModel[n];
        }
    }

}

