/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.UserVouchers
 *  com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherDetailModel$a
 *  com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherRedeemInfoModel
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.voucher.MyVoucherModel;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.UserVouchers;
import com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherDetailModel;
import com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherRedeemInfoModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class VoucherDetailModel
extends ResponseBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="user_vouchers")
    private final ArrayList<UserVouchers> e;
    @SerializedName(value="country_id")
    private final String f;
    @SerializedName(value="info_card")
    private final VoucherRedeemInfoModel g;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public VoucherDetailModel() {
    }

    public VoucherDetailModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
        parcel.readArrayList(UserVouchers.class.getClassLoader());
        parcel.readString();
        parcel.readParcelable(VoucherRedeemInfoModel.class.getClassLoader());
    }

    public int describeContents() {
        return 0;
    }

    public final VoucherRedeemInfoModel e() {
        return this.g;
    }

    public final ArrayList<UserVouchers> f() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeTypedList(this.e);
        parcel.writeString(this.f);
        parcel.writeParcelable((Parcelable)this.g, n2);
    }
}

