/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import i2.a0.d.l;

public final class ImageInfo
implements Parcelable {
    public static final Parcelable.Creator<ImageInfo> CREATOR = new a();
    @SerializedName(value="source")
    private final PictureObject a;

    public ImageInfo(PictureObject pictureObject) {
        this.a = pictureObject;
    }

    public final PictureObject a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ImageInfo)) break block3;
                ImageInfo imageInfo = (ImageInfo)object;
                if (l.c((Object)this.a, (Object)imageInfo.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        if (pictureObject != null) {
            return pictureObject.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ImageInfo(source=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
    }

    public static final class a
    implements Parcelable.Creator<ImageInfo> {
        public final ImageInfo a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new ImageInfo((PictureObject)parcel.readParcelable(ImageInfo.class.getClassLoader()));
        }

        public final ImageInfo[] b(int n) {
            return new ImageInfo[n];
        }
    }

}

