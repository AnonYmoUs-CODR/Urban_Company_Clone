/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.update_and_info_dialog.enums.TypeOfDialog
 *  com.urbanclap.urbanclap.core.update_and_info_dialog.models.AlertModel
 *  com.urbanclap.urbanclap.core.update_and_info_dialog.models.AppUpdateModel
 *  com.urbanclap.urbanclap.core.update_and_info_dialog.models.UpdateAndInfoDialogModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel
 *  java.lang.ClassLoader
 */
package com.urbanclap.urbanclap.core.update_and_info_dialog.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.update_and_info_dialog.enums.TypeOfDialog;
import com.urbanclap.urbanclap.core.update_and_info_dialog.models.AlertModel;
import com.urbanclap.urbanclap.core.update_and_info_dialog.models.AppUpdateModel;
import com.urbanclap.urbanclap.core.update_and_info_dialog.models.UpdateAndInfoDialogModel;
import com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel;

public class UpdateAndInfoDialogModel
extends ApiResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<UpdateAndInfoDialogModel> CREATOR = new a();
    @Expose
    @SerializedName(value="app_update")
    private AppUpdateModel e;
    @Expose
    @SerializedName(value="info_alert")
    private AlertModel f;

    public UpdateAndInfoDialogModel() {
    }

    public UpdateAndInfoDialogModel(Parcel parcel) {
        this.e = (AppUpdateModel)parcel.readParcelable(AppUpdateModel.class.getClassLoader());
        this.f = (AlertModel)parcel.readParcelable(AlertModel.class.getClassLoader());
    }

    public int describeContents() {
        return 0;
    }

    public AppUpdateModel h() {
        return this.e;
    }

    public AlertModel i() {
        return this.f;
    }

    public TypeOfDialog j() {
        if (this.h() != null) {
            if (this.h().b()) {
                return TypeOfDialog.SOFT_UPDATE;
            }
            if (this.h().a()) {
                return TypeOfDialog.FORCE_UPDATE;
            }
            return TypeOfDialog.NONE;
        }
        if (this.i() != null) {
            return TypeOfDialog.INFO;
        }
        return TypeOfDialog.NONE;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeParcelable((Parcelable)this.e, n2);
        parcel.writeParcelable((Parcelable)this.f, n2);
    }
}

