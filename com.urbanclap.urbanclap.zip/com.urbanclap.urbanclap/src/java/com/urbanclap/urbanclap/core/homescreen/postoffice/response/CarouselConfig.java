/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  d
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.FlingBehaviour;
import i2.a0.d.g;
import i2.a0.d.l;

public final class CarouselConfig
implements Parcelable {
    public static final Parcelable.Creator<CarouselConfig> CREATOR = new a();
    @SerializedName(value="cyclic_enabled")
    private boolean a;
    @SerializedName(value="auto_scroll_enabled")
    private boolean b;
    @SerializedName(value="auto_scroll_duration")
    private long c;
    @SerializedName(value="fling_behaviour")
    private FlingBehaviour d;

    public CarouselConfig() {
        this(false, false, 0L, null, 15, null);
    }

    public CarouselConfig(boolean bl, boolean bl2, long l2, FlingBehaviour flingBehaviour) {
        l.g((Object)((Object)flingBehaviour), (String)"flingBehaviour");
        this.a = bl;
        this.b = bl2;
        this.c = l2;
        this.d = flingBehaviour;
    }

    public /* synthetic */ CarouselConfig(boolean bl, boolean bl2, long l2, FlingBehaviour flingBehaviour, int n, g g2) {
        boolean bl3 = (n & 1) != 0 ? false : bl;
        boolean bl4 = (n & 2) != 0 ? false : bl2;
        if ((n & 4) != 0) {
            l2 = 3000L;
        }
        long l3 = l2;
        if ((n & 8) != 0) {
            flingBehaviour = FlingBehaviour.FREE_FLOW;
        }
        FlingBehaviour flingBehaviour2 = flingBehaviour;
        this(bl3, bl4, l3, flingBehaviour2);
    }

    public final long a() {
        return this.c;
    }

    public final boolean b() {
        return this.b;
    }

    public final FlingBehaviour c() {
        return this.d;
    }

    public final boolean d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CarouselConfig)) break block3;
                CarouselConfig carouselConfig = (CarouselConfig)object;
                if (this.a == carouselConfig.a && this.b == carouselConfig.b && this.c == carouselConfig.c && l.c((Object)((Object)this.d), (Object)((Object)carouselConfig.d))) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int n = this.a;
        int n2 = 1;
        if (n != 0) {
            n = 1;
        }
        int n3 = n * 31;
        int n4 = this.b;
        if (n4 == 0) {
            n2 = n4;
        }
        int n5 = 31 * (31 * (n3 + n2) + d.a((long)this.c));
        FlingBehaviour flingBehaviour = this.d;
        int n6 = flingBehaviour != null ? flingBehaviour.hashCode() : 0;
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CarouselConfig(isCyclic=");
        stringBuilder.append(this.a);
        stringBuilder.append(", autoScrollEnabled=");
        stringBuilder.append(this.b);
        stringBuilder.append(", autoScrollDuration=");
        stringBuilder.append(this.c);
        stringBuilder.append(", flingBehaviour=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeInt((int)this.a);
        parcel.writeInt((int)this.b);
        parcel.writeLong(this.c);
        parcel.writeString(this.d.name());
    }

    public static final class a
    implements Parcelable.Creator<CarouselConfig> {
        public final CarouselConfig a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            boolean bl = parcel.readInt() != 0;
            int n = parcel.readInt();
            boolean bl2 = false;
            if (n != 0) {
                bl2 = true;
            }
            long l2 = parcel.readLong();
            FlingBehaviour flingBehaviour = (FlingBehaviour)Enum.valueOf(FlingBehaviour.class, (String)parcel.readString());
            CarouselConfig carouselConfig = new CarouselConfig(bl, bl2, l2, flingBehaviour);
            return carouselConfig;
        }

        public final CarouselConfig[] b(int n) {
            return new CarouselConfig[n];
        }
    }

}

