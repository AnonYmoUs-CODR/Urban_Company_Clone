/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.DiscoveryItemsBodyTemplateTypes;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBodyData;
import i2.a0.d.l;
import java.util.Objects;

public final class HomeScreenItemBody
implements Parcelable {
    public static final Parcelable.Creator<HomeScreenItemBody> CREATOR = new Parcelable.Creator<HomeScreenItemBody>(){

        public HomeScreenItemBody a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new HomeScreenItemBody(parcel);
        }

        public HomeScreenItemBody[] b(int n) {
            return new HomeScreenItemBody[n];
        }
    };
    @SerializedName(value="type")
    private final DiscoveryItemsBodyTemplateTypes a;
    @SerializedName(value="data")
    private final HomeScreenItemBodyData b;

    public HomeScreenItemBody(Parcel parcel) {
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes;
        l.g((Object)parcel, (String)"source");
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (object != null) {
            DiscoveryItemsBodyTemplateTypes[] arrdiscoveryItemsBodyTemplateTypes = DiscoveryItemsBodyTemplateTypes.values();
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
            discoveryItemsBodyTemplateTypes = arrdiscoveryItemsBodyTemplateTypes[(Integer)object];
        } else {
            discoveryItemsBodyTemplateTypes = null;
        }
        Parcelable parcelable = parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
        l.f((Object)parcelable, (String)"source.readParcelable<Ho\u2026::class.java.classLoader)");
        this(discoveryItemsBodyTemplateTypes, (HomeScreenItemBodyData)parcelable);
    }

    public HomeScreenItemBody(DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes, HomeScreenItemBodyData homeScreenItemBodyData) {
        l.g((Object)homeScreenItemBodyData, (String)"bodyData");
        this.a = discoveryItemsBodyTemplateTypes;
        this.b = homeScreenItemBodyData;
    }

    public final HomeScreenItemBodyData a() {
        return this.b;
    }

    public final DiscoveryItemsBodyTemplateTypes b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HomeScreenItemBody)) break block3;
                HomeScreenItemBody homeScreenItemBody = (HomeScreenItemBody)object;
                if (l.c((Object)((Object)this.a), (Object)((Object)homeScreenItemBody.a)) && l.c((Object)this.b, (Object)homeScreenItemBody.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes = this.a;
        int n = discoveryItemsBodyTemplateTypes != null ? discoveryItemsBodyTemplateTypes.hashCode() : 0;
        int n2 = n * 31;
        HomeScreenItemBodyData homeScreenItemBodyData = this.b;
        int n3 = 0;
        if (homeScreenItemBodyData != null) {
            n3 = homeScreenItemBodyData.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HomeScreenItemBody(type=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", bodyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        DiscoveryItemsBodyTemplateTypes discoveryItemsBodyTemplateTypes = this.a;
        Integer n2 = discoveryItemsBodyTemplateTypes != null ? Integer.valueOf((int)discoveryItemsBodyTemplateTypes.ordinal()) : null;
        parcel.writeValue((Object)n2);
        parcel.writeParcelable((Parcelable)this.b, 0);
    }

}

