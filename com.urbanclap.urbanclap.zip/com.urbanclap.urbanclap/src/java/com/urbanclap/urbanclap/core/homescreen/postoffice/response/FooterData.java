/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.extras.Analytics
 *  com.urbanclap.urbanclap.ucshared.extras.TapAction
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.OtherAttributes
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.extras.Analytics;
import com.urbanclap.urbanclap.ucshared.extras.TapAction;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.OtherAttributes;
import i2.a0.d.l;

public final class FooterData
implements Parcelable {
    public static final Parcelable.Creator<FooterData> CREATOR = new a();
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="text_color")
    private final String b;
    @SerializedName(value="other_attributes")
    private final OtherAttributes c;
    @SerializedName(value="tap_action")
    private final TapAction d;
    @SerializedName(value="tracking_data")
    private final TrackingData e;
    @SerializedName(value="analytics")
    private final Analytics f;

    public FooterData(String string, String string2, OtherAttributes otherAttributes, TapAction tapAction, TrackingData trackingData, Analytics analytics) {
        this.a = string;
        this.b = string2;
        this.c = otherAttributes;
        this.d = tapAction;
        this.e = trackingData;
        this.f = analytics;
    }

    public final Analytics a() {
        return this.f;
    }

    public final OtherAttributes b() {
        return this.c;
    }

    public final TapAction c() {
        return this.d;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof FooterData)) break block3;
                FooterData footerData = (FooterData)object;
                if (l.c((Object)this.a, (Object)footerData.a) && l.c((Object)this.b, (Object)footerData.b) && l.c((Object)this.c, (Object)footerData.c) && l.c((Object)this.d, (Object)footerData.d) && l.c((Object)this.e, (Object)footerData.e) && l.c((Object)this.f, (Object)footerData.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final TrackingData f() {
        return this.e;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        OtherAttributes otherAttributes = this.c;
        int n5 = otherAttributes != null ? otherAttributes.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        TapAction tapAction = this.d;
        int n7 = tapAction != null ? tapAction.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        TrackingData trackingData = this.e;
        int n9 = trackingData != null ? trackingData.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        Analytics analytics = this.f;
        int n11 = 0;
        if (analytics != null) {
            n11 = analytics.hashCode();
        }
        return n10 + n11;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FooterData(text=");
        stringBuilder.append(this.a);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", otherAttributes=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", trackingData=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", analytics=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeParcelable((Parcelable)this.e, n);
        parcel.writeParcelable((Parcelable)this.f, n);
    }

    public static final class a
    implements Parcelable.Creator<FooterData> {
        public final FooterData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            FooterData footerData = new FooterData(parcel.readString(), parcel.readString(), (OtherAttributes)parcel.readParcelable(FooterData.class.getClassLoader()), (TapAction)parcel.readParcelable(FooterData.class.getClassLoader()), (TrackingData)parcel.readParcelable(FooterData.class.getClassLoader()), (Analytics)parcel.readParcelable(FooterData.class.getClassLoader()));
            return footerData;
        }

        public final FooterData[] b(int n) {
            return new FooterData[n];
        }
    }

}

