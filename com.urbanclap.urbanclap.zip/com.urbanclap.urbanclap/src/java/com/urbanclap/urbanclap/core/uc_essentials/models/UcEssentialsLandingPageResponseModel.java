/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenTemplate
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.uc_essentials.models;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenTemplate;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.List;

public final class UcEssentialsLandingPageResponseModel
extends ResponseBaseModel {
    @SerializedName(value="templates")
    private final List<HomeScreenTemplate> e;
    @SerializedName(value="tracking_data")
    private final TrackingData f;

    public final List<HomeScreenTemplate> e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof UcEssentialsLandingPageResponseModel)) break block3;
                UcEssentialsLandingPageResponseModel ucEssentialsLandingPageResponseModel = (UcEssentialsLandingPageResponseModel)((Object)object);
                if (l.c(this.e, ucEssentialsLandingPageResponseModel.e) && l.c((Object)this.f, (Object)ucEssentialsLandingPageResponseModel.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final TrackingData f() {
        return this.f;
    }

    public int hashCode() {
        List<HomeScreenTemplate> list = this.e;
        int n2 = list != null ? list.hashCode() : 0;
        int n3 = n2 * 31;
        TrackingData trackingData = this.f;
        int n4 = 0;
        if (trackingData != null) {
            n4 = trackingData.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UcEssentialsLandingPageResponseModel(templates=");
        stringBuilder.append(this.e);
        stringBuilder.append(", trackingData=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

