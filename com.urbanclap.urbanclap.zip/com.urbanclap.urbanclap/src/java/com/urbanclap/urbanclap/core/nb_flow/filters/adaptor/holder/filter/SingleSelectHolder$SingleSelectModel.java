/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder$FilterSelectBaseModel
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.SingleSelectHolder$SingleSelectModel$a
 */
package com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder;
import com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.SingleSelectHolder$SingleSelectModel;

public class SingleSelectHolder$SingleSelectModel
extends FilterSelectBaseHolder.FilterSelectBaseModel {
    public static final Parcelable.Creator<SingleSelectHolder$SingleSelectModel> CREATOR = new a();

    public SingleSelectHolder$SingleSelectModel(Parcel parcel) {
        super(parcel);
    }
}

