/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBodyQuestionAnswerData;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class HomeScreenItemBodyQuestionData
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="category_key")
    private final String b;
    @SerializedName(value="question_tag")
    private final String c;
    @SerializedName(value="answers")
    private final List<HomeScreenItemBodyQuestionAnswerData> d;

    public HomeScreenItemBodyQuestionData(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        this(string, string2, parcel.readString(), (List<HomeScreenItemBodyQuestionAnswerData>)parcel.createTypedArrayList((Parcelable.Creator)HomeScreenItemBodyQuestionAnswerData.CREATOR));
    }

    public HomeScreenItemBodyQuestionData(String string, String string2, String string3, List<HomeScreenItemBodyQuestionAnswerData> list) {
        l.g((Object)string2, (String)"categoryKey");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = list;
    }

    public final List<HomeScreenItemBodyQuestionAnswerData> a() {
        return this.d;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HomeScreenItemBodyQuestionData)) break block3;
                HomeScreenItemBodyQuestionData homeScreenItemBodyQuestionData = (HomeScreenItemBodyQuestionData)object;
                if (l.c((Object)this.a, (Object)homeScreenItemBodyQuestionData.a) && l.c((Object)this.b, (Object)homeScreenItemBodyQuestionData.b) && l.c((Object)this.c, (Object)homeScreenItemBodyQuestionData.c) && l.c(this.d, homeScreenItemBodyQuestionData.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        List<HomeScreenItemBodyQuestionAnswerData> list = this.d;
        int n7 = 0;
        if (list != null) {
            n7 = list.hashCode();
        }
        return n6 + n7;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HomeScreenItemBodyQuestionData(title=");
        stringBuilder.append(this.a);
        stringBuilder.append(", categoryKey=");
        stringBuilder.append(this.b);
        stringBuilder.append(", questionTag=");
        stringBuilder.append(this.c);
        stringBuilder.append(", answers=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeTypedList(this.d);
    }

    public static final class a
    implements Parcelable.Creator<HomeScreenItemBodyQuestionData> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public HomeScreenItemBodyQuestionData a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new HomeScreenItemBodyQuestionData(parcel);
        }

        public HomeScreenItemBodyQuestionData[] b(int n) {
            return new HomeScreenItemBodyQuestionData[n];
        }
    }

}

