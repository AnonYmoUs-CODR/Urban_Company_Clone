/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class RequestType
extends Enum<RequestType> {
    private static final /* synthetic */ RequestType[] $VALUES;
    @SerializedName(value="payment_info")
    public static final /* enum */ RequestType PAYMENT_INFO;
    @SerializedName(value="request_info")
    public static final /* enum */ RequestType REQUEST_INFO;
    @SerializedName(value="review")
    public static final /* enum */ RequestType REVIEW;

    public static {
        RequestType requestType;
        RequestType requestType2;
        RequestType requestType3;
        RequestType[] arrrequestType = new RequestType[3];
        REQUEST_INFO = requestType2 = new RequestType();
        arrrequestType[0] = requestType2;
        REVIEW = requestType = new RequestType();
        arrrequestType[1] = requestType;
        PAYMENT_INFO = requestType3 = new RequestType();
        arrrequestType[2] = requestType3;
        $VALUES = arrrequestType;
    }

    public static RequestType valueOf(String string) {
        return (RequestType)Enum.valueOf(RequestType.class, (String)string);
    }

    public static RequestType[] values() {
        return (RequestType[])$VALUES.clone();
    }
}

