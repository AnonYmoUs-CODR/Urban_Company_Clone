/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class DiscoveryItemsHeaderTemplateTypes
extends Enum<DiscoveryItemsHeaderTemplateTypes> {
    private static final /* synthetic */ DiscoveryItemsHeaderTemplateTypes[] $VALUES;
    @SerializedName(value="image_subtitle_icon")
    public static final /* enum */ DiscoveryItemsHeaderTemplateTypes IMAGE_SUBTITLE_ICON;
    @SerializedName(value="image_title_subtitle")
    public static final /* enum */ DiscoveryItemsHeaderTemplateTypes IMAGE_TITLE_SUBTITLE;
    @SerializedName(value="title_subtitle")
    public static final /* enum */ DiscoveryItemsHeaderTemplateTypes TITLE_SUBTITLE;
    @SerializedName(value="title_subtitle_block")
    public static final /* enum */ DiscoveryItemsHeaderTemplateTypes TITLE_SUBTITLE_BLOCK;
    @SerializedName(value="title_subtitle_cta")
    public static final /* enum */ DiscoveryItemsHeaderTemplateTypes TITLE_SUBTITLE_CTA;

    public static {
        DiscoveryItemsHeaderTemplateTypes discoveryItemsHeaderTemplateTypes;
        DiscoveryItemsHeaderTemplateTypes discoveryItemsHeaderTemplateTypes2;
        DiscoveryItemsHeaderTemplateTypes discoveryItemsHeaderTemplateTypes3;
        DiscoveryItemsHeaderTemplateTypes discoveryItemsHeaderTemplateTypes4;
        DiscoveryItemsHeaderTemplateTypes discoveryItemsHeaderTemplateTypes5;
        DiscoveryItemsHeaderTemplateTypes[] arrdiscoveryItemsHeaderTemplateTypes = new DiscoveryItemsHeaderTemplateTypes[5];
        TITLE_SUBTITLE = discoveryItemsHeaderTemplateTypes2 = new DiscoveryItemsHeaderTemplateTypes();
        arrdiscoveryItemsHeaderTemplateTypes[0] = discoveryItemsHeaderTemplateTypes2;
        IMAGE_TITLE_SUBTITLE = discoveryItemsHeaderTemplateTypes5 = new DiscoveryItemsHeaderTemplateTypes();
        arrdiscoveryItemsHeaderTemplateTypes[1] = discoveryItemsHeaderTemplateTypes5;
        TITLE_SUBTITLE_BLOCK = discoveryItemsHeaderTemplateTypes3 = new DiscoveryItemsHeaderTemplateTypes();
        arrdiscoveryItemsHeaderTemplateTypes[2] = discoveryItemsHeaderTemplateTypes3;
        TITLE_SUBTITLE_CTA = discoveryItemsHeaderTemplateTypes4 = new DiscoveryItemsHeaderTemplateTypes();
        arrdiscoveryItemsHeaderTemplateTypes[3] = discoveryItemsHeaderTemplateTypes4;
        IMAGE_SUBTITLE_ICON = discoveryItemsHeaderTemplateTypes = new DiscoveryItemsHeaderTemplateTypes();
        arrdiscoveryItemsHeaderTemplateTypes[4] = discoveryItemsHeaderTemplateTypes;
        $VALUES = arrdiscoveryItemsHeaderTemplateTypes;
    }

    public static DiscoveryItemsHeaderTemplateTypes valueOf(String string) {
        return (DiscoveryItemsHeaderTemplateTypes)Enum.valueOf(DiscoveryItemsHeaderTemplateTypes.class, (String)string);
    }

    public static DiscoveryItemsHeaderTemplateTypes[] values() {
        return (DiscoveryItemsHeaderTemplateTypes[])$VALUES.clone();
    }
}

