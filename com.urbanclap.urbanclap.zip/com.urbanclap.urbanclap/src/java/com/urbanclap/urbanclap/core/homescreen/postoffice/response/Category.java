/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import i2.a0.d.g;
import i2.a0.d.l;

public final class Category
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="picture")
    private final PictureObject a;
    @SerializedName(value="font_name")
    private final String b;
    @SerializedName(value="display_name")
    private final String c;
    @SerializedName(value="key_name")
    private final String d;

    public Category(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        PictureObject pictureObject = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        l.f((Object)string3, (String)"parcel.readString()");
        this(pictureObject, string, string2, string3);
    }

    public Category(PictureObject pictureObject, String string, String string2, String string3) {
        l.g((Object)string3, (String)"mKeyname");
        this.a = pictureObject;
        this.b = string;
        this.c = string2;
        this.d = string3;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.d;
    }

    public final PictureObject c() {
        return this.a;
    }

    public final String d() {
        if (!TextUtils.isEmpty((CharSequence)this.c)) {
            String string = this.c;
            l.e((Object)string);
            return string;
        }
        return "";
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Category)) break block3;
                Category category = (Category)object;
                if (l.c((Object)this.a, (Object)category.a) && l.c((Object)this.b, (Object)category.b) && l.c((Object)this.c, (Object)category.c) && l.c((Object)this.d, (Object)category.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string3 = this.d;
        int n7 = 0;
        if (string3 != null) {
            n7 = string3.hashCode();
        }
        return n6 + n7;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Category(pictureObject=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", mFontName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", mDisplayName=");
        stringBuilder.append(this.c);
        stringBuilder.append(", mKeyname=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
    }

    public static final class a
    implements Parcelable.Creator<Category> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public Category a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new Category(parcel);
        }

        public Category[] b(int n) {
            return new Category[n];
        }
    }

}

