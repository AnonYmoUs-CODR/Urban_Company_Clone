/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.Category
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.Category$a
 *  com.urbanclap.urbanclap.core.view_all.GetAllCategoriesResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.view_all;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.Category;
import com.urbanclap.urbanclap.core.view_all.GetAllCategoriesResponseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class GetAllCategoriesResponseModel
extends ResponseBaseModel {
    public static final a CREATOR;
    @SerializedName(value="categories")
    private final List<Category> e;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public GetAllCategoriesResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        ArrayList arrayList = parcel.createTypedArrayList((Parcelable.Creator)Category.CREATOR);
        l.f((Object)arrayList, (String)"parcel.createTypedArrayList(Category)");
        this((List<Category>)arrayList);
    }

    public GetAllCategoriesResponseModel(List<Category> list) {
        l.g(list, (String)"categories");
        this.e = list;
    }

    public int describeContents() {
        return 0;
    }

    public final List<Category> e() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeTypedList(this.e);
    }
}

