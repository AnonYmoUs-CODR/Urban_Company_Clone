/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class Text
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="text_color")
    private final String b;
    @SerializedName(value="font_size")
    private final Integer c;

    public Text(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), (Integer)parcel.readValue(Integer.TYPE.getClassLoader()));
    }

    public Text(String string, String string2, Integer n) {
        this.a = string;
        this.b = string2;
        this.c = n;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final Integer c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Text)) break block3;
                Text text = (Text)object;
                if (l.c((Object)this.a, (Object)text.a) && l.c((Object)this.b, (Object)text.b) && l.c((Object)this.c, (Object)text.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Integer n5 = this.c;
        int n6 = 0;
        if (n5 != null) {
            n6 = n5.hashCode();
        }
        return n4 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Text(text=");
        stringBuilder.append(this.a);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", textSize=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeValue((Object)this.c);
    }

    public static final class a
    implements Parcelable.Creator<Text> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public Text a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new Text(parcel);
        }

        public Text[] b(int n) {
            return new Text[n];
        }
    }

}

