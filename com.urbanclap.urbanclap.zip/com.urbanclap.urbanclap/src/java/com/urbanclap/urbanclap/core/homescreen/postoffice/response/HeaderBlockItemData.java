/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import i2.a0.d.l;

public final class HeaderBlockItemData
implements Parcelable {
    public static final Parcelable.Creator<HeaderBlockItemData> CREATOR = new a();
    @SerializedName(alternate={"image_url"}, value="image")
    private final PictureObject a;
    @SerializedName(value="title")
    private final String b;
    @SerializedName(value="subtitle")
    private final String c;

    public HeaderBlockItemData(PictureObject pictureObject, String string, String string2) {
        this.a = pictureObject;
        this.b = string;
        this.c = string2;
    }

    public final PictureObject a() {
        return this.a;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HeaderBlockItemData)) break block3;
                HeaderBlockItemData headerBlockItemData = (HeaderBlockItemData)object;
                if (l.c((Object)this.a, (Object)headerBlockItemData.a) && l.c((Object)this.b, (Object)headerBlockItemData.b) && l.c((Object)this.c, (Object)headerBlockItemData.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = 0;
        if (string2 != null) {
            n5 = string2.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HeaderBlockItemData(image=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", title=");
        stringBuilder.append(this.b);
        stringBuilder.append(", subtitle=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

    public static final class a
    implements Parcelable.Creator<HeaderBlockItemData> {
        public final HeaderBlockItemData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new HeaderBlockItemData((PictureObject)parcel.readParcelable(HeaderBlockItemData.class.getClassLoader()), parcel.readString(), parcel.readString());
        }

        public final HeaderBlockItemData[] b(int n) {
            return new HeaderBlockItemData[n];
        }
    }

}

