/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import i2.a0.d.l;

public final class ProviderData
implements Parcelable {
    public static final Parcelable.Creator<ProviderData> CREATOR = new Parcelable.Creator<ProviderData>(){

        public ProviderData a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new ProviderData(parcel);
        }

        public ProviderData[] b(int n) {
            return new ProviderData[n];
        }
    };
    @SerializedName(value="name")
    private final String a;
    @SerializedName(value="id")
    private final String b;
    @SerializedName(value="profile_image")
    private final PictureObject c;

    public ProviderData(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this(parcel.readString(), parcel.readString(), (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader()));
    }

    public ProviderData(String string, String string2, PictureObject pictureObject) {
        this.a = string;
        this.b = string2;
        this.c = pictureObject;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public final PictureObject c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ProviderData)) break block3;
                ProviderData providerData = (ProviderData)object;
                if (l.c((Object)this.a, (Object)providerData.a) && l.c((Object)this.b, (Object)providerData.b) && l.c((Object)this.c, (Object)providerData.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        PictureObject pictureObject = this.c;
        int n5 = 0;
        if (pictureObject != null) {
            n5 = pictureObject.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ProviderData(name=");
        stringBuilder.append(this.a);
        stringBuilder.append(", id=");
        stringBuilder.append(this.b);
        stringBuilder.append(", profileImage=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, 0);
    }

}

