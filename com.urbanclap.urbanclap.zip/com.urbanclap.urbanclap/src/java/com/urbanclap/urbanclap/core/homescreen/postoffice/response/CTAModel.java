/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Objects
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.CTAData;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.Objects;

public final class CTAModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="primary")
    private final CTAData a;

    public CTAModel(CTAData cTAData) {
        l.g((Object)cTAData, (String)"primary");
        this.a = cTAData;
    }

    public final CTAData a() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CTAModel)) break block3;
                CTAModel cTAModel = (CTAModel)object;
                if (l.c((Object)this.a, (Object)cTAModel.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        CTAData cTAData = this.a;
        if (cTAData != null) {
            return cTAData.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CTAModel(primary=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, 0);
    }

    public static final class a
    implements Parcelable.Creator<CTAModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public CTAModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            Parcelable parcelable = parcel.readParcelable(CTAModel.class.getClassLoader());
            Objects.requireNonNull((Object)parcelable, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.core.homescreen.postoffice.response.CTAData");
            return new CTAModel((CTAData)parcelable);
        }

        public CTAModel[] b(int n) {
            return new CTAModel[n];
        }
    }

}

