/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.RequestBody;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.VaccinationInfo;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;

public final class RequestData
implements Parcelable {
    public static final Parcelable.Creator<RequestData> CREATOR = new a();
    @SerializedName(value="title")
    private final String a;
    @SerializedName(value="subtitle")
    private final String b;
    @SerializedName(value="image")
    private final PictureObject c;
    @SerializedName(value="vaccination_info")
    private final VaccinationInfo d;
    @SerializedName(value="overlay_image")
    private final String e;
    @SerializedName(value="body")
    private final RequestBody f;
    @SerializedName(value="suffix_label")
    private final String g;
    @SerializedName(value="is_dismissable")
    private final boolean h;
    @SerializedName(value="bg_gradient_colors")
    private final ArrayList<String> i;

    public RequestData(String string, String string2, PictureObject pictureObject, VaccinationInfo vaccinationInfo, String string3, RequestBody requestBody, String string4, boolean bl, ArrayList<String> arrayList) {
        this.a = string;
        this.b = string2;
        this.c = pictureObject;
        this.d = vaccinationInfo;
        this.e = string3;
        this.f = requestBody;
        this.g = string4;
        this.h = bl;
        this.i = arrayList;
    }

    public final ArrayList<String> a() {
        return this.i;
    }

    public final RequestBody b() {
        return this.f;
    }

    public final PictureObject c() {
        return this.c;
    }

    public final String d() {
        return this.e;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof RequestData)) break block3;
                RequestData requestData = (RequestData)object;
                if (l.c((Object)this.a, (Object)requestData.a) && l.c((Object)this.b, (Object)requestData.b) && l.c((Object)this.c, (Object)requestData.c) && l.c((Object)this.d, (Object)requestData.d) && l.c((Object)this.e, (Object)requestData.e) && l.c((Object)this.f, (Object)requestData.f) && l.c((Object)this.g, (Object)requestData.g) && this.h == requestData.h && l.c(this.i, requestData.i)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.g;
    }

    public final String g() {
        return this.a;
    }

    public final VaccinationInfo h() {
        return this.d;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        PictureObject pictureObject = this.c;
        int n5 = pictureObject != null ? pictureObject.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        VaccinationInfo vaccinationInfo = this.d;
        int n7 = vaccinationInfo != null ? vaccinationInfo.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string3 = this.e;
        int n9 = string3 != null ? string3.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        RequestBody requestBody = this.f;
        int n11 = requestBody != null ? requestBody.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string4 = this.g;
        int n13 = string4 != null ? string4.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        int n15 = this.h ? 1 : 0;
        if (n15 != 0) {
            n15 = 1;
        }
        int n16 = 31 * (n14 + n15);
        ArrayList<String> arrayList = this.i;
        int n17 = 0;
        if (arrayList != null) {
            n17 = arrayList.hashCode();
        }
        return n16 + n17;
    }

    public final boolean i() {
        return this.h;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RequestData(title=");
        stringBuilder.append(this.a);
        stringBuilder.append(", subtitle=");
        stringBuilder.append(this.b);
        stringBuilder.append(", image=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", vaccinationInfo=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", overlayImage=");
        stringBuilder.append(this.e);
        stringBuilder.append(", body=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", suffixLabel=");
        stringBuilder.append(this.g);
        stringBuilder.append(", isDismissable=");
        stringBuilder.append(this.h);
        stringBuilder.append(", bgColorList=");
        stringBuilder.append(this.i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n);
        VaccinationInfo vaccinationInfo = this.d;
        if (vaccinationInfo != null) {
            parcel.writeInt(1);
            vaccinationInfo.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.e);
        parcel.writeParcelable((Parcelable)this.f, n);
        parcel.writeString(this.g);
        parcel.writeInt((int)this.h);
        ArrayList<String> arrayList = this.i;
        if (arrayList != null) {
            parcel.writeInt(1);
            parcel.writeInt(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                parcel.writeString((String)iterator.next());
            }
        } else {
            parcel.writeInt(0);
        }
    }

    public static final class a
    implements Parcelable.Creator<RequestData> {
        public final RequestData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(RequestData.class.getClassLoader());
            VaccinationInfo vaccinationInfo = parcel.readInt() != 0 ? (VaccinationInfo)VaccinationInfo.CREATOR.createFromParcel(parcel) : null;
            String string3 = parcel.readString();
            RequestBody requestBody = (RequestBody)parcel.readParcelable(RequestData.class.getClassLoader());
            String string4 = parcel.readString();
            boolean bl = parcel.readInt() != 0;
            int n = parcel.readInt();
            ArrayList arrayList = null;
            if (n != 0) {
                int n2;
                arrayList = new ArrayList(n2);
                for (n2 = parcel.readInt(); n2 != 0; --n2) {
                    arrayList.add((Object)parcel.readString());
                }
            }
            ArrayList arrayList2 = arrayList;
            RequestData requestData = new RequestData(string, string2, pictureObject, vaccinationInfo, string3, requestBody, string4, bl, (ArrayList<String>)arrayList2);
            return requestData;
        }

        public final RequestData[] b(int n) {
            return new RequestData[n];
        }
    }

}

