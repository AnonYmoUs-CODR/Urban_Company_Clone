/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.ucshared.extras.Analytics
 *  com.urbanclap.urbanclap.ucshared.models.CallToActionModel
 *  com.urbanclap.urbanclap.ucshared.models.Icon
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HeaderBlockItemData;
import com.urbanclap.urbanclap.ucshared.extras.Analytics;
import com.urbanclap.urbanclap.ucshared.models.CallToActionModel;
import com.urbanclap.urbanclap.ucshared.models.Icon;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class HeaderData
implements Parcelable {
    public static final Parcelable.Creator<HeaderData> CREATOR = new a();
    @SerializedName(value="image")
    private final PictureObject a;
    @SerializedName(value="icon")
    private final Icon b;
    @SerializedName(value="subtitle_icon")
    private final PictureObject c;
    @SerializedName(value="title")
    private final String d;
    @SerializedName(value="subtitle")
    private final String e;
    @SerializedName(value="cta")
    private final CallToActionModel f;
    @SerializedName(value="block_items")
    private final List<HeaderBlockItemData> g;
    @SerializedName(value="bg_color")
    private final String h;
    @SerializedName(value="analytics")
    private final Analytics i;

    public HeaderData(PictureObject pictureObject, Icon icon, PictureObject pictureObject2, String string, String string2, CallToActionModel callToActionModel, List<HeaderBlockItemData> list, String string3, Analytics analytics) {
        this.a = pictureObject;
        this.b = icon;
        this.c = pictureObject2;
        this.d = string;
        this.e = string2;
        this.f = callToActionModel;
        this.g = list;
        this.h = string3;
        this.i = analytics;
    }

    public final Analytics a() {
        return this.i;
    }

    public final String b() {
        return this.h;
    }

    public final List<HeaderBlockItemData> c() {
        return this.g;
    }

    public final CallToActionModel d() {
        return this.f;
    }

    public int describeContents() {
        return 0;
    }

    public final Icon e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HeaderData)) break block3;
                HeaderData headerData = (HeaderData)object;
                if (l.c((Object)this.a, (Object)headerData.a) && l.c((Object)this.b, (Object)headerData.b) && l.c((Object)this.c, (Object)headerData.c) && l.c((Object)this.d, (Object)headerData.d) && l.c((Object)this.e, (Object)headerData.e) && l.c((Object)this.f, (Object)headerData.f) && l.c(this.g, headerData.g) && l.c((Object)this.h, (Object)headerData.h) && l.c((Object)this.i, (Object)headerData.i)) break block2;
            }
            return false;
        }
        return true;
    }

    public final PictureObject f() {
        return this.a;
    }

    public final String g() {
        return this.e;
    }

    public final PictureObject h() {
        return this.c;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        Icon icon = this.b;
        int n3 = icon != null ? icon.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        PictureObject pictureObject2 = this.c;
        int n5 = pictureObject2 != null ? pictureObject2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string = this.d;
        int n7 = string != null ? string.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string2 = this.e;
        int n9 = string2 != null ? string2.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        CallToActionModel callToActionModel = this.f;
        int n11 = callToActionModel != null ? callToActionModel.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        List<HeaderBlockItemData> list = this.g;
        int n13 = list != null ? list.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        String string3 = this.h;
        int n15 = string3 != null ? string3.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        Analytics analytics = this.i;
        int n17 = 0;
        if (analytics != null) {
            n17 = analytics.hashCode();
        }
        return n16 + n17;
    }

    public final String i() {
        return this.d;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HeaderData(image=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", icon=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", subtitleIcon=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", title=");
        stringBuilder.append(this.d);
        stringBuilder.append(", subtitle=");
        stringBuilder.append(this.e);
        stringBuilder.append(", cta=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", blockItems=");
        stringBuilder.append(this.g);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.h);
        stringBuilder.append(", analytics=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeParcelable((Parcelable)this.b, n);
        parcel.writeParcelable((Parcelable)this.c, n);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeParcelable((Parcelable)this.f, n);
        List<HeaderBlockItemData> list = this.g;
        if (list != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            for (HeaderBlockItemData headerBlockItemData : list) {
                if (headerBlockItemData != null) {
                    parcel.writeInt(1);
                    headerBlockItemData.writeToParcel(parcel, 0);
                    continue;
                }
                parcel.writeInt(0);
            }
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.h);
        parcel.writeParcelable((Parcelable)this.i, n);
    }

    public static final class a
    implements Parcelable.Creator<HeaderData> {
        public final HeaderData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(HeaderData.class.getClassLoader());
            Icon icon = (Icon)parcel.readParcelable(HeaderData.class.getClassLoader());
            PictureObject pictureObject2 = (PictureObject)parcel.readParcelable(HeaderData.class.getClassLoader());
            String string = parcel.readString();
            String string2 = parcel.readString();
            CallToActionModel callToActionModel = (CallToActionModel)parcel.readParcelable(HeaderData.class.getClassLoader());
            int n = parcel.readInt();
            ArrayList arrayList = null;
            if (n != 0) {
                int n2;
                ArrayList arrayList2 = new ArrayList(n2);
                for (n2 = parcel.readInt(); n2 != 0; --n2) {
                    HeaderBlockItemData headerBlockItemData = parcel.readInt() != 0 ? (HeaderBlockItemData)HeaderBlockItemData.CREATOR.createFromParcel(parcel) : null;
                    arrayList2.add((Object)headerBlockItemData);
                }
                arrayList = arrayList2;
            }
            HeaderData headerData = new HeaderData(pictureObject, icon, pictureObject2, string, string2, callToActionModel, (List<HeaderBlockItemData>)arrayList, parcel.readString(), (Analytics)parcel.readParcelable(HeaderData.class.getClassLoader()));
            return headerData;
        }

        public final HeaderData[] b(int n) {
            return new HeaderData[n];
        }
    }

}

