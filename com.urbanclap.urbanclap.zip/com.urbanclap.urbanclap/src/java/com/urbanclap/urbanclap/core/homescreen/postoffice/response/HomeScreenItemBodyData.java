/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.BodyDataItem
 *  com.urbanclap.urbanclap.ucshared.extras.Analytics
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.BodyDataItem;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.CarouselConfig;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBody;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.HomeScreenItemBodyQuestionData;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.ItemDisplayConfig;
import com.urbanclap.urbanclap.ucshared.extras.Analytics;
import com.urbanclap.urbanclap.ucshared.models.create_request.QuestionCollectionModel;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;

public final class HomeScreenItemBodyData
implements Parcelable {
    public static final Parcelable.Creator<HomeScreenItemBodyData> CREATOR = new a();
    @SerializedName(value="analytics")
    private final Analytics A;
    @SerializedName(value="item_display_config")
    private final ItemDisplayConfig B;
    @SerializedName(value="carousel_config")
    private final CarouselConfig C;
    @SerializedName(value="number_of_columns")
    private final Integer a;
    @SerializedName(value="number_of_rows")
    private final Integer b;
    @SerializedName(value="sticky_view")
    private final HomeScreenItemBody c;
    @SerializedName(value="bg_color_list")
    private final ArrayList<String> d;
    @SerializedName(value="show_bg_image")
    private final boolean e;
    @SerializedName(value="items")
    private final ArrayList<BodyDataItem> f;
    @SerializedName(value="cover_image")
    private final PictureObject g;
    @SerializedName(value="image")
    private final PictureObject h;
    @SerializedName(value="theming_color")
    private final String i;
    @SerializedName(value="title")
    private final String j;
    @SerializedName(value="event_data")
    private final String k;
    @SerializedName(value="subtitle")
    private final String s;
    @SerializedName(value="bg_color")
    private final String t;
    @SerializedName(value="type")
    private final String u;
    @SerializedName(value="single_select")
    private final HomeScreenItemBodyQuestionData v;
    @SerializedName(value="collective")
    private final QuestionCollectionModel w;
    @SerializedName(value="rate_card_url")
    private final String x;
    @SerializedName(value="display_size")
    private final String y;
    @SerializedName(value="has_more_reviews")
    private final Boolean z;

    public HomeScreenItemBodyData(Integer n, Integer n2, HomeScreenItemBody homeScreenItemBody, ArrayList<String> arrayList, boolean bl, ArrayList<BodyDataItem> arrayList2, PictureObject pictureObject, PictureObject pictureObject2, String string, String string2, String string3, String string4, String string5, String string6, HomeScreenItemBodyQuestionData homeScreenItemBodyQuestionData, QuestionCollectionModel questionCollectionModel, String string7, String string8, Boolean bl2, Analytics analytics, ItemDisplayConfig itemDisplayConfig, CarouselConfig carouselConfig) {
        l.g(arrayList2, (String)"bodyDataItems");
        this.a = n;
        this.b = n2;
        this.c = homeScreenItemBody;
        this.d = arrayList;
        this.e = bl;
        this.f = arrayList2;
        this.g = pictureObject;
        this.h = pictureObject2;
        this.i = string;
        this.j = string2;
        this.k = string3;
        this.s = string4;
        this.t = string5;
        this.u = string6;
        this.v = homeScreenItemBodyQuestionData;
        this.w = questionCollectionModel;
        this.x = string7;
        this.y = string8;
        this.z = bl2;
        this.A = analytics;
        this.B = itemDisplayConfig;
        this.C = carouselConfig;
    }

    public final Analytics a() {
        return this.A;
    }

    public final String b() {
        return this.t;
    }

    public final ArrayList<String> c() {
        return this.d;
    }

    public final ArrayList<BodyDataItem> d() {
        return this.f;
    }

    public int describeContents() {
        return 0;
    }

    public final CarouselConfig e() {
        return this.C;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof HomeScreenItemBodyData)) break block3;
                HomeScreenItemBodyData homeScreenItemBodyData = (HomeScreenItemBodyData)object;
                if (l.c((Object)this.a, (Object)homeScreenItemBodyData.a) && l.c((Object)this.b, (Object)homeScreenItemBodyData.b) && l.c((Object)this.c, (Object)homeScreenItemBodyData.c) && l.c(this.d, homeScreenItemBodyData.d) && this.e == homeScreenItemBodyData.e && l.c(this.f, homeScreenItemBodyData.f) && l.c((Object)this.g, (Object)homeScreenItemBodyData.g) && l.c((Object)this.h, (Object)homeScreenItemBodyData.h) && l.c((Object)this.i, (Object)homeScreenItemBodyData.i) && l.c((Object)this.j, (Object)homeScreenItemBodyData.j) && l.c((Object)this.k, (Object)homeScreenItemBodyData.k) && l.c((Object)this.s, (Object)homeScreenItemBodyData.s) && l.c((Object)this.t, (Object)homeScreenItemBodyData.t) && l.c((Object)this.u, (Object)homeScreenItemBodyData.u) && l.c((Object)this.v, (Object)homeScreenItemBodyData.v) && l.c((Object)((Object)this.w), (Object)((Object)homeScreenItemBodyData.w)) && l.c((Object)this.x, (Object)homeScreenItemBodyData.x) && l.c((Object)this.y, (Object)homeScreenItemBodyData.y) && l.c((Object)this.z, (Object)homeScreenItemBodyData.z) && l.c((Object)this.A, (Object)homeScreenItemBodyData.A) && l.c((Object)this.B, (Object)homeScreenItemBodyData.B) && l.c((Object)this.C, (Object)homeScreenItemBodyData.C)) break block2;
            }
            return false;
        }
        return true;
    }

    public final QuestionCollectionModel f() {
        return this.w;
    }

    public final PictureObject g() {
        return this.g;
    }

    public final String h() {
        return this.y;
    }

    public int hashCode() {
        Integer n = this.a;
        int n2 = n != null ? n.hashCode() : 0;
        int n3 = n2 * 31;
        Integer n4 = this.b;
        int n5 = n4 != null ? n4.hashCode() : 0;
        int n6 = 31 * (n3 + n5);
        HomeScreenItemBody homeScreenItemBody = this.c;
        int n7 = homeScreenItemBody != null ? homeScreenItemBody.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        ArrayList<String> arrayList = this.d;
        int n9 = arrayList != null ? arrayList.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        int n11 = this.e ? 1 : 0;
        if (n11 != 0) {
            n11 = 1;
        }
        int n12 = 31 * (n10 + n11);
        ArrayList<BodyDataItem> arrayList2 = this.f;
        int n13 = arrayList2 != null ? arrayList2.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        PictureObject pictureObject = this.g;
        int n15 = pictureObject != null ? pictureObject.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        PictureObject pictureObject2 = this.h;
        int n17 = pictureObject2 != null ? pictureObject2.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string = this.i;
        int n19 = string != null ? string.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        String string2 = this.j;
        int n21 = string2 != null ? string2.hashCode() : 0;
        int n22 = 31 * (n20 + n21);
        String string3 = this.k;
        int n23 = string3 != null ? string3.hashCode() : 0;
        int n24 = 31 * (n22 + n23);
        String string4 = this.s;
        int n25 = string4 != null ? string4.hashCode() : 0;
        int n26 = 31 * (n24 + n25);
        String string5 = this.t;
        int n27 = string5 != null ? string5.hashCode() : 0;
        int n28 = 31 * (n26 + n27);
        String string6 = this.u;
        int n29 = string6 != null ? string6.hashCode() : 0;
        int n30 = 31 * (n28 + n29);
        HomeScreenItemBodyQuestionData homeScreenItemBodyQuestionData = this.v;
        int n31 = homeScreenItemBodyQuestionData != null ? homeScreenItemBodyQuestionData.hashCode() : 0;
        int n32 = 31 * (n30 + n31);
        QuestionCollectionModel questionCollectionModel = this.w;
        int n33 = questionCollectionModel != null ? questionCollectionModel.hashCode() : 0;
        int n34 = 31 * (n32 + n33);
        String string7 = this.x;
        int n35 = string7 != null ? string7.hashCode() : 0;
        int n36 = 31 * (n34 + n35);
        String string8 = this.y;
        int n37 = string8 != null ? string8.hashCode() : 0;
        int n38 = 31 * (n36 + n37);
        Boolean bl = this.z;
        int n39 = bl != null ? bl.hashCode() : 0;
        int n40 = 31 * (n38 + n39);
        Analytics analytics = this.A;
        int n41 = analytics != null ? analytics.hashCode() : 0;
        int n42 = 31 * (n40 + n41);
        ItemDisplayConfig itemDisplayConfig = this.B;
        int n43 = itemDisplayConfig != null ? itemDisplayConfig.hashCode() : 0;
        int n44 = 31 * (n42 + n43);
        CarouselConfig carouselConfig = this.C;
        int n45 = 0;
        if (carouselConfig != null) {
            n45 = carouselConfig.hashCode();
        }
        return n44 + n45;
    }

    public final String i() {
        return this.k;
    }

    public final Boolean j() {
        return this.z;
    }

    public final PictureObject k() {
        return this.h;
    }

    public final ItemDisplayConfig l() {
        return this.B;
    }

    public final Integer m() {
        return this.a;
    }

    public final Integer n() {
        return this.b;
    }

    public final String o() {
        return this.u;
    }

    public final String p() {
        return this.x;
    }

    public final boolean q() {
        return this.e;
    }

    public final HomeScreenItemBodyQuestionData r() {
        return this.v;
    }

    public final HomeScreenItemBody s() {
        return this.c;
    }

    public final String t() {
        return this.s;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("HomeScreenItemBodyData(noOfColumns=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", noOfRows=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", stickyViewData=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", bgColorList=");
        stringBuilder.append(this.d);
        stringBuilder.append(", showBgImage=");
        stringBuilder.append(this.e);
        stringBuilder.append(", bodyDataItems=");
        stringBuilder.append(this.f);
        stringBuilder.append(", coverImage=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", image=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", themingColor=");
        stringBuilder.append(this.i);
        stringBuilder.append(", title=");
        stringBuilder.append(this.j);
        stringBuilder.append(", eventData=");
        stringBuilder.append(this.k);
        stringBuilder.append(", subTitle=");
        stringBuilder.append(this.s);
        stringBuilder.append(", bgColor=");
        stringBuilder.append(this.t);
        stringBuilder.append(", questionType=");
        stringBuilder.append(this.u);
        stringBuilder.append(", singleSelectData=");
        stringBuilder.append((Object)this.v);
        stringBuilder.append(", collectiveData=");
        stringBuilder.append((Object)this.w);
        stringBuilder.append(", rateCardUrl=");
        stringBuilder.append(this.x);
        stringBuilder.append(", displaySize=");
        stringBuilder.append(this.y);
        stringBuilder.append(", hasMoreReviews=");
        stringBuilder.append((Object)this.z);
        stringBuilder.append(", analytics=");
        stringBuilder.append((Object)this.A);
        stringBuilder.append(", itemDisplayConfig=");
        stringBuilder.append((Object)this.B);
        stringBuilder.append(", carouselConfig=");
        stringBuilder.append((Object)this.C);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final String u() {
        return this.j;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        Integer n2 = this.a;
        if (n2 != null) {
            parcel.writeInt(1);
            parcel.writeInt(n2.intValue());
        } else {
            parcel.writeInt(0);
        }
        Integer n3 = this.b;
        if (n3 != null) {
            parcel.writeInt(1);
            parcel.writeInt(n3.intValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.c, n);
        ArrayList<String> arrayList = this.d;
        if (arrayList != null) {
            parcel.writeInt(1);
            parcel.writeInt(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                parcel.writeString((String)iterator.next());
            }
        } else {
            parcel.writeInt(0);
        }
        parcel.writeInt((int)this.e);
        ArrayList<BodyDataItem> arrayList2 = this.f;
        parcel.writeInt(arrayList2.size());
        Iterator iterator = arrayList2.iterator();
        while (iterator.hasNext()) {
            ((BodyDataItem)iterator.next()).writeToParcel(parcel, 0);
        }
        parcel.writeParcelable((Parcelable)this.g, n);
        parcel.writeParcelable((Parcelable)this.h, n);
        parcel.writeString(this.i);
        parcel.writeString(this.j);
        parcel.writeString(this.k);
        parcel.writeString(this.s);
        parcel.writeString(this.t);
        parcel.writeString(this.u);
        parcel.writeParcelable((Parcelable)this.v, n);
        parcel.writeParcelable((Parcelable)this.w, n);
        parcel.writeString(this.x);
        parcel.writeString(this.y);
        Boolean bl = this.z;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.A, n);
        ItemDisplayConfig itemDisplayConfig = this.B;
        if (itemDisplayConfig != null) {
            parcel.writeInt(1);
            itemDisplayConfig.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        CarouselConfig carouselConfig = this.C;
        if (carouselConfig != null) {
            parcel.writeInt(1);
            carouselConfig.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<HomeScreenItemBodyData> {
        public final HomeScreenItemBodyData a(Parcel parcel) {
            ArrayList arrayList;
            Boolean bl;
            int n;
            l.g((Object)parcel, (String)"in");
            Integer n2 = parcel.readInt() != 0 ? Integer.valueOf((int)parcel.readInt()) : null;
            Integer n3 = parcel.readInt() != 0 ? Integer.valueOf((int)parcel.readInt()) : null;
            HomeScreenItemBody homeScreenItemBody = (HomeScreenItemBody)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            if (parcel.readInt() != 0) {
                int n4;
                arrayList = new ArrayList(n4);
                for (n4 = parcel.readInt(); n4 != 0; --n4) {
                    arrayList.add((Object)parcel.readString());
                }
            } else {
                arrayList = null;
            }
            int n5 = parcel.readInt();
            boolean bl2 = true;
            boolean bl3 = n5 != 0;
            ArrayList arrayList2 = new ArrayList(n);
            for (n = parcel.readInt(); n != 0; --n) {
                arrayList2.add((Object)((BodyDataItem)BodyDataItem.CREATOR.createFromParcel(parcel)));
            }
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            PictureObject pictureObject2 = (PictureObject)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            String string4 = parcel.readString();
            String string5 = parcel.readString();
            String string6 = parcel.readString();
            HomeScreenItemBodyQuestionData homeScreenItemBodyQuestionData = (HomeScreenItemBodyQuestionData)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            QuestionCollectionModel questionCollectionModel = (QuestionCollectionModel)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            String string7 = parcel.readString();
            String string8 = parcel.readString();
            if (parcel.readInt() != 0) {
                if (parcel.readInt() == 0) {
                    bl2 = false;
                }
                bl = bl2;
            } else {
                bl = null;
            }
            Analytics analytics = (Analytics)parcel.readParcelable(HomeScreenItemBodyData.class.getClassLoader());
            ItemDisplayConfig itemDisplayConfig = parcel.readInt() != 0 ? (ItemDisplayConfig)ItemDisplayConfig.CREATOR.createFromParcel(parcel) : null;
            CarouselConfig carouselConfig = parcel.readInt() != 0 ? (CarouselConfig)CarouselConfig.CREATOR.createFromParcel(parcel) : null;
            HomeScreenItemBodyData homeScreenItemBodyData = new HomeScreenItemBodyData(n2, n3, homeScreenItemBody, (ArrayList<String>)arrayList, bl3, (ArrayList<BodyDataItem>)arrayList2, pictureObject, pictureObject2, string, string2, string3, string4, string5, string6, homeScreenItemBodyQuestionData, questionCollectionModel, string7, string8, bl, analytics, itemDisplayConfig, carouselConfig);
            return homeScreenItemBodyData;
        }

        public final HomeScreenItemBodyData[] b(int n) {
            return new HomeScreenItemBodyData[n];
        }
    }

}

