/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  t1.r.k.g.k0.z.e.e0
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.CTAModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.io.Serializable;
import java.util.ArrayList;
import t1.r.k.g.k0.z.e.e0;

public final class RequestBody
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="line_items")
    private final ArrayList<e0<String, String>> a;
    @SerializedName(value="cta")
    private final CTAModel b;

    public RequestBody(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((ArrayList<e0<String, String>>)((ArrayList)parcel.readSerializable()), (CTAModel)parcel.readParcelable(CTAModel.class.getClassLoader()));
    }

    public RequestBody(ArrayList<e0<String, String>> arrayList, CTAModel cTAModel) {
        this.a = arrayList;
        this.b = cTAModel;
    }

    public final CTAModel a() {
        return this.b;
    }

    public final ArrayList<e0<String, String>> b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof RequestBody)) break block3;
                RequestBody requestBody = (RequestBody)object;
                if (l.c(this.a, requestBody.a) && l.c((Object)this.b, (Object)requestBody.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        ArrayList<e0<String, String>> arrayList = this.a;
        int n = arrayList != null ? arrayList.hashCode() : 0;
        int n2 = n * 31;
        CTAModel cTAModel = this.b;
        int n3 = 0;
        if (cTAModel != null) {
            n3 = cTAModel.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RequestBody(items=");
        stringBuilder.append(this.a);
        stringBuilder.append(", cta=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeSerializable(this.a);
        parcel.writeParcelable((Parcelable)this.b, 0);
    }

    public static final class a
    implements Parcelable.Creator<RequestBody> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public RequestBody a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new RequestBody(parcel);
        }

        public RequestBody[] b(int n) {
            return new RequestBody[n];
        }
    }

}

