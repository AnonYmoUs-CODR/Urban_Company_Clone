/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.ImageInfo;
import i2.a0.d.l;

public final class VaccinationInfo
implements Parcelable {
    public static final Parcelable.Creator<VaccinationInfo> CREATOR = new a();
    @SerializedName(value="image")
    private final ImageInfo a;
    @SerializedName(value="title")
    private final String b;

    public VaccinationInfo(ImageInfo imageInfo, String string) {
        this.a = imageInfo;
        this.b = string;
    }

    public final ImageInfo a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof VaccinationInfo)) break block3;
                VaccinationInfo vaccinationInfo = (VaccinationInfo)object;
                if (l.c((Object)this.a, (Object)vaccinationInfo.a) && l.c((Object)this.b, (Object)vaccinationInfo.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        ImageInfo imageInfo = this.a;
        int n = imageInfo != null ? imageInfo.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = 0;
        if (string != null) {
            n3 = string.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("VaccinationInfo(image=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", title=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        ImageInfo imageInfo = this.a;
        if (imageInfo != null) {
            parcel.writeInt(1);
            imageInfo.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<VaccinationInfo> {
        public final VaccinationInfo a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            ImageInfo imageInfo = parcel.readInt() != 0 ? (ImageInfo)ImageInfo.CREATOR.createFromParcel(parcel) : null;
            return new VaccinationInfo(imageInfo, parcel.readString());
        }

        public final VaccinationInfo[] b(int n) {
            return new VaccinationInfo[n];
        }
    }

}

