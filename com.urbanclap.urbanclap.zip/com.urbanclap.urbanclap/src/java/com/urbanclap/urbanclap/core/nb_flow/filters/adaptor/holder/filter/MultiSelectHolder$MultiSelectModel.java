/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder$FilterSelectBaseModel
 *  com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.MultiSelectHolder$MultiSelectModel$a
 */
package com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.FilterSelectBaseHolder;
import com.urbanclap.urbanclap.core.nb_flow.filters.adaptor.holder.filter.MultiSelectHolder$MultiSelectModel;

public class MultiSelectHolder$MultiSelectModel
extends FilterSelectBaseHolder.FilterSelectBaseModel {
    public static final Parcelable.Creator<MultiSelectHolder$MultiSelectModel> CREATOR = new a();

    public MultiSelectHolder$MultiSelectModel(Parcel parcel) {
        super(parcel);
    }
}

