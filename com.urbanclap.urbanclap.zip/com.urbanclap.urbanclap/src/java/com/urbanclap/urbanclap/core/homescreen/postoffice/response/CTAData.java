/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.extras.TapAction
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.CtaType;
import com.urbanclap.urbanclap.ucshared.extras.TapAction;
import i2.a0.d.l;

public final class CTAData
implements Parcelable {
    public static final Parcelable.Creator<CTAData> CREATOR = new a();
    @SerializedName(value="bg_color")
    private final String a;
    @SerializedName(value="border_color")
    private final String b;
    @SerializedName(value="text")
    private final String c;
    @SerializedName(value="tap_action")
    private final TapAction d;
    @SerializedName(value="text_color")
    private final String e;
    @SerializedName(value="type")
    private final CtaType f;

    public CTAData(String string, String string2, String string3, TapAction tapAction, String string4, CtaType ctaType) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = tapAction;
        this.e = string4;
        this.f = ctaType;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final TapAction c() {
        return this.d;
    }

    public final String d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CTAData)) break block3;
                CTAData cTAData = (CTAData)object;
                if (l.c((Object)this.a, (Object)cTAData.a) && l.c((Object)this.b, (Object)cTAData.b) && l.c((Object)this.c, (Object)cTAData.c) && l.c((Object)this.d, (Object)cTAData.d) && l.c((Object)this.e, (Object)cTAData.e) && l.c((Object)((Object)this.f), (Object)((Object)cTAData.f))) break block2;
            }
            return false;
        }
        return true;
    }

    public final CtaType f() {
        return this.f;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        TapAction tapAction = this.d;
        int n7 = tapAction != null ? tapAction.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string4 = this.e;
        int n9 = string4 != null ? string4.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        CtaType ctaType = this.f;
        int n11 = 0;
        if (ctaType != null) {
            n11 = ctaType.hashCode();
        }
        return n10 + n11;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CTAData(bgColor=");
        stringBuilder.append(this.a);
        stringBuilder.append(", borderColor=");
        stringBuilder.append(this.b);
        stringBuilder.append(", text=");
        stringBuilder.append(this.c);
        stringBuilder.append(", tapAction=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", textColor=");
        stringBuilder.append(this.e);
        stringBuilder.append(", type=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeParcelable((Parcelable)this.d, n);
        parcel.writeString(this.e);
        CtaType ctaType = this.f;
        if (ctaType != null) {
            parcel.writeInt(1);
            parcel.writeString(ctaType.name());
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<CTAData> {
        public final CTAData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            TapAction tapAction = (TapAction)parcel.readParcelable(CTAData.class.getClassLoader());
            String string4 = parcel.readString();
            CtaType ctaType = parcel.readInt() != 0 ? (CtaType)Enum.valueOf(CtaType.class, (String)parcel.readString()) : null;
            CTAData cTAData = new CTAData(string, string2, string3, tapAction, string4, ctaType);
            return cTAData;
        }

        public final CTAData[] b(int n) {
            return new CTAData[n];
        }
    }

}

