/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.BlockerCta
 *  com.urbanclap.urbanclap.core.homescreen.postoffice.response.BlockerView
 *  com.urbanclap.urbanclap.ucshared.extras.TrackingData
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.BlockerCta;
import com.urbanclap.urbanclap.core.homescreen.postoffice.response.BlockerView;
import com.urbanclap.urbanclap.ucshared.extras.TrackingData;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class Template
implements Parcelable {
    public static final Parcelable.Creator<Template> CREATOR = new a();
    @SerializedName(value="image")
    private final PictureObject a;
    @SerializedName(value="title")
    private final String b;
    @SerializedName(value="subtitle")
    private final String c;
    @SerializedName(value="label")
    private final BlockerView d;
    @SerializedName(value="isDismissable")
    private final Boolean e;
    @SerializedName(value="trackingData")
    private final TrackingData f;
    @SerializedName(value="ctas")
    private final List<BlockerCta> g;

    public Template(PictureObject pictureObject, String string, String string2, BlockerView blockerView, Boolean bl, TrackingData trackingData, List<BlockerCta> list) {
        this.a = pictureObject;
        this.b = string;
        this.c = string2;
        this.d = blockerView;
        this.e = bl;
        this.f = trackingData;
        this.g = list;
    }

    public final List<BlockerCta> a() {
        return this.g;
    }

    public final PictureObject b() {
        return this.a;
    }

    public final BlockerView c() {
        return this.d;
    }

    public final String d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public final TrackingData f() {
        return this.f;
    }

    public final Boolean g() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        BlockerView blockerView = this.d;
        if (blockerView != null) {
            parcel.writeInt(1);
            blockerView.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        Boolean bl = this.e;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.f, n);
        List<BlockerCta> list = this.g;
        if (list != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((BlockerCta)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
    }

    public static final class a
    implements Parcelable.Creator<Template> {
        public final Template a(Parcel parcel) {
            Boolean bl;
            l.g((Object)parcel, (String)"in");
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(Template.class.getClassLoader());
            String string = parcel.readString();
            String string2 = parcel.readString();
            BlockerView blockerView = parcel.readInt() != 0 ? (BlockerView)BlockerView.CREATOR.createFromParcel(parcel) : null;
            if (parcel.readInt() != 0) {
                boolean bl2 = parcel.readInt() != 0;
                bl = bl2;
            } else {
                bl = null;
            }
            TrackingData trackingData = (TrackingData)parcel.readParcelable(Template.class.getClassLoader());
            int n = parcel.readInt();
            ArrayList arrayList = null;
            if (n != 0) {
                int n2;
                arrayList = new ArrayList(n2);
                for (n2 = parcel.readInt(); n2 != 0; --n2) {
                    arrayList.add((Object)((BlockerCta)BlockerCta.CREATOR.createFromParcel(parcel)));
                }
            }
            ArrayList arrayList2 = arrayList;
            Template template = new Template(pictureObject, string, string2, blockerView, bl, trackingData, (List<BlockerCta>)arrayList2);
            return template;
        }

        public final Template[] b(int n) {
            return new Template[n];
        }
    }

}

