/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import com.google.gson.annotations.SerializedName;

public final class CtaType
extends Enum<CtaType> {
    private static final /* synthetic */ CtaType[] $VALUES;
    @SerializedName(value="button")
    public static final /* enum */ CtaType BUTTON;
    @SerializedName(value="icon")
    public static final /* enum */ CtaType ICON;

    public static {
        CtaType ctaType;
        CtaType ctaType2;
        CtaType[] arrctaType = new CtaType[2];
        BUTTON = ctaType2 = new CtaType();
        arrctaType[0] = ctaType2;
        ICON = ctaType = new CtaType();
        arrctaType[1] = ctaType;
        $VALUES = arrctaType;
    }

    public static CtaType valueOf(String string) {
        return (CtaType)Enum.valueOf(CtaType.class, (String)string);
    }

    public static CtaType[] values() {
        return (CtaType[])$VALUES.clone();
    }
}

