/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherRedeemDetailModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.voucher.MyVoucherModel;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.core.voucher.MyVoucherModel.VoucherRedeemDetailModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class VoucherRedeemDetailModel
extends ResponseBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="message")
    private final String e;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public VoucherRedeemDetailModel() {
    }

    public VoucherRedeemDetailModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
        parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.e);
    }
}

