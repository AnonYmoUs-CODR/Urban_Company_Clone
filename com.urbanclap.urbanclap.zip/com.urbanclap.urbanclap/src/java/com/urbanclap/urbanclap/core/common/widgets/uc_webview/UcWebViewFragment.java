/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.webkit.CookieManager
 *  android.webkit.ValueCallback
 *  android.webkit.WebViewClient
 *  androidx.fragment.app.Fragment
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.Observer
 *  com.urbanclap.urbanclap.core.common.widgets.uc_webview.UcWebViewFragment$a
 *  com.urbanclap.urbanclap.core.common.widgets.uc_webview.UcWebViewFragment$c
 *  com.urbanclap.urbanclap.core.common.widgets.uc_webview.UcWebViewFragment$onViewCreated
 *  com.urbanclap.urbanclap.core.common.widgets.uc_webview.UcWebViewFragment$onViewCreated$1
 *  com.urbanclap.urbanclap.core.gift_card.GiftCardPurchaseWebViewListener
 *  com.urbanclap.urbanclap.ucshared.common.web.WebViewListenerMetaData
 *  com.urbanclap.urbanclap.widgetstore.uc_webview.UcWebView
 *  i2.a0.c.a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.a0.d.m
 *  i2.f
 *  i2.h
 *  i2.h0.s
 *  i2.t
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Objects
 *  t1.r.k.g.b0.c.b.a.a
 *  t1.r.k.g.b0.c.b.a.a$a
 *  t1.r.k.g.n
 *  t1.r.k.j.i
 *  t1.r.k.n.d
 *  t1.r.k.n.r0.b
 *  t1.r.k.p.b1.c
 *  t1.r.k.p.b1.d
 */
package com.urbanclap.urbanclap.core.common.widgets.uc_webview;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebViewClient;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import com.urbanclap.urbanclap.core.common.widgets.uc_webview.UcWebViewFragment;
import com.urbanclap.urbanclap.core.gift_card.GiftCardPurchaseWebViewListener;
import com.urbanclap.urbanclap.ucshared.common.web.WebViewListenerMetaData;
import com.urbanclap.urbanclap.widgetstore.uc_webview.UcWebView;
import i2.a0.d.g;
import i2.a0.d.l;
import i2.a0.d.m;
import i2.h;
import i2.h0.s;
import i2.t;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import t1.r.k.g.b0.c.b.a.a;
import t1.r.k.g.k0.r;
import t1.r.k.g.n;
import t1.r.k.g.o;
import t1.r.k.j.i;

/*
 * Exception performing whole class analysis.
 */
public final class UcWebViewFragment
extends Fragment
implements t1.r.k.p.b1.c {
    public static final a j;
    public final i2.f a;
    public final i2.f b;
    public final i2.f c;
    public t1.r.k.p.b1.d d;
    public final i2.f e;
    public i2.a0.c.a<t> f;
    public boolean g;
    public String h;
    public HashMap i;

    public static {
        j = new /* Unavailable Anonymous Inner Class!! */;
    }

    public UcWebViewFragment() {
        this.a = h.b((i2.a0.c.a)new i2.a0.c.a<String>(){

            public final String a() {
                Bundle bundle = this.getArguments();
                if (bundle != null) {
                    return bundle.getString(t1.r.k.g.b0.c.b.a.a.l.k());
                }
                return null;
            }
        });
        this.b = h.b((i2.a0.c.a)new i2.a0.c.a<String>(){

            public final String a() {
                Bundle bundle = this.getArguments();
                if (bundle != null) {
                    return bundle.getString(t1.r.k.g.b0.c.b.a.a.l.b());
                }
                return null;
            }
        });
        this.c = h.b((i2.a0.c.a)new i2.a0.c.a<WebViewListenerMetaData>(){

            public final WebViewListenerMetaData a() {
                Bundle bundle = this.getArguments();
                WebViewListenerMetaData webViewListenerMetaData = bundle != null ? (WebViewListenerMetaData)bundle.getParcelable(t1.r.k.g.b0.c.b.a.a.l.h()) : null;
                Objects.requireNonNull(webViewListenerMetaData, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.common.web.WebViewListenerMetaData");
                return webViewListenerMetaData;
            }
        });
        this.e = h.b((i2.a0.c.a)new i2.a0.c.a<String>(){

            public final String a() {
                Bundle bundle = this.getArguments();
                if (bundle != null) {
                    return bundle.getString(t1.r.k.g.b0.c.b.a.a.l.j());
                }
                return null;
            }
        });
    }

    public static final /* synthetic */ t1.r.k.p.b1.d Ca(UcWebViewFragment ucWebViewFragment) {
        return ucWebViewFragment.d;
    }

    public static final /* synthetic */ String Da(UcWebViewFragment ucWebViewFragment) {
        return ucWebViewFragment.Ha();
    }

    public static final /* synthetic */ void Ea(UcWebViewFragment ucWebViewFragment, String string) {
        ucWebViewFragment.h = string;
    }

    public void Aa() {
        HashMap hashMap = this.i;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View Ba(int n2) {
        View view;
        if (this.i == null) {
            this.i = new HashMap();
        }
        if ((view = (View)this.i.get((Object)n2)) == null) {
            View view2 = this.getView();
            if (view2 == null) {
                return null;
            }
            view = view2.findViewById(n2);
            this.i.put((Object)n2, (Object)view);
        }
        return view;
    }

    public final void Fa() {
        ((UcWebView)this.Ba(n.af)).e();
    }

    public final String Ga() {
        return (String)this.b.getValue();
    }

    public final String Ha() {
        return (String)this.e.getValue();
    }

    public final String Ia() {
        return (String)this.a.getValue();
    }

    public final WebViewListenerMetaData Ja() {
        return (WebViewListenerMetaData)this.c.getValue();
    }

    public final boolean Ka() {
        if (this.g) {
            return true;
        }
        t1.r.k.p.b1.d d2 = this.d;
        if (d2 != null) {
            l.e((Object)d2);
            if (!d2.b(this.h)) {
                return false;
            }
        }
        return ((UcWebView)this.Ba(n.af)).j();
    }

    public final void La(i2.a0.c.a<t> a2) {
        l.g(a2, (String)"dismissAction");
        this.f = a2;
    }

    public final void Ma() {
        t1.r.k.n.r0.b.b.c().observe((LifecycleOwner)this, (Observer)new c(this));
    }

    public void onActivityResult(int n2, int n3, Intent intent) {
        ((UcWebView)this.Ba(n.af)).i(n2, n3, intent);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        l.g((Object)layoutInflater, (String)"inflater");
        try {
            this.g = false;
            View view = layoutInflater.inflate(o.W3, viewGroup, false);
            return view;
        }
        catch (Exception exception) {
            this.g = true;
            return layoutInflater.inflate(o.E, viewGroup, false);
        }
    }

    public /* synthetic */ void onDestroyView() {
        super.onDestroyView();
        this.Aa();
    }

    public void onDismiss() {
        i2.a0.c.a<t> a2 = this.f;
        if (a2 != null) {
            (t)a2.invoke();
        }
    }

    public void onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        l.g((Object)arrstring, (String)"permissions");
        l.g((Object)arrn, (String)"grantResults");
        super.onRequestPermissionsResult(n2, arrstring, arrn);
        ((UcWebView)this.Ba(n.af)).k(n2, arrstring, arrn);
    }

    public void onStart() {
        super.onStart();
        ((UcWebView)this.Ba(n.af)).f("JSInterface && JSInterface.onAppForeground && JSInterface.onAppForeground()", null);
    }

    public void onStop() {
        super.onStop();
        ((UcWebView)this.Ba(n.af)).f("JSInterface && JSInterface.onAppBackground && JSInterface.onAppBackground()", null);
    }

    public void onViewCreated(View view, Bundle bundle) {
        Object object;
        a.a a2;
        l.g((Object)view, (String)"view");
        super.onViewCreated(view, bundle);
        if (this.g) {
            return;
        }
        String string = this.Ha();
        if (l.c((Object)string, (Object)(a2 = t1.r.k.g.b0.c.b.a.a.l).e())) {
            Context context = this.getContext();
            l.e((Object)context);
            l.f((Object)context, (String)"context!!");
            object = new t1.r.k.g.i0.b(this, context, this);
        } else if (l.c((Object)string, (Object)a2.a())) {
            Context context = this.getContext();
            l.e((Object)context);
            l.f((Object)context, (String)"context!!");
            object = new t1.r.k.g.o0.d.a.b(this, context, this);
        } else if (l.c((Object)string, (Object)a2.d())) {
            Context context = this.getContext();
            l.e((Object)context);
            l.f((Object)context, (String)"context!!");
            object = new GiftCardPurchaseWebViewListener((Fragment)this, context, (t1.r.k.p.b1.c)this, this.Ja());
        } else if (l.c((Object)string, (Object)a2.g()) || l.c((Object)string, (Object)a2.f())) {
            Context context = this.getContext();
            l.e((Object)context);
            l.f((Object)context, (String)"context!!");
            object = new r(this, context, this);
        } else if (l.c((Object)string, (Object)a2.i())) {
            Context context = this.getContext();
            l.e((Object)context);
            l.f((Object)context, (String)"context!!");
            object = new i((Fragment)this, context, (t1.r.k.p.b1.c)this);
        } else {
            object = null;
        }
        this.d = object;
        int n2 = n.af;
        ((UcWebView)this.Ba(n2)).m((Fragment)this, this.d);
        ((UcWebView)this.Ba(n2)).d();
        ((UcWebView)this.Ba(n2)).requestFocus(130);
        String string2 = this.Ga();
        List list = null;
        if (string2 != null) {
            list = s.n0((CharSequence)string2, (String[])new String[]{";"}, (boolean)false, (int)0, (int)6, null);
        }
        if (list != null) {
            for (String string3 : list) {
                CookieManager.getInstance().setCookie(t1.r.k.n.d.c, string3);
                CookieManager.getInstance().setCookie("https://www.urbancompany.com/", string3);
                CookieManager.getInstance().setCookie("https://chat.urbancompany.com/", string3);
            }
        }
        String string4 = this.Ia();
        int n3 = n.af;
        UcWebView ucWebView = (UcWebView)this.Ba(n3);
        l.e((Object)string4);
        ucWebView.h(string4);
        this.Ma();
        ((UcWebView)this.Ba(n3)).setWebViewClient((WebViewClient)new onViewCreated.1(this));
    }

}

