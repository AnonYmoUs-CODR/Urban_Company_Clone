/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.core.homescreen.postoffice.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class Overlay
implements Parcelable {
    public static final Parcelable.Creator<Overlay> CREATOR = new Parcelable.Creator<Overlay>(){

        public Overlay a(Parcel parcel) {
            l.g((Object)parcel, (String)"source");
            return new Overlay(parcel);
        }

        public Overlay[] b(int n) {
            return new Overlay[n];
        }
    };
    @SerializedName(value="text")
    private final String a;
    @SerializedName(value="tint_color")
    private final String b;
    @SerializedName(value="text_color")
    private final String c;

    public Overlay(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        this(parcel.readString(), parcel.readString(), parcel.readString());
    }

    public Overlay(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }

}

