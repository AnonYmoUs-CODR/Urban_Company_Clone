/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.recyclerview.widget.GridLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$State
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap;

import android.content.Context;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import i2.a0.d.l;
import t1.r.k.a;

public final class UcGridLayoutManager
extends GridLayoutManager {
    public final a a;

    public UcGridLayoutManager(Context context, a a2, int n2) {
        l.g((Object)context, (String)"context");
        l.g((Object)a2, (String)"listener");
        super(context, n2);
        this.a = a2;
    }

    public void onLayoutCompleted(RecyclerView.State state) {
        super.onLayoutCompleted(state);
        this.a.a();
    }

    public boolean supportsPredictiveItemAnimations() {
        return false;
    }
}

