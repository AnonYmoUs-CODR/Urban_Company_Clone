/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  com.google.gson.Gson
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$ConfigModel
 *  com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel$PriceModel
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.b.b.c.a
 *  t1.r.b.c.d
 *  t1.r.b.c.f
 *  t1.r.k.j.e0.d
 *  t1.r.k.j.u
 *  t1.r.k.n.c
 *  t1.r.k.n.c$b
 *  t1.r.k.n.n0.d
 *  t1.r.k.n.w0.f
 */
package com.urbanclap.urbanclap.payments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.google.gson.Gson;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import com.urbanclap.urbanclap.ucshared.models.PackageCartItem;
import com.urbanclap.urbanclap.ucshared.models.create_request.NewPackageItemModel;
import com.urbanclap.urbanclap.ucshared.models.uccart.CartRepository;
import i2.a0.d.l;
import i2.h0.r;
import java.util.ArrayList;
import java.util.List;
import t1.r.b.b.c.a;
import t1.r.k.j.u;
import t1.r.k.n.c;
import t1.r.k.n.n0.d;
import t1.r.k.n.w0.f;

public final class ThirdPartyEventsReceiver
extends BroadcastReceiver {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onReceive(Context var1_1, Intent var2_2) {
        l.g((Object)var1_1, (String)"context");
        l.g((Object)var2_2, (String)"intent");
        var3_3 = var2_2.getStringExtra("userSubscriptionID");
        var4_4 = "categoryKey";
        var5_5 = var2_2.getStringExtra(var4_4);
        var6_6 = var2_2.getStringExtra("requestId");
        var7_7 = var2_2.getDoubleExtra("amount", 0.0);
        var9_8 = var2_2.getStringExtra("paymentMode");
        var10_9 = "preRequestCode";
        var11_10 = var2_2.getStringExtra(var10_9);
        var12_11 = "bookingTime";
        var13_12 = var2_2.getStringExtra(var12_11);
        var2_2.getStringExtra("eventPageSource");
        var15_13 = var2_2.getBooleanExtra("fireCleverTap", false);
        var16_14 = (CartRepository)CartRepository.l.a();
        var17_15 = t1.r.b.c.d.a;
        var18_16 = u.a;
        var19_17 = f.c;
        var20_18 = new ArrayList();
        for (PackageCartItem var54_25 : var16_14.e()) {
            block18 : {
                block17 : {
                    if (var54_25.c() == null) break block17;
                    var59_30 = var18_16;
                    var60_31 = var54_25.c();
                    var57_28 = var12_11;
                    l.f((Object)var60_31, (String)"cartItemValue.getmItem()");
                    if (var60_31.i() == null) ** GOTO lbl-1000
                    var61_32 = var54_25.c();
                    l.f((Object)var61_32, (String)"cartItemValue.getmItem()");
                    if (var61_32.q() != null) {
                        var58_29 = var13_12;
                        var62_33 = var54_25.c();
                        l.f((Object)var62_33, (String)"cartItemValue.getmItem()");
                        var63_34 = var62_33.k();
                        var55_26 = var4_4;
                        var64_20 = var54_25.c();
                        l.f((Object)var64_20, (String)"cartItemValue.getmItem()");
                        var65_21 = var64_20.i();
                        var56_27 = var10_9;
                        l.f((Object)var65_21, (String)"cartItemValue.getmItem().itemConfiguration");
                        var66_22 = var65_21.b();
                        var67_23 = var54_25.c();
                        l.f((Object)var67_23, (String)"cartItemValue.getmItem()");
                        var68_24 = var67_23.q();
                        l.e((Object)var68_24);
                        l.f((Object)var68_24, (String)"cartItemValue.getmItem().price!!");
                        var20_18.add((Object)new t1.r.k.j.e0.d(var63_34, var66_22, var68_24.b()));
                    } else lbl-1000: // 2 sources:
                    {
                        var55_26 = var4_4;
                        var56_27 = var10_9;
                        var58_29 = var13_12;
                    }
                    break block18;
                }
                var55_26 = var4_4;
                var56_27 = var10_9;
                var57_28 = var12_11;
                var58_29 = var13_12;
                var59_30 = var18_16;
            }
            var18_16 = var59_30;
            var12_11 = var57_28;
            var13_12 = var58_29;
            var4_4 = var55_26;
            var10_9 = var56_27;
        }
        var22_35 = var4_4;
        var23_36 = var10_9;
        var24_37 = var12_11;
        var25_38 = var13_12;
        var26_39 = var18_16;
        var16_14.c();
        var27_40 = var3_3 == null || r.y(var3_3);
        if (!var27_40) {
            var49_41 = AnalyticsTriggers.SubscriptionPurchaseSuccessfulQnaFlow;
            var50_42 = t1.r.b.c.f.a();
            var50_42.B(var3_3);
            var50_42.p(f.c.b());
            var50_42.i(var5_5);
            l.f((Object)var50_42, (String)"AnalyticsProps.create()\n\u2026tCategoryKey(categoryKey)");
            var17_15.D0(var49_41, var50_42);
        }
        if (var15_13) {
            l.f((Object)var6_6, (String)"requestId");
            l.f((Object)var9_8, (String)"paymentMode");
            l.f((Object)var11_10, (String)var23_36);
            var33_43 = var22_35;
            l.f((Object)var5_5, (String)var33_43);
            l.f((Object)var25_38, (String)var24_37);
            var28_44 = var17_15;
            var31_45 = var7_7;
            var29_46 = var20_18;
            var34_47 = var6_6;
            var30_48 = var5_5;
            var26_39.b("success", var7_7, var6_6, var9_8, var11_10, (t1.r.b.c.l)var17_15, var5_5, var25_38, null, "pre", null, null);
        } else {
            var28_44 = var17_15;
            var29_46 = var20_18;
            var30_48 = var5_5;
            var31_45 = var7_7;
            var33_43 = var22_35;
            var34_47 = var6_6;
        }
        var35_49 = new Gson().s((Object)var29_46);
        l.f((Object)var30_48, (String)var33_43);
        var36_50 = c.c;
        var37_51 = var36_50.r(d.c.c());
        var38_52 = (int)var31_45;
        var26_39.f("REQUEST_SUBMITTED", false, var30_48, 0, 0, var37_51, null, var38_52, var35_49, var34_47);
        if (var19_17.a() != null) {
            var48_53 = l.c((Object)var19_17.a(), (Object)"male") != false ? "REQUEST_SUBMITTED_MALE" : "REQUEST_SUBMITTED_FEMALE";
            var26_39.d(var48_53, false, var30_48, 0, 0);
        }
        if (var19_17.a() != null && var19_17.j() != null && (r.w("new_user", var19_17.j(), true) || l.c((Object)"no_request_user", (Object)var19_17.j()))) {
            var47_54 = l.c((Object)var19_17.a(), (Object)"male") != false ? "REQUEST_SUBMITTED_MALE_NEW" : "REQUEST_SUBMITTED_FEMALE_NEW";
            if (r.w(var47_54, "REQUEST_SUBMITTED_FEMALE_NEW", true)) {
                if (r.w(var30_48, "salon_at_home", true) || r.w(var30_48, "spa_at_home", true) || r.w(var30_48, "party_makeup_artist", true) || a.a.contains((Object)var30_48)) {
                    var26_39.d(var47_54, false, var30_48, 0, 0);
                }
            } else {
                var26_39.d(var47_54, false, var30_48, 0, 0);
            }
        }
        if (r.w(var30_48, "salon_at_home", true)) {
            var40_55 = "REQUEST_SUBMITTED_SALON";
        } else if (r.w(var30_48, "ac_service_repair", true)) {
            var40_55 = "REQUEST_SUBMITTED_AC_SERVICING_REPAIR";
        } else {
            var39_57 = r.w(var30_48, "massage_for_men", true);
            var40_55 = null;
            if (var39_57) {
                var40_55 = "REQUEST_SUBMITTED_MASSAGE_FOR_MEN";
            }
        }
        var41_56 = var40_55;
        if (!var36_50.X((CharSequence)var41_56)) {
            l.e((Object)var41_56);
            var26_39.d(var41_56, false, var30_48, 0, 0);
        }
        var26_39.e(var30_48, 0);
        var42_58 = AnalyticsTriggers.Purchase;
        var43_59 = t1.r.b.c.f.a();
        var43_59.i(var30_48);
        var43_59.D(var19_17.a());
        var43_59.X(var19_17.j());
        l.f((Object)var43_59, (String)"AnalyticsProps.create()\n\u2026(loginUtil.getUserType())");
        var28_44.D0(var42_58, var43_59);
    }
}

