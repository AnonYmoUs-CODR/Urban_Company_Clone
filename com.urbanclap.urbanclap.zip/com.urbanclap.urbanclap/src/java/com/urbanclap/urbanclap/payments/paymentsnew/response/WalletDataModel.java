/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.Options
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.WalletDataModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.Options;
import com.urbanclap.urbanclap.payments.paymentsnew.response.WalletDataModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class WalletDataModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="payment_mode")
    private final String b;
    @SerializedName(value="title")
    private final String c;
    @SerializedName(value="options")
    private final ArrayList<Options> d;
    @SerializedName(value="dowtime_message")
    private final String e;
    @SerializedName(value="is_disable")
    private boolean f;
    @SerializedName(value="disable_reason")
    private final String g;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public WalletDataModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        ArrayList arrayList = parcel.readArrayList(Options.class.getClassLoader());
        String string3 = parcel.readString();
        boolean bl = parcel.readByte() != (byte)(false ? 1 : 0);
        this(string, string2, (ArrayList<Options>)arrayList, string3, bl, parcel.readString());
    }

    public WalletDataModel(String string, String string2, ArrayList<Options> arrayList, String string3, boolean bl, String string4) {
        super(null, 1, null);
        this.b = string;
        this.c = string2;
        this.d = arrayList;
        this.e = string3;
        this.f = bl;
        this.g = string4;
    }

    public final String b() {
        return this.g;
    }

    public final String c() {
        return this.e;
    }

    public final ArrayList<Options> d() {
        return this.d;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof WalletDataModel)) break block3;
                WalletDataModel walletDataModel = (WalletDataModel)((Object)object);
                if (l.c((Object)this.b, (Object)walletDataModel.b) && l.c((Object)this.c, (Object)walletDataModel.c) && l.c(this.d, walletDataModel.d) && l.c((Object)this.e, (Object)walletDataModel.e) && this.f == walletDataModel.f && l.c((Object)this.g, (Object)walletDataModel.g)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.c;
    }

    public final boolean g() {
        return this.f;
    }

    public int hashCode() {
        String string = this.b;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.c;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        ArrayList<Options> arrayList = this.d;
        int n6 = arrayList != null ? arrayList.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string3 = this.e;
        int n8 = string3 != null ? string3.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        int n10 = this.f ? 1 : 0;
        if (n10 != 0) {
            n10 = 1;
        }
        int n11 = 31 * (n9 + n10);
        String string4 = this.g;
        int n12 = 0;
        if (string4 != null) {
            n12 = string4.hashCode();
        }
        return n11 + n12;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WalletDataModel(paymentMode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", title=");
        stringBuilder.append(this.c);
        stringBuilder.append(", optionsArrayList=");
        stringBuilder.append(this.d);
        stringBuilder.append(", downtimeMessage=");
        stringBuilder.append(this.e);
        stringBuilder.append(", isDisabled=");
        stringBuilder.append(this.f);
        stringBuilder.append(", disableReason=");
        stringBuilder.append(this.g);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeTypedList(this.d);
        parcel.writeString(this.e);
        parcel.writeByte((byte)this.f);
        parcel.writeString(this.g);
    }
}

