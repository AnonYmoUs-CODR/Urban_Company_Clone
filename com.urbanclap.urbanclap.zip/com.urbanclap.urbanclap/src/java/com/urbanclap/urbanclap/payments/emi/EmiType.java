/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.payments.emi;

public final class EmiType
extends Enum<EmiType> {
    private static final /* synthetic */ EmiType[] $VALUES;
    public static final /* enum */ EmiType NO_COST;
    public static final /* enum */ EmiType STANDARD;

    public static {
        EmiType emiType;
        EmiType emiType2;
        EmiType[] arremiType = new EmiType[2];
        NO_COST = emiType = new EmiType();
        arremiType[0] = emiType;
        STANDARD = emiType2 = new EmiType();
        arremiType[1] = emiType2;
        $VALUES = arremiType;
    }

    public static EmiType valueOf(String string) {
        return (EmiType)Enum.valueOf(EmiType.class, (String)string);
    }

    public static EmiType[] values() {
        return (EmiType[])$VALUES.clone();
    }
}

