/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.payments.manage_payment_options;

public final class ManagePaymentOptionTemplateType
extends Enum<ManagePaymentOptionTemplateType> {
    private static final /* synthetic */ ManagePaymentOptionTemplateType[] $VALUES;
    public static final /* enum */ ManagePaymentOptionTemplateType CARD;
    public static final /* enum */ ManagePaymentOptionTemplateType HEADER;
    public static final /* enum */ ManagePaymentOptionTemplateType SEPERATOR;
    public static final /* enum */ ManagePaymentOptionTemplateType UPI;
    public static final /* enum */ ManagePaymentOptionTemplateType WALLET;

    public static {
        ManagePaymentOptionTemplateType managePaymentOptionTemplateType;
        ManagePaymentOptionTemplateType managePaymentOptionTemplateType2;
        ManagePaymentOptionTemplateType managePaymentOptionTemplateType3;
        ManagePaymentOptionTemplateType managePaymentOptionTemplateType4;
        ManagePaymentOptionTemplateType managePaymentOptionTemplateType5;
        ManagePaymentOptionTemplateType[] arrmanagePaymentOptionTemplateType = new ManagePaymentOptionTemplateType[5];
        UPI = managePaymentOptionTemplateType4 = new ManagePaymentOptionTemplateType();
        arrmanagePaymentOptionTemplateType[0] = managePaymentOptionTemplateType4;
        CARD = managePaymentOptionTemplateType = new ManagePaymentOptionTemplateType();
        arrmanagePaymentOptionTemplateType[1] = managePaymentOptionTemplateType;
        WALLET = managePaymentOptionTemplateType3 = new ManagePaymentOptionTemplateType();
        arrmanagePaymentOptionTemplateType[2] = managePaymentOptionTemplateType3;
        SEPERATOR = managePaymentOptionTemplateType5 = new ManagePaymentOptionTemplateType();
        arrmanagePaymentOptionTemplateType[3] = managePaymentOptionTemplateType5;
        HEADER = managePaymentOptionTemplateType2 = new ManagePaymentOptionTemplateType();
        arrmanagePaymentOptionTemplateType[4] = managePaymentOptionTemplateType2;
        $VALUES = arrmanagePaymentOptionTemplateType;
    }

    public static ManagePaymentOptionTemplateType valueOf(String string) {
        return (ManagePaymentOptionTemplateType)Enum.valueOf(ManagePaymentOptionTemplateType.class, (String)string);
    }

    public static ManagePaymentOptionTemplateType[] values() {
        return (ManagePaymentOptionTemplateType[])$VALUES.clone();
    }
}

