/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.PayWithAppDataModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.PayWithAppModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.PayWithAppDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.PayWithAppModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class PayWithAppModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final Parcelable.Creator<PayWithAppModel> CREATOR;
    @SerializedName(value="data")
    @b(className="PayWithAppDataModel", fieldName="parent")
    private final PayWithAppDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public PayWithAppModel(PayWithAppDataModel payWithAppDataModel) {
        super(null, 1, null);
        this.b = payWithAppDataModel;
    }

    public final PayWithAppDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PayWithAppModel)) break block3;
                PayWithAppModel payWithAppModel = (PayWithAppModel)((Object)object);
                if (l.c((Object)this.b, (Object)payWithAppModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        PayWithAppDataModel payWithAppDataModel = this.b;
        if (payWithAppDataModel != null) {
            return payWithAppDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PayWithAppModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        PayWithAppDataModel payWithAppDataModel = this.b;
        if (payWithAppDataModel != null) {
            parcel.writeInt(1);
            payWithAppDataModel.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }
}

