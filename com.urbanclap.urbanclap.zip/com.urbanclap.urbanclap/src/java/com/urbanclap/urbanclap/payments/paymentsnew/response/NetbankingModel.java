/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.NetbankingModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.NetbankingDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.NetbankingModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class NetbankingModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="data")
    @b(className="NetbankingModel", fieldName="parent")
    private final NetbankingDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public NetbankingModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((NetbankingDataModel)parcel.readParcelable(NetbankingDataModel.class.getClassLoader()));
    }

    public NetbankingModel(NetbankingDataModel netbankingDataModel) {
        super(null, 1, null);
        this.b = netbankingDataModel;
    }

    public final NetbankingDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof NetbankingModel)) break block3;
                NetbankingModel netbankingModel = (NetbankingModel)((Object)object);
                if (l.c((Object)((Object)this.b), (Object)((Object)netbankingModel.b))) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        NetbankingDataModel netbankingDataModel = this.b;
        if (netbankingDataModel != null) {
            return netbankingDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NetbankingModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

