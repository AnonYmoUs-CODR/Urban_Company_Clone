/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.AddCard$a
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentOptionsTemplateTypes
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  t1.r.k.j.f0.i.m
 *  t1.r.k.j.f0.i.m$b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.payments.paymentsnew.models.AddCard;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentOptionsTemplateTypes;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.List;
import t1.r.k.j.f0.i.m;

/*
 * Exception performing whole class analysis.
 */
public final class AddCard
extends m.b
implements Parcelable {
    public static final Parcelable.Creator<AddCard> CREATOR;
    public PaymentOptionsTemplateTypes a;
    public String b;
    public Integer c;
    public String d;
    public Boolean e;
    public String f;
    public List<String> g;
    public Boolean h;
    public Boolean i;
    public String j;
    public List<String> k;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public AddCard(PaymentOptionsTemplateTypes paymentOptionsTemplateTypes, String string, Integer n, String string2, Boolean bl, String string3, List<String> list, Boolean bl2, Boolean bl3, String string4, List<String> list2) {
        l.g((Object)paymentOptionsTemplateTypes, (String)"type");
        this.a = paymentOptionsTemplateTypes;
        this.b = string;
        this.c = n;
        this.d = string2;
        this.e = bl;
        this.f = string3;
        this.g = list;
        this.h = bl2;
        this.i = bl3;
        this.j = string4;
        this.k = list2;
    }

    public /* synthetic */ AddCard(PaymentOptionsTemplateTypes paymentOptionsTemplateTypes, String string, Integer n, String string2, Boolean bl, String string3, List list, Boolean bl2, Boolean bl3, String string4, List list2, int n2, g g2) {
        Boolean bl4 = Boolean.FALSE;
        Boolean bl5 = (n2 & 16) != 0 ? bl4 : bl;
        String string5 = (n2 & 32) != 0 ? null : string3;
        List list3 = (n2 & 64) != 0 ? null : list;
        Boolean bl6 = (n2 & 128) != 0 ? bl4 : bl2;
        Boolean bl7 = (n2 & 256) != 0 ? bl4 : bl3;
        List list4 = (n2 & 1024) != 0 ? null : list2;
        this(paymentOptionsTemplateTypes, string, n, string2, bl5, string5, (List<String>)list3, bl6, bl7, string4, (List<String>)list4);
    }

    public final String a() {
        return this.j;
    }

    public final Integer b() {
        return this.c;
    }

    public final List<String> c() {
        return this.k;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.d;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof AddCard)) break block3;
                AddCard addCard = (AddCard)((Object)object);
                if (l.c((Object)this.a, (Object)addCard.a) && l.c((Object)this.b, (Object)addCard.b) && l.c((Object)this.c, (Object)addCard.c) && l.c((Object)this.d, (Object)addCard.d) && l.c((Object)this.e, (Object)addCard.e) && l.c((Object)this.f, (Object)addCard.f) && l.c(this.g, addCard.g) && l.c((Object)this.h, (Object)addCard.h) && l.c((Object)this.i, (Object)addCard.i) && l.c((Object)this.j, (Object)addCard.j) && l.c(this.k, addCard.k)) break block2;
            }
            return false;
        }
        return true;
    }

    public final List<String> f() {
        return this.g;
    }

    public final String g() {
        return this.f;
    }

    public final PaymentOptionsTemplateTypes h() {
        return this.a;
    }

    public int hashCode() {
        PaymentOptionsTemplateTypes paymentOptionsTemplateTypes = this.a;
        int n = paymentOptionsTemplateTypes != null ? paymentOptionsTemplateTypes.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Integer n5 = this.c;
        int n6 = n5 != null ? n5.hashCode() : 0;
        int n7 = 31 * (n4 + n6);
        String string2 = this.d;
        int n8 = string2 != null ? string2.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        Boolean bl = this.e;
        int n10 = bl != null ? bl.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        String string3 = this.f;
        int n12 = string3 != null ? string3.hashCode() : 0;
        int n13 = 31 * (n11 + n12);
        List<String> list = this.g;
        int n14 = list != null ? list.hashCode() : 0;
        int n15 = 31 * (n13 + n14);
        Boolean bl2 = this.h;
        int n16 = bl2 != null ? bl2.hashCode() : 0;
        int n17 = 31 * (n15 + n16);
        Boolean bl3 = this.i;
        int n18 = bl3 != null ? bl3.hashCode() : 0;
        int n19 = 31 * (n17 + n18);
        String string4 = this.j;
        int n20 = string4 != null ? string4.hashCode() : 0;
        int n21 = 31 * (n19 + n20);
        List<String> list2 = this.k;
        int n22 = 0;
        if (list2 != null) {
            n22 = list2.hashCode();
        }
        return n21 + n22;
    }

    public final Boolean i() {
        return this.e;
    }

    public final Boolean j() {
        return this.i;
    }

    public final Boolean k() {
        return this.h;
    }

    public final void l(Boolean bl) {
        this.h = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("AddCard(type=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", paymentMode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", gatewayId=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", pgName=");
        stringBuilder.append(this.d);
        stringBuilder.append(", isAutoPayEnabled=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", title=");
        stringBuilder.append(this.f);
        stringBuilder.append(", subTitles=");
        stringBuilder.append(this.g);
        stringBuilder.append(", isDisable=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", isCardSaveMandatory=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", cardSaveInfoText=");
        stringBuilder.append(this.j);
        stringBuilder.append(", infoList=");
        stringBuilder.append(this.k);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a.name());
        parcel.writeString(this.b);
        Integer n2 = this.c;
        if (n2 != null) {
            parcel.writeInt(1);
            parcel.writeInt(n2.intValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.d);
        Boolean bl = this.e;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.f);
        parcel.writeStringList(this.g);
        Boolean bl2 = this.h;
        if (bl2 != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl2.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        Boolean bl3 = this.i;
        if (bl3 != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl3.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.j);
        parcel.writeStringList(this.k);
    }
}

