/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  t1.r.k.j.d0.i.a
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.ArrayList;
import t1.r.k.j.d0.i.a;

@SuppressLint(value={"ParcelCreator"})
public final class DelinkOrRemoveResponseModel
extends ResponseBaseModel {
    @SerializedName(value="payment_options")
    private final ArrayList<PaymentsItemBaseModel> e;
    @SerializedName(value="message_dialog")
    private final a f;
    @SerializedName(value="delink_status")
    private final Boolean g;

    public DelinkOrRemoveResponseModel(ArrayList<PaymentsItemBaseModel> arrayList, a a2, Boolean bl) {
        this.e = arrayList;
        this.f = a2;
        this.g = bl;
    }

    public final Boolean e() {
        return this.g;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof DelinkOrRemoveResponseModel)) break block3;
                DelinkOrRemoveResponseModel delinkOrRemoveResponseModel = (DelinkOrRemoveResponseModel)((Object)object);
                if (l.c(this.e, delinkOrRemoveResponseModel.e) && l.c((Object)this.f, (Object)delinkOrRemoveResponseModel.f) && l.c((Object)this.g, (Object)delinkOrRemoveResponseModel.g)) break block2;
            }
            return false;
        }
        return true;
    }

    public final a f() {
        return this.f;
    }

    public final ArrayList<PaymentsItemBaseModel> g() {
        return this.e;
    }

    public int hashCode() {
        ArrayList<PaymentsItemBaseModel> arrayList = this.e;
        int n2 = arrayList != null ? arrayList.hashCode() : 0;
        int n3 = n2 * 31;
        a a2 = this.f;
        int n4 = a2 != null ? a2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        Boolean bl = this.g;
        int n6 = 0;
        if (bl != null) {
            n6 = bl.hashCode();
        }
        return n5 + n6;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DelinkOrRemoveResponseModel(paymentOptionScreenTemplates=");
        stringBuilder.append(this.e);
        stringBuilder.append(", messageDialog=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", delinkStatus=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

