/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.CardType;
import i2.a0.d.l;

public final class NoCostEmiModel
implements Parcelable {
    public static final Parcelable.Creator<NoCostEmiModel> CREATOR = new a();
    @SerializedName(value="id")
    private final String a;
    @SerializedName(value="emi")
    private final String b;
    @SerializedName(value="interest")
    private final String c;
    @SerializedName(value="discount")
    private final String d;
    @SerializedName(value="total")
    private final String e;
    @SerializedName(value="card_type")
    private final CardType f;
    @SerializedName(value="info_text")
    private final String g;
    @SerializedName(value="tenure")
    private final int h;
    @SerializedName(value="bank")
    private final String i;
    @SerializedName(value="emi_type")
    private final String j;
    public boolean k;

    public NoCostEmiModel(String string, String string2, String string3, String string4, String string5, CardType cardType, String string6, int n, String string7, String string8, boolean bl) {
        l.g((Object)string, (String)"id");
        l.g((Object)string2, (String)"emi");
        l.g((Object)string3, (String)"interest");
        l.g((Object)string4, (String)"discount");
        l.g((Object)string5, (String)"total");
        l.g((Object)((Object)cardType), (String)"card_type");
        l.g((Object)string7, (String)"bank");
        l.g((Object)string8, (String)"emi_type");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = cardType;
        this.g = string6;
        this.h = n;
        this.i = string7;
        this.j = string8;
        this.k = bl;
    }

    public final String a() {
        return this.i;
    }

    public final CardType b() {
        return this.f;
    }

    public final String c() {
        return this.d;
    }

    public final String d() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.j;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof NoCostEmiModel)) break block3;
                NoCostEmiModel noCostEmiModel = (NoCostEmiModel)object;
                if (l.c((Object)this.a, (Object)noCostEmiModel.a) && l.c((Object)this.b, (Object)noCostEmiModel.b) && l.c((Object)this.c, (Object)noCostEmiModel.c) && l.c((Object)this.d, (Object)noCostEmiModel.d) && l.c((Object)this.e, (Object)noCostEmiModel.e) && l.c((Object)((Object)this.f), (Object)((Object)noCostEmiModel.f)) && l.c((Object)this.g, (Object)noCostEmiModel.g) && this.h == noCostEmiModel.h && l.c((Object)this.i, (Object)noCostEmiModel.i) && l.c((Object)this.j, (Object)noCostEmiModel.j) && this.k == noCostEmiModel.k) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.a;
    }

    public final String g() {
        return this.g;
    }

    public final String h() {
        return this.c;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.d;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string5 = this.e;
        int n9 = string5 != null ? string5.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        CardType cardType = this.f;
        int n11 = cardType != null ? cardType.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string6 = this.g;
        int n13 = string6 != null ? string6.hashCode() : 0;
        int n14 = 31 * (31 * (n12 + n13) + this.h);
        String string7 = this.i;
        int n15 = string7 != null ? string7.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        String string8 = this.j;
        int n17 = 0;
        if (string8 != null) {
            n17 = string8.hashCode();
        }
        int n18 = 31 * (n16 + n17);
        int n19 = this.k ? 1 : 0;
        if (n19 != 0) {
            n19 = 1;
        }
        return n18 + n19;
    }

    public final int i() {
        return this.h;
    }

    public final String j() {
        return this.e;
    }

    public final boolean k() {
        return this.k;
    }

    public final void l(boolean bl) {
        this.k = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NoCostEmiModel(id=");
        stringBuilder.append(this.a);
        stringBuilder.append(", emi=");
        stringBuilder.append(this.b);
        stringBuilder.append(", interest=");
        stringBuilder.append(this.c);
        stringBuilder.append(", discount=");
        stringBuilder.append(this.d);
        stringBuilder.append(", total=");
        stringBuilder.append(this.e);
        stringBuilder.append(", card_type=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", info_text=");
        stringBuilder.append(this.g);
        stringBuilder.append(", tenure=");
        stringBuilder.append(this.h);
        stringBuilder.append(", bank=");
        stringBuilder.append(this.i);
        stringBuilder.append(", emi_type=");
        stringBuilder.append(this.j);
        stringBuilder.append(", isSelected=");
        stringBuilder.append(this.k);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f.name());
        parcel.writeString(this.g);
        parcel.writeInt(this.h);
        parcel.writeString(this.i);
        parcel.writeString(this.j);
        parcel.writeInt((int)this.k);
    }

    public static final class a
    implements Parcelable.Creator<NoCostEmiModel> {
        public final NoCostEmiModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            String string4 = parcel.readString();
            String string5 = parcel.readString();
            CardType cardType = (CardType)Enum.valueOf(CardType.class, (String)parcel.readString());
            String string6 = parcel.readString();
            int n = parcel.readInt();
            String string7 = parcel.readString();
            String string8 = parcel.readString();
            boolean bl = parcel.readInt() != 0;
            NoCostEmiModel noCostEmiModel = new NoCostEmiModel(string, string2, string3, string4, string5, cardType, string6, n, string7, string8, bl);
            return noCostEmiModel;
        }

        public final NoCostEmiModel[] b(int n) {
            return new NoCostEmiModel[n];
        }
    }

}

