/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.CardType;
import i2.a0.d.l;

public final class StandardEmiModel
implements Parcelable {
    public static final Parcelable.Creator<StandardEmiModel> CREATOR = new a();
    @SerializedName(value="id")
    private final String a;
    @SerializedName(value="emi")
    private final String b;
    @SerializedName(value="interest")
    private final String c;
    @SerializedName(value="total")
    private final String d;
    @SerializedName(value="card_type")
    private final CardType e;
    @SerializedName(value="info_text")
    private final String f;
    @SerializedName(value="tenure")
    private final int g;
    @SerializedName(value="bank")
    private final String h;
    @SerializedName(value="emi_type")
    private final String i;
    public boolean j;

    public StandardEmiModel(String string, String string2, String string3, String string4, CardType cardType, String string5, int n, String string6, String string7, boolean bl) {
        l.g((Object)string, (String)"id");
        l.g((Object)string2, (String)"emi");
        l.g((Object)string3, (String)"interest");
        l.g((Object)string4, (String)"total");
        l.g((Object)((Object)cardType), (String)"card_type");
        l.g((Object)string6, (String)"bank");
        l.g((Object)string7, (String)"emi_type");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = cardType;
        this.f = string5;
        this.g = n;
        this.h = string6;
        this.i = string7;
        this.j = bl;
    }

    public final String a() {
        return this.h;
    }

    public final CardType b() {
        return this.e;
    }

    public final String c() {
        return this.b;
    }

    public final String d() {
        return this.i;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.a;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof StandardEmiModel)) break block3;
                StandardEmiModel standardEmiModel = (StandardEmiModel)object;
                if (l.c((Object)this.a, (Object)standardEmiModel.a) && l.c((Object)this.b, (Object)standardEmiModel.b) && l.c((Object)this.c, (Object)standardEmiModel.c) && l.c((Object)this.d, (Object)standardEmiModel.d) && l.c((Object)((Object)this.e), (Object)((Object)standardEmiModel.e)) && l.c((Object)this.f, (Object)standardEmiModel.f) && this.g == standardEmiModel.g && l.c((Object)this.h, (Object)standardEmiModel.h) && l.c((Object)this.i, (Object)standardEmiModel.i) && this.j == standardEmiModel.j) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.f;
    }

    public final String g() {
        return this.c;
    }

    public final int h() {
        return this.g;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.d;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        CardType cardType = this.e;
        int n9 = cardType != null ? cardType.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        String string5 = this.f;
        int n11 = string5 != null ? string5.hashCode() : 0;
        int n12 = 31 * (31 * (n10 + n11) + this.g);
        String string6 = this.h;
        int n13 = string6 != null ? string6.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        String string7 = this.i;
        int n15 = 0;
        if (string7 != null) {
            n15 = string7.hashCode();
        }
        int n16 = 31 * (n14 + n15);
        int n17 = this.j ? 1 : 0;
        if (n17 != 0) {
            n17 = 1;
        }
        return n16 + n17;
    }

    public final String i() {
        return this.d;
    }

    public final boolean j() {
        return this.j;
    }

    public final void k(boolean bl) {
        this.j = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StandardEmiModel(id=");
        stringBuilder.append(this.a);
        stringBuilder.append(", emi=");
        stringBuilder.append(this.b);
        stringBuilder.append(", interest=");
        stringBuilder.append(this.c);
        stringBuilder.append(", total=");
        stringBuilder.append(this.d);
        stringBuilder.append(", card_type=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", info_text=");
        stringBuilder.append(this.f);
        stringBuilder.append(", tenure=");
        stringBuilder.append(this.g);
        stringBuilder.append(", bank=");
        stringBuilder.append(this.h);
        stringBuilder.append(", emi_type=");
        stringBuilder.append(this.i);
        stringBuilder.append(", isSelected=");
        stringBuilder.append(this.j);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e.name());
        parcel.writeString(this.f);
        parcel.writeInt(this.g);
        parcel.writeString(this.h);
        parcel.writeString(this.i);
        parcel.writeInt((int)this.j);
    }

    public static final class a
    implements Parcelable.Creator<StandardEmiModel> {
        public final StandardEmiModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            String string4 = parcel.readString();
            CardType cardType = (CardType)Enum.valueOf(CardType.class, (String)parcel.readString());
            String string5 = parcel.readString();
            int n = parcel.readInt();
            String string6 = parcel.readString();
            String string7 = parcel.readString();
            boolean bl = parcel.readInt() != 0;
            StandardEmiModel standardEmiModel = new StandardEmiModel(string, string2, string3, string4, cardType, string5, n, string6, string7, bl);
            return standardEmiModel;
        }

        public final StandardEmiModel[] b(int n) {
            return new StandardEmiModel[n];
        }
    }

}

