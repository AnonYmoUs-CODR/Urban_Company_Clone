/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.models.AskWhatsAppPermissionResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel
 */
package com.urbanclap.urbanclap.payments.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.models.AskWhatsAppPermissionResponseModel;
import com.urbanclap.urbanclap.ucshared.models.ApiResponseBaseModel;

public class AskWhatsAppPermissionResponseModel
extends ApiResponseBaseModel {
    public static final Parcelable.Creator<AskWhatsAppPermissionResponseModel> CREATOR = new a();
    @SerializedName(value="ask_permission")
    private boolean e;

    public AskWhatsAppPermissionResponseModel() {
    }

    public AskWhatsAppPermissionResponseModel(Parcel parcel) {
        super(parcel);
        boolean bl = parcel.readByte() != 0;
        this.e = bl;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeByte((byte)this.e);
    }
}

