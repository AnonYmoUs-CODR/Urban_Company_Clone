/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.NoCostEmiModel;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.StandardEmiModel;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class EmiOptionsModel
implements Parcelable {
    public static final Parcelable.Creator<EmiOptionsModel> CREATOR = new a();
    @SerializedName(value="no_cost_emi")
    private final List<NoCostEmiModel> a;
    @SerializedName(value="standard_emi")
    private final List<StandardEmiModel> b;

    public EmiOptionsModel(List<NoCostEmiModel> list, List<StandardEmiModel> list2) {
        this.a = list;
        this.b = list2;
    }

    public final EmiOptionsModel a(List<NoCostEmiModel> list, List<StandardEmiModel> list2) {
        return new EmiOptionsModel(list, list2);
    }

    public final List<NoCostEmiModel> b() {
        return this.a;
    }

    public final List<StandardEmiModel> c() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof EmiOptionsModel)) break block3;
                EmiOptionsModel emiOptionsModel = (EmiOptionsModel)object;
                if (l.c(this.a, emiOptionsModel.a) && l.c(this.b, emiOptionsModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        List<NoCostEmiModel> list = this.a;
        int n = list != null ? list.hashCode() : 0;
        int n2 = n * 31;
        List<StandardEmiModel> list2 = this.b;
        int n3 = 0;
        if (list2 != null) {
            n3 = list2.hashCode();
        }
        return n2 + n3;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EmiOptionsModel(no_cost_emi=");
        stringBuilder.append(this.a);
        stringBuilder.append(", standard_emi=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        List<StandardEmiModel> list;
        l.g((Object)parcel, (String)"parcel");
        List<NoCostEmiModel> list2 = this.a;
        if (list2 != null) {
            parcel.writeInt(1);
            parcel.writeInt(list2.size());
            Iterator iterator = list2.iterator();
            while (iterator.hasNext()) {
                ((NoCostEmiModel)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
        if ((list = this.b) != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((StandardEmiModel)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
    }

    public static final class a
    implements Parcelable.Creator<EmiOptionsModel> {
        public final EmiOptionsModel a(Parcel parcel) {
            ArrayList arrayList;
            l.g((Object)parcel, (String)"in");
            if (parcel.readInt() != 0) {
                int n;
                arrayList = new ArrayList(n);
                for (n = parcel.readInt(); n != 0; --n) {
                    arrayList.add((Object)((NoCostEmiModel)NoCostEmiModel.CREATOR.createFromParcel(parcel)));
                }
            } else {
                arrayList = null;
            }
            int n = parcel.readInt();
            ArrayList arrayList2 = null;
            if (n != 0) {
                int n2;
                arrayList2 = new ArrayList(n2);
                for (n2 = parcel.readInt(); n2 != 0; --n2) {
                    arrayList2.add((Object)((StandardEmiModel)StandardEmiModel.CREATOR.createFromParcel(parcel)));
                }
            }
            return new EmiOptionsModel((List<NoCostEmiModel>)arrayList, (List<StandardEmiModel>)arrayList2);
        }

        public final EmiOptionsModel[] b(int n) {
            return new EmiOptionsModel[n];
        }
    }

}

