/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.util.ArrayList
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import java.util.ArrayList;

@SuppressLint(value={"ParcelCreator"})
public final class ManagePaymentOptionResponseModel
extends ResponseBaseModel {
    @SerializedName(value="payment_options")
    private final ArrayList<PaymentsItemBaseModel> e;

    public ManagePaymentOptionResponseModel(ArrayList<PaymentsItemBaseModel> arrayList) {
        this.e = arrayList;
    }

    public final ArrayList<PaymentsItemBaseModel> e() {
        return this.e;
    }
}

