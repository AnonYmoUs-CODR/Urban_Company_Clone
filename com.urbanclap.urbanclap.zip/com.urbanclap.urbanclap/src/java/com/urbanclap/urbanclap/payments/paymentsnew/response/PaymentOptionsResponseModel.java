/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.payments.models.Insurance
 *  com.urbanclap.urbanclap.payments.models.autoPay.AutoPayDetails
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentInfoModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.TnCModel
 *  com.urbanclap.urbanclap.ucshared.models.PaymentSummary
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.annotation.SuppressLint;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.payments.models.Insurance;
import com.urbanclap.urbanclap.payments.models.autoPay.AutoPayDetails;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentInfoModel;
import com.urbanclap.urbanclap.payments.paymentsnew.models.TnCModel;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummary;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

@SuppressLint(value={"ParcelCreator"})
public final class PaymentOptionsResponseModel
extends ResponseBaseModel {
    @SerializedName(value="payment_options")
    private final ArrayList<PaymentsItemBaseModel> e;
    @SerializedName(value="payment_summary")
    private ArrayList<PaymentSummary> f;
    @SerializedName(value="amount_payable")
    private String g;
    @SerializedName(value="amount")
    private Double h;
    @SerializedName(value="insurance")
    private Insurance i;
    @SerializedName(value="terms_of_service")
    private TnCModel j;
    @SerializedName(value="auto_pay_details")
    private AutoPayDetails k;
    @SerializedName(value="compliance_image")
    private PictureObject s;
    @SerializedName(value="online_payment_trust_image")
    private PictureObject t;
    @SerializedName(value="bottom_nudge")
    private List<String> u;
    @SerializedName(value="refresh_payment_options")
    private Boolean v;
    @SerializedName(value="client_auth_token")
    private String w;
    @SerializedName(value="payment_info")
    private final PaymentInfoModel x;

    public PaymentOptionsResponseModel(ArrayList<PaymentsItemBaseModel> arrayList, ArrayList<PaymentSummary> arrayList2, String string, Double d2, Insurance insurance, TnCModel tnCModel, AutoPayDetails autoPayDetails, PictureObject pictureObject, PictureObject pictureObject2, List<String> list, Boolean bl, String string2, PaymentInfoModel paymentInfoModel) {
        l.g(arrayList, (String)"paymentOptionScreenTemplates");
        l.g(arrayList2, (String)"paymentSummaryArray");
        this.e = arrayList;
        this.f = arrayList2;
        this.g = string;
        this.h = d2;
        this.i = insurance;
        this.j = tnCModel;
        this.k = autoPayDetails;
        this.s = pictureObject;
        this.t = pictureObject2;
        this.u = list;
        this.v = bl;
        this.w = string2;
        this.x = paymentInfoModel;
    }

    public final Double e() {
        return this.h;
    }

    public final String f() {
        return this.g;
    }

    public final AutoPayDetails g() {
        return this.k;
    }

    public final List<String> h() {
        return this.u;
    }

    public final String i() {
        return this.w;
    }

    public final PictureObject j() {
        return this.s;
    }

    public final Insurance k() {
        return this.i;
    }

    public final PictureObject l() {
        return this.t;
    }

    public final PaymentInfoModel m() {
        return this.x;
    }

    public final ArrayList<PaymentsItemBaseModel> n() {
        return this.e;
    }

    public final ArrayList<PaymentSummary> o() {
        return this.f;
    }

    public final Boolean p() {
        return this.v;
    }

    public final TnCModel q() {
        return this.j;
    }
}

