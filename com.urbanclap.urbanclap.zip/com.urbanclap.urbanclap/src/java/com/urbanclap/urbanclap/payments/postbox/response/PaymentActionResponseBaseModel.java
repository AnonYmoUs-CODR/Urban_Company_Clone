/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.models.DisclaimerInfo
 *  com.urbanclap.urbanclap.payments.models.PaymentCommunication
 *  com.urbanclap.urbanclap.payments.models.PaymentGateways
 *  com.urbanclap.urbanclap.payments.models.SearchOfferSummary
 *  com.urbanclap.urbanclap.payments.postbox.response.PaymentActionResponseBaseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.PaymentSummary
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.ClassLoader
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.postbox.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.models.DisclaimerInfo;
import com.urbanclap.urbanclap.payments.models.PaymentCommunication;
import com.urbanclap.urbanclap.payments.models.PaymentGateways;
import com.urbanclap.urbanclap.payments.models.SearchOfferSummary;
import com.urbanclap.urbanclap.payments.postbox.response.PaymentActionResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummary;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import java.util.ArrayList;
import java.util.List;

public class PaymentActionResponseBaseModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<PaymentActionResponseBaseModel> CREATOR = new a();
    @SerializedName(value="payment_summary")
    private ArrayList<PaymentSummary> e;
    @SerializedName(value="payment_communication")
    private PaymentCommunication f;
    @SerializedName(value="payment_gateways")
    private PaymentGateways g;
    @SerializedName(value="search_offer_summary")
    private SearchOfferSummary h;
    @SerializedName(value="disclaimer_info")
    private DisclaimerInfo i;

    public PaymentActionResponseBaseModel() {
    }

    public PaymentActionResponseBaseModel(Parcel parcel) {
        super(parcel);
        this.e = parcel.createTypedArrayList(PaymentSummary.CREATOR);
        this.f = (PaymentCommunication)parcel.readParcelable(PaymentCommunication.class.getClassLoader());
        this.g = (PaymentGateways)parcel.readParcelable(PaymentGateways.class.getClassLoader());
        this.h = (SearchOfferSummary)parcel.readParcelable(SearchOfferSummary.class.getClassLoader());
        this.i = (DisclaimerInfo)parcel.readParcelable(DisclaimerInfo.class.getClassLoader());
    }

    public int describeContents() {
        return 0;
    }

    public DisclaimerInfo e() {
        return this.i;
    }

    public PaymentCommunication f() {
        return this.f;
    }

    public ArrayList<PaymentSummary> g() {
        return this.e;
    }

    public SearchOfferSummary h() {
        return this.h;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeTypedList(this.e);
        parcel.writeParcelable((Parcelable)this.f, n2);
        parcel.writeParcelable((Parcelable)this.g, n2);
        parcel.writeParcelable((Parcelable)this.h, n2);
        parcel.writeParcelable((Parcelable)this.i, n2);
    }
}

