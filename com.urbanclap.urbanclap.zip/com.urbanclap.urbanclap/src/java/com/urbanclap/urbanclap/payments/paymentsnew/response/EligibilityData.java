/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.EligibilityData$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.EligibilityData;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class EligibilityData
extends ResponseBaseModel {
    public static final a CREATOR;
    public String e;
    public String f;
    public String g;
    public boolean h;
    public String i;
    public String j;
    public String k;
    public String s;
    public String t;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public EligibilityData(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        boolean bl = parcel.readByte() != (byte)(false ? 1 : 0);
        this(string, string2, string3, bl, parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString());
    }

    public EligibilityData(String string, String string2, String string3, boolean bl, String string4, String string5, String string6, String string7, String string8) {
        this.e = string;
        this.f = string2;
        this.g = string3;
        this.h = bl;
        this.i = string4;
        this.j = string5;
        this.k = string6;
        this.s = string7;
        this.t = string8;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.t;
    }

    public final String f() {
        return this.g;
    }

    public final boolean g() {
        return this.h;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeByte((byte)this.h);
        parcel.writeString(this.i);
        parcel.writeString(this.j);
        parcel.writeString(this.k);
        parcel.writeString(this.s);
        parcel.writeString(this.t);
    }
}

