/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentOptionEligibilityResponseModel$a
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentOptionEligibilityResponseModel$b
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.payments.paymentsnew.response.EligibilityData;
import com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentOptionEligibilityResponseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class PaymentOptionEligibilityResponseModel
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<PaymentOptionEligibilityResponseModel> CREATOR;
    public static final b h;
    public List<EligibilityData> e;
    public String f;
    public String g;

    public static {
        h = new /* Unavailable Anonymous Inner Class!! */;
        CREATOR = new a();
    }

    public PaymentOptionEligibilityResponseModel(Parcel parcel) {
        l.g((Object)parcel, (String)"source");
        ArrayList arrayList = new ArrayList();
        parcel.readList((List)arrayList, EligibilityData.class.getClassLoader());
        this((List<EligibilityData>)arrayList, parcel.readString(), parcel.readString());
    }

    public PaymentOptionEligibilityResponseModel(List<EligibilityData> list, String string, String string2) {
        this.e = list;
        this.f = string;
        this.g = string2;
    }

    public int describeContents() {
        return 0;
    }

    public final List<EligibilityData> e() {
        return this.e;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeList(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
    }
}

