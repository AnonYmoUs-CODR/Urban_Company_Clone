/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.CodOptions
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.CodDataModel$a
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.SafetyInfoModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.CodOptions;
import com.urbanclap.urbanclap.payments.paymentsnew.response.CodDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.SafetyInfoModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class CodDataModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="payment_mode")
    private final String b;
    @SerializedName(value="title")
    private final String c;
    @SerializedName(value="cod_options")
    private final ArrayList<CodOptions> d;
    @SerializedName(value="card_save_info_text")
    private final String e;
    @SerializedName(value="is_disable")
    private boolean f;
    @SerializedName(value="disable_reason")
    private final String g;
    @SerializedName(value="dowtime_message")
    private final String h;
    @SerializedName(value="safety_info")
    private final SafetyInfoModel i;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CodDataModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        ArrayList arrayList = parcel.readArrayList(CodOptions.class.getClassLoader());
        String string3 = parcel.readString();
        boolean bl = parcel.readByte() != (byte)(false ? 1 : 0);
        this(string, string2, (ArrayList<CodOptions>)arrayList, string3, bl, parcel.readString(), parcel.readString(), (SafetyInfoModel)parcel.readParcelable(SafetyInfoModel.class.getClassLoader()));
    }

    public CodDataModel(String string, String string2, ArrayList<CodOptions> arrayList, String string3, boolean bl, String string4, String string5, SafetyInfoModel safetyInfoModel) {
        super(null, 1, null);
        this.b = string;
        this.c = string2;
        this.d = arrayList;
        this.e = string3;
        this.f = bl;
        this.g = string4;
        this.h = string5;
        this.i = safetyInfoModel;
    }

    public final String b() {
        return this.e;
    }

    public final ArrayList<CodOptions> c() {
        return this.d;
    }

    public final String d() {
        return this.g;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.h;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CodDataModel)) break block3;
                CodDataModel codDataModel = (CodDataModel)((Object)object);
                if (l.c((Object)this.b, (Object)codDataModel.b) && l.c((Object)this.c, (Object)codDataModel.c) && l.c(this.d, codDataModel.d) && l.c((Object)this.e, (Object)codDataModel.e) && this.f == codDataModel.f && l.c((Object)this.g, (Object)codDataModel.g) && l.c((Object)this.h, (Object)codDataModel.h) && l.c((Object)this.i, (Object)codDataModel.i)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.b;
    }

    public final SafetyInfoModel g() {
        return this.i;
    }

    public final String h() {
        return this.c;
    }

    public int hashCode() {
        String string = this.b;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.c;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        ArrayList<CodOptions> arrayList = this.d;
        int n6 = arrayList != null ? arrayList.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string3 = this.e;
        int n8 = string3 != null ? string3.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        int n10 = this.f ? 1 : 0;
        if (n10 != 0) {
            n10 = 1;
        }
        int n11 = 31 * (n9 + n10);
        String string4 = this.g;
        int n12 = string4 != null ? string4.hashCode() : 0;
        int n13 = 31 * (n11 + n12);
        String string5 = this.h;
        int n14 = string5 != null ? string5.hashCode() : 0;
        int n15 = 31 * (n13 + n14);
        SafetyInfoModel safetyInfoModel = this.i;
        int n16 = 0;
        if (safetyInfoModel != null) {
            n16 = safetyInfoModel.hashCode();
        }
        return n15 + n16;
    }

    public final boolean i() {
        return this.f;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CodDataModel(paymentMode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", title=");
        stringBuilder.append(this.c);
        stringBuilder.append(", codOptions=");
        stringBuilder.append(this.d);
        stringBuilder.append(", cardSaveInfoText=");
        stringBuilder.append(this.e);
        stringBuilder.append(", isDisabled=");
        stringBuilder.append(this.f);
        stringBuilder.append(", disableReason=");
        stringBuilder.append(this.g);
        stringBuilder.append(", downtimeMessage=");
        stringBuilder.append(this.h);
        stringBuilder.append(", safetyInfo=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeTypedList(this.d);
        parcel.writeString(this.e);
        parcel.writeByte((byte)this.f);
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeParcelable((Parcelable)this.i, n2);
    }
}

