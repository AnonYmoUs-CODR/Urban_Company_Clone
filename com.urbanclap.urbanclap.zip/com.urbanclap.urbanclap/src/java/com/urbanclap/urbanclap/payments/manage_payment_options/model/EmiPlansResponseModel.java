/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.manage_payment_options.model.EmiBankModel
 *  com.urbanclap.urbanclap.payments.manage_payment_options.model.EmiPlansResponseModel$a
 *  com.urbanclap.urbanclap.payments.manage_payment_options.model.NoCostEmiDescriptionModel
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.EmiBankModel;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.EmiPlansResponseModel;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.NoCostEmiDescriptionModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.Iterator;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class EmiPlansResponseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<EmiPlansResponseModel> CREATOR;
    @SerializedName(value="banks")
    private final List<EmiBankModel> e;
    @SerializedName(value="no_cost_emi_description")
    private final NoCostEmiDescriptionModel f;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public EmiPlansResponseModel(List<EmiBankModel> list, NoCostEmiDescriptionModel noCostEmiDescriptionModel) {
        this.e = list;
        this.f = noCostEmiDescriptionModel;
    }

    public final List<EmiBankModel> e() {
        return this.e;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof EmiPlansResponseModel)) break block3;
                EmiPlansResponseModel emiPlansResponseModel = (EmiPlansResponseModel)((Object)object);
                if (l.c(this.e, emiPlansResponseModel.e) && l.c((Object)this.f, (Object)emiPlansResponseModel.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final NoCostEmiDescriptionModel f() {
        return this.f;
    }

    public int hashCode() {
        List<EmiBankModel> list = this.e;
        int n2 = list != null ? list.hashCode() : 0;
        int n3 = n2 * 31;
        NoCostEmiDescriptionModel noCostEmiDescriptionModel = this.f;
        int n4 = 0;
        if (noCostEmiDescriptionModel != null) {
            n4 = noCostEmiDescriptionModel.hashCode();
        }
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EmiPlansResponseModel(banks=");
        stringBuilder.append(this.e);
        stringBuilder.append(", no_cost_emi_description=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        NoCostEmiDescriptionModel noCostEmiDescriptionModel;
        l.g((Object)parcel, (String)"parcel");
        List<EmiBankModel> list = this.e;
        if (list != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((EmiBankModel)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
        if ((noCostEmiDescriptionModel = this.f) != null) {
            parcel.writeInt(1);
            noCostEmiDescriptionModel.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }
}

