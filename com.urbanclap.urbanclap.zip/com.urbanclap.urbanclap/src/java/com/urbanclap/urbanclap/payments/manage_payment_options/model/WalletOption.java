/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class WalletOption
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="logo_url")
    private final String a;
    @SerializedName(value="wallet_id")
    private final String b;
    @SerializedName(value="display_name")
    private final String c;
    @SerializedName(value="gateway_id")
    private final Integer d;
    @SerializedName(value="action_text")
    private final String e;

    public WalletOption(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        String string3 = parcel.readString();
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (!(object instanceof Integer)) {
            object = null;
        }
        this(string, string2, string3, (Integer)object, parcel.readString());
    }

    public WalletOption(String string, String string2, String string3, Integer n, String string4) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = n;
        this.e = string4;
    }

    public final String a() {
        return this.e;
    }

    public final String b() {
        return this.c;
    }

    public final Integer c() {
        return this.d;
    }

    public final String d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof WalletOption)) break block3;
                WalletOption walletOption = (WalletOption)object;
                if (l.c((Object)this.a, (Object)walletOption.a) && l.c((Object)this.b, (Object)walletOption.b) && l.c((Object)this.c, (Object)walletOption.c) && l.c((Object)this.d, (Object)walletOption.d) && l.c((Object)this.e, (Object)walletOption.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        Integer n7 = this.d;
        int n8 = n7 != null ? n7.hashCode() : 0;
        int n9 = 31 * (n6 + n8);
        String string4 = this.e;
        int n10 = 0;
        if (string4 != null) {
            n10 = string4.hashCode();
        }
        return n9 + n10;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WalletOption(logoUrl=");
        stringBuilder.append(this.a);
        stringBuilder.append(", walletId=");
        stringBuilder.append(this.b);
        stringBuilder.append(", displayName=");
        stringBuilder.append(this.c);
        stringBuilder.append(", gatewayId=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", actionText=");
        stringBuilder.append(this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeValue((Object)this.d);
        parcel.writeString(this.e);
    }

    public static final class a
    implements Parcelable.Creator<WalletOption> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public WalletOption a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new WalletOption(parcel);
        }

        public WalletOption[] b(int n) {
            return new WalletOption[n];
        }
    }

}

