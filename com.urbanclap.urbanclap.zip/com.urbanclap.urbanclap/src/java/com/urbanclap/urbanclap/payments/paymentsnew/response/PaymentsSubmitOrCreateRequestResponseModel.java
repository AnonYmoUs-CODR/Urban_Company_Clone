/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  androidx.annotation.Nullable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.models.AmazonParams
 *  com.urbanclap.urbanclap.payments.models.ErrorInPayment
 *  com.urbanclap.urbanclap.payments.models.JuspayToken
 *  com.urbanclap.urbanclap.payments.models.PaymentLinks
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentsSubmitOrCreateRequestResponseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.models.AmazonParams;
import com.urbanclap.urbanclap.payments.models.ErrorInPayment;
import com.urbanclap.urbanclap.payments.models.JuspayToken;
import com.urbanclap.urbanclap.payments.models.PaymentLinks;
import com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentsSubmitOrCreateRequestResponseModel;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PaymentsSubmitOrCreateRequestResponseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<PaymentsSubmitOrCreateRequestResponseModel> CREATOR = new a();
    @SerializedName(value="id")
    private String A;
    @SerializedName(value="payment_links")
    private PaymentLinks B;
    @SerializedName(value="juspay")
    private JuspayToken C;
    @SerializedName(value="end_url")
    private String D;
    @SerializedName(value="generate_signature_url")
    private String E;
    @SerializedName(value="verify_signature_url")
    private String F;
    @SerializedName(value="amazon_params")
    private AmazonParams G;
    @SerializedName(value="payment_checksum")
    private String H;
    @SerializedName(value="display_note")
    private String I;
    @SerializedName(value="payment_url")
    @Nullable
    private String J;
    @SerializedName(value="booking_time")
    @Nullable
    private String K;
    @SerializedName(value="action_type")
    @Nullable
    private String L;
    @SerializedName(value="request_id")
    private String e;
    @SerializedName(value="payment_hash")
    private String f;
    @SerializedName(value="transaction_id")
    private String g;
    @SerializedName(value="timerConfig")
    private Integer h;
    @SerializedName(value="byPassProcessRestart")
    private boolean i = false;
    @SerializedName(value="paid_amount")
    private Number j;
    @SerializedName(value="options")
    private ArrayList<String> k;
    @SerializedName(value="error")
    private ErrorInPayment s;
    @SerializedName(value="otp_token")
    private String t;
    @SerializedName(value="user_subscription_id")
    private String u;
    @SerializedName(value="care_package_id")
    private String v;
    @SerializedName(value="status_type")
    private String w;
    @SerializedName(value="pg_name")
    private String x;
    @SerializedName(value="currency")
    private String y;
    @SerializedName(value="user_voucher_id")
    private String z;

    public PaymentsSubmitOrCreateRequestResponseModel() {
    }

    public PaymentsSubmitOrCreateRequestResponseModel(Parcel parcel) {
        super(parcel);
        this.e = parcel.readString();
        this.K = parcel.readString();
        this.f = parcel.readString();
        this.g = parcel.readString();
        this.j = (Number)parcel.readSerializable();
        this.k = parcel.createStringArrayList();
        this.s = (ErrorInPayment)parcel.readParcelable(ErrorInPayment.class.getClassLoader());
        this.t = parcel.readString();
        this.u = parcel.readString();
        this.v = parcel.readString();
        this.w = parcel.readString();
        this.x = parcel.readString();
        this.y = parcel.readString();
        this.z = parcel.readString();
        this.A = parcel.readString();
        this.B = (PaymentLinks)parcel.readParcelable(PaymentLinks.class.getClassLoader());
        this.C = (JuspayToken)parcel.readParcelable(JuspayToken.class.getClassLoader());
        this.D = parcel.readString();
        this.E = parcel.readString();
        this.F = parcel.readString();
        this.G = (AmazonParams)parcel.readParcelable(AmazonParams.class.getClassLoader());
        this.H = parcel.readString();
        this.I = parcel.readString();
        this.J = parcel.readString();
        this.L = parcel.readString();
        this.h = parcel.readInt();
        byte by = parcel.readByte();
        boolean bl = false;
        if (by != 0) {
            bl = true;
        }
        this.i = bl;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        if (!TextUtils.isEmpty((CharSequence)this.K)) {
            return this.K;
        }
        return "NA";
    }

    public String f() {
        return this.v;
    }

    public String g() {
        return this.y;
    }

    public String h() {
        return this.I;
    }

    public String i() {
        return this.D;
    }

    public JuspayToken j() {
        return this.C;
    }

    public Number k() {
        return this.j;
    }

    public String l() {
        return this.H;
    }

    public String m() {
        return this.J;
    }

    public String n() {
        return this.x;
    }

    public String o() {
        return this.e;
    }

    public String p() {
        return this.w;
    }

    public Long q() {
        Integer n2 = this.h;
        if (n2 == null) {
            return null;
        }
        return (long)n2;
    }

    public String r() {
        return this.g;
    }

    public String s() {
        return this.u;
    }

    public String t() {
        return this.z;
    }

    public boolean u() {
        return this.i;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeString(this.e);
        parcel.writeString(this.K);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        parcel.writeSerializable((Serializable)this.j);
        parcel.writeStringList(this.k);
        parcel.writeParcelable((Parcelable)this.s, n2);
        parcel.writeString(this.t);
        parcel.writeString(this.u);
        parcel.writeString(this.v);
        parcel.writeString(this.w);
        parcel.writeString(this.x);
        parcel.writeString(this.y);
        parcel.writeString(this.z);
        parcel.writeString(this.A);
        parcel.writeParcelable((Parcelable)this.B, n2);
        parcel.writeParcelable((Parcelable)this.C, n2);
        parcel.writeString(this.D);
        parcel.writeString(this.E);
        parcel.writeString(this.F);
        parcel.writeParcelable((Parcelable)this.G, n2);
        parcel.writeString(this.H);
        parcel.writeString(this.I);
        parcel.writeString(this.J);
        parcel.writeString(this.L);
        parcel.writeInt(this.h.intValue());
        parcel.writeByte((byte)(this.i ? 1 : 0));
    }
}

