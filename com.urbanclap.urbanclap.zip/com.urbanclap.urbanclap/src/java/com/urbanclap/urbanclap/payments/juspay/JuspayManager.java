/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Parcelable
 *  androidx.annotation.Keep
 *  androidx.fragment.app.FragmentActivity
 *  com.google.gson.Gson
 *  com.urbanclap.urbanclap.payments.juspay.JuspayManager$e
 *  com.urbanclap.urbanclap.payments.paymentsnew.widgets.TransactionActivity
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  in.juspay.hypersdk.ui.HyperPaymentsCallback
 *  in.juspay.hypersdk.ui.HyperPaymentsCallbackAdapter
 *  in.juspay.services.HyperServices
 *  j2.b.f
 *  j2.b.i0
 *  j2.b.m1
 *  j2.b.y0
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Objects
 *  java.util.UUID
 *  org.json.JSONArray
 *  org.json.JSONObject
 *  t1.r.k.j.t
 *  t1.r.k.j.t$a
 *  t1.r.k.n.w0.f
 */
package com.urbanclap.urbanclap.payments.juspay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import androidx.annotation.Keep;
import androidx.fragment.app.FragmentActivity;
import com.google.gson.Gson;
import com.urbanclap.urbanclap.payments.juspay.JuspayManager;
import com.urbanclap.urbanclap.payments.paymentsnew.response.PaymentsSubmitOrCreateRequestResponseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.widgets.TransactionActivity;
import com.urbanclap.urbanclap.ucshared.models.postbox.request_models.wallet.consult_wallet_balance.response.ConsultWalletBalanceResponseModel;
import i2.a0.c.p;
import i2.a0.d.g;
import i2.a0.d.l;
import i2.h0.s;
import in.juspay.hypersdk.ui.HyperPaymentsCallback;
import in.juspay.hypersdk.ui.HyperPaymentsCallbackAdapter;
import in.juspay.services.HyperServices;
import j2.b.i0;
import j2.b.m1;
import j2.b.y0;
import java.util.ArrayList;
import java.util.Objects;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;
import t1.r.k.j.t;
import t1.r.k.n.w0.f;

public final class JuspayManager {
    public static final String a = "prod";
    public static boolean b;
    public static boolean c;
    public static final JuspayManager d;

    public static {
        d = new JuspayManager();
    }

    public static /* synthetic */ void j(JuspayManager juspayManager, Activity activity, int n, String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, boolean bl, boolean bl2, String string10, Integer n2, String string11, PaymentsSubmitOrCreateRequestResponseModel paymentsSubmitOrCreateRequestResponseModel, int n3, Object object) {
        boolean bl3 = (n3 & 4096) != 0 ? false : bl2;
        String string12 = (n3 & 8192) != 0 ? null : string10;
        Integer n4 = (n3 & 16384) != 0 ? null : n2;
        String string13 = (n3 & 32768) != 0 ? null : string11;
        juspayManager.i(activity, n, string, string2, string3, string4, string5, string6, string7, string8, string9, bl, bl3, string12, n4, string13, paymentsSubmitOrCreateRequestResponseModel);
    }

    public static final void o(Context context) {
        l.g((Object)context, (String)"applicationContext");
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        j2.b.f.d((i0)m1.a, (i2.x.g)y0.b(), null, (p)new e(jSONObject2, jSONObject, context, null), (int)2, null);
    }

    public final void a(Activity activity, String string, double d2, String[] arrstring, String string2, a a2) {
        l.g((Object)activity, (String)"activity");
        l.g((Object)arrstring, (String)"checkTypes");
        l.g((Object)a2, (String)"paymentsCallback");
        JSONArray jSONArray = new JSONArray();
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            jSONArray.put(i, (Object)arrstring[i]);
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("checkType", (Object)jSONArray);
        if (string2 != null) {
            jSONObject.put("mobile", (Object)string2);
        }
        JSONArray jSONArray2 = new JSONArray();
        jSONArray2.put(0, (Object)jSONObject);
        JSONObject jSONObject2 = new JSONObject();
        jSONObject2.put("apps", (Object)jSONArray2);
        JSONObject jSONObject3 = new JSONObject();
        jSONObject3.put("action", (Object)"eligibility");
        jSONObject3.put("amount", (Object)String.valueOf((double)d2));
        jSONObject3.put("clientAuthToken", (Object)string);
        jSONObject3.put("data", (Object)jSONObject2);
        this.e(activity, jSONObject3, a2);
    }

    public final void b(Activity activity, String string, i2.a0.c.l<? super ConsultWalletBalanceResponseModel, i2.t> l2) {
        l.g((Object)activity, (String)"activity");
        l.g(l2, (String)"callback");
        if (c) {
            return;
        }
        c = true;
        Gson gson = new Gson();
        JuspayPayload juspayPayload = new JuspayPayload("refreshWalletBalances", null, null, null, string, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Boolean.FALSE, null, null, null, 125829102, null);
        this.e(activity, new JSONObject(gson.s((Object)juspayPayload)), new a(l2){
            public final /* synthetic */ i2.a0.c.l a;
            {
                this.a = l2;
            }

            public void K0() {
                a.a.b(this);
            }

            public void L0(JSONObject jSONObject) {
                double d2;
                l.g((Object)jSONObject, (String)"response");
                JuspayManager juspayManager = JuspayManager.d;
                int n = 0;
                juspayManager.q(false);
                a.a.d(this, jSONObject);
                JSONArray jSONArray = jSONObject.getJSONArray("list");
                int n2 = jSONArray.length();
                do {
                    d2 = 0.0;
                    if (n >= n2) break;
                    JSONObject jSONObject2 = jSONArray.getJSONObject(n);
                    if (l.c((Object)jSONObject2.optString("wallet"), (Object)"AMAZONPAY")) {
                        i2.a0.c.l l2 = this.a;
                        String string = jSONObject2.optString("id");
                        String string2 = jSONObject2.optString("token", "");
                        String string3 = jSONObject2.optString("currentBalance", "0.0");
                        l.f((Object)string3, (String)"wall.optString(\"currentBalance\", \"0.0\")");
                        Double d3 = i2.h0.p.j(string3);
                        if (d3 != null) {
                            d2 = d3;
                        }
                        ConsultWalletBalanceResponseModel consultWalletBalanceResponseModel = new ConsultWalletBalanceResponseModel(string, "", "AMAZONPAY", string2, d2, jSONObject2.optBoolean("linked"), "");
                        l2.invoke(consultWalletBalanceResponseModel);
                        return;
                    }
                    ++n;
                } while (true);
                android.util.Log.d((String)"JuspayManager", (String)"processResult: a");
                i2.a0.c.l l3 = this.a;
                ConsultWalletBalanceResponseModel consultWalletBalanceResponseModel = new ConsultWalletBalanceResponseModel("", "", "AMAZONPAY", "", d2, Boolean.FALSE, "");
                l3.invoke(consultWalletBalanceResponseModel);
            }

            public void M0() {
                a.a.c(this);
            }

            public void N0() {
                a.a.a(this);
            }

            public void o0() {
                a.a.e(this);
            }
        });
    }

    public final String c() {
        String string = f.c.b();
        if (string != null) {
            return string;
        }
        return "";
    }

    public final JSONObject d(Double d2, String string, Integer n) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("amount", (Object)d2);
        jSONObject.put("userId", (Object)string);
        jSONObject.put("gateway_id", (Object)n);
        return jSONObject;
    }

    public final void e(Activity activity, JSONObject jSONObject, a a2) {
        l.g((Object)activity, (String)"activity");
        l.g((Object)jSONObject, (String)"processInnerpayload");
        HyperServices hyperServices = new HyperServices((FragmentActivity)activity);
        JSONObject jSONObject2 = new JSONObject();
        jSONObject2.put("requestId", (Object)UUID.randomUUID().toString());
        jSONObject2.put("service", (Object)"in.juspay.hyperapi");
        JSONObject jSONObject3 = new JSONObject();
        jSONObject3.put("action", (Object)"initiate");
        jSONObject3.put("merchantId", (Object)"urbanclap");
        jSONObject3.put("clientId", (Object)"urbanclap_android");
        jSONObject3.put("customerId", (Object)d.c());
        jSONObject3.put("environment", (Object)a);
        jSONObject3.put("eligibilityInInitiate", true);
        jSONObject2.put("payload", (Object)jSONObject3);
        JSONObject jSONObject4 = new JSONObject();
        jSONObject4.put("requestId", (Object)UUID.randomUUID().toString());
        jSONObject4.put("service", (Object)"in.juspay.hyperapi");
        jSONObject4.put("payload", (Object)jSONObject);
        hyperServices.initiate(jSONObject2, (HyperPaymentsCallback)new HyperPaymentsCallbackAdapter(a2, hyperServices, activity, jSONObject4){
            public final /* synthetic */ a a;
            public final /* synthetic */ HyperServices b;
            public final /* synthetic */ Activity c;
            public final /* synthetic */ JSONObject d;
            {
                this.a = a2;
                this.b = hyperServices;
                this.c = activity;
                this.d = jSONObject;
            }

            /*
             * Exception decompiling
             */
            public void onEvent(}
        java.lang.IllegalStateException: Parameters not created
        
        