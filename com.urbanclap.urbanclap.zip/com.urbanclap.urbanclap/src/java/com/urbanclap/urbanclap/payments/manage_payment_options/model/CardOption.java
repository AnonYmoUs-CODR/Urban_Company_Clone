/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class CardOption
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="card_token")
    private final String a;
    @SerializedName(value="display_name")
    private final String b;
    @SerializedName(value="gateway_id")
    private final Integer c;
    @SerializedName(value="action_text")
    private final String d;
    @SerializedName(value="card_bin")
    private String e;
    @SerializedName(value="customer_id")
    private String f;

    public CardOption(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        Object object = parcel.readValue(Integer.TYPE.getClassLoader());
        if (!(object instanceof Integer)) {
            object = null;
        }
        this(string, string2, (Integer)object, parcel.readString(), parcel.readString(), parcel.readString());
    }

    public CardOption(String string, String string2, Integer n, String string3, String string4, String string5) {
        this.a = string;
        this.b = string2;
        this.c = n;
        this.d = string3;
        this.e = string4;
        this.f = string5;
    }

    public final String a() {
        return this.d;
    }

    public final String b() {
        return this.e;
    }

    public final String c() {
        return this.a;
    }

    public final String d() {
        return this.f;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CardOption)) break block3;
                CardOption cardOption = (CardOption)object;
                if (l.c((Object)this.a, (Object)cardOption.a) && l.c((Object)this.b, (Object)cardOption.b) && l.c((Object)this.c, (Object)cardOption.c) && l.c((Object)this.d, (Object)cardOption.d) && l.c((Object)this.e, (Object)cardOption.e) && l.c((Object)this.f, (Object)cardOption.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final Integer f() {
        return this.c;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Integer n5 = this.c;
        int n6 = n5 != null ? n5.hashCode() : 0;
        int n7 = 31 * (n4 + n6);
        String string3 = this.d;
        int n8 = string3 != null ? string3.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        String string4 = this.e;
        int n10 = string4 != null ? string4.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        String string5 = this.f;
        int n12 = 0;
        if (string5 != null) {
            n12 = string5.hashCode();
        }
        return n11 + n12;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CardOption(cardToken=");
        stringBuilder.append(this.a);
        stringBuilder.append(", displayName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", gatewayId=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", actionText=");
        stringBuilder.append(this.d);
        stringBuilder.append(", cardBin=");
        stringBuilder.append(this.e);
        stringBuilder.append(", customerId=");
        stringBuilder.append(this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeValue((Object)this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f);
    }

    public static final class a
    implements Parcelable.Creator<CardOption> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public CardOption a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new CardOption(parcel);
        }

        public CardOption[] b(int n) {
            return new CardOption[n];
        }
    }

}

