/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.WalletOption;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class ManageWalletDataModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="payment_mode")
    private final String a;
    @SerializedName(value="title")
    private final String b;
    @SerializedName(value="options")
    private final ArrayList<WalletOption> c;

    public ManageWalletDataModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), (ArrayList<WalletOption>)parcel.readArrayList(WalletOption.class.getClassLoader()));
    }

    public ManageWalletDataModel(String string, String string2, ArrayList<WalletOption> arrayList) {
        this.a = string;
        this.b = string2;
        this.c = arrayList;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final ArrayList<WalletOption> c() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ManageWalletDataModel)) break block3;
                ManageWalletDataModel manageWalletDataModel = (ManageWalletDataModel)object;
                if (l.c((Object)this.a, (Object)manageWalletDataModel.a) && l.c((Object)this.b, (Object)manageWalletDataModel.b) && l.c(this.c, manageWalletDataModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        ArrayList<WalletOption> arrayList = this.c;
        int n5 = 0;
        if (arrayList != null) {
            n5 = arrayList.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ManageWalletDataModel(paymentMode=");
        stringBuilder.append(this.a);
        stringBuilder.append(", title=");
        stringBuilder.append(this.b);
        stringBuilder.append(", walletList=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeTypedList(this.c);
    }

    public static final class a
    implements Parcelable.Creator<ManageWalletDataModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ManageWalletDataModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ManageWalletDataModel(parcel);
        }

        public ManageWalletDataModel[] b(int n) {
            return new ManageWalletDataModel[n];
        }
    }

}

