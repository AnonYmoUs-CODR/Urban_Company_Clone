/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.ActiveBanks
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.StoredCards
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.StoredCards$a
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.ActiveBanks;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.StoredCards;
import java.util.ArrayList;
import java.util.List;

public class ActiveCardsAndBanksModel
implements Parcelable {
    public static final Parcelable.Creator<ActiveCardsAndBanksModel> CREATOR = new Parcelable.Creator<ActiveCardsAndBanksModel>(){

        public ActiveCardsAndBanksModel a(Parcel parcel) {
            return new ActiveCardsAndBanksModel(parcel);
        }

        public ActiveCardsAndBanksModel[] b(int n) {
            return new ActiveCardsAndBanksModel[n];
        }
    };
    public ArrayList<ActiveBanks> a;
    public ArrayList<StoredCards> b;

    public ActiveCardsAndBanksModel() {
        this.a = new ArrayList();
        this.b = new ArrayList();
    }

    public ActiveCardsAndBanksModel(Parcel parcel) {
        this.a = parcel.createTypedArrayList(ActiveBanks.CREATOR);
        this.b = parcel.createTypedArrayList((Parcelable.Creator)StoredCards.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeTypedList(this.a);
        parcel.writeTypedList(this.b);
    }

}

