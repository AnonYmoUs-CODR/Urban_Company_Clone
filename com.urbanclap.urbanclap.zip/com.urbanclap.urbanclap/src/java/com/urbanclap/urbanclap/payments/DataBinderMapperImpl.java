/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.SparseArray
 *  android.util.SparseIntArray
 *  android.view.View
 *  androidx.databinding.DataBinderMapper
 *  androidx.databinding.DataBindingComponent
 *  androidx.databinding.ViewDataBinding
 *  androidx.databinding.library.baseAdapters.DataBinderMapperImpl
 *  com.urbanclap.urbanclap.payments.DataBinderMapperImpl$a
 *  com.urbanclap.urbanclap.payments.DataBinderMapperImpl$b
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  t1.r.k.j.o
 *  t1.r.k.j.y.a0
 *  t1.r.k.j.y.b
 *  t1.r.k.j.y.c0
 *  t1.r.k.j.y.d
 *  t1.r.k.j.y.e0
 *  t1.r.k.j.y.f
 *  t1.r.k.j.y.g0
 *  t1.r.k.j.y.h
 *  t1.r.k.j.y.i0
 *  t1.r.k.j.y.j
 *  t1.r.k.j.y.k0
 *  t1.r.k.j.y.l
 *  t1.r.k.j.y.m0
 *  t1.r.k.j.y.o
 *  t1.r.k.j.y.o0
 *  t1.r.k.j.y.q
 *  t1.r.k.j.y.s
 *  t1.r.k.j.y.t0
 *  t1.r.k.j.y.u
 *  t1.r.k.j.y.v0
 *  t1.r.k.j.y.w
 *  t1.r.k.j.y.y
 */
package com.urbanclap.urbanclap.payments;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.urbanclap.urbanclap.payments.DataBinderMapperImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import t1.r.k.j.o;
import t1.r.k.j.y.a0;
import t1.r.k.j.y.c0;
import t1.r.k.j.y.d;
import t1.r.k.j.y.e0;
import t1.r.k.j.y.f;
import t1.r.k.j.y.g0;
import t1.r.k.j.y.h;
import t1.r.k.j.y.i0;
import t1.r.k.j.y.j;
import t1.r.k.j.y.k0;
import t1.r.k.j.y.l;
import t1.r.k.j.y.m0;
import t1.r.k.j.y.o0;
import t1.r.k.j.y.q;
import t1.r.k.j.y.s;
import t1.r.k.j.y.t0;
import t1.r.k.j.y.u;
import t1.r.k.j.y.v0;
import t1.r.k.j.y.w;
import t1.r.k.j.y.y;

public class DataBinderMapperImpl
extends DataBinderMapper {
    public static final SparseIntArray a;

    public static {
        SparseIntArray sparseIntArray;
        a = sparseIntArray = new SparseIntArray(22);
        sparseIntArray.put(o.g, 1);
        sparseIntArray.put(o.h, 2);
        sparseIntArray.put(o.i, 3);
        sparseIntArray.put(o.j, 4);
        sparseIntArray.put(o.k, 5);
        sparseIntArray.put(o.o, 6);
        sparseIntArray.put(o.p, 7);
        sparseIntArray.put(o.q, 8);
        sparseIntArray.put(o.r, 9);
        sparseIntArray.put(o.s, 10);
        sparseIntArray.put(o.t, 11);
        sparseIntArray.put(o.u, 12);
        sparseIntArray.put(o.v, 13);
        sparseIntArray.put(o.w, 14);
        sparseIntArray.put(o.x, 15);
        sparseIntArray.put(o.y, 16);
        sparseIntArray.put(o.z, 17);
        sparseIntArray.put(o.A, 18);
        sparseIntArray.put(o.B, 19);
        sparseIntArray.put(o.D, 20);
        sparseIntArray.put(o.V, 21);
        sparseIntArray.put(o.W, 22);
    }

    public List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(2);
        arrayList.add((Object)new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add((Object)new com.urbanclap.urbanclap.ucshared.DataBinderMapperImpl());
        return arrayList;
    }

    public String convertBrIdToString(int n2) {
        return (String)a.a.get(n2);
    }

    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int n2) {
        block46 : {
            block47 : {
                int n3 = a.get(n2);
                if (n3 <= 0) break block46;
                Object object = view.getTag();
                if (object == null) break block47;
                switch (n3) {
                    default: {
                        break block46;
                    }
                    case 22: {
                        if ("layout/payment_horizontal_listing_upi_item_0".equals(object)) {
                            return new v0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for payment_horizontal_listing_upi_item is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 21: {
                        if ("layout/payment_horizontal_listing_item_0".equals(object)) {
                            return new t0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for payment_horizontal_listing_item is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 20: {
                        if ("layout/activity_payments_options_seperator_0".equals(object)) {
                            return new o0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_options_seperator is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 19: {
                        if ("layout/activity_payments_option_type_safety_info_0".equals(object)) {
                            return new m0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_type_safety_info is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 18: {
                        if ("layout/activity_payments_option_type_header_0".equals(object)) {
                            return new k0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_type_header is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 17: {
                        if ("layout/activity_payments_option_item_wallet_0".equals(object)) {
                            return new i0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_wallet is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 16: {
                        if ("layout/activity_payments_option_item_upi_0".equals(object)) {
                            return new g0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_upi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 15: {
                        if ("layout/activity_payments_option_item_pay_with_app_0".equals(object)) {
                            return new e0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_pay_with_app is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 14: {
                        if ("layout/activity_payments_option_item_netbanking_0".equals(object)) {
                            return new c0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_netbanking is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 13: {
                        if ("layout/activity_payments_option_item_more_upi_0".equals(object)) {
                            return new a0(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_more_upi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 12: {
                        if ("layout/activity_payments_option_item_emi_0".equals(object)) {
                            return new y(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_emi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 11: {
                        if ("layout/activity_payments_option_item_collect_upi_0".equals(object)) {
                            return new w(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_collect_upi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 10: {
                        if ("layout/activity_payments_option_item_cod_0".equals(object)) {
                            return new u(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_cod is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 9: {
                        if ("layout/activity_payments_option_item_card_0".equals(object)) {
                            return new s(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_card is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 8: {
                        if ("layout/activity_payments_option_item_add_upi_0".equals(object)) {
                            return new q(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_add_upi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 7: {
                        if ("layout/activity_payments_option_item_add_card_0".equals(object)) {
                            return new t1.r.k.j.y.o(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option_item_add_card is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 6: {
                        if ("layout/activity_payments_option_0".equals(object)) {
                            return new l(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_payments_option is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 5: {
                        if ("layout/activity_manage_payment_options_wallet_0".equals(object)) {
                            return new j(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_manage_payment_options_wallet is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 4: {
                        if ("layout/activity_manage_payment_options_upi_0".equals(object)) {
                            return new h(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_manage_payment_options_upi is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 3: {
                        if ("layout/activity_manage_payment_options_header_0".equals(object)) {
                            return new f(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_manage_payment_options_header is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 2: {
                        if ("layout/activity_manage_payment_options_card_0".equals(object)) {
                            return new d(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_manage_payment_options_card is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    case 1: {
                        if ("layout/activity_manage_payment_options_0".equals(object)) {
                            return new t1.r.k.j.y.b(dataBindingComponent, view);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("The tag for activity_manage_payment_options is invalid. Received: ");
                        stringBuilder.append(object);
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                }
            }
            throw new RuntimeException("view must have a tag");
        }
        return null;
    }

    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] arrview, int n2) {
        if (arrview != null) {
            if (arrview.length == 0) {
                return null;
            }
            if (a.get(n2) > 0) {
                if (arrview[0].getTag() != null) {
                    return null;
                }
                throw new RuntimeException("view must have a tag");
            }
        }
        return null;
    }

    public int getLayoutId(String string) {
        if (string == null) {
            return 0;
        }
        Integer n2 = (Integer)b.a.get((Object)string);
        if (n2 == null) {
            return 0;
        }
        return n2;
    }
}

