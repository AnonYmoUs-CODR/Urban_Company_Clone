/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class Success
implements Parcelable {
    public static final Parcelable.Creator<Success> CREATOR = new a();
    @Expose
    @SerializedName(value="data")
    private String a;

    public Success() {
        this(null, 1, null);
    }

    public Success(String string) {
        this.a = string;
    }

    public /* synthetic */ Success(String string, int n, g g2) {
        if ((n & 1) != 0) {
            string = "";
        }
        this(string);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof Success)) break block3;
                Success success = (Success)object;
                if (l.c((Object)this.a, (Object)success.a)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        if (string != null) {
            return string.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Success(data=");
        stringBuilder.append(this.a);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
    }

    public static final class a
    implements Parcelable.Creator<Success> {
        public final Success a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new Success(parcel.readString());
        }

        public final Success[] b(int n) {
            return new Success[n];
        }
    }

}

