/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.EmiOptionsModel;
import i2.a0.d.l;

public final class EmiBankModel
implements Parcelable {
    public static final Parcelable.Creator<EmiBankModel> CREATOR = new a();
    @SerializedName(value="bank_image")
    private final PictureObject a;
    @SerializedName(value="bank_name")
    private final String b;
    @SerializedName(value="bank_code")
    private final String c;
    @SerializedName(value="emi_options")
    private final EmiOptionsModel d;
    @SerializedName(value="disclaimer_text")
    private final String e;
    public boolean f;

    public EmiBankModel(PictureObject pictureObject, String string, String string2, EmiOptionsModel emiOptionsModel, String string3, boolean bl) {
        l.g((Object)string, (String)"bank_name");
        l.g((Object)string2, (String)"bank_code");
        l.g((Object)emiOptionsModel, (String)"emi_options");
        this.a = pictureObject;
        this.b = string;
        this.c = string2;
        this.d = emiOptionsModel;
        this.e = string3;
        this.f = bl;
    }

    public static /* synthetic */ EmiBankModel b(EmiBankModel emiBankModel, PictureObject pictureObject, String string, String string2, EmiOptionsModel emiOptionsModel, String string3, boolean bl, int n, Object object) {
        if ((n & 1) != 0) {
            pictureObject = emiBankModel.a;
        }
        if ((n & 2) != 0) {
            string = emiBankModel.b;
        }
        String string4 = string;
        if ((n & 4) != 0) {
            string2 = emiBankModel.c;
        }
        String string5 = string2;
        if ((n & 8) != 0) {
            emiOptionsModel = emiBankModel.d;
        }
        EmiOptionsModel emiOptionsModel2 = emiOptionsModel;
        if ((n & 16) != 0) {
            string3 = emiBankModel.e;
        }
        String string6 = string3;
        if ((n & 32) != 0) {
            bl = emiBankModel.f;
        }
        boolean bl2 = bl;
        return emiBankModel.a(pictureObject, string4, string5, emiOptionsModel2, string6, bl2);
    }

    public final EmiBankModel a(PictureObject pictureObject, String string, String string2, EmiOptionsModel emiOptionsModel, String string3, boolean bl) {
        l.g((Object)string, (String)"bank_name");
        l.g((Object)string2, (String)"bank_code");
        l.g((Object)emiOptionsModel, (String)"emi_options");
        EmiBankModel emiBankModel = new EmiBankModel(pictureObject, string, string2, emiOptionsModel, string3, bl);
        return emiBankModel;
    }

    public final String c() {
        return this.c;
    }

    public final PictureObject d() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.b;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof EmiBankModel)) break block3;
                EmiBankModel emiBankModel = (EmiBankModel)object;
                if (l.c((Object)this.a, (Object)emiBankModel.a) && l.c((Object)this.b, (Object)emiBankModel.b) && l.c((Object)this.c, (Object)emiBankModel.c) && l.c((Object)this.d, (Object)emiBankModel.d) && l.c((Object)this.e, (Object)emiBankModel.e) && this.f == emiBankModel.f) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.e;
    }

    public final EmiOptionsModel g() {
        return this.d;
    }

    public final boolean h() {
        return this.f;
    }

    public int hashCode() {
        PictureObject pictureObject = this.a;
        int n = pictureObject != null ? pictureObject.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.c;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        EmiOptionsModel emiOptionsModel = this.d;
        int n7 = emiOptionsModel != null ? emiOptionsModel.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string3 = this.e;
        int n9 = 0;
        if (string3 != null) {
            n9 = string3.hashCode();
        }
        int n10 = 31 * (n8 + n9);
        int n11 = this.f ? 1 : 0;
        if (n11 != 0) {
            n11 = 1;
        }
        return n10 + n11;
    }

    public final void i(boolean bl) {
        this.f = bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EmiBankModel(bank_image=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", bank_name=");
        stringBuilder.append(this.b);
        stringBuilder.append(", bank_code=");
        stringBuilder.append(this.c);
        stringBuilder.append(", emi_options=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", disclaimer_text=");
        stringBuilder.append(this.e);
        stringBuilder.append(", isSelected=");
        stringBuilder.append(this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.a, n);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        this.d.writeToParcel(parcel, 0);
        parcel.writeString(this.e);
        parcel.writeInt((int)this.f);
    }

    public static final class a
    implements Parcelable.Creator<EmiBankModel> {
        public final EmiBankModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(EmiBankModel.class.getClassLoader());
            String string = parcel.readString();
            String string2 = parcel.readString();
            EmiOptionsModel emiOptionsModel = (EmiOptionsModel)EmiOptionsModel.CREATOR.createFromParcel(parcel);
            String string3 = parcel.readString();
            boolean bl = parcel.readInt() != 0;
            EmiBankModel emiBankModel = new EmiBankModel(pictureObject, string, string2, emiOptionsModel, string3, bl);
            return emiBankModel;
        }

        public final EmiBankModel[] b(int n) {
            return new EmiBankModel[n];
        }
    }

}

