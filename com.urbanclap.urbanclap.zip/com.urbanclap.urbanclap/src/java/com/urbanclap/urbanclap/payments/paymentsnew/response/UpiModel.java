/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.UpiDataModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.UpiModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.UpiDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.UpiModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class UpiModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="data")
    @b(className="UpiModel", fieldName="parent")
    private final UpiDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public UpiModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((UpiDataModel)parcel.readParcelable(UpiDataModel.class.getClassLoader()));
    }

    public UpiModel(UpiDataModel upiDataModel) {
        super(null, 1, null);
        this.b = upiDataModel;
    }

    public final UpiDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof UpiModel)) break block3;
                UpiModel upiModel = (UpiModel)((Object)object);
                if (l.c((Object)this.b, (Object)upiModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        UpiDataModel upiDataModel = this.b;
        if (upiDataModel != null) {
            return upiDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("UpiModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

