/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.CardOption;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class ManageCardDataModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="payment_mode")
    private final String a;
    @SerializedName(value="title")
    private final String b;
    @SerializedName(value="options")
    private final ArrayList<CardOption> c;

    public ManageCardDataModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), (ArrayList<CardOption>)parcel.readArrayList(CardOption.class.getClassLoader()));
    }

    public ManageCardDataModel(String string, String string2, ArrayList<CardOption> arrayList) {
        this.a = string;
        this.b = string2;
        this.c = arrayList;
    }

    public final ArrayList<CardOption> a() {
        return this.c;
    }

    public final String b() {
        return this.a;
    }

    public final String c() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ManageCardDataModel)) break block3;
                ManageCardDataModel manageCardDataModel = (ManageCardDataModel)object;
                if (l.c((Object)this.a, (Object)manageCardDataModel.a) && l.c((Object)this.b, (Object)manageCardDataModel.b) && l.c(this.c, manageCardDataModel.c)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        ArrayList<CardOption> arrayList = this.c;
        int n5 = 0;
        if (arrayList != null) {
            n5 = arrayList.hashCode();
        }
        return n4 + n5;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ManageCardDataModel(paymentMode=");
        stringBuilder.append(this.a);
        stringBuilder.append(", title=");
        stringBuilder.append(this.b);
        stringBuilder.append(", cardList=");
        stringBuilder.append(this.c);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeTypedList(this.c);
    }

    public static final class a
    implements Parcelable.Creator<ManageCardDataModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ManageCardDataModel a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new ManageCardDataModel(parcel);
        }

        public ManageCardDataModel[] b(int n) {
            return new ManageCardDataModel[n];
        }
    }

}

