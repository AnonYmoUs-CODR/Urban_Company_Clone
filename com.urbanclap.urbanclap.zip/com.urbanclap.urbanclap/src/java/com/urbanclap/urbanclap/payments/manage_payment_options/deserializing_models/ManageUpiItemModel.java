/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models.ManageUpiDataModel
 *  com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models.ManageUpiItemModel$a
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models.ManageUpiDataModel;
import com.urbanclap.urbanclap.payments.manage_payment_options.deserializing_models.ManageUpiItemModel;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class ManageUpiItemModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="data")
    @b(className="ManageUpiDataModel", fieldName="parent")
    private final ManageUpiDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public ManageUpiItemModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((ManageUpiDataModel)parcel.readParcelable(ManageUpiDataModel.class.getClassLoader()));
    }

    public ManageUpiItemModel(ManageUpiDataModel manageUpiDataModel) {
        super(null, 1, null);
        this.b = manageUpiDataModel;
    }

    public final ManageUpiDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ManageUpiItemModel)) break block3;
                ManageUpiItemModel manageUpiItemModel = (ManageUpiItemModel)((Object)object);
                if (l.c((Object)this.b, (Object)manageUpiItemModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        ManageUpiDataModel manageUpiDataModel = this.b;
        if (manageUpiDataModel != null) {
            return manageUpiDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ManageUpiItemModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

