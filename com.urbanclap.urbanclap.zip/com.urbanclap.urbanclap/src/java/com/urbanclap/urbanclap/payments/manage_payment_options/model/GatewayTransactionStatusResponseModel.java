/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.manage_payment_options.model.GatewayTransactionStatusResponseModel$a
 *  com.urbanclap.urbanclap.payments.manage_payment_options.model.Success
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.GatewayTransactionStatusResponseModel;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.Success;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class GatewayTransactionStatusResponseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<GatewayTransactionStatusResponseModel> CREATOR;
    @SerializedName(value="success")
    private Success e;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public GatewayTransactionStatusResponseModel(Success success) {
        this.e = success;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof GatewayTransactionStatusResponseModel)) break block3;
                GatewayTransactionStatusResponseModel gatewayTransactionStatusResponseModel = (GatewayTransactionStatusResponseModel)((Object)object);
                if (l.c((Object)this.e, (Object)gatewayTransactionStatusResponseModel.e)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        Success success = this.e;
        if (success != null) {
            return success.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GatewayTransactionStatusResponseModel(success=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        Success success = this.e;
        if (success != null) {
            parcel.writeInt(1);
            success.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }
}

