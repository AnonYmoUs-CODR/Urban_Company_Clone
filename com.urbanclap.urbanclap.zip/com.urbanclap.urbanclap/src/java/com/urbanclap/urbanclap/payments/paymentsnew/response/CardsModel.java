/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.CardsDataModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.CardsModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.CardsDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.CardsModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class CardsModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="data")
    @b(className="CardsDataModel", fieldName="parent")
    private final CardsDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CardsModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((CardsDataModel)parcel.readParcelable(CardsDataModel.class.getClassLoader()));
    }

    public CardsModel(CardsDataModel cardsDataModel) {
        super(null, 1, null);
        this.b = cardsDataModel;
    }

    public final CardsDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CardsModel)) break block3;
                CardsModel cardsModel = (CardsModel)((Object)object);
                if (l.c((Object)this.b, (Object)cardsModel.b)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        CardsDataModel cardsDataModel = this.b;
        if (cardsDataModel != null) {
            return cardsDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CardsModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

