/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  com.urbanclap.urbanclap.payments.models.BankOffers
 *  com.urbanclap.urbanclap.payments.models.Coupon
 *  com.urbanclap.urbanclap.payments.models.CouponCommunication
 *  com.urbanclap.urbanclap.payments.models.DisclaimerInfo
 *  com.urbanclap.urbanclap.payments.models.Insurance
 *  com.urbanclap.urbanclap.payments.models.MissMatchAndCod
 *  com.urbanclap.urbanclap.payments.models.PaymentOptions
 *  com.urbanclap.urbanclap.payments.models.RateCard
 *  com.urbanclap.urbanclap.payments.models.autoPay.AutoPayDetails
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentInfoModel
 *  com.urbanclap.urbanclap.payments.postbox.response.PaymentOptionsResponseBaseModel$a
 *  com.urbanclap.urbanclap.ucshared.models.PaymentSummary
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.lang.ClassLoader
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  t1.r.k.n.c
 */
package com.urbanclap.urbanclap.payments.postbox.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.payments.models.BankOffers;
import com.urbanclap.urbanclap.payments.models.Coupon;
import com.urbanclap.urbanclap.payments.models.CouponCommunication;
import com.urbanclap.urbanclap.payments.models.DisclaimerInfo;
import com.urbanclap.urbanclap.payments.models.Insurance;
import com.urbanclap.urbanclap.payments.models.MissMatchAndCod;
import com.urbanclap.urbanclap.payments.models.PaymentOptions;
import com.urbanclap.urbanclap.payments.models.RateCard;
import com.urbanclap.urbanclap.payments.models.autoPay.AutoPayDetails;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentInfoModel;
import com.urbanclap.urbanclap.payments.postbox.response.PaymentOptionsResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.PaymentSummary;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import java.util.ArrayList;
import java.util.List;
import t1.r.k.n.c;

public class PaymentOptionsResponseBaseModel
extends ResponseBaseModel {
    public static final Parcelable.Creator<PaymentOptionsResponseBaseModel> CREATOR = new a();
    @SerializedName(value="disclaimer_info")
    private DisclaimerInfo A;
    @SerializedName(value="payment_summary")
    public ArrayList<PaymentSummary> e;
    @SerializedName(value="bank_offers")
    private BankOffers f;
    @SerializedName(value="payment_options")
    private PaymentOptions g;
    @SerializedName(value="insurance")
    private Insurance h;
    @SerializedName(value="rate_card")
    private RateCard i;
    @SerializedName(value="coupon")
    private Coupon j;
    @SerializedName(value="is_bank_offer_expanded")
    private boolean k;
    @SerializedName(value="payment_info")
    private PaymentInfoModel s;
    @SerializedName(value="auto_pay_details")
    private AutoPayDetails t;
    @SerializedName(value="compliance_image")
    public PictureObject u;
    @SerializedName(value="online_payment_trust_image")
    public PictureObject v;
    public CouponCommunication w;
    public String x;
    public MissMatchAndCod y;
    public boolean z;

    public PaymentOptionsResponseBaseModel() {
    }

    public PaymentOptionsResponseBaseModel(Parcel parcel) {
        super(parcel);
        this.e = parcel.createTypedArrayList(PaymentSummary.CREATOR);
        this.f = (BankOffers)parcel.readParcelable(BankOffers.class.getClassLoader());
        this.g = (PaymentOptions)parcel.readParcelable(PaymentOptions.class.getClassLoader());
        this.h = (Insurance)parcel.readParcelable(Insurance.class.getClassLoader());
        this.i = (RateCard)parcel.readParcelable(RateCard.class.getClassLoader());
        this.j = (Coupon)parcel.readParcelable(Coupon.class.getClassLoader());
        byte by = parcel.readByte();
        boolean bl = true;
        boolean bl2 = by != 0;
        this.k = bl2;
        this.s = (PaymentInfoModel)parcel.readParcelable(PaymentInfoModel.class.getClassLoader());
        this.t = (AutoPayDetails)parcel.readParcelable(AutoPayDetails.class.getClassLoader());
        this.u = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        this.v = (PictureObject)parcel.readParcelable(PictureObject.class.getClassLoader());
        this.A = (DisclaimerInfo)parcel.readParcelable(DisclaimerInfo.class.getClassLoader());
        this.w = (CouponCommunication)parcel.readParcelable(CouponCommunication.class.getClassLoader());
        this.x = parcel.readString();
        this.y = (MissMatchAndCod)parcel.readParcelable(MissMatchAndCod.class.getClassLoader());
        if (parcel.readByte() == 0) {
            bl = false;
        }
        this.z = bl;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.x;
    }

    public AutoPayDetails f() {
        return this.t;
    }

    public BankOffers g() {
        return this.f;
    }

    public PictureObject h() {
        return this.u;
    }

    public Coupon i() {
        return this.j;
    }

    public CouponCommunication j() {
        return this.w;
    }

    public DisclaimerInfo k() {
        return this.A;
    }

    public Insurance l() {
        return this.h;
    }

    public PaymentInfoModel m() {
        return this.s;
    }

    public PaymentOptions n() {
        return this.g;
    }

    public ArrayList<PaymentSummary> o() {
        if (c.x(this.e)) {
            return this.e;
        }
        return new ArrayList();
    }

    public RateCard p() {
        return this.i;
    }

    public boolean q() {
        return this.z;
    }

    public void r(String string) {
        this.x = string;
    }

    public void s(MissMatchAndCod missMatchAndCod) {
        this.y = missMatchAndCod;
    }

    public void t(CouponCommunication couponCommunication) {
        this.w = couponCommunication;
    }

    public void u(ArrayList<PaymentSummary> arrayList) {
        this.e = arrayList;
    }

    public void v(ArrayList<PaymentSummary> arrayList) {
        if (this.e == null) {
            this.e = new ArrayList();
        }
        this.e.clear();
        this.u(arrayList);
    }

    public void writeToParcel(Parcel parcel, int n2) {
        super.writeToParcel(parcel, n2);
        parcel.writeTypedList(this.e);
        parcel.writeParcelable((Parcelable)this.f, n2);
        parcel.writeParcelable((Parcelable)this.g, n2);
        parcel.writeParcelable((Parcelable)this.h, n2);
        parcel.writeParcelable((Parcelable)this.i, n2);
        parcel.writeParcelable((Parcelable)this.j, n2);
        parcel.writeByte((byte)this.k);
        parcel.writeParcelable((Parcelable)this.s, n2);
        parcel.writeParcelable((Parcelable)this.t, n2);
        parcel.writeParcelable((Parcelable)this.u, n2);
        parcel.writeParcelable((Parcelable)this.v, n2);
        parcel.writeParcelable((Parcelable)this.A, n2);
        parcel.writeParcelable((Parcelable)this.w, n2);
        parcel.writeString(this.x);
        parcel.writeParcelable((Parcelable)this.y, n2);
        parcel.writeByte((byte)this.z);
    }
}

