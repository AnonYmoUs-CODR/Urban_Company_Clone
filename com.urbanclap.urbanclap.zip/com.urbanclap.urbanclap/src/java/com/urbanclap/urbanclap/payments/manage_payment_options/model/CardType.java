/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import com.google.gson.annotations.SerializedName;

public final class CardType
extends Enum<CardType> {
    private static final /* synthetic */ CardType[] $VALUES;
    @SerializedName(value="CREDIT")
    public static final /* enum */ CardType CREDIT;
    @SerializedName(value="DEBIT")
    public static final /* enum */ CardType DEBIT;

    public static {
        CardType cardType;
        CardType cardType2;
        CardType[] arrcardType = new CardType[2];
        CREDIT = cardType2 = new CardType();
        arrcardType[0] = cardType2;
        DEBIT = cardType = new CardType();
        arrcardType[1] = cardType;
        $VALUES = arrcardType;
    }

    public static CardType valueOf(String string) {
        return (CardType)Enum.valueOf(CardType.class, (String)string);
    }

    public static CardType[] values() {
        return (CardType[])$VALUES.clone();
    }
}

