/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.urbanclap.payments.emi;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.payments.emi.EmiType;
import com.urbanclap.urbanclap.payments.manage_payment_options.model.CardType;
import i2.a0.d.l;

public final class EmiPlan
implements Parcelable {
    public static final Parcelable.Creator<EmiPlan> CREATOR = new a();
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final CardType f;
    public final String g;
    public final String h;
    public final int i;
    public final String j;
    public final String k;
    public final EmiType s;

    public EmiPlan(String string, String string2, String string3, String string4, String string5, CardType cardType, String string6, String string7, int n, String string8, String string9, EmiType emiType) {
        l.g((Object)string, (String)"id");
        l.g((Object)string2, (String)"emi");
        l.g((Object)string3, (String)"interest");
        l.g((Object)string5, (String)"total");
        l.g((Object)((Object)cardType), (String)"cardType");
        l.g((Object)string7, (String)"code");
        l.g((Object)string8, (String)"bankCode");
        l.g((Object)string9, (String)"emiTypeString");
        l.g((Object)((Object)emiType), (String)"emiType");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = cardType;
        this.g = string6;
        this.h = string7;
        this.i = n;
        this.j = string8;
        this.k = string9;
        this.s = emiType;
    }

    public final String a() {
        return this.j;
    }

    public final String b() {
        return this.h;
    }

    public final String c() {
        return this.b;
    }

    public final EmiType d() {
        return this.s;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.k;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof EmiPlan)) break block3;
                EmiPlan emiPlan = (EmiPlan)object;
                if (l.c((Object)this.a, (Object)emiPlan.a) && l.c((Object)this.b, (Object)emiPlan.b) && l.c((Object)this.c, (Object)emiPlan.c) && l.c((Object)this.d, (Object)emiPlan.d) && l.c((Object)this.e, (Object)emiPlan.e) && l.c((Object)((Object)this.f), (Object)((Object)emiPlan.f)) && l.c((Object)this.g, (Object)emiPlan.g) && l.c((Object)this.h, (Object)emiPlan.h) && this.i == emiPlan.i && l.c((Object)this.j, (Object)emiPlan.j) && l.c((Object)this.k, (Object)emiPlan.k) && l.c((Object)((Object)this.s), (Object)((Object)emiPlan.s))) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.a;
    }

    public final String g() {
        return this.g;
    }

    public final int h() {
        return this.i;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.c;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.d;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string5 = this.e;
        int n9 = string5 != null ? string5.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        CardType cardType = this.f;
        int n11 = cardType != null ? cardType.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string6 = this.g;
        int n13 = string6 != null ? string6.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        String string7 = this.h;
        int n15 = string7 != null ? string7.hashCode() : 0;
        int n16 = 31 * (31 * (n14 + n15) + this.i);
        String string8 = this.j;
        int n17 = string8 != null ? string8.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string9 = this.k;
        int n19 = string9 != null ? string9.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        EmiType emiType = this.s;
        int n21 = 0;
        if (emiType != null) {
            n21 = emiType.hashCode();
        }
        return n20 + n21;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("EmiPlan(id=");
        stringBuilder.append(this.a);
        stringBuilder.append(", emi=");
        stringBuilder.append(this.b);
        stringBuilder.append(", interest=");
        stringBuilder.append(this.c);
        stringBuilder.append(", discount=");
        stringBuilder.append(this.d);
        stringBuilder.append(", total=");
        stringBuilder.append(this.e);
        stringBuilder.append(", cardType=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", infoText=");
        stringBuilder.append(this.g);
        stringBuilder.append(", code=");
        stringBuilder.append(this.h);
        stringBuilder.append(", tenure=");
        stringBuilder.append(this.i);
        stringBuilder.append(", bankCode=");
        stringBuilder.append(this.j);
        stringBuilder.append(", emiTypeString=");
        stringBuilder.append(this.k);
        stringBuilder.append(", emiType=");
        stringBuilder.append((Object)this.s);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        parcel.writeString(this.e);
        parcel.writeString(this.f.name());
        parcel.writeString(this.g);
        parcel.writeString(this.h);
        parcel.writeInt(this.i);
        parcel.writeString(this.j);
        parcel.writeString(this.k);
        parcel.writeString(this.s.name());
    }

    public static final class a
    implements Parcelable.Creator<EmiPlan> {
        public final EmiPlan a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            EmiPlan emiPlan = new EmiPlan(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), (CardType)Enum.valueOf(CardType.class, (String)parcel.readString()), parcel.readString(), parcel.readString(), parcel.readInt(), parcel.readString(), parcel.readString(), (EmiType)Enum.valueOf(EmiType.class, (String)parcel.readString()));
            return emiPlan;
        }

        public final EmiPlan[] b(int n) {
            return new EmiPlan[n];
        }
    }

}

