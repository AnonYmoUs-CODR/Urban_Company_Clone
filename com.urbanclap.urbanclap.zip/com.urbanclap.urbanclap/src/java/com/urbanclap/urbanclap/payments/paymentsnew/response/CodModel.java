/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.CodModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.k.n.l0.b
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.CodDataModel;
import com.urbanclap.urbanclap.payments.paymentsnew.response.CodModel;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.l0.b;

/*
 * Exception performing whole class analysis.
 */
public final class CodModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="data")
    @b(className="CodModel", fieldName="parent")
    private final CodDataModel b;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public CodModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this((CodDataModel)parcel.readParcelable(CodDataModel.class.getClassLoader()));
    }

    public CodModel(CodDataModel codDataModel) {
        super(null, 1, null);
        this.b = codDataModel;
    }

    public final CodDataModel b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CodModel)) break block3;
                CodModel codModel = (CodModel)((Object)object);
                if (l.c((Object)((Object)this.b), (Object)((Object)codModel.b))) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        CodDataModel codDataModel = this.b;
        if (codDataModel != null) {
            return codDataModel.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CodModel(paymentOptionKeyData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeParcelable((Parcelable)this.b, n2);
    }
}

