/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  com.google.gson.annotations.Expose
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.k.n.q0.v.a
 */
package com.urbanclap.urbanclap.payments.postbox.request;

import androidx.annotation.Keep;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;
import t1.r.k.n.q0.v.a;

@Keep
public final class GatewayTransactionStatusRequestModel
extends a {
    @Expose
    @SerializedName(value="transaction_id")
    private final String transaction_id;

    public GatewayTransactionStatusRequestModel(String string, String string2, String string3, String string4) {
        l.g((Object)string2, (String)"mDeviceId");
        l.g((Object)string3, (String)"mVersionName");
        l.g((Object)string4, (String)"mVersionCode");
        super(string2, string3, string4, null, 0, null, 56, null);
        this.transaction_id = string;
    }
}

