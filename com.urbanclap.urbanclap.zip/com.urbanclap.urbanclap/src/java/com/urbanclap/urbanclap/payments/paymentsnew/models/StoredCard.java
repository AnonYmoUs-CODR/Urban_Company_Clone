/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentOptionsTemplateTypes
 *  com.urbanclap.urbanclap.payments.paymentsnew.models.StoredCard$a
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.Card
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.StoredCards
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  t1.r.k.j.f0.i.m
 *  t1.r.k.j.f0.i.m$j
 */
package com.urbanclap.urbanclap.payments.paymentsnew.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.payments.paymentsnew.models.PaymentOptionsTemplateTypes;
import com.urbanclap.urbanclap.payments.paymentsnew.models.StoredCard;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.Card;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.StoredCards;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import t1.r.k.j.f0.i.m;

/*
 * Exception performing whole class analysis.
 */
public final class StoredCard
extends m.j
implements Parcelable {
    public static final Parcelable.Creator<StoredCard> CREATOR;
    public PaymentOptionsTemplateTypes a;
    public String b;
    public int c;
    public String d;
    public Card e;
    public Boolean f;
    public String g;
    public List<String> h;
    public ArrayList<StoredCards> i;
    public String j;
    public String k;
    public List<String> s;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public StoredCard(PaymentOptionsTemplateTypes paymentOptionsTemplateTypes, String string, int n, String string2, Card card, Boolean bl, String string3, List<String> list, ArrayList<StoredCards> arrayList, String string4, String string5, List<String> list2) {
        this.a = paymentOptionsTemplateTypes;
        this.b = string;
        this.c = n;
        this.d = string2;
        this.e = card;
        this.f = bl;
        this.g = string3;
        this.h = list;
        this.i = arrayList;
        this.j = string4;
        this.k = string5;
        this.s = list2;
    }

    public /* synthetic */ StoredCard(PaymentOptionsTemplateTypes paymentOptionsTemplateTypes, String string, int n, String string2, Card card, Boolean bl, String string3, List list, ArrayList arrayList, String string4, String string5, List list2, int n2, g g2) {
        Boolean bl2 = (n2 & 32) != 0 ? Boolean.FALSE : bl;
        String string6 = (n2 & 64) != 0 ? null : string3;
        List list3 = (n2 & 128) != 0 ? Collections.emptyList() : list;
        ArrayList arrayList2 = (n2 & 256) != 0 ? null : arrayList;
        String string7 = (n2 & 512) != 0 ? null : string4;
        String string8 = (n2 & 1024) != 0 ? null : string5;
        List list4 = (n2 & 2048) != 0 ? null : list2;
        this(paymentOptionsTemplateTypes, string, n, string2, card, bl2, string6, (List<String>)list3, (ArrayList<StoredCards>)arrayList2, string7, string8, (List<String>)list4);
    }

    public final String a() {
        return this.j;
    }

    public final String b() {
        return this.k;
    }

    public final ArrayList<StoredCards> c() {
        return this.i;
    }

    public final int d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public final List<String> e() {
        return this.s;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof StoredCard)) break block3;
                StoredCard storedCard = (StoredCard)((Object)object);
                if (l.c((Object)this.a, (Object)storedCard.a) && l.c((Object)this.b, (Object)storedCard.b) && this.c == storedCard.c && l.c((Object)this.d, (Object)storedCard.d) && l.c((Object)this.e, (Object)storedCard.e) && l.c((Object)this.f, (Object)storedCard.f) && l.c((Object)this.g, (Object)storedCard.g) && l.c(this.h, storedCard.h) && l.c(this.i, storedCard.i) && l.c((Object)this.j, (Object)storedCard.j) && l.c((Object)this.k, (Object)storedCard.k) && l.c(this.s, storedCard.s)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.b;
    }

    public final String g() {
        return this.d;
    }

    public final Card h() {
        return this.e;
    }

    public int hashCode() {
        PaymentOptionsTemplateTypes paymentOptionsTemplateTypes = this.a;
        int n = paymentOptionsTemplateTypes != null ? paymentOptionsTemplateTypes.hashCode() : 0;
        int n2 = n * 31;
        String string = this.b;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (31 * (n2 + n3) + this.c);
        String string2 = this.d;
        int n5 = string2 != null ? string2.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        Card card = this.e;
        int n7 = card != null ? card.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        Boolean bl = this.f;
        int n9 = bl != null ? bl.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        String string3 = this.g;
        int n11 = string3 != null ? string3.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        List<String> list = this.h;
        int n13 = list != null ? list.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        ArrayList<StoredCards> arrayList = this.i;
        int n15 = arrayList != null ? arrayList.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        String string4 = this.j;
        int n17 = string4 != null ? string4.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string5 = this.k;
        int n19 = string5 != null ? string5.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        List<String> list2 = this.s;
        int n21 = 0;
        if (list2 != null) {
            n21 = list2.hashCode();
        }
        return n20 + n21;
    }

    public final List<String> i() {
        return this.h;
    }

    public final String j() {
        return this.g;
    }

    public final PaymentOptionsTemplateTypes k() {
        return this.a;
    }

    public final Boolean l() {
        return this.f;
    }

    public final void m(Card card) {
        this.e = card;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("StoredCard(type=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", paymentMode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", gatewayId=");
        stringBuilder.append(this.c);
        stringBuilder.append(", pgName=");
        stringBuilder.append(this.d);
        stringBuilder.append(", storedCard=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(", isPayLater=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", title=");
        stringBuilder.append(this.g);
        stringBuilder.append(", subtitleList=");
        stringBuilder.append(this.h);
        stringBuilder.append(", cardsList=");
        stringBuilder.append(this.i);
        stringBuilder.append(", bottomSheetTitle=");
        stringBuilder.append(this.j);
        stringBuilder.append(", cardSaveInfoText=");
        stringBuilder.append(this.k);
        stringBuilder.append(", infoList=");
        stringBuilder.append(this.s);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        PaymentOptionsTemplateTypes paymentOptionsTemplateTypes = this.a;
        if (paymentOptionsTemplateTypes != null) {
            parcel.writeInt(1);
            parcel.writeString(paymentOptionsTemplateTypes.name());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.b);
        parcel.writeInt(this.c);
        parcel.writeString(this.d);
        Card card = this.e;
        if (card != null) {
            parcel.writeInt(1);
            card.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        Boolean bl = this.f;
        if (bl != null) {
            parcel.writeInt(1);
            parcel.writeInt((int)bl.booleanValue());
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.g);
        parcel.writeStringList(this.h);
        ArrayList<StoredCards> arrayList = this.i;
        if (arrayList != null) {
            parcel.writeInt(1);
            parcel.writeInt(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                parcel.writeParcelable((Parcelable)((StoredCards)iterator.next()), n);
            }
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.j);
        parcel.writeString(this.k);
        parcel.writeStringList(this.s);
    }
}

