/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.manage_payment_options.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

public final class UpiOption
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="logo_url")
    private String a;
    @SerializedName(value="display_name")
    private String b;
    @SerializedName(value="upi_id")
    private ArrayList<Integer> c;
    @SerializedName(value="action_text")
    private String d;

    public UpiOption() {
    }

    public UpiOption(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
        this.a = parcel.readString();
        this.b = parcel.readString();
        ArrayList arrayList = this.c;
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        this.c = arrayList;
        parcel.readList((List)arrayList, Integer.TYPE.getClassLoader());
        this.d = parcel.readString();
    }

    public final String a() {
        return this.d;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.a;
    }

    public final ArrayList<Integer> d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeList(this.c);
        parcel.writeString(this.d);
    }

    public static final class a
    implements Parcelable.Creator<UpiOption> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public UpiOption a(Parcel parcel) {
            l.g((Object)parcel, (String)"parcel");
            return new UpiOption(parcel);
        }

        public UpiOption[] b(int n) {
            return new UpiOption[n];
        }
    }

}

