/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel
 *  com.urbanclap.urbanclap.payments.paymentsnew.other_models.ActiveBanks
 *  com.urbanclap.urbanclap.payments.paymentsnew.response.NetbankingDataModel$a
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 */
package com.urbanclap.urbanclap.payments.paymentsnew.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.payments.paymentsnew.deserializer.PaymentsItemBaseModel;
import com.urbanclap.urbanclap.payments.paymentsnew.other_models.ActiveBanks;
import com.urbanclap.urbanclap.payments.paymentsnew.response.NetbankingDataModel;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class NetbankingDataModel
extends PaymentsItemBaseModel
implements Parcelable {
    public static final a CREATOR;
    @SerializedName(value="payment_mode")
    private final String b;
    @SerializedName(value="title")
    private final String c;
    @SerializedName(value="gateway_id")
    private final int d;
    @SerializedName(value="pg_name")
    private final String e;
    @SerializedName(value="active_banks")
    private final ArrayList<ActiveBanks> f;
    @SerializedName(value="dowtime_message")
    private final String g;
    @SerializedName(value="is_disable")
    private boolean h;
    @SerializedName(value="disable_reason")
    private final String i;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public NetbankingDataModel(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        String string = parcel.readString();
        String string2 = parcel.readString();
        int n2 = parcel.readInt();
        String string3 = parcel.readString();
        ArrayList arrayList = parcel.readArrayList(ActiveBanks.class.getClassLoader());
        String string4 = parcel.readString();
        boolean bl = parcel.readByte() != (byte)(false ? 1 : 0);
        this(string, string2, n2, string3, (ArrayList<ActiveBanks>)arrayList, string4, bl, parcel.readString());
    }

    public NetbankingDataModel(String string, String string2, int n2, String string3, ArrayList<ActiveBanks> arrayList, String string4, boolean bl, String string5) {
        super(null, 1, null);
        this.b = string;
        this.c = string2;
        this.d = n2;
        this.e = string3;
        this.f = arrayList;
        this.g = string4;
        this.h = bl;
        this.i = string5;
    }

    public final ArrayList<ActiveBanks> b() {
        return this.f;
    }

    public final String c() {
        return this.i;
    }

    public final String d() {
        return this.g;
    }

    public int describeContents() {
        return 0;
    }

    public final int e() {
        return this.d;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof NetbankingDataModel)) break block3;
                NetbankingDataModel netbankingDataModel = (NetbankingDataModel)((Object)object);
                if (l.c((Object)this.b, (Object)netbankingDataModel.b) && l.c((Object)this.c, (Object)netbankingDataModel.c) && this.d == netbankingDataModel.d && l.c((Object)this.e, (Object)netbankingDataModel.e) && l.c(this.f, netbankingDataModel.f) && l.c((Object)this.g, (Object)netbankingDataModel.g) && this.h == netbankingDataModel.h && l.c((Object)this.i, (Object)netbankingDataModel.i)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String f() {
        return this.b;
    }

    public final String g() {
        return this.e;
    }

    public final String h() {
        return this.c;
    }

    public int hashCode() {
        String string = this.b;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = n2 * 31;
        String string2 = this.c;
        int n4 = string2 != null ? string2.hashCode() : 0;
        int n5 = 31 * (31 * (n3 + n4) + this.d);
        String string3 = this.e;
        int n6 = string3 != null ? string3.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        ArrayList<ActiveBanks> arrayList = this.f;
        int n8 = arrayList != null ? arrayList.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        String string4 = this.g;
        int n10 = string4 != null ? string4.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        int n12 = this.h ? 1 : 0;
        if (n12 != 0) {
            n12 = 1;
        }
        int n13 = 31 * (n11 + n12);
        String string5 = this.i;
        int n14 = 0;
        if (string5 != null) {
            n14 = string5.hashCode();
        }
        return n13 + n14;
    }

    public final boolean i() {
        return this.h;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("NetbankingDataModel(paymentMode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", title=");
        stringBuilder.append(this.c);
        stringBuilder.append(", gatewayId=");
        stringBuilder.append(this.d);
        stringBuilder.append(", pgName=");
        stringBuilder.append(this.e);
        stringBuilder.append(", activeBanksArrayList=");
        stringBuilder.append(this.f);
        stringBuilder.append(", downtimeMessage=");
        stringBuilder.append(this.g);
        stringBuilder.append(", isDisabled=");
        stringBuilder.append(this.h);
        stringBuilder.append(", disableReason=");
        stringBuilder.append(this.i);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeInt(this.d);
        parcel.writeString(this.e);
        parcel.writeTypedList(this.f);
        parcel.writeString(this.g);
        parcel.writeByte((byte)this.h);
        parcel.writeString(this.i);
    }
}

