/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.IntentSender
 *  android.content.IntentSender$SendIntentException
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.Observer
 *  com.google.android.gms.auth.api.Auth
 *  com.google.android.gms.auth.api.credentials.CredentialPickerConfig
 *  com.google.android.gms.auth.api.credentials.CredentialPickerConfig$Builder
 *  com.google.android.gms.auth.api.credentials.CredentialsApi
 *  com.google.android.gms.auth.api.credentials.HintRequest
 *  com.google.android.gms.auth.api.credentials.HintRequest$Builder
 *  com.google.android.gms.auth.api.phone.SmsRetriever
 *  com.google.android.gms.common.api.GoogleApiClient
 *  com.google.android.gms.tasks.Task
 *  com.urbanclap.urbanclap.compass.locationselection.CountriesData
 *  com.urbanclap.urbanclap.login.SmsReceiver
 *  com.urbanclap.urbanclap.login.SmsReceiver$a
 *  com.urbanclap.urbanclap.login.UcLoginUtils
 *  com.urbanclap.urbanclap.login.login_managers.PhoneLoginManager$Source
 *  com.urbanclap.urbanclap.login.login_managers.PhoneLoginManager$a
 *  com.urbanclap.urbanclap.login.login_managers.PhoneLoginManager$c
 *  i2.a0.c.p
 *  i2.a0.d.l
 *  i2.x.d
 *  i2.x.g
 *  j2.b.f
 *  j2.b.i0
 *  j2.b.m1
 *  j2.b.y0
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Map
 *  java.util.Objects
 *  t1.r.k.i.j
 *  t1.r.k.i.t.a
 *  t1.r.k.i.t.a$a
 *  t1.r.k.i.t.b
 *  t1.r.k.n.o0.c
 *  t1.r.k.n.p
 *  t1.r.k.n.p$a
 *  t1.r.k.n.p0.a
 */
package com.urbanclap.urbanclap.login.login_managers;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.auth.api.credentials.CredentialsApi;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.Task;
import com.urbanclap.urbanclap.compass.locationselection.CountriesData;
import com.urbanclap.urbanclap.login.SmsReceiver;
import com.urbanclap.urbanclap.login.UcLoginUtils;
import com.urbanclap.urbanclap.login.login_managers.PhoneLoginManager;
import i2.a0.d.l;
import i2.x.d;
import i2.x.g;
import j2.b.f;
import j2.b.i0;
import j2.b.m1;
import j2.b.y0;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import t1.r.k.i.j;
import t1.r.k.i.t.a;
import t1.r.k.n.p;

/*
 * Exception performing whole class analysis.
 */
public final class PhoneLoginManager
extends t1.r.k.i.t.a
implements SmsReceiver.a {
    public GoogleApiClient b;
    public SmsReceiver c;
    public boolean d;
    public boolean e;
    public a f;
    public boolean g;
    public final Context h;

    public PhoneLoginManager(Context context, a.a a2) {
        l.g((Object)context, (String)"callingContext");
        l.g((Object)a2, (String)"managerCallback");
        super(a2);
        this.h = context;
        this.c = new SmsReceiver((SmsReceiver.a)this);
        this.l();
    }

    public static final /* synthetic */ Context e(PhoneLoginManager phoneLoginManager) {
        return phoneLoginManager.h;
    }

    public static final /* synthetic */ void g(PhoneLoginManager phoneLoginManager, GoogleApiClient googleApiClient) {
        phoneLoginManager.b = googleApiClient;
    }

    public void N0(String string) {
        l.g((Object)string, (String)"otp");
        Context context = this.h;
        Objects.requireNonNull((Object)context, (String)"null cannot be cast to non-null type com.urbanclap.urbanclap.ucshared.login.AutoLoginInterface");
        ((t1.r.k.n.p0.a)context).U1(string);
    }

    public void b(Object object) {
        l.g((Object)object, (String)"userData");
        a a2 = object;
        Source source = a2.b();
        int n2 = t1.r.k.i.t.b.a[source.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                return;
            }
            if (a2.c() != null) {
                Map map = a2.c();
                l.e((Object)map);
                this.p((Map<String, ? extends Object>)map);
                return;
            }
        } else if (a2.a() != null) {
            UcLoginUtils ucLoginUtils = UcLoginUtils.a;
            String string = a2.a();
            l.e((Object)string);
            ArrayList arrayList = ucLoginUtils.a(string);
            if (arrayList != null && arrayList.size() == 0) {
                a.a a3 = this.a();
                String string2 = p.d.a().getString(j.u);
                l.f((Object)string2, (String)"UcSharedApplication.cont\u2026_do_not_serve_in_country)");
                a3.m(string2);
                return;
            }
            Integer n3 = arrayList != null ? Integer.valueOf((int)arrayList.size()) : null;
            l.e((Object)n3);
            if (n3 > 1) {
                this.a().t(arrayList);
                this.f = a2;
                LiveData liveData = this.a().K();
                Context context = this.h;
                Objects.requireNonNull((Object)context, (String)"null cannot be cast to non-null type androidx.lifecycle.LifecycleOwner");
                liveData.observe((LifecycleOwner)context, }
        }
    }
    java.lang.IllegalStateException: Inner class got unexpected class file - revert this change
    
    