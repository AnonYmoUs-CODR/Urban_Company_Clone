/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.login.model.response_objects.GenerateOtpApiResponseObject$a
 *  com.urbanclap.urbanclap.login.model.response_objects.MissingFieldType
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.List
 */
package com.urbanclap.urbanclap.login.model.response_objects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.login.model.response_objects.GenerateOtpApiResponseObject;
import com.urbanclap.urbanclap.login.model.response_objects.MissingFieldType;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import i2.a0.d.l;
import java.util.Iterator;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
public final class GenerateOtpApiResponseObject
extends ResponseBaseModel
implements Parcelable {
    public static final Parcelable.Creator<GenerateOtpApiResponseObject> CREATOR;
    @SerializedName(value="otpGenerated")
    private final boolean e;
    @SerializedName(value="missingFields")
    private final List<MissingFieldType> f;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public GenerateOtpApiResponseObject(boolean bl, List<MissingFieldType> list) {
        this.e = bl;
        this.f = list;
    }

    public final List<MissingFieldType> e() {
        return this.f;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof GenerateOtpApiResponseObject)) break block3;
                GenerateOtpApiResponseObject generateOtpApiResponseObject = (GenerateOtpApiResponseObject)((Object)object);
                if (this.e == generateOtpApiResponseObject.e && l.c(this.f, generateOtpApiResponseObject.f)) break block2;
            }
            return false;
        }
        return true;
    }

    public final boolean f() {
        return this.e;
    }

    public int hashCode() {
        int n2 = this.e ? 1 : 0;
        if (n2 != 0) {
            n2 = 1;
        }
        int n3 = n2 * 31;
        List<MissingFieldType> list = this.f;
        int n4 = list != null ? list.hashCode() : 0;
        return n3 + n4;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GenerateOtpApiResponseObject(otpGenerated=");
        stringBuilder.append(this.e);
        stringBuilder.append(", missingFields=");
        stringBuilder.append(this.f);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeInt((int)this.e);
        List<MissingFieldType> list = this.f;
        if (list != null) {
            parcel.writeInt(1);
            parcel.writeInt(list.size());
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((MissingFieldType)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
    }
}

