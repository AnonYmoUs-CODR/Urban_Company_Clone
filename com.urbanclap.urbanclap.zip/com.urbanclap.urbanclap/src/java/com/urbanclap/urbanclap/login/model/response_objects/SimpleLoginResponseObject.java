/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.login.model.response_objects.SimpleLoginResponseObject$a
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  com.urbanclap.urbanclap.ucshared.models.UserData
 *  com.urbanclap.urbanclap.ucshared.models.UserData$City
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.login.model.response_objects;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.login.model.response_objects.SimpleLoginResponseObject;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.UserData;
import i2.a0.d.g;
import i2.a0.d.l;

/*
 * Exception performing whole class analysis.
 */
public final class SimpleLoginResponseObject
extends ResponseBaseModel {
    public static final a CREATOR;
    @SerializedName(value="token")
    private String e;
    @SerializedName(value="user")
    private UserData f;
    @SerializedName(value="user_type")
    private String g;
    @SerializedName(value="last_cr_city")
    private UserData.City h;

    public static {
        CREATOR = new /* Unavailable Anonymous Inner Class!! */;
    }

    public SimpleLoginResponseObject() {
    }

    public SimpleLoginResponseObject(Parcel parcel) {
        l.g((Object)parcel, (String)"parcel");
        this();
        this.e = parcel.readString();
        this.f = (UserData)parcel.readParcelable(UserData.class.getClassLoader());
        this.g = parcel.readString();
        this.h = (UserData.City)parcel.readParcelable(UserData.City.class.getClassLoader());
    }

    public int describeContents() {
        return 0;
    }

    public final UserData.City e() {
        return this.h;
    }

    public final String f() {
        return this.e;
    }

    public final UserData g() {
        return this.f;
    }

    public final String h() {
        return this.g;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        super.writeToParcel(parcel, n2);
        parcel.writeString(this.e);
        parcel.writeParcelable((Parcelable)this.f, n2);
        parcel.writeString(this.g);
        parcel.writeParcelable((Parcelable)this.h, n2);
    }
}

