/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucaddress.models.MapBottomSheetData;
import i2.a0.d.l;

public final class MapBottomSheetItem
implements Parcelable {
    public static final Parcelable.Creator<MapBottomSheetItem> CREATOR = new a();
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="data")
    private final MapBottomSheetData b;

    public MapBottomSheetItem(String string, MapBottomSheetData mapBottomSheetData) {
        this.a = string;
        this.b = mapBottomSheetData;
    }

    public final MapBottomSheetData a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        MapBottomSheetData mapBottomSheetData = this.b;
        if (mapBottomSheetData != null) {
            parcel.writeInt(1);
            mapBottomSheetData.writeToParcel(parcel, 0);
            return;
        }
        parcel.writeInt(0);
    }

    public static final class a
    implements Parcelable.Creator<MapBottomSheetItem> {
        public final MapBottomSheetItem a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            MapBottomSheetData mapBottomSheetData = parcel.readInt() != 0 ? (MapBottomSheetData)MapBottomSheetData.CREATOR.createFromParcel(parcel) : null;
            return new MapBottomSheetItem(string, mapBottomSheetData);
        }

        public final MapBottomSheetItem[] b(int n2) {
            return new MapBottomSheetItem[n2];
        }
    }

}

