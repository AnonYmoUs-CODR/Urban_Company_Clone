/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.ViewModel
 *  androidx.lifecycle.ViewModelProvider
 *  androidx.lifecycle.ViewModelProvider$NewInstanceFactory
 *  com.urbanclap.urbanclap.ucaddress.CustomViewModelFactory$Type
 *  com.urbanclap.urbanclap.ucaddress.models.MapAddressInfo
 *  i2.a0.d.l
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.NoWhenBranchMatchedException
 *  t1.r.k.m.b
 *  t1.r.k.m.m.h.b
 */
package com.urbanclap.urbanclap.ucaddress;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.urbanclap.urbanclap.ucaddress.CustomViewModelFactory;
import com.urbanclap.urbanclap.ucaddress.models.MapAddressInfo;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import i2.a0.d.l;
import kotlin.NoWhenBranchMatchedException;
import t1.r.k.m.b;

public final class CustomViewModelFactory
extends ViewModelProvider.NewInstanceFactory {
    public final Type a;
    public final Object b;
    public final boolean c;
    public final MapAddressInfo d;

    public CustomViewModelFactory(Type type, Object object, boolean bl, MapAddressInfo mapAddressInfo) {
        l.g((Object)type, (String)"type");
        this.a = type;
        this.b = object;
        this.c = bl;
        this.d = mapAddressInfo;
    }

    public <T extends ViewModel> T create(Class<T> class_) {
        l.g(class_, (String)"modelClass");
        Type type = this.a;
        if (b.a[type.ordinal()] == 1) {
            return (T)new t1.r.k.m.m.h.b((UcAddress)this.b, this.c, this.d);
        }
        throw new NoWhenBranchMatchedException();
    }
}

