/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.OtherAttributes
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.OtherAttributes;
import i2.a0.d.l;

public final class MapBottomSheetItemCta
implements Parcelable {
    public static final Parcelable.Creator<MapBottomSheetItemCta> CREATOR = new a();
    @SerializedName(value="type")
    private final String a;
    @SerializedName(value="text")
    private final String b;
    @SerializedName(value="other_attributes")
    private final OtherAttributes c;

    public MapBottomSheetItemCta(String string, String string2, OtherAttributes otherAttributes) {
        this.a = string;
        this.b = string2;
        this.c = otherAttributes;
    }

    public final OtherAttributes a() {
        return this.c;
    }

    public final String b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeParcelable((Parcelable)this.c, n2);
    }

    public static final class a
    implements Parcelable.Creator<MapBottomSheetItemCta> {
        public final MapBottomSheetItemCta a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            return new MapBottomSheetItemCta(parcel.readString(), parcel.readString(), (OtherAttributes)parcel.readParcelable(MapBottomSheetItemCta.class.getClassLoader()));
        }

        public final MapBottomSheetItemCta[] b(int n2) {
            return new MapBottomSheetItemCta[n2];
        }
    }

}

