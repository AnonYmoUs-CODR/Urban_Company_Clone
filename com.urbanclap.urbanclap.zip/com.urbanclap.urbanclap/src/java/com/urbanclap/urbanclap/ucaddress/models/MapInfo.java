/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class MapInfo
implements Parcelable {
    public static final Parcelable.Creator<MapInfo> CREATOR = new a();
    @SerializedName(value="pin_title")
    private final String a;
    @SerializedName(value="show_pulse_animation")
    private final Boolean b;

    public MapInfo(String string, Boolean bl) {
        this.a = string;
        this.b = bl;
    }

    public final String a() {
        return this.a;
    }

    public final Boolean b() {
        return this.b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        int n3;
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        Boolean bl = this.b;
        if (bl != null) {
            parcel.writeInt(1);
            n3 = bl.booleanValue() ? 1 : 0;
        } else {
            n3 = 0;
        }
        parcel.writeInt(n3);
    }

    public static final class a
    implements Parcelable.Creator<MapInfo> {
        public final MapInfo a(Parcel parcel) {
            Boolean bl;
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            if (parcel.readInt() != 0) {
                boolean bl2 = parcel.readInt() != 0;
                bl = bl2;
            } else {
                bl = null;
            }
            return new MapInfo(string, bl);
        }

        public final MapInfo[] b(int n2) {
            return new MapInfo[n2];
        }
    }

}

