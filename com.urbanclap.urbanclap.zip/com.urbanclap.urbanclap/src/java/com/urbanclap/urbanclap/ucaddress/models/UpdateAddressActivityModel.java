/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AddressFlowTypes
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import com.urbanclap.urbanclap.ucshared.models.create_request.AddressFlowTypes;

public class UpdateAddressActivityModel
implements Parcelable {
    public static final Parcelable.Creator<UpdateAddressActivityModel> CREATOR = new Parcelable.Creator<UpdateAddressActivityModel>(){

        public UpdateAddressActivityModel a(Parcel parcel) {
            return new UpdateAddressActivityModel(parcel);
        }

        public UpdateAddressActivityModel[] b(int n2) {
            return new UpdateAddressActivityModel[n2];
        }
    };
    public boolean a;
    public String b;
    public String c;
    public UcAddress d;
    public float e;
    public String f;
    public AddressFlowTypes g;

    public UpdateAddressActivityModel(Parcel parcel) {
        boolean bl = parcel.readByte() != 0;
        this.a = bl;
        this.b = parcel.readString();
        this.c = parcel.readString();
        this.d = (UcAddress)parcel.readParcelable(UcAddress.class.getClassLoader());
        this.e = parcel.readFloat();
        this.f = parcel.readString();
        int n2 = parcel.readInt();
        AddressFlowTypes addressFlowTypes = n2 == -1 ? null : AddressFlowTypes.values()[n2];
        this.g = addressFlowTypes;
    }

    public UpdateAddressActivityModel(boolean bl, String string, String string2, UcAddress ucAddress, float f, String string3, AddressFlowTypes addressFlowTypes) {
        this.a = bl;
        this.b = string;
        this.c = string2;
        this.d = ucAddress;
        this.e = f;
        this.f = string3;
        this.g = addressFlowTypes;
    }

    public AddressFlowTypes a() {
        return this.g;
    }

    public String b() {
        return this.b;
    }

    public String c() {
        return this.c;
    }

    public float d() {
        return this.e;
    }

    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.f;
    }

    public UcAddress f() {
        return this.d;
    }

    public boolean g() {
        return this.a;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        parcel.writeByte((byte)this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        parcel.writeParcelable((Parcelable)this.d, n2);
        parcel.writeFloat(this.e);
        parcel.writeString(this.f);
        AddressFlowTypes addressFlowTypes = this.g;
        int n3 = addressFlowTypes == null ? -1 : addressFlowTypes.ordinal();
        parcel.writeInt(n3);
    }

}

