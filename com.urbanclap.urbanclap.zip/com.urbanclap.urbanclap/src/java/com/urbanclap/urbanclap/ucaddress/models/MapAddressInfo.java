/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucaddress.models.MapBottomSheetItem;
import com.urbanclap.urbanclap.ucaddress.models.MapInfo;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Iterator;

public final class MapAddressInfo
implements Parcelable {
    public static final Parcelable.Creator<MapAddressInfo> CREATOR = new a();
    @SerializedName(value="screen_type")
    private final String a;
    @SerializedName(value="map")
    private final MapInfo b;
    @SerializedName(value="bottom_sheet_items")
    private ArrayList<MapBottomSheetItem> c;

    public MapAddressInfo(String string, MapInfo mapInfo, ArrayList<MapBottomSheetItem> arrayList) {
        this.a = string;
        this.b = mapInfo;
        this.c = arrayList;
    }

    public final ArrayList<MapBottomSheetItem> a() {
        return this.c;
    }

    public final MapInfo b() {
        return this.b;
    }

    public final String c() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        MapInfo mapInfo = this.b;
        if (mapInfo != null) {
            parcel.writeInt(1);
            mapInfo.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        ArrayList<MapBottomSheetItem> arrayList = this.c;
        if (arrayList != null) {
            parcel.writeInt(1);
            parcel.writeInt(arrayList.size());
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                ((MapBottomSheetItem)iterator.next()).writeToParcel(parcel, 0);
            }
        } else {
            parcel.writeInt(0);
        }
    }

    public static final class a
    implements Parcelable.Creator<MapAddressInfo> {
        public final MapAddressInfo a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            MapInfo mapInfo = parcel.readInt() != 0 ? (MapInfo)MapInfo.CREATOR.createFromParcel(parcel) : null;
            int n2 = parcel.readInt();
            ArrayList arrayList = null;
            if (n2 != 0) {
                int n3;
                ArrayList arrayList2 = new ArrayList(n3);
                for (n3 = parcel.readInt(); n3 != 0; --n3) {
                    arrayList2.add((Object)((MapBottomSheetItem)MapBottomSheetItem.CREATOR.createFromParcel(parcel)));
                }
                arrayList = arrayList2;
            }
            return new MapAddressInfo(string, mapInfo, arrayList);
        }

        public final MapAddressInfo[] b(int n2) {
            return new MapAddressInfo[n2];
        }
    }

}

