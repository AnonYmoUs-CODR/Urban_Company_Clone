/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.urbanclap.urbanclap.ucaddress.add_address.address_details.AddressDetailsFragmentEntity$a
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable
 *  com.urbanclap.urbanclap.ucshared.models.KParcelable$a
 *  com.urbanclap.urbanclap.ucshared.models.create_request.ActionBottomSheet
 *  com.urbanclap.urbanclap.ucshared.models.create_request.AddressFlowTypes
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.add_address.address_details;

import android.os.Parcel;
import android.os.Parcelable;
import com.urbanclap.urbanclap.ucaddress.add_address.address_details.AddressDetailsFragmentEntity;
import com.urbanclap.urbanclap.ucshared.models.KParcelable;
import com.urbanclap.urbanclap.ucshared.models.create_request.ActionBottomSheet;
import com.urbanclap.urbanclap.ucshared.models.create_request.AddressFlowTypes;
import i2.a0.d.g;
import i2.a0.d.l;

public final class AddressDetailsFragmentEntity
implements KParcelable {
    public static final Parcelable.Creator<AddressDetailsFragmentEntity> CREATOR = new a();
    public final boolean a;
    public final float b;
    public final String c;
    public final String d;
    public final AddressFlowTypes e;
    public final ActionBottomSheet f;
    public final ActionBottomSheet g;

    public AddressDetailsFragmentEntity(Parcel parcel) {
        boolean bl = parcel.readInt() != 0;
        float f2 = parcel.readFloat();
        String string = parcel.readString();
        l.f((Object)string, (String)"parcel.readString()");
        String string2 = parcel.readString();
        l.f((Object)string2, (String)"parcel.readString()");
        int n2 = parcel.readInt();
        AddressFlowTypes addressFlowTypes = n2 >= 0 ? AddressFlowTypes.values()[n2] : null;
        this(bl, f2, string, string2, addressFlowTypes, (ActionBottomSheet)parcel.readParcelable(ActionBottomSheet.class.getClassLoader()), (ActionBottomSheet)parcel.readParcelable(ActionBottomSheet.class.getClassLoader()));
    }

    public /* synthetic */ AddressDetailsFragmentEntity(Parcel parcel, g g2) {
        this(parcel);
    }

    public AddressDetailsFragmentEntity(boolean bl, float f2, String string, String string2, AddressFlowTypes addressFlowTypes, ActionBottomSheet actionBottomSheet, ActionBottomSheet actionBottomSheet2) {
        l.g((Object)string, (String)"mScreenSource");
        l.g((Object)string2, (String)"mCategoryKey");
        this.a = bl;
        this.b = f2;
        this.c = string;
        this.d = string2;
        this.e = addressFlowTypes;
        this.f = actionBottomSheet;
        this.g = actionBottomSheet2;
    }

    public final ActionBottomSheet a() {
        return this.f;
    }

    public final String b() {
        return this.d;
    }

    public final boolean c() {
        return this.a;
    }

    public final float d() {
        return this.b;
    }

    public int describeContents() {
        return KParcelable.a.a((KParcelable)this);
    }

    public final String e() {
        return this.c;
    }

    public final ActionBottomSheet f() {
        return this.g;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"dest");
        parcel.writeInt((int)this.a);
        parcel.writeFloat(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.d);
        AddressFlowTypes addressFlowTypes = this.e;
        int n3 = addressFlowTypes != null ? addressFlowTypes.ordinal() : -1;
        parcel.writeInt(n3);
        parcel.writeParcelable((Parcelable)this.f, n2);
        parcel.writeParcelable((Parcelable)this.g, n2);
    }
}

