/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.common.PictureObject
 *  i2.a0.d.l
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.common.PictureObject;
import com.urbanclap.urbanclap.ucaddress.models.MapBottomSheetItemCta;
import com.urbanclap.urbanclap.ucaddress.models.MapBottomSheetValidation;
import i2.a0.d.l;

public final class MapBottomSheetData
implements Parcelable {
    public static final Parcelable.Creator<MapBottomSheetData> CREATOR = new a();
    @SerializedName(value="overflow_text")
    private final String a;
    @SerializedName(value="placeholder_text")
    private final String b;
    @SerializedName(value="footer_text")
    private final String c;
    @SerializedName(value="validation")
    private final MapBottomSheetValidation d;
    @SerializedName(value="address_component_type")
    private final String e;
    @SerializedName(value="title_component_type")
    private final String f;
    @SerializedName(value="subtitle_component_type")
    private final String g;
    @SerializedName(value="cta")
    private final MapBottomSheetItemCta h;
    @SerializedName(value="icon")
    private final PictureObject i;
    @SerializedName(value="id")
    private final String j;

    public MapBottomSheetData(String string, String string2, String string3, MapBottomSheetValidation mapBottomSheetValidation, String string4, String string5, String string6, MapBottomSheetItemCta mapBottomSheetItemCta, PictureObject pictureObject, String string7) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = mapBottomSheetValidation;
        this.e = string4;
        this.f = string5;
        this.g = string6;
        this.h = mapBottomSheetItemCta;
        this.i = pictureObject;
        this.j = string7;
    }

    public final String a() {
        return this.e;
    }

    public final MapBottomSheetItemCta b() {
        return this.h;
    }

    public final String c() {
        return this.c;
    }

    public final PictureObject d() {
        return this.i;
    }

    public int describeContents() {
        return 0;
    }

    public final String e() {
        return this.j;
    }

    public final String f() {
        return this.a;
    }

    public final String g() {
        return this.b;
    }

    public final String h() {
        return this.g;
    }

    public final String i() {
        return this.f;
    }

    public final MapBottomSheetValidation j() {
        return this.d;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        l.g((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
        MapBottomSheetValidation mapBottomSheetValidation = this.d;
        if (mapBottomSheetValidation != null) {
            parcel.writeInt(1);
            mapBottomSheetValidation.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeString(this.e);
        parcel.writeString(this.f);
        parcel.writeString(this.g);
        MapBottomSheetItemCta mapBottomSheetItemCta = this.h;
        if (mapBottomSheetItemCta != null) {
            parcel.writeInt(1);
            mapBottomSheetItemCta.writeToParcel(parcel, 0);
        } else {
            parcel.writeInt(0);
        }
        parcel.writeParcelable((Parcelable)this.i, n2);
        parcel.writeString(this.j);
    }

    public static final class a
    implements Parcelable.Creator<MapBottomSheetData> {
        public final MapBottomSheetData a(Parcel parcel) {
            l.g((Object)parcel, (String)"in");
            String string = parcel.readString();
            String string2 = parcel.readString();
            String string3 = parcel.readString();
            MapBottomSheetValidation mapBottomSheetValidation = parcel.readInt() != 0 ? (MapBottomSheetValidation)MapBottomSheetValidation.CREATOR.createFromParcel(parcel) : null;
            String string4 = parcel.readString();
            String string5 = parcel.readString();
            String string6 = parcel.readString();
            MapBottomSheetItemCta mapBottomSheetItemCta = parcel.readInt() != 0 ? (MapBottomSheetItemCta)MapBottomSheetItemCta.CREATOR.createFromParcel(parcel) : null;
            PictureObject pictureObject = (PictureObject)parcel.readParcelable(MapBottomSheetData.class.getClassLoader());
            String string7 = parcel.readString();
            MapBottomSheetData mapBottomSheetData = new MapBottomSheetData(string, string2, string3, mapBottomSheetValidation, string4, string5, string6, mapBottomSheetItemCta, pictureObject, string7);
            return mapBottomSheetData;
        }

        public final MapBottomSheetData[] b(int n2) {
            return new MapBottomSheetData[n2];
        }
    }

}

