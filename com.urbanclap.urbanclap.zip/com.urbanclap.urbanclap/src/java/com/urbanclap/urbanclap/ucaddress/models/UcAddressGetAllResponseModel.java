/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucaddress.models.MapAddressInfo
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 *  java.util.ArrayList
 */
package com.urbanclap.urbanclap.ucaddress.models;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucaddress.models.MapAddressInfo;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;
import java.util.ArrayList;

public final class UcAddressGetAllResponseModel
extends ResponseBaseModel {
    @SerializedName(value="addresses")
    private final ArrayList<UcAddress> e = new ArrayList();
    @SerializedName(value="skip_geocode_verification")
    private final boolean f;
    @SerializedName(value="map_address_info")
    private final MapAddressInfo g;

    public final ArrayList<UcAddress> e() {
        return this.e;
    }

    public final MapAddressInfo f() {
        return this.g;
    }

    public final boolean g() {
        return this.f;
    }
}

