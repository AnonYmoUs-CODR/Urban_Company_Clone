/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel
 */
package com.urbanclap.urbanclap.ucaddress.models;

import com.google.gson.annotations.SerializedName;
import com.urbanclap.urbanclap.ucshared.models.ResponseBaseModel;
import com.urbanclap.urbanclap.ucshared.models.UcAddress;

public final class UcAddressUpdateAddresslResponseModel
extends ResponseBaseModel {
    @SerializedName(value="location")
    private final UcAddress e;

    public final UcAddress e() {
        return this.e;
    }
}

