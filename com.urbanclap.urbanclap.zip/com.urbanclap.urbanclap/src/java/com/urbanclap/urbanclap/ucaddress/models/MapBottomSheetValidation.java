/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.l;

public final class MapBottomSheetValidation
implements Parcelable {
    public static final Parcelable.Creator<MapBottomSheetValidation> CREATOR = new a();
    @SerializedName(value="required")
    private final Boolean a;
    @SerializedName(value="failure_text")
    private final String b;

    public MapBottomSheetValidation(Boolean bl, String string) {
        this.a = bl;
        this.b = string;
    }

    public final String a() {
        return this.b;
    }

    public final Boolean b() {
        return this.a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n2) {
        int n3;
        l.g((Object)parcel, (String)"parcel");
        Boolean bl = this.a;
        if (bl != null) {
            parcel.writeInt(1);
            n3 = bl.booleanValue() ? 1 : 0;
        } else {
            n3 = 0;
        }
        parcel.writeInt(n3);
        parcel.writeString(this.b);
    }

    public static final class a
    implements Parcelable.Creator<MapBottomSheetValidation> {
        public final MapBottomSheetValidation a(Parcel parcel) {
            Boolean bl;
            l.g((Object)parcel, (String)"in");
            if (parcel.readInt() != 0) {
                boolean bl2 = parcel.readInt() != 0;
                bl = bl2;
            } else {
                bl = null;
            }
            return new MapBottomSheetValidation(bl, parcel.readString());
        }

        public final MapBottomSheetValidation[] b(int n2) {
            return new MapBottomSheetValidation[n2];
        }
    }

}

