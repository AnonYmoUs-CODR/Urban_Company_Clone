/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.urbanclap.ucaddress.add_address.helpers;

public final class AddressValidationErrorType
extends Enum<AddressValidationErrorType> {
    private static final /* synthetic */ AddressValidationErrorType[] $VALUES;
    public static final /* enum */ AddressValidationErrorType ADDRESS;
    public static final /* enum */ AddressValidationErrorType ADDRESS_PHONE_NUMBER;
    public static final /* enum */ AddressValidationErrorType CITY;
    public static final /* enum */ AddressValidationErrorType CITY_KEY;
    public static final /* enum */ AddressValidationErrorType ERROR_MESSAGE;
    public static final /* enum */ AddressValidationErrorType HOUSE_ADDRESS;
    public static final /* enum */ AddressValidationErrorType INIT;
    public static final /* enum */ AddressValidationErrorType LAT;
    public static final /* enum */ AddressValidationErrorType LNG;
    public static final /* enum */ AddressValidationErrorType LOCALITY;
    public static final /* enum */ AddressValidationErrorType NICK_NAME;
    public static final /* enum */ AddressValidationErrorType NO_ERROR;
    public static final /* enum */ AddressValidationErrorType OPTIONAL_INSTRUCTIONS;
    public static final /* enum */ AddressValidationErrorType PLACE_ID;
    public static final /* enum */ AddressValidationErrorType USER_NAME;

    public static {
        AddressValidationErrorType addressValidationErrorType;
        AddressValidationErrorType addressValidationErrorType2;
        AddressValidationErrorType addressValidationErrorType3;
        AddressValidationErrorType addressValidationErrorType4;
        AddressValidationErrorType addressValidationErrorType5;
        AddressValidationErrorType addressValidationErrorType6;
        AddressValidationErrorType addressValidationErrorType7;
        AddressValidationErrorType addressValidationErrorType8;
        AddressValidationErrorType addressValidationErrorType9;
        AddressValidationErrorType addressValidationErrorType10;
        AddressValidationErrorType addressValidationErrorType11;
        AddressValidationErrorType addressValidationErrorType12;
        AddressValidationErrorType addressValidationErrorType13;
        AddressValidationErrorType addressValidationErrorType14;
        AddressValidationErrorType addressValidationErrorType15;
        AddressValidationErrorType[] arraddressValidationErrorType = new AddressValidationErrorType[15];
        ADDRESS = addressValidationErrorType13 = new AddressValidationErrorType();
        arraddressValidationErrorType[0] = addressValidationErrorType13;
        LOCALITY = addressValidationErrorType2 = new AddressValidationErrorType();
        arraddressValidationErrorType[1] = addressValidationErrorType2;
        CITY = addressValidationErrorType5 = new AddressValidationErrorType();
        arraddressValidationErrorType[2] = addressValidationErrorType5;
        CITY_KEY = addressValidationErrorType15 = new AddressValidationErrorType();
        arraddressValidationErrorType[3] = addressValidationErrorType15;
        PLACE_ID = addressValidationErrorType4 = new AddressValidationErrorType();
        arraddressValidationErrorType[4] = addressValidationErrorType4;
        NICK_NAME = addressValidationErrorType7 = new AddressValidationErrorType();
        arraddressValidationErrorType[5] = addressValidationErrorType7;
        LAT = addressValidationErrorType12 = new AddressValidationErrorType();
        arraddressValidationErrorType[6] = addressValidationErrorType12;
        LNG = addressValidationErrorType3 = new AddressValidationErrorType();
        arraddressValidationErrorType[7] = addressValidationErrorType3;
        ERROR_MESSAGE = addressValidationErrorType9 = new AddressValidationErrorType();
        arraddressValidationErrorType[8] = addressValidationErrorType9;
        NO_ERROR = addressValidationErrorType14 = new AddressValidationErrorType();
        arraddressValidationErrorType[9] = addressValidationErrorType14;
        INIT = addressValidationErrorType10 = new AddressValidationErrorType();
        arraddressValidationErrorType[10] = addressValidationErrorType10;
        USER_NAME = addressValidationErrorType6 = new AddressValidationErrorType();
        arraddressValidationErrorType[11] = addressValidationErrorType6;
        ADDRESS_PHONE_NUMBER = addressValidationErrorType = new AddressValidationErrorType();
        arraddressValidationErrorType[12] = addressValidationErrorType;
        HOUSE_ADDRESS = addressValidationErrorType11 = new AddressValidationErrorType();
        arraddressValidationErrorType[13] = addressValidationErrorType11;
        OPTIONAL_INSTRUCTIONS = addressValidationErrorType8 = new AddressValidationErrorType();
        arraddressValidationErrorType[14] = addressValidationErrorType8;
        $VALUES = arraddressValidationErrorType;
    }

    public static AddressValidationErrorType valueOf(String string) {
        return (AddressValidationErrorType)Enum.valueOf(AddressValidationErrorType.class, (String)string);
    }

    public static AddressValidationErrorType[] values() {
        return (AddressValidationErrorType[])$VALUES.clone();
    }
}

