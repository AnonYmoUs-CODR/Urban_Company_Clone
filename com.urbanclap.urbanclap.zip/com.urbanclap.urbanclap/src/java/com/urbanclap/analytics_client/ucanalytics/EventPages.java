/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.ucanalytics;

public final class EventPages
extends Enum<EventPages> {
    private static final /* synthetic */ EventPages[] $VALUES;
    public static final /* enum */ EventPages ADDRESS;
    public static final /* enum */ EventPages AUTH;
    public static final /* enum */ EventPages BPR;
    public static final /* enum */ EventPages BPR_V2;
    public static final /* enum */ EventPages CATEGORIES;
    public static final /* enum */ EventPages CHECKOUT;
    public static final /* enum */ EventPages GROOMING_PROFILE;
    public static final /* enum */ EventPages HOMESCREEN;
    public static final /* enum */ EventPages LOCATION;
    public static final /* enum */ EventPages LUMINOSITY;
    public static final /* enum */ EventPages ONBOARDING;
    public static final /* enum */ EventPages PACKAGE;
    public static final /* enum */ EventPages PAYMENT;
    public static final /* enum */ EventPages PRODUCT_DETAILS;
    public static final /* enum */ EventPages PRODUCT_SELECTION;
    public static final /* enum */ EventPages QNA;
    public static final /* enum */ EventPages REACT;
    public static final /* enum */ EventPages SCHEDULER;
    public static final /* enum */ EventPages SEARCH;
    public static final /* enum */ EventPages SLOTS;
    public static final /* enum */ EventPages SUMMARY;
    private final String value;

    public static {
        EventPages eventPages;
        EventPages eventPages2;
        EventPages eventPages3;
        EventPages eventPages4;
        EventPages eventPages5;
        EventPages eventPages6;
        EventPages eventPages7;
        EventPages eventPages8;
        EventPages eventPages9;
        EventPages eventPages10;
        EventPages eventPages11;
        EventPages eventPages12;
        EventPages eventPages13;
        EventPages eventPages14;
        EventPages eventPages15;
        EventPages eventPages16;
        EventPages eventPages17;
        EventPages eventPages18;
        EventPages eventPages19;
        EventPages eventPages20;
        EventPages eventPages21;
        EventPages[] arreventPages = new EventPages[21];
        HOMESCREEN = eventPages15 = new EventPages("homescreen");
        arreventPages[0] = eventPages15;
        LUMINOSITY = eventPages9 = new EventPages("luminosity");
        arreventPages[1] = eventPages9;
        QNA = eventPages4 = new EventPages("qna");
        arreventPages[2] = eventPages4;
        ADDRESS = eventPages13 = new EventPages("address");
        arreventPages[3] = eventPages13;
        PAYMENT = eventPages8 = new EventPages("payment");
        arreventPages[4] = eventPages8;
        CATEGORIES = eventPages3 = new EventPages("categories");
        arreventPages[5] = eventPages3;
        SUMMARY = eventPages21 = new EventPages("summary");
        arreventPages[6] = eventPages21;
        SLOTS = eventPages2 = new EventPages("slots");
        arreventPages[7] = eventPages2;
        SCHEDULER = eventPages6 = new EventPages("scheduler");
        arreventPages[8] = eventPages6;
        ONBOARDING = eventPages12 = new EventPages("onboarding");
        arreventPages[9] = eventPages12;
        AUTH = eventPages19 = new EventPages("auth");
        arreventPages[10] = eventPages19;
        LOCATION = eventPages5 = new EventPages("location");
        arreventPages[11] = eventPages5;
        SEARCH = eventPages7 = new EventPages("search");
        arreventPages[12] = eventPages7;
        BPR = eventPages14 = new EventPages("bpr");
        arreventPages[13] = eventPages14;
        BPR_V2 = eventPages18 = new EventPages("bprScreenV2");
        arreventPages[14] = eventPages18;
        PACKAGE = eventPages = new EventPages("package");
        arreventPages[15] = eventPages;
        CHECKOUT = eventPages17 = new EventPages("checkout");
        arreventPages[16] = eventPages17;
        PRODUCT_SELECTION = eventPages11 = new EventPages("product_selection");
        arreventPages[17] = eventPages11;
        PRODUCT_DETAILS = eventPages10 = new EventPages("product_details");
        arreventPages[18] = eventPages10;
        REACT = eventPages20 = new EventPages("react");
        arreventPages[19] = eventPages20;
        GROOMING_PROFILE = eventPages16 = new EventPages("grooming_profile");
        arreventPages[20] = eventPages16;
        $VALUES = arreventPages;
    }

    private EventPages(String string2) {
        this.value = string2;
    }

    public static EventPages valueOf(String string) {
        return (EventPages)Enum.valueOf(EventPages.class, (String)string);
    }

    public static EventPages[] values() {
        return (EventPages[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

