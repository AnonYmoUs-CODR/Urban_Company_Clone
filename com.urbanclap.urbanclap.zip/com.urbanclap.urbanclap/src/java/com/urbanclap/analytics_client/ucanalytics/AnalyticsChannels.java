/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.ucanalytics;

public final class AnalyticsChannels
extends Enum<AnalyticsChannels> {
    private static final /* synthetic */ AnalyticsChannels[] $VALUES;
    public static final /* enum */ AnalyticsChannels AppsFlyr;
    public static final /* enum */ AnalyticsChannels CleverTap;
    public static final /* enum */ AnalyticsChannels UCPerformance;
    public static final /* enum */ AnalyticsChannels UCServer;
    public static final /* enum */ AnalyticsChannels UCServerV2;
    private String channel;

    public static {
        AnalyticsChannels analyticsChannels;
        AnalyticsChannels analyticsChannels2;
        AnalyticsChannels analyticsChannels3;
        AnalyticsChannels analyticsChannels4;
        AnalyticsChannels analyticsChannels5;
        UCServer = analyticsChannels3 = new AnalyticsChannels("ucserver");
        CleverTap = analyticsChannels5 = new AnalyticsChannels("clevertap");
        UCPerformance = analyticsChannels2 = new AnalyticsChannels("ucperformance");
        AppsFlyr = analyticsChannels = new AnalyticsChannels("appsflyr");
        UCServerV2 = analyticsChannels4 = new AnalyticsChannels("ucserverv2");
        $VALUES = new AnalyticsChannels[]{analyticsChannels3, analyticsChannels5, analyticsChannels2, analyticsChannels, analyticsChannels4};
    }

    private AnalyticsChannels(String string2) {
        this.channel = string2;
    }

    public static AnalyticsChannels valueOf(String string) {
        return (AnalyticsChannels)Enum.valueOf(AnalyticsChannels.class, (String)string);
    }

    public static AnalyticsChannels[] values() {
        return (AnalyticsChannels[])$VALUES.clone();
    }

    public String toString() {
        return this.channel;
    }
}

