/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.ucanalytics.channelClients.ucPerformance;

public final class PerfTrackerIdentifiers
extends Enum<PerfTrackerIdentifiers> {
    private static final /* synthetic */ PerfTrackerIdentifiers[] $VALUES;
    public static final /* enum */ PerfTrackerIdentifiers API_LOAD;
    public static final /* enum */ PerfTrackerIdentifiers IMAGE_LOAD;
    public static final /* enum */ PerfTrackerIdentifiers PAGE_LOAD;

    public static {
        PerfTrackerIdentifiers perfTrackerIdentifiers;
        PerfTrackerIdentifiers perfTrackerIdentifiers2;
        PerfTrackerIdentifiers perfTrackerIdentifiers3;
        IMAGE_LOAD = perfTrackerIdentifiers = new PerfTrackerIdentifiers();
        API_LOAD = perfTrackerIdentifiers2 = new PerfTrackerIdentifiers();
        PAGE_LOAD = perfTrackerIdentifiers3 = new PerfTrackerIdentifiers();
        $VALUES = new PerfTrackerIdentifiers[]{perfTrackerIdentifiers, perfTrackerIdentifiers2, perfTrackerIdentifiers3};
    }

    public static PerfTrackerIdentifiers valueOf(String string) {
        return (PerfTrackerIdentifiers)Enum.valueOf(PerfTrackerIdentifiers.class, (String)string);
    }

    public static PerfTrackerIdentifiers[] values() {
        return (PerfTrackerIdentifiers[])$VALUES.clone();
    }
}

