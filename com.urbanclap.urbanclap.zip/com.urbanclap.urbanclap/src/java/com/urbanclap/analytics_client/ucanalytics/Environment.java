/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.ucanalytics;

import i2.a0.d.l;

public final class Environment
extends Enum<Environment> {
    private static final /* synthetic */ Environment[] $VALUES;
    public static final /* enum */ Environment DEV;
    public static final /* enum */ Environment PROD;
    public static final /* enum */ Environment STAGE;
    private String serverUrl;

    public static {
        Environment environment;
        Environment environment2;
        Environment environment3;
        Environment[] arrenvironment = new Environment[3];
        STAGE = environment = new Environment("https://event-api-stage.urbanclap.com/");
        arrenvironment[0] = environment;
        DEV = environment2 = new Environment("https://event-api-dev.urbanclap.com/");
        arrenvironment[1] = environment2;
        PROD = environment3 = new Environment("https://event-api.urbanclap.com/");
        arrenvironment[2] = environment3;
        $VALUES = arrenvironment;
    }

    private Environment(String string2) {
        this.serverUrl = string2;
    }

    public static Environment valueOf(String string) {
        return (Environment)Enum.valueOf(Environment.class, (String)string);
    }

    public static Environment[] values() {
        return (Environment[])$VALUES.clone();
    }

    public final String getServerUrl() {
        return this.serverUrl;
    }

    public final void setServerUrl(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.serverUrl = string;
    }
}

