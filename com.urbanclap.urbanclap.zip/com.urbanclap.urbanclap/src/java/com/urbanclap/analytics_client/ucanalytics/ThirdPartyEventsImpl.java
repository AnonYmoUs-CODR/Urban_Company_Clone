/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.Toast
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.util.Iterator
 *  java.util.Objects
 *  org.json.JSONObject
 *  t1.r.b.c.a
 *  t1.r.b.c.d
 *  t1.r.b.c.f
 *  t1.r.b.c.n.a
 *  t1.r.b.c.n.a$d
 *  t1.r.k.n.n0.d
 *  t1.r.k.n.p$a
 */
package com.urbanclap.analytics_client.ucanalytics;

import android.content.Context;
import android.widget.Toast;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import i2.a0.d.l;
import java.util.Iterator;
import java.util.Objects;
import org.json.JSONObject;
import t1.r.b.c.a;
import t1.r.b.c.f;
import t1.r.b.c.n.a;
import t1.r.k.n.n0.d;
import t1.r.k.n.p;

public final class ThirdPartyEventsImpl {
    public static final String a = "category_key";
    public static final String b = "gdv";
    public static final String c = "revenue";
    public static a d;
    public static final ThirdPartyEventsImpl e;

    public static {
        e = new ThirdPartyEventsImpl();
    }

    public final JSONObject a(JSONObject jSONObject) {
        ThirdPartyEventType thirdPartyEventType;
        ThirdPartyEventType thirdPartyEventType2;
        l.g((Object)jSONObject, (String)"jsonObject");
        ThirdPartyEventType thirdPartyEventType3 = ThirdPartyEventType.CLEVER_TAP;
        if (jSONObject.has(thirdPartyEventType3.getKey())) {
            jSONObject.remove(thirdPartyEventType3.getKey());
        }
        if (jSONObject.has((thirdPartyEventType2 = ThirdPartyEventType.APPS_FLYER).getKey())) {
            jSONObject.remove(thirdPartyEventType2.getKey());
        }
        if (jSONObject.has((thirdPartyEventType = ThirdPartyEventType.FACEBOOK).getKey())) {
            jSONObject.remove(thirdPartyEventType.getKey());
        }
        return jSONObject;
    }

    public final f b(JSONObject jSONObject, boolean bl, boolean bl2) {
        f f2;
        if (bl) {
            f2 = t1.r.b.c.n.a.d.c();
        } else {
            a.d d2 = t1.r.b.c.n.a.d;
            f2 = bl2 ? d2.b() : d2.a();
        }
        l.e((Object)jSONObject);
        Iterator iterator = jSONObject.keys();
        l.f((Object)iterator, (String)"jsonObject!!.keys()");
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            f2.put((Object)string, (Object)jSONObject.get(string).toString());
        }
        return f2;
    }

    public final void c(String string, JSONObject jSONObject) {
        l.g((Object)string, (String)"eventName");
        l.g((Object)jSONObject, (String)"jsonObject");
        jSONObject.put("country_key", (Object)d.c.c());
        jSONObject.put("device_type", (Object)"android");
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.getItem(string);
        if (analyticsTriggers != null) {
            t1.r.b.c.d.a.D0(analyticsTriggers, e.b(jSONObject, false, true));
            return;
        }
        Context context = p.d.a();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("trigger ");
        stringBuilder.append(string);
        stringBuilder.append(" not found map ");
        stringBuilder.append((Object)jSONObject);
        Toast.makeText((Context)context, (CharSequence)stringBuilder.toString(), (int)0).show();
    }

    public final void d(String string, JSONObject jSONObject) {
        int n;
        int n2;
        String string2;
        l.g((Object)string, (String)"eventName");
        l.g((Object)jSONObject, (String)"jsonObject");
        String string3 = a;
        if (jSONObject.has(string3)) {
            Object object = jSONObject.get(string3);
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.String");
            string2 = (String)object;
        } else {
            string2 = "";
        }
        String string4 = string2;
        String string5 = b;
        if (jSONObject.has(string5)) {
            Object object = jSONObject.get(string5);
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
            n2 = (Integer)object;
        } else {
            n2 = 0;
        }
        String string6 = c;
        if (jSONObject.has(string6)) {
            Object object = jSONObject.get(string6);
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.Int");
            n = (Integer)object;
        } else {
            n = 0;
        }
        a a2 = d;
        if (a2 != null) {
            a2.i(string, false, string4, null, n2, n);
        }
    }

    public final void e(JSONObject jSONObject, a a2) {
        ThirdPartyEventType thirdPartyEventType;
        l.g((Object)jSONObject, (String)"jsonObject");
        l.g((Object)a2, (String)"analyticsClientEventsListner");
        if (d == null) {
            d = a2;
        }
        JSONObject jSONObject2 = new JSONObject(jSONObject.toString());
        this.a(jSONObject2);
        ThirdPartyEventType thirdPartyEventType2 = ThirdPartyEventType.CLEVER_TAP;
        if (jSONObject.has(thirdPartyEventType2.getKey())) {
            Object object = jSONObject.get(thirdPartyEventType2.getKey());
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.String");
            this.c((String)object, jSONObject2);
        }
        ThirdPartyEventType thirdPartyEventType3 = ThirdPartyEventType.FACEBOOK;
        boolean bl = jSONObject.has(thirdPartyEventType3.getKey());
        String string = null;
        if (bl) {
            Object object = jSONObject.get(thirdPartyEventType3.getKey());
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.String");
            string = (String)object;
        }
        if (jSONObject.has((thirdPartyEventType = ThirdPartyEventType.APPS_FLYER).getKey())) {
            Object object = jSONObject.get(thirdPartyEventType.getKey());
            Objects.requireNonNull((Object)object, (String)"null cannot be cast to non-null type kotlin.String");
            string = (String)object;
        }
        if (string != null) {
            this.d(string, jSONObject2);
        }
    }

    public static final class ThirdPartyEventType
    extends Enum<ThirdPartyEventType> {
        private static final /* synthetic */ ThirdPartyEventType[] $VALUES;
        public static final /* enum */ ThirdPartyEventType APPS_FLYER;
        public static final /* enum */ ThirdPartyEventType CLEVER_TAP;
        public static final /* enum */ ThirdPartyEventType FACEBOOK;
        private final String key;

        public static {
            ThirdPartyEventType thirdPartyEventType;
            ThirdPartyEventType thirdPartyEventType2;
            ThirdPartyEventType thirdPartyEventType3;
            ThirdPartyEventType[] arrthirdPartyEventType = new ThirdPartyEventType[3];
            FACEBOOK = thirdPartyEventType2 = new ThirdPartyEventType("facebook_key");
            arrthirdPartyEventType[0] = thirdPartyEventType2;
            APPS_FLYER = thirdPartyEventType3 = new ThirdPartyEventType("apps_flyer_key");
            arrthirdPartyEventType[1] = thirdPartyEventType3;
            CLEVER_TAP = thirdPartyEventType = new ThirdPartyEventType("clever_tap_key");
            arrthirdPartyEventType[2] = thirdPartyEventType;
            $VALUES = arrthirdPartyEventType;
        }

        private ThirdPartyEventType(String string2) {
            this.key = string2;
        }

        public static ThirdPartyEventType valueOf(String string) {
            return (ThirdPartyEventType)Enum.valueOf(ThirdPartyEventType.class, (String)string);
        }

        public static ThirdPartyEventType[] values() {
            return (ThirdPartyEventType[])$VALUES.clone();
        }

        public final String getKey() {
            return this.key;
        }
    }

}

