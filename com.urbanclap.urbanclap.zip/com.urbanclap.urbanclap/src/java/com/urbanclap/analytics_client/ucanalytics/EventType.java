/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.ucanalytics;

import i2.a0.d.l;

public final class EventType
extends Enum<EventType> {
    private static final /* synthetic */ EventType[] $VALUES;
    public static final /* enum */ EventType UCPERFORMANCE;
    public static final /* enum */ EventType UCSERVER;
    private String endpoint;
    private String tableName;

    public static {
        EventType eventType;
        EventType eventType2;
        EventType[] arreventType = new EventType[2];
        UCSERVER = eventType2 = new EventType("newevent", "events_ucserver");
        arreventType[0] = eventType2;
        UCPERFORMANCE = eventType = new EventType("customer-performance", "events_ucperformance");
        arreventType[1] = eventType;
        $VALUES = arreventType;
    }

    private EventType(String string2, String string3) {
        this.endpoint = string2;
        this.tableName = string3;
    }

    public static EventType valueOf(String string) {
        return (EventType)Enum.valueOf(EventType.class, (String)string);
    }

    public static EventType[] values() {
        return (EventType[])$VALUES.clone();
    }

    public final String getEndpoint() {
        return this.endpoint;
    }

    public final String getTableName() {
        return this.tableName;
    }

    public final void setEndpoint(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.endpoint = string;
    }

    public final void setTableName(String string) {
        l.g((Object)string, (String)"<set-?>");
        this.tableName = string;
    }
}

