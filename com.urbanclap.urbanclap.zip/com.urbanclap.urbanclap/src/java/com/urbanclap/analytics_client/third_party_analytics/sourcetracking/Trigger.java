/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics_client.third_party_analytics.sourcetracking;

public final class Trigger
extends Enum<Trigger> {
    private static final /* synthetic */ Trigger[] $VALUES;
    public static final /* enum */ Trigger deeplink;
    public static final /* enum */ Trigger notification;
    public static final /* enum */ Trigger page;

    public static {
        Trigger trigger;
        Trigger trigger2;
        Trigger trigger3;
        page = trigger2 = new Trigger();
        deeplink = trigger3 = new Trigger();
        notification = trigger = new Trigger();
        $VALUES = new Trigger[]{trigger2, trigger3, trigger};
    }

    public static Trigger valueOf(String string) {
        return (Trigger)Enum.valueOf(Trigger.class, (String)string);
    }

    public static Trigger[] values() {
        return (Trigger[])$VALUES.clone();
    }
}

