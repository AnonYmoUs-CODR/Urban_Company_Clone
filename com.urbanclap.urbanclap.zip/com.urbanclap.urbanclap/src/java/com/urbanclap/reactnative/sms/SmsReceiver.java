/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  com.google.android.gms.common.api.Status
 *  i2.a0.d.l
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.f.h.k
 */
package com.urbanclap.reactnative.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.common.api.Status;
import com.urbanclap.reactnative.sms.SmsReceiver;
import i2.a0.d.l;
import i2.f;
import i2.h;
import i2.h0.s;
import t1.r.f.h.k;

public final class SmsReceiver
extends BroadcastReceiver {
    public final f a;
    public final a b;

    public SmsReceiver(a a2) {
        l.g((Object)a2, (String)"callback");
        this.b = a2;
        this.a = h.b(b.a);
    }

    public final k a() {
        return (k)this.a.getValue();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onReceive(Context context, Intent intent) {
        String string;
        block14 : {
            if (intent != null) {
                try {
                    string = intent.getAction();
                    break block14;
                }
                catch (Exception exception) {
                    k k2 = this.a();
                    if (k2 == null) return;
                    {
                        k2.d(exception);
                        return;
                    }
                }
            }
            string = null;
        }
        if (!l.c((Object)"com.google.android.gms.auth.api.phone.SMS_RETRIEVED", (Object)string)) return;
        {
            Bundle bundle = intent.getExtras();
            Object object = bundle != null ? bundle.get("com.google.android.gms.auth.api.phone.EXTRA_STATUS") : null;
            if (!(object instanceof Status)) {
                object = null;
            }
            Status status = (Status)object;
            Integer n = null;
            if (status != null) {
                n = status.getStatusCode();
            }
            if (n != null && n == 0) {
                String string2 = (String)bundle.get("com.google.android.gms.auth.api.phone.EXTRA_SMS_MESSAGE");
                if (string2 == null) {
                    this.b.O0("message is null");
                    return;
                }
                String string3 = (String)s.n0(string2, new String[]{":"}, false, 0, 6, null).get(1);
                if (string3 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                }
                String string4 = s.I0(string3).toString();
                if (string4 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
                }
                String string5 = string4.substring(0, 4);
                l.f((Object)string5, (String)"(this as java.lang.Strin\u2026ing(startIndex, endIndex)");
                if (string5 == null) throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
                {
                    String string6 = s.I0(string5).toString();
                    this.b.N0(string6);
                    return;
                }
            }
            if (n == null) {
                return;
            }
            if (n != 15) return;
            {
                this.b.O0("Connection timed out");
                return;
            }
        }
    }

    public static interface a {
        public void N0(String var1);

        public void O0(String var1);
    }

}

