/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.DownloadManager
 *  android.app.DownloadManager$Request
 *  android.content.ClipData
 *  android.content.ClipData$Item
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.os.Parcelable
 *  android.util.Log
 *  android.webkit.MimeTypeMap
 *  android.webkit.ValueCallback
 *  android.webkit.WebChromeClient
 *  android.webkit.WebChromeClient$FileChooserParams
 *  android.widget.Toast
 *  androidx.annotation.RequiresApi
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.FileProvider
 *  com.facebook.react.bridge.ActivityEventListener
 *  com.facebook.react.bridge.Promise
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.module.annotations.ReactModule
 *  com.facebook.react.modules.core.PermissionAwareActivity
 *  com.facebook.react.modules.core.PermissionListener
 *  com.urbanclap.reactnative.core.webview.RNCWebViewModule$MimeType
 *  com.urbanclap.reactnative.core.webview.RNCWebViewModule$ShouldOverrideUrlLoadingLock
 *  com.urbanclap.reactnative.core.webview.RNCWebViewModule$ShouldOverrideUrlLoadingLock$ShouldOverrideCallbackState
 *  com.urbanclap.reactnative.core.webview.RNCWebViewModule$a
 *  com.urbanclap.reactnative.core.webview.RNCWebViewModule$b
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.concurrent.atomic.AtomicReference
 */
package com.urbanclap.reactnative.core.webview;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Parcelable;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.module.annotations.ReactModule;
import com.facebook.react.modules.core.PermissionAwareActivity;
import com.facebook.react.modules.core.PermissionListener;
import com.urbanclap.reactnative.core.webview.RNCWebViewModule;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
@ReactModule(name="RNCWebView")
public class RNCWebViewModule
extends ReactContextBaseJavaModule
implements ActivityEventListener {
    private static final int FILE_DOWNLOAD_PERMISSION_REQUEST = 1;
    public static final String MODULE_NAME = "RNCWebView";
    private static final int PICKER = 1;
    private static final int PICKER_LEGACY = 3;
    public static final ShouldOverrideUrlLoadingLock shouldOverrideUrlLoadingLock;
    private DownloadManager.Request downloadRequest;
    private ValueCallback<Uri[]> filePathCallback;
    private ValueCallback<Uri> filePathCallbackLegacy;
    private File outputImage;
    private File outputVideo;
    private PermissionListener webviewFileDownloaderPermissionListener;

    public static {
        shouldOverrideUrlLoadingLock = new /* Unavailable Anonymous Inner Class!! */;
    }

    public RNCWebViewModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.webviewFileDownloaderPermissionListener = new a(this);
        reactApplicationContext.addActivityEventListener((ActivityEventListener)this);
    }

    private Boolean acceptsImages(String string) {
        if (string.matches("\\.\\w+")) {
            string = this.getMimeTypeFromExtension(string.replace((CharSequence)".", (CharSequence)""));
        }
        boolean bl = string.isEmpty() || string.toLowerCase().contains((CharSequence)MimeType.access$200(MimeType.IMAGE));
        return bl;
    }

    private Boolean acceptsImages(String[] arrstring) {
        String[] arrstring2 = this.getAcceptedMimeType(arrstring);
        boolean bl = this.arrayContainsString(arrstring2, MimeType.access$200(MimeType.DEFAULT)).booleanValue() || this.arrayContainsString(arrstring2, MimeType.access$200(MimeType.IMAGE)).booleanValue();
        return bl;
    }

    private Boolean acceptsVideo(String string) {
        if (Build.VERSION.SDK_INT < 23) {
            return Boolean.FALSE;
        }
        if (string.matches("\\.\\w+")) {
            string = this.getMimeTypeFromExtension(string.replace((CharSequence)".", (CharSequence)""));
        }
        boolean bl = string.isEmpty() || string.toLowerCase().contains((CharSequence)MimeType.access$200(MimeType.VIDEO));
        return bl;
    }

    private Boolean acceptsVideo(String[] arrstring) {
        if (Build.VERSION.SDK_INT < 23) {
            return Boolean.FALSE;
        }
        String[] arrstring2 = this.getAcceptedMimeType(arrstring);
        boolean bl = this.arrayContainsString(arrstring2, MimeType.access$200(MimeType.DEFAULT)).booleanValue() || this.arrayContainsString(arrstring2, MimeType.access$200(MimeType.VIDEO)).booleanValue();
        return bl;
    }

    public static /* synthetic */ DownloadManager.Request access$000(RNCWebViewModule rNCWebViewModule) {
        return rNCWebViewModule.downloadRequest;
    }

    public static /* synthetic */ Activity access$100(RNCWebViewModule rNCWebViewModule) {
        return rNCWebViewModule.getCurrentActivity();
    }

    private Boolean arrayContainsString(String[] arrstring, String string) {
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            if (!arrstring[i2].contains((CharSequence)string)) continue;
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    private String[] getAcceptedMimeType(String[] arrstring) {
        boolean bl = this.noAcceptTypesSet(arrstring);
        if (bl) {
            String[] arrstring2 = new String[]{MimeType.access$200(MimeType.DEFAULT)};
            return arrstring2;
        }
        String[] arrstring3 = new String[arrstring.length];
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            String string = arrstring[i2];
            if (string.matches("\\.\\w+")) {
                String string2 = this.getMimeTypeFromExtension(string.replace((CharSequence)".", (CharSequence)""));
                if (string2 != null) {
                    arrstring3[i2] = string2;
                    continue;
                }
                arrstring3[i2] = string;
                continue;
            }
            arrstring3[i2] = string;
        }
        return arrstring3;
    }

    private File getCapturedFile(MimeType mimeType) {
        String string;
        String string2;
        String string3;
        block3 : {
            String string4;
            String string5;
            block4 : {
                block1 : {
                    block2 : {
                        int n2 = b.a[mimeType.ordinal()];
                        string = "";
                        if (n2 == 1) break block1;
                        if (n2 == 2) break block2;
                        string2 = string3 = string;
                        break block3;
                    }
                    string5 = Environment.DIRECTORY_MOVIES;
                    string4 = "video-";
                    string2 = ".mp4";
                    break block4;
                }
                string5 = Environment.DIRECTORY_PICTURES;
                string4 = "image-";
                string2 = ".jpg";
            }
            String string6 = string5;
            string = string4;
            string3 = string6;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(String.valueOf((long)System.currentTimeMillis()));
        stringBuilder.append(string2);
        String string7 = stringBuilder.toString();
        if (Build.VERSION.SDK_INT < 23) {
            return new File(Environment.getExternalStoragePublicDirectory((String)string3), string7);
        }
        return File.createTempFile((String)string, (String)string2, (File)this.getReactApplicationContext().getExternalFilesDir(null));
    }

    private Intent getFileChooserIntent(String string) {
        String string2 = string.isEmpty() ? MimeType.access$200(MimeType.DEFAULT) : string;
        if (string.matches("\\.\\w+")) {
            string2 = this.getMimeTypeFromExtension(string.replace((CharSequence)".", (CharSequence)""));
        }
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType(string2);
        return intent;
    }

    private Intent getFileChooserIntent(String[] arrstring, boolean bl) {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType(MimeType.access$200(MimeType.DEFAULT));
        intent.putExtra("android.intent.extra.MIME_TYPES", this.getAcceptedMimeType(arrstring));
        intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bl);
        return intent;
    }

    private String getMimeTypeFromExtension(String string) {
        if (string != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(string);
        }
        return null;
    }

    private Uri getOutputUri(File file) {
        if (Build.VERSION.SDK_INT < 23) {
            return Uri.fromFile((File)file);
        }
        String string = this.getReactApplicationContext().getPackageName();
        ReactApplicationContext reactApplicationContext = this.getReactApplicationContext();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(".fileprovider");
        return FileProvider.getUriForFile((Context)reactApplicationContext, (String)stringBuilder.toString(), (File)file);
    }

    private PermissionAwareActivity getPermissionAwareActivity() {
        Activity activity = this.getCurrentActivity();
        if (activity != null) {
            if (activity instanceof PermissionAwareActivity) {
                return (PermissionAwareActivity)activity;
            }
            throw new IllegalStateException("Tried to use permissions API but the host Activity doesn't implement PermissionAwareActivity.");
        }
        throw new IllegalStateException("Tried to use permissions API while not attached to an Activity.");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Intent getPhotoIntent() {
        Intent intent;
        void var3_6;
        block6 : {
            File file;
            void var1_9;
            this.outputImage = file = this.getCapturedFile(MimeType.IMAGE);
            Uri uri = this.getOutputUri(file);
            intent = new Intent("android.media.action.IMAGE_CAPTURE");
            try {
                intent.putExtra("output", (Parcelable)uri);
                return intent;
            }
            catch (IllegalArgumentException illegalArgumentException) {
            }
            catch (IOException iOException) {}
            break block6;
            catch (IllegalArgumentException illegalArgumentException) {
            }
            catch (IOException iOException) {
                // empty catch block
            }
            intent = null;
            var3_6 = var1_9;
        }
        Log.e((String)"CREATE FILE", (String)"Error occurred while creating the File", (Throwable)var3_6);
        var3_6.printStackTrace();
        return intent;
    }

    private Uri[] getSelectedFiles(Intent intent, int n2) {
        if (intent == null) {
            return null;
        }
        if (intent.getClipData() != null) {
            int n3 = intent.getClipData().getItemCount();
            Uri[] arruri = new Uri[n3];
            for (int i2 = 0; i2 < n3; ++i2) {
                arruri[i2] = intent.getClipData().getItemAt(i2).getUri();
            }
            return arruri;
        }
        if (intent.getData() != null && n2 == -1 && Build.VERSION.SDK_INT >= 21) {
            return WebChromeClient.FileChooserParams.parseResult((int)n2, (Intent)intent);
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Intent getVideoIntent() {
        Intent intent;
        void var3_6;
        block6 : {
            File file;
            void var1_9;
            this.outputVideo = file = this.getCapturedFile(MimeType.VIDEO);
            Uri uri = this.getOutputUri(file);
            intent = new Intent("android.media.action.VIDEO_CAPTURE");
            try {
                intent.putExtra("output", (Parcelable)uri);
                return intent;
            }
            catch (IllegalArgumentException illegalArgumentException) {
            }
            catch (IOException iOException) {}
            break block6;
            catch (IllegalArgumentException illegalArgumentException) {
            }
            catch (IOException iOException) {
                // empty catch block
            }
            intent = null;
            var3_6 = var1_9;
        }
        Log.e((String)"CREATE FILE", (String)"Error occurred while creating the File", (Throwable)var3_6);
        var3_6.printStackTrace();
        return intent;
    }

    private Boolean noAcceptTypesSet(String[] arrstring) {
        int n2 = arrstring.length;
        int n3 = 1;
        if (n2 != 0 && (arrstring.length != n3 || arrstring[0] == null || arrstring[0].length() != 0)) {
            n3 = 0;
        }
        return (boolean)n3;
    }

    public void downloadFile() {
        ((DownloadManager)this.getCurrentActivity().getBaseContext().getSystemService("download")).enqueue(this.downloadRequest);
        Toast.makeText((Context)this.getCurrentActivity().getApplicationContext(), (CharSequence)"Downloading", (int)1).show();
    }

    public String getName() {
        return "RNCWebView";
    }

    public boolean grantFileDownloaderPermissions() {
        int n2 = Build.VERSION.SDK_INT;
        if (n2 > 28) {
            return true;
        }
        boolean bl = ContextCompat.checkSelfPermission((Context)this.getCurrentActivity(), (String)"android.permission.WRITE_EXTERNAL_STORAGE") == 0;
        if (!bl && n2 >= 23) {
            this.getPermissionAwareActivity().requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1, this.webviewFileDownloaderPermissionListener);
        }
        return bl;
    }

    @ReactMethod
    public void isFileUploadSupported(Promise promise) {
        Boolean bl = Boolean.TRUE;
        Boolean bl2 = Boolean.FALSE;
        int n2 = Build.VERSION.SDK_INT;
        if (n2 >= 21) {
            bl2 = bl;
        }
        if (n2 < 16 || n2 > 18) {
            bl = bl2;
        }
        promise.resolve((Object)bl);
    }

    public boolean needsCameraPermission() {
        boolean bl;
        PackageManager packageManager = this.getCurrentActivity().getPackageManager();
        bl = true;
        try {
            int n2;
            if (Arrays.asList((Object[])packageManager.getPackageInfo((String)this.getReactApplicationContext().getPackageName(), (int)4096).requestedPermissions).contains((Object)"android.permission.CAMERA") && (n2 = ContextCompat.checkSelfPermission((Context)this.getCurrentActivity(), (String)"android.permission.CAMERA")) != 0) {
                return bl;
            }
            bl = false;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {}
        return bl;
    }

    public void onActivityResult(Activity activity, int n2, int n3, Intent intent) {
        File file;
        File file2;
        if (this.filePathCallback == null && this.filePathCallbackLegacy == null) {
            return;
        }
        File file3 = this.outputImage;
        boolean bl = file3 != null && file3.length() > 0L;
        File file4 = this.outputVideo;
        boolean bl2 = file4 != null && file4.length() > 0L;
        if (n2 != 1) {
            if (n2 == 3) {
                if (n3 != -1) {
                    this.filePathCallbackLegacy.onReceiveValue(null);
                } else if (bl) {
                    this.filePathCallbackLegacy.onReceiveValue((Object)this.getOutputUri(this.outputImage));
                } else if (bl2) {
                    this.filePathCallbackLegacy.onReceiveValue((Object)this.getOutputUri(this.outputVideo));
                } else {
                    this.filePathCallbackLegacy.onReceiveValue((Object)intent.getData());
                }
            }
        } else if (n3 != -1) {
            ValueCallback<Uri[]> valueCallback = this.filePathCallback;
            if (valueCallback != null) {
                valueCallback.onReceiveValue(null);
            }
        } else if (bl) {
            ValueCallback<Uri[]> valueCallback = this.filePathCallback;
            Uri[] arruri = new Uri[]{this.getOutputUri(this.outputImage)};
            valueCallback.onReceiveValue((Object)arruri);
        } else if (bl2) {
            ValueCallback<Uri[]> valueCallback = this.filePathCallback;
            Uri[] arruri = new Uri[]{this.getOutputUri(this.outputVideo)};
            valueCallback.onReceiveValue((Object)arruri);
        } else {
            this.filePathCallback.onReceiveValue((Object)this.getSelectedFiles(intent, n3));
        }
        if ((file2 = this.outputImage) != null && !bl) {
            file2.delete();
        }
        if ((file = this.outputVideo) != null && !bl2) {
            file.delete();
        }
        this.filePathCallback = null;
        this.filePathCallbackLegacy = null;
        this.outputImage = null;
        this.outputVideo = null;
    }

    public void onNewIntent(Intent intent) {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ReactMethod(isBlockingSynchronousMethod=true)
    public void onShouldStartLoadWithRequestCallback(boolean bl, int n2) {
        AtomicReference atomicReference = shouldOverrideUrlLoadingLock.a(Integer.valueOf((int)n2));
        if (atomicReference == null) {
            return;
        }
        AtomicReference atomicReference2 = atomicReference;
        synchronized (atomicReference2) {
            ShouldOverrideCallbackState shouldOverrideCallbackState = bl ? ShouldOverrideCallbackState.DO_NOT_OVERRIDE : ShouldOverrideCallbackState.SHOULD_OVERRIDE;
            atomicReference.set((Object)shouldOverrideCallbackState);
            atomicReference.notify();
            return;
        }
    }

    public void setDownloadRequest(DownloadManager.Request request) {
        this.downloadRequest = request;
    }

    public void startPhotoPickerIntent(ValueCallback<Uri> valueCallback, String string) {
        Intent intent;
        Intent intent2;
        this.filePathCallbackLegacy = valueCallback;
        Intent intent3 = Intent.createChooser((Intent)this.getFileChooserIntent(string), (CharSequence)"");
        ArrayList arrayList = new ArrayList();
        if (this.acceptsImages(string).booleanValue() && (intent2 = this.getPhotoIntent()) != null) {
            arrayList.add((Object)intent2);
        }
        if (this.acceptsVideo(string).booleanValue() && (intent = this.getVideoIntent()) != null) {
            arrayList.add((Object)intent);
        }
        intent3.putExtra("android.intent.extra.INITIAL_INTENTS", (Parcelable[])arrayList.toArray((Object[])new Parcelable[0]));
        if (intent3.resolveActivity(this.getCurrentActivity().getPackageManager()) != null) {
            this.getCurrentActivity().startActivityForResult(intent3, 3);
            return;
        }
        Log.w((String)"RNCWebViewModule", (String)"there is no Activity to handle this Intent");
    }

    @RequiresApi(api=21)
    public boolean startPhotoPickerIntent(ValueCallback<Uri[]> valueCallback, String[] arrstring, boolean bl) {
        this.filePathCallback = valueCallback;
        ArrayList arrayList = new ArrayList();
        if (!this.needsCameraPermission()) {
            Intent intent;
            Intent intent2;
            if (this.acceptsImages(arrstring).booleanValue() && (intent = this.getPhotoIntent()) != null) {
                arrayList.add((Object)intent);
            }
            if (this.acceptsVideo(arrstring).booleanValue() && (intent2 = this.getVideoIntent()) != null) {
                arrayList.add((Object)intent2);
            }
        }
        Intent intent = this.getFileChooserIntent(arrstring, bl);
        Intent intent3 = new Intent("android.intent.action.CHOOSER");
        intent3.putExtra("android.intent.extra.INTENT", (Parcelable)intent);
        intent3.putExtra("android.intent.extra.INITIAL_INTENTS", (Parcelable[])arrayList.toArray((Object[])new Parcelable[0]));
        if (intent3.resolveActivity(this.getCurrentActivity().getPackageManager()) != null) {
            this.getCurrentActivity().startActivityForResult(intent3, 1);
            return true;
        }
        Log.w((String)"RNCWebViewModule", (String)"there is no Activity to handle this Intent");
        return true;
    }
}

