/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.lottieAnimation;

public final class AnimationRepeatMode
extends Enum<AnimationRepeatMode> {
    private static final /* synthetic */ AnimationRepeatMode[] $VALUES;
    public static final /* enum */ AnimationRepeatMode RESTART;
    public static final /* enum */ AnimationRepeatMode REVERSE;

    public static {
        AnimationRepeatMode animationRepeatMode;
        AnimationRepeatMode animationRepeatMode2;
        AnimationRepeatMode[] arranimationRepeatMode = new AnimationRepeatMode[2];
        REVERSE = animationRepeatMode2 = new AnimationRepeatMode();
        arranimationRepeatMode[0] = animationRepeatMode2;
        RESTART = animationRepeatMode = new AnimationRepeatMode();
        arranimationRepeatMode[1] = animationRepeatMode;
        $VALUES = arranimationRepeatMode;
    }

    public static AnimationRepeatMode valueOf(String string) {
        return (AnimationRepeatMode)Enum.valueOf(AnimationRepeatMode.class, (String)string);
    }

    public static AnimationRepeatMode[] values() {
        return (AnimationRepeatMode[])$VALUES.clone();
    }
}

