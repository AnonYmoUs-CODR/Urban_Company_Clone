/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.videoplayer.model;

public final class VideoCacheStrategy
extends Enum<VideoCacheStrategy> {
    private static final /* synthetic */ VideoCacheStrategy[] $VALUES;
    public static final /* enum */ VideoCacheStrategy DISABLED;
    public static final /* enum */ VideoCacheStrategy ENABLED;
    private final String value;

    public static {
        VideoCacheStrategy videoCacheStrategy;
        VideoCacheStrategy videoCacheStrategy2;
        VideoCacheStrategy[] arrvideoCacheStrategy = new VideoCacheStrategy[2];
        DISABLED = videoCacheStrategy2 = new VideoCacheStrategy("disabled");
        arrvideoCacheStrategy[0] = videoCacheStrategy2;
        ENABLED = videoCacheStrategy = new VideoCacheStrategy("enabled");
        arrvideoCacheStrategy[1] = videoCacheStrategy;
        $VALUES = arrvideoCacheStrategy;
    }

    private VideoCacheStrategy(String string2) {
        this.value = string2;
    }

    public static VideoCacheStrategy valueOf(String string) {
        return (VideoCacheStrategy)Enum.valueOf(VideoCacheStrategy.class, (String)string);
    }

    public static VideoCacheStrategy[] values() {
        return (VideoCacheStrategy[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

