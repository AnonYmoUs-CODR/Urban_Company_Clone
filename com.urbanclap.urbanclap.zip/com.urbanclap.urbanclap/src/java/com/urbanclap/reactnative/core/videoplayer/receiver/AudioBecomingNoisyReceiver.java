/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  i2.a0.d.l
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.i.h.l.c.a
 *  t1.r.i.h.l.c.a$a
 */
package com.urbanclap.reactnative.core.videoplayer.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import i2.a0.d.l;
import t1.r.i.h.l.c.a;

public final class AudioBecomingNoisyReceiver
extends BroadcastReceiver {
    public final Context a;
    public a b;

    public AudioBecomingNoisyReceiver(Context context) {
        l.g((Object)context, (String)"context");
        Context context2 = context.getApplicationContext();
        l.f((Object)context2, (String)"context.applicationContext");
        this.a = context2;
        this.b = a.n.a();
    }

    public final void a() {
        this.b = a.n.a();
        try {
            this.a.unregisterReceiver((BroadcastReceiver)this);
        }
        catch (Exception exception) {}
    }

    public final void b(a a2) {
        l.g((Object)a2, (String)"listener");
        this.b = a2;
        IntentFilter intentFilter = new IntentFilter("android.media.AUDIO_BECOMING_NOISY");
        this.a.registerReceiver((BroadcastReceiver)this, intentFilter);
    }

    public void onReceive(Context context, Intent intent) {
        l.g((Object)context, (String)"context");
        l.g((Object)intent, (String)"intent");
        if (l.c((Object)"android.media.AUDIO_BECOMING_NOISY", (Object)intent.getAction())) {
            this.b.c();
        }
    }
}

