/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.widget.ImageView
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.DecodeFormat
 *  com.urbanclap.reactnative.core.imageview.utils.PhotoUtils$b
 *  i2.a0.d.l
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.List
 *  java.util.Objects
 *  kotlin.NoWhenBranchMatchedException
 *  t1.f.a.b
 *  t1.f.a.c
 *  t1.f.a.f
 *  t1.f.a.g
 *  t1.f.a.h
 *  t1.f.a.l.i
 *  t1.f.a.l.k.h
 *  t1.f.a.l.m.c.e
 *  t1.f.a.l.m.c.g
 *  t1.f.a.l.m.c.h
 *  t1.f.a.l.m.c.m
 *  t1.f.a.l.m.e.c
 *  t1.f.a.p.d
 *  t1.f.a.p.e
 *  t1.f.a.p.h.k
 *  t1.r.i.h.f.j.a
 *  t1.r.i.h.f.k.c
 */
package com.urbanclap.reactnative.core.imageview.utils;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import com.bumptech.glide.load.DataSource;
import com.urbanclap.reactnative.core.imageview.utils.PhotoUtils;
import i2.a0.d.l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import kotlin.NoWhenBranchMatchedException;
import t1.f.a.f;
import t1.f.a.g;
import t1.f.a.l.i;
import t1.f.a.l.k.h;
import t1.f.a.l.m.c.e;
import t1.f.a.l.m.c.m;
import t1.f.a.l.m.e.c;
import t1.f.a.p.d;
import t1.f.a.p.h.k;

public final class PhotoUtils {
    public static final PhotoUtils a = new PhotoUtils();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final t1.f.a.p.e a(Drawable drawable, DecodeFormat decodeFormat, Transformation transformation, List<? extends t1.r.i.h.f.j.a> list, DiskStrategy diskStrategy) {
        com.bumptech.glide.load.DecodeFormat decodeFormat2;
        t1.f.a.p.e e2 = new t1.f.a.p.e();
        if (drawable != null) {
            e2.V(drawable);
        }
        ArrayList arrayList = new ArrayList();
        if (transformation != null) {
            arrayList.add((Object)transformation.getTransform());
        }
        if (list != null) {
            arrayList.addAll(list);
        }
        if (true ^ arrayList.isEmpty()) {
            Object[] arrobject = arrayList.toArray((Object[])new e[0]);
            Objects.requireNonNull((Object)arrobject, (String)"null cannot be cast to non-null type kotlin.Array<T>");
            Object[] arrobject2 = (e[])arrobject;
            e2 = e2.i0((i[])Arrays.copyOf((Object[])arrobject2, (int)arrobject2.length));
            l.f((Object)e2, (String)"options.transforms(*array)");
        }
        h h2 = t1.r.i.h.f.k.c.a[diskStrategy.ordinal()] != 1 ? h.b : h.a;
        t1.f.a.p.e e3 = e2.f(h2);
        l.f((Object)e3, (String)"options.diskCacheStrateg\u2026\n\n            }\n        )");
        int n = t1.r.i.h.f.k.c.b[decodeFormat.ordinal()];
        if (n != 1) {
            if (n != 2) throw new NoWhenBranchMatchedException();
            decodeFormat2 = com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565;
        } else {
            decodeFormat2 = com.bumptech.glide.load.DecodeFormat.PREFER_ARGB_8888;
        }
        t1.f.a.p.e e4 = e3.j(decodeFormat2);
        l.f((Object)e4, (String)"options.format(\n        \u20265\n            }\n        )");
        return e4;
    }

    public final f<Drawable> b(g g2, String string, PictureSize pictureSize, Integer n, boolean bl) {
        f f2;
        block5 : {
            block4 : {
                f2 = g2.u(string);
                if (n == null) break block4;
                f2.y((t1.f.a.h)t1.f.a.b.f((int)n));
                if (f2 != null) break block5;
            }
            if (!bl) {
                f2.y((t1.f.a.h)c.i());
            }
        }
        l.f((Object)f2, (String)"animationId?.let { anim \u2026nOptions.withCrossFade())");
        return f2;
    }

    public final void c(ImageView imageView, String string, DecodeFormat decodeFormat, PictureSize pictureSize, Drawable drawable, Integer n, Transformation transformation, List<? extends t1.r.i.h.f.j.a> list, DiskStrategy diskStrategy, a a2) {
        l.g((Object)imageView, (String)"imageView");
        l.g((Object)((Object)decodeFormat), (String)"decodeFormat");
        l.g((Object)((Object)pictureSize), (String)"pictureSize");
        l.g(list, (String)"customTransformations");
        l.g((Object)((Object)diskStrategy), (String)"diskCacheStrategy");
        g g2 = t1.f.a.c.v((View)imageView);
        l.f((Object)g2, (String)"Glide.with(imageView)");
        boolean bl = drawable != null;
        f<Drawable> f2 = this.b(g2, string, pictureSize, n, bl);
        f2.a(this.a(drawable, decodeFormat, transformation, list, diskStrategy));
        f2.m((d)new b(a2));
        f2.k(imageView);
    }

    public static final class DecodeFormat
    extends Enum<DecodeFormat> {
        private static final /* synthetic */ DecodeFormat[] $VALUES;
        public static final /* enum */ DecodeFormat ARGB_8888;
        public static final /* enum */ DecodeFormat RGB_565;

        public static {
            DecodeFormat decodeFormat;
            DecodeFormat decodeFormat2;
            DecodeFormat[] arrdecodeFormat = new DecodeFormat[2];
            ARGB_8888 = decodeFormat = new DecodeFormat();
            arrdecodeFormat[0] = decodeFormat;
            RGB_565 = decodeFormat2 = new DecodeFormat();
            arrdecodeFormat[1] = decodeFormat2;
            $VALUES = arrdecodeFormat;
        }

        public static DecodeFormat valueOf(String string) {
            return (DecodeFormat)Enum.valueOf(DecodeFormat.class, (String)string);
        }

        public static DecodeFormat[] values() {
            return (DecodeFormat[])$VALUES.clone();
        }
    }

    public static final class DiskStrategy
    extends Enum<DiskStrategy> {
        private static final /* synthetic */ DiskStrategy[] $VALUES;
        public static final /* enum */ DiskStrategy ALL;
        public static final /* enum */ DiskStrategy DEFAULT;

        public static {
            DiskStrategy diskStrategy;
            DiskStrategy diskStrategy2;
            DiskStrategy[] arrdiskStrategy = new DiskStrategy[2];
            DEFAULT = diskStrategy = new DiskStrategy();
            arrdiskStrategy[0] = diskStrategy;
            ALL = diskStrategy2 = new DiskStrategy();
            arrdiskStrategy[1] = diskStrategy2;
            $VALUES = arrdiskStrategy;
        }

        public static DiskStrategy valueOf(String string) {
            return (DiskStrategy)Enum.valueOf(DiskStrategy.class, (String)string);
        }

        public static DiskStrategy[] values() {
            return (DiskStrategy[])$VALUES.clone();
        }
    }

    public static final class PictureSize
    extends Enum<PictureSize> {
        private static final /* synthetic */ PictureSize[] $VALUES;
        public static final /* enum */ PictureSize FULL;
        public static final /* enum */ PictureSize ONE_THIRD;
        public static final /* enum */ PictureSize THUMBNAIL;
        private final float value;

        public static {
            PictureSize pictureSize;
            PictureSize pictureSize2;
            PictureSize pictureSize3;
            PictureSize[] arrpictureSize = new PictureSize[3];
            THUMBNAIL = pictureSize = new PictureSize(0.1f);
            arrpictureSize[0] = pictureSize;
            FULL = pictureSize2 = new PictureSize(1.0f);
            arrpictureSize[1] = pictureSize2;
            ONE_THIRD = pictureSize3 = new PictureSize(0.3f);
            arrpictureSize[2] = pictureSize3;
            $VALUES = arrpictureSize;
        }

        private PictureSize(float f2) {
            this.value = f2;
        }

        public static PictureSize valueOf(String string) {
            return (PictureSize)Enum.valueOf(PictureSize.class, (String)string);
        }

        public static PictureSize[] values() {
            return (PictureSize[])$VALUES.clone();
        }

        public final float getValue() {
            return this.value;
        }
    }

    public static final class Transformation
    extends Enum<Transformation> {
        private static final /* synthetic */ Transformation[] $VALUES;
        public static final /* enum */ Transformation CENTER_CROP;
        public static final /* enum */ Transformation CENTER_INSIDE;
        public static final /* enum */ Transformation FIT_CENTER;
        private final e transform;

        public static {
            Transformation transformation;
            Transformation transformation2;
            Transformation transformation3;
            Transformation[] arrtransformation = new Transformation[3];
            CENTER_CROP = transformation3 = new Transformation((e)new t1.f.a.l.m.c.g());
            arrtransformation[0] = transformation3;
            FIT_CENTER = transformation = new Transformation((e)new m());
            arrtransformation[1] = transformation;
            CENTER_INSIDE = transformation2 = new Transformation((e)new t1.f.a.l.m.c.h());
            arrtransformation[2] = transformation2;
            $VALUES = arrtransformation;
        }

        private Transformation(e e2) {
            this.transform = e2;
        }

        public static Transformation valueOf(String string) {
            return (Transformation)Enum.valueOf(Transformation.class, (String)string);
        }

        public static Transformation[] values() {
            return (Transformation[])$VALUES.clone();
        }

        public final e getTransform() {
            return this.transform;
        }
    }

    public static interface a {
        public void b(Drawable var1, DataSource var2);

        public void c(String var1);
    }

}

