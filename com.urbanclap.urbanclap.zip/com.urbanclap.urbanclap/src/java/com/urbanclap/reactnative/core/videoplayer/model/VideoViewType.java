/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.videoplayer.model;

public final class VideoViewType
extends Enum<VideoViewType> {
    private static final /* synthetic */ VideoViewType[] $VALUES;
    public static final /* enum */ VideoViewType HEADER_STORIES;
    public static final /* enum */ VideoViewType STANDARD;

    public static {
        VideoViewType videoViewType;
        VideoViewType videoViewType2;
        VideoViewType[] arrvideoViewType = new VideoViewType[2];
        STANDARD = videoViewType2 = new VideoViewType();
        arrvideoViewType[0] = videoViewType2;
        HEADER_STORIES = videoViewType = new VideoViewType();
        arrvideoViewType[1] = videoViewType;
        $VALUES = arrvideoViewType;
    }

    public static VideoViewType valueOf(String string) {
        return (VideoViewType)Enum.valueOf(VideoViewType.class, (String)string);
    }

    public static VideoViewType[] values() {
        return (VideoViewType[])$VALUES.clone();
    }
}

