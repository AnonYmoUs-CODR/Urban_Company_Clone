/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.imageview.utils;

public final class ScaleTypeMode
extends Enum<ScaleTypeMode> {
    private static final /* synthetic */ ScaleTypeMode[] $VALUES;
    public static final /* enum */ ScaleTypeMode CENTER_CROP;
    public static final /* enum */ ScaleTypeMode CENTER_INSIDE;
    public static final /* enum */ ScaleTypeMode FIT_CENTER;
    public static final /* enum */ ScaleTypeMode FIT_XY;
    private final String value;

    public static {
        ScaleTypeMode scaleTypeMode;
        ScaleTypeMode scaleTypeMode2;
        ScaleTypeMode scaleTypeMode3;
        ScaleTypeMode scaleTypeMode4;
        ScaleTypeMode[] arrscaleTypeMode = new ScaleTypeMode[4];
        FIT_XY = scaleTypeMode3 = new ScaleTypeMode("FIT_XY");
        arrscaleTypeMode[0] = scaleTypeMode3;
        FIT_CENTER = scaleTypeMode = new ScaleTypeMode("FIT_CENTER");
        arrscaleTypeMode[1] = scaleTypeMode;
        CENTER_CROP = scaleTypeMode4 = new ScaleTypeMode("CENTER_CROP");
        arrscaleTypeMode[2] = scaleTypeMode4;
        CENTER_INSIDE = scaleTypeMode2 = new ScaleTypeMode("CENTER_INSIDE");
        arrscaleTypeMode[3] = scaleTypeMode2;
        $VALUES = arrscaleTypeMode;
    }

    private ScaleTypeMode(String string2) {
        this.value = string2;
    }

    public static ScaleTypeMode valueOf(String string) {
        return (ScaleTypeMode)Enum.valueOf(ScaleTypeMode.class, (String)string);
    }

    public static ScaleTypeMode[] values() {
        return (ScaleTypeMode[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

