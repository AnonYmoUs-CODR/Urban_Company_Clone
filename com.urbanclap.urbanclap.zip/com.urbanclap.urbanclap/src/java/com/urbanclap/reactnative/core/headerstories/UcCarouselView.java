/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  androidx.viewpager.widget.ViewPager$PageTransformer
 *  i2.a0.d.l
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.f.h.k
 *  t1.r.i.h.a
 *  t1.r.i.h.a$a
 *  t1.r.i.h.e.a
 *  t1.r.i.h.e.c
 *  t1.r.i.h.e.f
 */
package com.urbanclap.reactnative.core.headerstories;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import i2.a0.d.l;
import t1.r.f.h.k;
import t1.r.i.h.a;
import t1.r.i.h.e.c;
import t1.r.i.h.e.f;

public final class UcCarouselView
extends FrameLayout {
    public t1.r.i.h.e.a a;
    public final int b;
    public f c;
    public int d;
    public c e;
    public PagerAdapter f;

    public UcCarouselView(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        l.g((Object)attributeSet, (String)"attrs");
        this(context, attributeSet, 0);
    }

    public UcCarouselView(Context context, AttributeSet attributeSet, int n) {
        l.g((Object)context, (String)"context");
        l.g((Object)attributeSet, (String)"attrs");
        super(context, attributeSet, n);
        this.b = 400;
        this.d = 400;
        this.e = new c(-1);
        this.c(attributeSet, n);
    }

    public static /* synthetic */ void e(UcCarouselView ucCarouselView, int n, boolean bl, int n2, Object object) {
        if ((n2 & 2) != 0) {
            bl = false;
        }
        ucCarouselView.d(n, bl);
    }

    public final void a(ViewPager.OnPageChangeListener onPageChangeListener) {
        l.g((Object)onPageChangeListener, (String)"listener");
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.addOnPageChangeListener(onPageChangeListener);
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final void b() {
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.clearOnPageChangeListeners();
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final void c(AttributeSet attributeSet, int n) {
        this.a = new t1.r.i.h.e.a(this.getContext());
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            t1.r.i.h.e.a a3 = this.a;
            if (a3 != null) {
                this.addView((View)a3);
                return;
            }
            l.v((String)"mCarouselViewPager");
            throw null;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final void d(int n, boolean bl) {
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.setCurrentItem(n, false);
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final PagerAdapter getMCarouselAdapter() {
        return this.f;
    }

    public final f getMPageIndicator() {
        return this.c;
    }

    public final int getMPageTransformInterval() {
        return this.d;
    }

    public final c getMPageTransformer() {
        return this.e;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onMeasure(int n, int n2) {
        if (this.c == null) {
            int n3 = this.getChildCount();
            for (int j = 0; j < n3; ++j) {
                f f2;
                View view = this.getChildAt(j);
                if (!(view instanceof f)) continue;
                this.c = f2 = (f)view;
                if (f2 == null) break;
                try {
                    t1.r.i.h.e.a a2 = this.a;
                    if (a2 != null) {
                        f2.setViewPager((ViewPager)a2);
                        break;
                    }
                    l.v((String)"mCarouselViewPager");
                }
                catch (Exception exception) {
                    ((a)a.p.a()).v().d(exception);
                    break;
                }
                throw null;
            }
        }
        super.onMeasure(n, n2);
    }

    public final void setMCarouselAdapter(PagerAdapter pagerAdapter) {
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.setAdapter(pagerAdapter);
            this.f = pagerAdapter;
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final void setMPageIndicator(f f2) {
        this.c = f2;
    }

    public final void setMPageTransformInterval(int n) {
        this.d = n > 0 ? n : this.b;
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.setTransitionVelocity(this.d);
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }

    public final void setMPageTransformer(c c2) {
        l.g((Object)c2, (String)"value");
        t1.r.i.h.e.a a2 = this.a;
        if (a2 != null) {
            a2.setPageTransformer(true, (ViewPager.PageTransformer)c2);
            return;
        }
        l.v((String)"mCarouselViewPager");
        throw null;
    }
}

