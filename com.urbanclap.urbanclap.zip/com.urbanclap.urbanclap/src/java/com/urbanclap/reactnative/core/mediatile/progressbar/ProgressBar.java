/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  i2.a0.d.l
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  t1.r.i.c
 *  t1.r.i.d
 *  t1.r.i.o.f
 */
package com.urbanclap.reactnative.core.mediatile.progressbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import i2.a0.d.l;
import java.util.HashMap;
import t1.r.i.c;
import t1.r.i.d;
import t1.r.i.o.f;

public final class ProgressBar
extends FrameLayout {
    public HashMap a;

    public ProgressBar(Context context, AttributeSet attributeSet) {
        l.g((Object)context, (String)"context");
        super(context, attributeSet);
        this.b();
    }

    public View a(int n) {
        View view;
        if (this.a == null) {
            this.a = new HashMap();
        }
        if ((view = (View)this.a.get((Object)n)) == null) {
            view = this.findViewById(n);
            this.a.put((Object)n, (Object)view);
        }
        return view;
    }

    public final void b() {
        FrameLayout.inflate((Context)this.getContext(), (int)d.c, (ViewGroup)this);
    }

    public final void c() {
        this.setProgress(0);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.c();
    }

    public final void setProgress(int n) {
        int n2 = f.a((int)n, (int)0, (int)100);
        android.widget.ProgressBar progressBar = (android.widget.ProgressBar)this.a(c.q);
        l.f((Object)progressBar, (String)"progress_ring");
        progressBar.setProgress(n2);
        TextView textView = (TextView)this.a(c.r);
        l.f((Object)textView, (String)"progress_text");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n2);
        stringBuilder.append('%');
        textView.setText((CharSequence)stringBuilder.toString());
    }
}

