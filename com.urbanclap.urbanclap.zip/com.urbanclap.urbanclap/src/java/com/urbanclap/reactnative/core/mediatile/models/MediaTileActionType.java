/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.mediatile.models;

public final class MediaTileActionType
extends Enum<MediaTileActionType> {
    private static final /* synthetic */ MediaTileActionType[] $VALUES;
    public static final /* enum */ MediaTileActionType Pick;
    public static final /* enum */ MediaTileActionType Upload;
    private final String type;

    public static {
        MediaTileActionType mediaTileActionType;
        MediaTileActionType mediaTileActionType2;
        MediaTileActionType[] arrmediaTileActionType = new MediaTileActionType[2];
        Pick = mediaTileActionType2 = new MediaTileActionType("Pick");
        arrmediaTileActionType[0] = mediaTileActionType2;
        Upload = mediaTileActionType = new MediaTileActionType("Upload");
        arrmediaTileActionType[1] = mediaTileActionType;
        $VALUES = arrmediaTileActionType;
    }

    private MediaTileActionType(String string2) {
        this.type = string2;
    }

    public static MediaTileActionType valueOf(String string) {
        return (MediaTileActionType)Enum.valueOf(MediaTileActionType.class, (String)string);
    }

    public static MediaTileActionType[] values() {
        return (MediaTileActionType[])$VALUES.clone();
    }

    public final String getType() {
        return this.type;
    }
}

