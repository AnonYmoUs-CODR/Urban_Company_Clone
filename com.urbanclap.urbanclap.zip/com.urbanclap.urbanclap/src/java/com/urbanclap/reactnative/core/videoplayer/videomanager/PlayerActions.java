/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.videoplayer.videomanager;

public final class PlayerActions
extends Enum<PlayerActions> {
    private static final /* synthetic */ PlayerActions[] $VALUES;
    public static final /* enum */ PlayerActions VIDEO_AUTO_PAUSED;
    public static final /* enum */ PlayerActions VIDEO_AUTO_STARTED;
    public static final /* enum */ PlayerActions VIDEO_COMPLETED;
    public static final /* enum */ PlayerActions VIDEO_MANUAL_PAUSED;
    public static final /* enum */ PlayerActions VIDEO_MANUAL_STARTED;
    public static final /* enum */ PlayerActions VIDEO_MUTED;
    public static final /* enum */ PlayerActions VIDEO_PLAY_INITIATED;
    public static final /* enum */ PlayerActions VIDEO_UNMUTED;

    public static {
        PlayerActions playerActions;
        PlayerActions playerActions2;
        PlayerActions playerActions3;
        PlayerActions playerActions4;
        PlayerActions playerActions5;
        PlayerActions playerActions6;
        PlayerActions playerActions7;
        PlayerActions playerActions8;
        PlayerActions[] arrplayerActions = new PlayerActions[8];
        VIDEO_PLAY_INITIATED = playerActions6 = new PlayerActions();
        arrplayerActions[0] = playerActions6;
        VIDEO_AUTO_STARTED = playerActions5 = new PlayerActions();
        arrplayerActions[1] = playerActions5;
        VIDEO_AUTO_PAUSED = playerActions2 = new PlayerActions();
        arrplayerActions[2] = playerActions2;
        VIDEO_MANUAL_STARTED = playerActions8 = new PlayerActions();
        arrplayerActions[3] = playerActions8;
        VIDEO_MANUAL_PAUSED = playerActions4 = new PlayerActions();
        arrplayerActions[4] = playerActions4;
        VIDEO_COMPLETED = playerActions7 = new PlayerActions();
        arrplayerActions[5] = playerActions7;
        VIDEO_MUTED = playerActions = new PlayerActions();
        arrplayerActions[6] = playerActions;
        VIDEO_UNMUTED = playerActions3 = new PlayerActions();
        arrplayerActions[7] = playerActions3;
        $VALUES = arrplayerActions;
    }

    public static PlayerActions valueOf(String string) {
        return (PlayerActions)Enum.valueOf(PlayerActions.class, (String)string);
    }

    public static PlayerActions[] values() {
        return (PlayerActions[])$VALUES.clone();
    }
}

