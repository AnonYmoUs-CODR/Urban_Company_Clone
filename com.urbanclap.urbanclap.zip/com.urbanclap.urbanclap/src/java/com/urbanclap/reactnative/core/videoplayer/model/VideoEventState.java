/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.videoplayer.model;

public final class VideoEventState
extends Enum<VideoEventState> {
    private static final /* synthetic */ VideoEventState[] $VALUES;
    public static final /* enum */ VideoEventState COLLAPSED;
    public static final /* enum */ VideoEventState EXPANDED;
    public static final /* enum */ VideoEventState MUTE;
    public static final /* enum */ VideoEventState PAUSED;
    public static final /* enum */ VideoEventState PLAYED;
    public static final /* enum */ VideoEventState UNMUTE;
    private final String value;

    public static {
        VideoEventState videoEventState;
        VideoEventState videoEventState2;
        VideoEventState videoEventState3;
        VideoEventState videoEventState4;
        VideoEventState videoEventState5;
        VideoEventState videoEventState6;
        VideoEventState[] arrvideoEventState = new VideoEventState[6];
        PLAYED = videoEventState2 = new VideoEventState("played");
        arrvideoEventState[0] = videoEventState2;
        PAUSED = videoEventState6 = new VideoEventState("paused");
        arrvideoEventState[1] = videoEventState6;
        EXPANDED = videoEventState4 = new VideoEventState("expanded");
        arrvideoEventState[2] = videoEventState4;
        COLLAPSED = videoEventState5 = new VideoEventState("collapsed");
        arrvideoEventState[3] = videoEventState5;
        MUTE = videoEventState = new VideoEventState("mute");
        arrvideoEventState[4] = videoEventState;
        UNMUTE = videoEventState3 = new VideoEventState("unmute");
        arrvideoEventState[5] = videoEventState3;
        $VALUES = arrvideoEventState;
    }

    private VideoEventState(String string2) {
        this.value = string2;
    }

    public static VideoEventState valueOf(String string) {
        return (VideoEventState)Enum.valueOf(VideoEventState.class, (String)string);
    }

    public static VideoEventState[] values() {
        return (VideoEventState[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

