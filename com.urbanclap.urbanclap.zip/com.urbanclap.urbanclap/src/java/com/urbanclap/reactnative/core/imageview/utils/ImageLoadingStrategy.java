/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.imageview.utils;

public final class ImageLoadingStrategy
extends Enum<ImageLoadingStrategy> {
    private static final /* synthetic */ ImageLoadingStrategy[] $VALUES;
    public static final /* enum */ ImageLoadingStrategy LOCAL;
    public static final /* enum */ ImageLoadingStrategy REMOTE;
    private final String value;

    public static {
        ImageLoadingStrategy imageLoadingStrategy;
        ImageLoadingStrategy imageLoadingStrategy2;
        ImageLoadingStrategy[] arrimageLoadingStrategy = new ImageLoadingStrategy[2];
        LOCAL = imageLoadingStrategy2 = new ImageLoadingStrategy("LOCAL");
        arrimageLoadingStrategy[0] = imageLoadingStrategy2;
        REMOTE = imageLoadingStrategy = new ImageLoadingStrategy("REMOTE");
        arrimageLoadingStrategy[1] = imageLoadingStrategy;
        $VALUES = arrimageLoadingStrategy;
    }

    private ImageLoadingStrategy(String string2) {
        this.value = string2;
    }

    public static ImageLoadingStrategy valueOf(String string) {
        return (ImageLoadingStrategy)Enum.valueOf(ImageLoadingStrategy.class, (String)string);
    }

    public static ImageLoadingStrategy[] values() {
        return (ImageLoadingStrategy[])$VALUES.clone();
    }

    public final String getValue() {
        return this.value;
    }
}

