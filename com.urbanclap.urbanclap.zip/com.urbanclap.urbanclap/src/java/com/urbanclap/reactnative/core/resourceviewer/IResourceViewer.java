/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.reactnative.core.resourceviewer.IResourceViewer$a
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.core.resourceviewer;

import com.urbanclap.reactnative.core.resourceviewer.IResourceViewer;

public interface IResourceViewer {
    public static final a a = a.c;

    public static final class Actions
    extends Enum<Actions> {
        private static final /* synthetic */ Actions[] $VALUES;
        public static final /* enum */ Actions OPEN;
        public static final /* enum */ Actions UNZIP;

        public static {
            Actions actions;
            Actions actions2;
            Actions[] arractions = new Actions[2];
            OPEN = actions2 = new Actions();
            arractions[0] = actions2;
            UNZIP = actions = new Actions();
            arractions[1] = actions;
            $VALUES = arractions;
        }

        public static Actions valueOf(String string) {
            return (Actions)Enum.valueOf(Actions.class, (String)string);
        }

        public static Actions[] values() {
            return (Actions[])$VALUES.clone();
        }
    }

}

