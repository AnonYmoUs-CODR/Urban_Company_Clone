/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.content.Intent
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  com.facebook.react.bridge.ActivityEventListener
 *  com.facebook.react.bridge.LifecycleEventListener
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.modules.core.PermissionListener
 *  com.urbanclap.reactnative.modules.BaseModule$a
 *  com.urbanclap.reactnative.modules.BaseModule$b
 *  com.urbanclap.reactnative.modules.BaseModule$d
 *  com.urbanclap.reactnative.modules.BaseModule$h$a
 *  i2.a0.c.a
 *  i2.a0.c.l
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  i2.a0.d.m
 *  i2.f
 *  i2.h
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  t1.r.f.a
 *  t1.r.f.h.d
 *  t1.r.f.h.k
 *  t1.r.f.h.n
 *  t1.r.f.h.q
 *  t1.r.f.h.w
 *  t1.r.i.h.a
 *  t1.r.i.h.a$a
 *  t1.r.i.o.q
 *  t1.r.i.o.s
 *  t1.r.i.o.v
 */
package com.urbanclap.reactnative.modules;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.modules.core.PermissionListener;
import com.urbanclap.reactnative.modules.BaseModule;
import i2.a0.d.l;
import i2.a0.d.m;
import t1.r.f.h.k;
import t1.r.f.h.n;
import t1.r.f.h.q;
import t1.r.f.h.w;
import t1.r.i.h.a;
import t1.r.i.o.s;
import t1.r.i.o.v;

/*
 * Exception performing whole class analysis.
 */
public abstract class BaseModule
extends ReactContextBaseJavaModule
implements PermissionListener {
    public static final a Companion;
    public static final String DATA_NOT_FOUND_CODE = "DATA_NOT_FOUND";
    public static final String DATA_NOT_FOUND_MESSAGE = "data not found";
    public static final String INVALID_RESULT_CODE = "INVALID_RESULT_CODE";
    public static final String REQUEST_CANCELLED_CODE = "REQUEST_CANCELLED";
    public static final String REQUEST_CANCELLED_MESSAGE = "request was cancelled";
    public static final String REQUEST_ERROR_CODE = "REQUEST_ERROR_CODE";
    public static final String REQUEST_ERROR_MESSAGE = "There was an error placing the request";
    public static final String REQUEST_SUCCESS_MESSAGE = "request success message";
    private final ActivityEventListener activityEventListener;
    private final i2.f deviceInfoPlugin$delegate;
    private final LifecycleEventListener lifeCycleEventListener;
    private final i2.f loggerPlugin$delegate;
    private final i2.f networkPlugin$delegate;
    private final i2.f preferencePlugin$delegate;
    private final i2.f reactAppVariantConfigProvider$delegate;
    private final s reactPackageAttributesFactory;
    private final i2.f userInfoPlugin$delegate;

    public static {
        Companion = new /* Unavailable Anonymous Inner Class!! */;
    }

    public BaseModule(ReactApplicationContext reactApplicationContext) {
        l.g((Object)reactApplicationContext, (String)"reactContext");
        super(reactApplicationContext);
        this.reactPackageAttributesFactory = new s();
        this.loggerPlugin$delegate = i2.h.b((i2.a0.c.a)e.a);
        this.reactAppVariantConfigProvider$delegate = i2.h.b((i2.a0.c.a)i.a);
        this.networkPlugin$delegate = i2.h.b((i2.a0.c.a)f.a);
        this.deviceInfoPlugin$delegate = i2.h.b((i2.a0.c.a)c.a);
        this.userInfoPlugin$delegate = i2.h.b((i2.a0.c.a)j.a);
        this.preferencePlugin$delegate = i2.h.b((i2.a0.c.a)g.a);
        this.activityEventListener = new b(this);
        this.lifeCycleEventListener = new d(this);
    }

    private final Object proceed(i2.a0.c.l<? super Activity, ? extends Object> l2) {
        Object object;
        Activity activity = this.getCurrentActivity();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Activity Found ");
        stringBuilder.append((Object)activity);
        this.logD(stringBuilder.toString());
        if (activity != null) {
            l.f((Object)activity, (String)"it1");
            object = l2.invoke((Object)activity);
        } else {
            object = null;
        }
        if (object != null) {
            return object;
        }
        this.logD("Activity Not Found");
        return Boolean.FALSE;
    }

    public final void addActivityEventsListener() {
        this.getReactApplicationContext().addActivityEventListener(this.activityEventListener);
        this.getReactApplicationContext().addLifecycleEventListener(this.lifeCycleEventListener);
    }

    public final t1.r.f.h.d getDeviceInfoPlugin() {
        return (t1.r.f.h.d)this.deviceInfoPlugin$delegate.getValue();
    }

    public final k getLoggerPlugin() {
        return (k)this.loggerPlugin$delegate.getValue();
    }

    public final n getNetworkPlugin() {
        return (n)this.networkPlugin$delegate.getValue();
    }

    public final q getPreferencePlugin() {
        return (q)this.preferencePlugin$delegate.getValue();
    }

    public final t1.r.i.o.q getReactAppVariantConfigProvider() {
        return (t1.r.i.o.q)this.reactAppVariantConfigProvider$delegate.getValue();
    }

    public final String getString(int n2) {
        String string = ((t1.r.i.h.a)t1.r.i.h.a.p.a()).i().getString(n2);
        l.f((Object)string, (String)"UCReactApp.getInstance().application.getString(id)");
        return string;
    }

    public abstract String getTag();

    public final w getUserInfoPlugin() {
        return (w)this.userInfoPlugin$delegate.getValue();
    }

    public void handleOnHostResume() {
    }

    public boolean handleRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        return true;
    }

    public void handleResult(Activity activity, int n2, int n3, Intent intent) {
        l.g((Object)activity, (String)"activity");
        Log.d((String)"TAG", (String)"handleResult: ");
    }

    public final void logD(String string) {
        l.g((Object)string, (String)"message");
        v.a((String)this.getTag(), (String)string);
    }

    public boolean onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        return this.handleRequestPermissionsResult(n2, arrstring, arrn);
    }

    public final Object proceedAsync(i2.a0.c.a<? extends Object> a2) {
        l.g(a2, (String)"action");
        this.logD("Proceed Async no activity");
        return a2.invoke();
    }

    public final Object proceedAsyncContext(i2.a0.c.l<? super Activity, ? extends Object> l2) {
        l.g(l2, (String)"action");
        this.logD("Proceed Async");
        return this.proceed(l2);
    }

    public final Object proceedSyncContext(final i2.a0.c.l<? super Activity, ? extends Object> l2) {
        l.g(l2, (String)"action");
        this.logD("Proceed Sync");
        return this.proceed((i2.a0.c.l<? super Activity, ? extends Object>)new i2.a0.c.l<Activity, Object>(){

            public final Object a(Activity activity) {
                l.g((Object)activity, (String)"activity");
                return new Handler(Looper.getMainLooper()).post((Runnable)new a(this, activity));
            }
        });
    }

    public abstract void providePlugin(t1.r.f.a var1);

}

