/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.modal;

public final class AppVariant
extends Enum<AppVariant> {
    private static final /* synthetic */ AppVariant[] $VALUES;
    public static final /* enum */ AppVariant CUSTOMER;
    public static final /* enum */ AppVariant PROVIDER;

    public static {
        AppVariant appVariant;
        AppVariant appVariant2;
        AppVariant[] arrappVariant = new AppVariant[2];
        CUSTOMER = appVariant2 = new AppVariant();
        arrappVariant[0] = appVariant2;
        PROVIDER = appVariant = new AppVariant();
        arrappVariant[1] = appVariant;
        $VALUES = arrappVariant;
    }

    public static AppVariant valueOf(String string) {
        return (AppVariant)Enum.valueOf(AppVariant.class, (String)string);
    }

    public static AppVariant[] values() {
        return (AppVariant[])$VALUES.clone();
    }
}

