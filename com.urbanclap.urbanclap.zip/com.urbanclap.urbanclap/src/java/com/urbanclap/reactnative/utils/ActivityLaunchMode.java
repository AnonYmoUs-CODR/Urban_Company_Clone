/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.utils;

public final class ActivityLaunchMode
extends Enum<ActivityLaunchMode> {
    private static final /* synthetic */ ActivityLaunchMode[] $VALUES;
    public static final /* enum */ ActivityLaunchMode NEW_TASK;
    public static final /* enum */ ActivityLaunchMode NORMAL;
    private final int launchMode;

    public static {
        ActivityLaunchMode activityLaunchMode;
        ActivityLaunchMode activityLaunchMode2;
        ActivityLaunchMode[] arractivityLaunchMode = new ActivityLaunchMode[2];
        NORMAL = activityLaunchMode2 = new ActivityLaunchMode(0);
        arractivityLaunchMode[0] = activityLaunchMode2;
        NEW_TASK = activityLaunchMode = new ActivityLaunchMode(1);
        arractivityLaunchMode[1] = activityLaunchMode;
        $VALUES = arractivityLaunchMode;
    }

    private ActivityLaunchMode(int n2) {
        this.launchMode = n2;
    }

    public static ActivityLaunchMode valueOf(String string) {
        return (ActivityLaunchMode)Enum.valueOf(ActivityLaunchMode.class, (String)string);
    }

    public static ActivityLaunchMode[] values() {
        return (ActivityLaunchMode[])$VALUES.clone();
    }

    public final int getLaunchMode() {
        return this.launchMode;
    }
}

