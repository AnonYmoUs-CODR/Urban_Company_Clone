/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.utils.enums;

public final class SupportedOtpScreensCustomer
extends Enum<SupportedOtpScreensCustomer> {
    private static final /* synthetic */ SupportedOtpScreensCustomer[] $VALUES;
    public static final /* enum */ SupportedOtpScreensCustomer CUSTOMER_REQUEST_JOURNEY;
    private final String screenName;

    public static {
        SupportedOtpScreensCustomer supportedOtpScreensCustomer;
        SupportedOtpScreensCustomer[] arrsupportedOtpScreensCustomer = new SupportedOtpScreensCustomer[1];
        CUSTOMER_REQUEST_JOURNEY = supportedOtpScreensCustomer = new SupportedOtpScreensCustomer("customerRequestJourney");
        arrsupportedOtpScreensCustomer[0] = supportedOtpScreensCustomer;
        $VALUES = arrsupportedOtpScreensCustomer;
    }

    private SupportedOtpScreensCustomer(String string2) {
        this.screenName = string2;
    }

    public static SupportedOtpScreensCustomer valueOf(String string) {
        return (SupportedOtpScreensCustomer)Enum.valueOf(SupportedOtpScreensCustomer.class, (String)string);
    }

    public static SupportedOtpScreensCustomer[] values() {
        return (SupportedOtpScreensCustomer[])$VALUES.clone();
    }

    public final String getScreenName() {
        return this.screenName;
    }
}

