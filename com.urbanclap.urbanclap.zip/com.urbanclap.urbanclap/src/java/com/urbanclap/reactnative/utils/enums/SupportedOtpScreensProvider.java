/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.reactnative.utils.enums;

public final class SupportedOtpScreensProvider
extends Enum<SupportedOtpScreensProvider> {
    private static final /* synthetic */ SupportedOtpScreensProvider[] $VALUES;
    public static final /* enum */ SupportedOtpScreensProvider ONBOARDING_OTP;
    private final String screenName;

    public static {
        SupportedOtpScreensProvider supportedOtpScreensProvider;
        SupportedOtpScreensProvider[] arrsupportedOtpScreensProvider = new SupportedOtpScreensProvider[1];
        ONBOARDING_OTP = supportedOtpScreensProvider = new SupportedOtpScreensProvider("onboarding/otp");
        arrsupportedOtpScreensProvider[0] = supportedOtpScreensProvider;
        $VALUES = arrsupportedOtpScreensProvider;
    }

    private SupportedOtpScreensProvider(String string2) {
        this.screenName = string2;
    }

    public static SupportedOtpScreensProvider valueOf(String string) {
        return (SupportedOtpScreensProvider)Enum.valueOf(SupportedOtpScreensProvider.class, (String)string);
    }

    public static SupportedOtpScreensProvider[] values() {
        return (SupportedOtpScreensProvider[])$VALUES.clone();
    }

    public final String getScreenName() {
        return this.screenName;
    }
}

