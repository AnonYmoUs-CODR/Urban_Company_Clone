/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins.enums;

public final class FilePickerErrorCode
extends Enum<FilePickerErrorCode> {
    private static final /* synthetic */ FilePickerErrorCode[] $VALUES;
    public static final /* enum */ FilePickerErrorCode APPLICATION_NOT_FOUND;
    public static final /* enum */ FilePickerErrorCode DIALOG_CANCELLED;
    public static final /* enum */ FilePickerErrorCode FILE_NOT_PICKED;
    public static final /* enum */ FilePickerErrorCode FILE_URI_NULL;
    public static final /* enum */ FilePickerErrorCode PERMISSION_DENIED;

    public static {
        FilePickerErrorCode filePickerErrorCode;
        FilePickerErrorCode filePickerErrorCode2;
        FilePickerErrorCode filePickerErrorCode3;
        FilePickerErrorCode filePickerErrorCode4;
        FilePickerErrorCode filePickerErrorCode5;
        FilePickerErrorCode[] arrfilePickerErrorCode = new FilePickerErrorCode[5];
        FILE_NOT_PICKED = filePickerErrorCode3 = new FilePickerErrorCode();
        arrfilePickerErrorCode[0] = filePickerErrorCode3;
        DIALOG_CANCELLED = filePickerErrorCode = new FilePickerErrorCode();
        arrfilePickerErrorCode[1] = filePickerErrorCode;
        PERMISSION_DENIED = filePickerErrorCode5 = new FilePickerErrorCode();
        arrfilePickerErrorCode[2] = filePickerErrorCode5;
        APPLICATION_NOT_FOUND = filePickerErrorCode4 = new FilePickerErrorCode();
        arrfilePickerErrorCode[3] = filePickerErrorCode4;
        FILE_URI_NULL = filePickerErrorCode2 = new FilePickerErrorCode();
        arrfilePickerErrorCode[4] = filePickerErrorCode2;
        $VALUES = arrfilePickerErrorCode;
    }

    public static FilePickerErrorCode valueOf(String string) {
        return (FilePickerErrorCode)Enum.valueOf(FilePickerErrorCode.class, (String)string);
    }

    public static FilePickerErrorCode[] values() {
        return (FilePickerErrorCode[])$VALUES.clone();
    }
}

