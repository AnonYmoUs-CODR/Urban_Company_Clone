/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins.enums;

public final class FileType
extends Enum<FileType> {
    private static final /* synthetic */ FileType[] $VALUES;
    public static final /* enum */ FileType Audio;
    public static final /* enum */ FileType Doc;
    public static final /* enum */ FileType Image;
    public static final /* enum */ FileType Video;
    private final String type;

    public static {
        FileType fileType;
        FileType fileType2;
        FileType fileType3;
        FileType fileType4;
        FileType[] arrfileType = new FileType[4];
        Image = fileType3 = new FileType("image");
        arrfileType[0] = fileType3;
        Video = fileType4 = new FileType("video");
        arrfileType[1] = fileType4;
        Doc = fileType2 = new FileType("doc");
        arrfileType[2] = fileType2;
        Audio = fileType = new FileType("audio");
        arrfileType[3] = fileType;
        $VALUES = arrfileType;
    }

    private FileType(String string2) {
        this.type = string2;
    }

    public static FileType valueOf(String string) {
        return (FileType)Enum.valueOf(FileType.class, (String)string);
    }

    public static FileType[] values() {
        return (FileType[])$VALUES.clone();
    }

    public final String getType() {
        return this.type;
    }
}

