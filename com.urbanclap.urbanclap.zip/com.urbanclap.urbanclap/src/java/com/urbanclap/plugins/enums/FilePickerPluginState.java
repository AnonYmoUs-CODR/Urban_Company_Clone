/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins.enums;

public final class FilePickerPluginState
extends Enum<FilePickerPluginState> {
    private static final /* synthetic */ FilePickerPluginState[] $VALUES;
    public static final /* enum */ FilePickerPluginState AVAILABLE;
    public static final /* enum */ FilePickerPluginState UNAVAILABLE;

    public static {
        FilePickerPluginState filePickerPluginState;
        FilePickerPluginState filePickerPluginState2;
        FilePickerPluginState[] arrfilePickerPluginState = new FilePickerPluginState[2];
        AVAILABLE = filePickerPluginState = new FilePickerPluginState();
        arrfilePickerPluginState[0] = filePickerPluginState;
        UNAVAILABLE = filePickerPluginState2 = new FilePickerPluginState();
        arrfilePickerPluginState[1] = filePickerPluginState2;
        $VALUES = arrfilePickerPluginState;
    }

    public static FilePickerPluginState valueOf(String string) {
        return (FilePickerPluginState)Enum.valueOf(FilePickerPluginState.class, (String)string);
    }

    public static FilePickerPluginState[] values() {
        return (FilePickerPluginState[])$VALUES.clone();
    }
}

