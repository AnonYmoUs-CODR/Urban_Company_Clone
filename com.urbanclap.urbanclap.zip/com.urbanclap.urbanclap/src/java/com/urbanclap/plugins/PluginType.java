/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins;

public final class PluginType
extends Enum<PluginType> {
    private static final /* synthetic */ PluginType[] $VALUES;
    public static final /* enum */ PluginType ANALYTICS;
    public static final /* enum */ PluginType COMMUNICATION;
    public static final /* enum */ PluginType CRASHLYTICS;
    public static final /* enum */ PluginType DEVICE_INFO;
    public static final /* enum */ PluginType DOWNLOAD;
    public static final /* enum */ PluginType EVENT_CHUCKER_INTERCEPTOR;
    public static final /* enum */ PluginType EVENT_INTERCEPTOR;
    public static final /* enum */ PluginType FILE_PICKER;
    public static final /* enum */ PluginType FILE_UPLOAD;
    public static final /* enum */ PluginType IMAGE_TRACKER;
    public static final /* enum */ PluginType LOCATION;
    public static final /* enum */ PluginType LOGGER;
    public static final /* enum */ PluginType LOGIN;
    public static final /* enum */ PluginType NAVIGATOR;
    public static final /* enum */ PluginType NETWORK;
    public static final /* enum */ PluginType NOTIFICATION;
    public static final /* enum */ PluginType PAYMENT;
    public static final /* enum */ PluginType PREFERENCE;
    public static final /* enum */ PluginType RESOURCE;
    public static final /* enum */ PluginType SESSION_RECORDER;
    public static final /* enum */ PluginType SMS;
    public static final /* enum */ PluginType TRACER;
    public static final /* enum */ PluginType USER_INFO;

    public static {
        PluginType pluginType;
        PluginType pluginType2;
        PluginType pluginType3;
        PluginType pluginType4;
        PluginType pluginType5;
        PluginType pluginType6;
        PluginType pluginType7;
        PluginType pluginType8;
        PluginType pluginType9;
        PluginType pluginType10;
        PluginType pluginType11;
        PluginType pluginType12;
        PluginType pluginType13;
        PluginType pluginType14;
        PluginType pluginType15;
        PluginType pluginType16;
        PluginType pluginType17;
        PluginType pluginType18;
        PluginType pluginType19;
        PluginType pluginType20;
        PluginType pluginType21;
        PluginType pluginType22;
        PluginType pluginType23;
        PluginType[] arrpluginType = new PluginType[23];
        COMMUNICATION = pluginType7 = new PluginType();
        arrpluginType[0] = pluginType7;
        DEVICE_INFO = pluginType11 = new PluginType();
        arrpluginType[1] = pluginType11;
        DOWNLOAD = pluginType2 = new PluginType();
        arrpluginType[2] = pluginType2;
        LOGIN = pluginType18 = new PluginType();
        arrpluginType[3] = pluginType18;
        NAVIGATOR = pluginType13 = new PluginType();
        arrpluginType[4] = pluginType13;
        NETWORK = pluginType6 = new PluginType();
        arrpluginType[5] = pluginType6;
        NOTIFICATION = pluginType21 = new PluginType();
        arrpluginType[6] = pluginType21;
        USER_INFO = pluginType8 = new PluginType();
        arrpluginType[7] = pluginType8;
        LOGGER = pluginType4 = new PluginType();
        arrpluginType[8] = pluginType4;
        TRACER = pluginType15 = new PluginType();
        arrpluginType[9] = pluginType15;
        PREFERENCE = pluginType23 = new PluginType();
        arrpluginType[10] = pluginType23;
        ANALYTICS = pluginType5 = new PluginType();
        arrpluginType[11] = pluginType5;
        EVENT_INTERCEPTOR = pluginType14 = new PluginType();
        arrpluginType[12] = pluginType14;
        EVENT_CHUCKER_INTERCEPTOR = pluginType9 = new PluginType();
        arrpluginType[13] = pluginType9;
        RESOURCE = pluginType3 = new PluginType();
        arrpluginType[14] = pluginType3;
        CRASHLYTICS = pluginType19 = new PluginType();
        arrpluginType[15] = pluginType19;
        SMS = pluginType20 = new PluginType();
        arrpluginType[16] = pluginType20;
        LOCATION = pluginType16 = new PluginType();
        arrpluginType[17] = pluginType16;
        SESSION_RECORDER = pluginType10 = new PluginType();
        arrpluginType[18] = pluginType10;
        IMAGE_TRACKER = pluginType22 = new PluginType();
        arrpluginType[19] = pluginType22;
        PAYMENT = pluginType17 = new PluginType();
        arrpluginType[20] = pluginType17;
        FILE_UPLOAD = pluginType = new PluginType();
        arrpluginType[21] = pluginType;
        FILE_PICKER = pluginType12 = new PluginType();
        arrpluginType[22] = pluginType12;
        $VALUES = arrpluginType;
    }

    public static PluginType valueOf(String string) {
        return (PluginType)Enum.valueOf(PluginType.class, (String)string);
    }

    public static PluginType[] values() {
        return (PluginType[])$VALUES.clone();
    }
}

