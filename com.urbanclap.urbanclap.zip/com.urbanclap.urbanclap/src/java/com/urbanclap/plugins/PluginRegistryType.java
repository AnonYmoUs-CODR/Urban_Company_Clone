/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins;

public final class PluginRegistryType
extends Enum<PluginRegistryType> {
    private static final /* synthetic */ PluginRegistryType[] $VALUES;
    public static final /* enum */ PluginRegistryType ANALYTICS;
    public static final /* enum */ PluginRegistryType COMMUNICATION;
    public static final /* enum */ PluginRegistryType NETWORK;
    public static final /* enum */ PluginRegistryType ORION;
    public static final /* enum */ PluginRegistryType REACT;

    public static {
        PluginRegistryType pluginRegistryType;
        PluginRegistryType pluginRegistryType2;
        PluginRegistryType pluginRegistryType3;
        PluginRegistryType pluginRegistryType4;
        PluginRegistryType pluginRegistryType5;
        REACT = pluginRegistryType2 = new PluginRegistryType();
        NETWORK = pluginRegistryType3 = new PluginRegistryType();
        ANALYTICS = pluginRegistryType5 = new PluginRegistryType();
        ORION = pluginRegistryType = new PluginRegistryType();
        COMMUNICATION = pluginRegistryType4 = new PluginRegistryType();
        $VALUES = new PluginRegistryType[]{pluginRegistryType2, pluginRegistryType3, pluginRegistryType5, pluginRegistryType, pluginRegistryType4};
    }

    public static PluginRegistryType valueOf(String string) {
        return (PluginRegistryType)Enum.valueOf(PluginRegistryType.class, (String)string);
    }

    public static PluginRegistryType[] values() {
        return (PluginRegistryType[])$VALUES.clone();
    }
}

