/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.plugins.utils;

public final class DialogType
extends Enum<DialogType> {
    private static final /* synthetic */ DialogType[] $VALUES;
    public static final /* enum */ DialogType APP_STORE_RATING;
    public static final /* enum */ DialogType DEFAULT;

    public static {
        DialogType dialogType;
        DialogType dialogType2;
        DialogType[] arrdialogType = new DialogType[2];
        DEFAULT = dialogType2 = new DialogType();
        arrdialogType[0] = dialogType2;
        APP_STORE_RATING = dialogType = new DialogType();
        arrdialogType[1] = dialogType;
        $VALUES = arrdialogType;
    }

    public static DialogType valueOf(String string) {
        return (DialogType)Enum.valueOf(DialogType.class, (String)string);
    }

    public static DialogType[] values() {
        return (DialogType[])$VALUES.clone();
    }
}

