/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.PrefetchPayload;
import i2.a0.d.l;

@Keep
public final class PrefetchPayloadWrapper {
    private final PrefetchPayload payload;
    private final String requestId;
    private final String service;

    public PrefetchPayloadWrapper(String string, String string2, PrefetchPayload prefetchPayload) {
        this.requestId = string;
        this.service = string2;
        this.payload = prefetchPayload;
    }

    public static /* synthetic */ PrefetchPayloadWrapper copy$default(PrefetchPayloadWrapper prefetchPayloadWrapper, String string, String string2, PrefetchPayload prefetchPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = prefetchPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = prefetchPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            prefetchPayload = prefetchPayloadWrapper.payload;
        }
        return prefetchPayloadWrapper.copy(string, string2, prefetchPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final PrefetchPayload component3() {
        return this.payload;
    }

    public final PrefetchPayloadWrapper copy(String string, String string2, PrefetchPayload prefetchPayload) {
        return new PrefetchPayloadWrapper(string, string2, prefetchPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PrefetchPayloadWrapper)) break block3;
                PrefetchPayloadWrapper prefetchPayloadWrapper = (PrefetchPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)prefetchPayloadWrapper.requestId) && l.c((Object)this.service, (Object)prefetchPayloadWrapper.service) && l.c((Object)this.payload, (Object)prefetchPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final PrefetchPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        PrefetchPayload prefetchPayload = this.payload;
        int n5 = 0;
        if (prefetchPayload != null) {
            n5 = prefetchPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("PrefetchPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

