/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.CreateWalletPayload;
import i2.a0.d.l;

@Keep
public final class CreateWalletPayloadWrapper {
    private final CreateWalletPayload payload;
    private final String requestId;
    private final String service;

    public CreateWalletPayloadWrapper(String string, String string2, CreateWalletPayload createWalletPayload) {
        l.g((Object)createWalletPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.payload = createWalletPayload;
    }

    public static /* synthetic */ CreateWalletPayloadWrapper copy$default(CreateWalletPayloadWrapper createWalletPayloadWrapper, String string, String string2, CreateWalletPayload createWalletPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = createWalletPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = createWalletPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            createWalletPayload = createWalletPayloadWrapper.payload;
        }
        return createWalletPayloadWrapper.copy(string, string2, createWalletPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final CreateWalletPayload component3() {
        return this.payload;
    }

    public final CreateWalletPayloadWrapper copy(String string, String string2, CreateWalletPayload createWalletPayload) {
        l.g((Object)createWalletPayload, (String)"payload");
        return new CreateWalletPayloadWrapper(string, string2, createWalletPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CreateWalletPayloadWrapper)) break block3;
                CreateWalletPayloadWrapper createWalletPayloadWrapper = (CreateWalletPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)createWalletPayloadWrapper.requestId) && l.c((Object)this.service, (Object)createWalletPayloadWrapper.service) && l.c((Object)this.payload, (Object)createWalletPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final CreateWalletPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        CreateWalletPayload createWalletPayload = this.payload;
        int n5 = 0;
        if (createWalletPayload != null) {
            n5 = createWalletPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CreateWalletPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

