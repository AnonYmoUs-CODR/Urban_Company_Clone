/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;

@Keep
public final class PaymentProcessPayload {
    private final String action;
    private final ArrayList<Object> allowedMethods;
    private final String amount;
    private final String application;
    private final String authType;
    private final String cardBin;
    private final String cardExpMonth;
    private final String cardExpYear;
    private final String cardNumber;
    private final String cardSecurityCode;
    private final String cardToken;
    private final String clientAuthToken;
    private final String custVpa;
    private final String directWalletToken;
    private final String displayNote;
    private final String emiBank;
    private final Integer emiTenure;
    private final String emiType;
    private final ArrayList<Object> endUrls;
    private final Boolean isEmi;
    private final String nameOnCard;
    private final String orderId;
    private final String payWithApp;
    private final String paymentMethod;
    private final String paymentMethodType;
    private final String redirectUrl;
    private final Boolean saveToLocker;
    private final String sdkPresent;
    private final Boolean showLoader;
    private final Boolean upiSdkPresent;
    private final String walletId;
    private final String walletName;

    public PaymentProcessPayload(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, String string12, String string13, String string14, String string15, String string16, Integer n, String string17, String string18, Boolean bl, Boolean bl2, Boolean bl3, Boolean bl4, ArrayList<Object> arrayList, ArrayList<Object> arrayList2, String string19, String string20, String string21, String string22, String string23, String string24, String string25) {
        l.g((Object)string, (String)"action");
        l.g((Object)string2, (String)"orderId");
        this.action = string;
        this.orderId = string2;
        this.custVpa = string3;
        this.displayNote = string4;
        this.clientAuthToken = string5;
        this.paymentMethod = string6;
        this.payWithApp = string7;
        this.cardNumber = string8;
        this.cardExpMonth = string9;
        this.cardExpYear = string10;
        this.cardSecurityCode = string11;
        this.cardBin = string12;
        this.emiBank = string13;
        this.cardToken = string14;
        this.nameOnCard = string15;
        this.emiType = string16;
        this.emiTenure = n;
        this.directWalletToken = string17;
        this.sdkPresent = string18;
        this.saveToLocker = bl;
        this.showLoader = bl2;
        this.upiSdkPresent = bl3;
        this.isEmi = bl4;
        this.endUrls = arrayList;
        this.allowedMethods = arrayList2;
        this.application = string19;
        this.walletName = string20;
        this.walletId = string21;
        this.paymentMethodType = string22;
        this.redirectUrl = string23;
        this.authType = string24;
        this.amount = string25;
    }

    public /* synthetic */ PaymentProcessPayload(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, String string12, String string13, String string14, String string15, String string16, Integer n, String string17, String string18, Boolean bl, Boolean bl2, Boolean bl3, Boolean bl4, ArrayList arrayList, ArrayList arrayList2, String string19, String string20, String string21, String string22, String string23, String string24, String string25, int n2, g g2) {
        String string26 = (n2 & 4) != 0 ? null : string3;
        String string27 = (n2 & 8) != 0 ? null : string4;
        String string28 = (n2 & 16) != 0 ? null : string5;
        String string29 = (n2 & 32) != 0 ? null : string6;
        String string30 = (n2 & 64) != 0 ? null : string7;
        String string31 = (n2 & 128) != 0 ? null : string8;
        String string32 = (n2 & 256) != 0 ? null : string9;
        String string33 = (n2 & 512) != 0 ? null : string10;
        String string34 = (n2 & 1024) != 0 ? null : string11;
        String string35 = (n2 & 2048) != 0 ? null : string12;
        String string36 = (n2 & 4096) != 0 ? null : string13;
        String string37 = (n2 & 8192) != 0 ? null : string14;
        String string38 = (n2 & 16384) != 0 ? null : string15;
        String string39 = (32768 & n2) != 0 ? null : string16;
        Integer n3 = (65536 & n2) != 0 ? null : n;
        String string40 = (131072 & n2) != 0 ? null : string17;
        String string41 = (262144 & n2) != 0 ? null : string18;
        Boolean bl5 = (524288 & n2) != 0 ? null : bl;
        Boolean bl6 = (1048576 & n2) != 0 ? null : bl2;
        Boolean bl7 = (2097152 & n2) != 0 ? null : bl3;
        Boolean bl8 = (4194304 & n2) != 0 ? null : bl4;
        ArrayList arrayList3 = (8388608 & n2) != 0 ? null : arrayList;
        ArrayList arrayList4 = (16777216 & n2) != 0 ? null : arrayList2;
        String string42 = (33554432 & n2) != 0 ? null : string19;
        String string43 = (67108864 & n2) != 0 ? null : string20;
        String string44 = (134217728 & n2) != 0 ? null : string21;
        String string45 = (268435456 & n2) != 0 ? null : string22;
        String string46 = (536870912 & n2) != 0 ? null : string23;
        String string47 = (1073741824 & n2) != 0 ? null : string24;
        String string48 = (n2 & Integer.MIN_VALUE) != 0 ? null : string25;
        this(string, string2, string26, string27, string28, string29, string30, string31, string32, string33, string34, string35, string36, string37, string38, string39, n3, string40, string41, bl5, bl6, bl7, bl8, (ArrayList<Object>)arrayList3, (ArrayList<Object>)arrayList4, string42, string43, string44, string45, string46, string47, string48);
    }

    public static /* synthetic */ PaymentProcessPayload copy$default(PaymentProcessPayload paymentProcessPayload, String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, String string12, String string13, String string14, String string15, String string16, Integer n, String string17, String string18, Boolean bl, Boolean bl2, Boolean bl3, Boolean bl4, ArrayList arrayList, ArrayList arrayList2, String string19, String string20, String string21, String string22, String string23, String string24, String string25, int n2, Object object) {
        String string26 = (n2 & 1) != 0 ? paymentProcessPayload.action : string;
        String string27 = (n2 & 2) != 0 ? paymentProcessPayload.orderId : string2;
        String string28 = (n2 & 4) != 0 ? paymentProcessPayload.custVpa : string3;
        String string29 = (n2 & 8) != 0 ? paymentProcessPayload.displayNote : string4;
        String string30 = (n2 & 16) != 0 ? paymentProcessPayload.clientAuthToken : string5;
        String string31 = (n2 & 32) != 0 ? paymentProcessPayload.paymentMethod : string6;
        String string32 = (n2 & 64) != 0 ? paymentProcessPayload.payWithApp : string7;
        String string33 = (n2 & 128) != 0 ? paymentProcessPayload.cardNumber : string8;
        String string34 = (n2 & 256) != 0 ? paymentProcessPayload.cardExpMonth : string9;
        String string35 = (n2 & 512) != 0 ? paymentProcessPayload.cardExpYear : string10;
        String string36 = (n2 & 1024) != 0 ? paymentProcessPayload.cardSecurityCode : string11;
        String string37 = (n2 & 2048) != 0 ? paymentProcessPayload.cardBin : string12;
        String string38 = (n2 & 4096) != 0 ? paymentProcessPayload.emiBank : string13;
        String string39 = (n2 & 8192) != 0 ? paymentProcessPayload.cardToken : string14;
        String string40 = string39;
        String string41 = (n2 & 16384) != 0 ? paymentProcessPayload.nameOnCard : string15;
        int n3 = n2 & 32768;
        String string42 = string41;
        String string43 = n3 != 0 ? paymentProcessPayload.emiType : string16;
        int n4 = n2 & 65536;
        String string44 = string43;
        Integer n5 = n4 != 0 ? paymentProcessPayload.emiTenure : n;
        int n6 = n2 & 131072;
        Integer n7 = n5;
        String string45 = n6 != 0 ? paymentProcessPayload.directWalletToken : string17;
        int n8 = n2 & 262144;
        String string46 = string45;
        String string47 = n8 != 0 ? paymentProcessPayload.sdkPresent : string18;
        int n9 = n2 & 524288;
        String string48 = string47;
        Boolean bl5 = n9 != 0 ? paymentProcessPayload.saveToLocker : bl;
        int n10 = n2 & 1048576;
        Boolean bl6 = bl5;
        Boolean bl7 = n10 != 0 ? paymentProcessPayload.showLoader : bl2;
        int n11 = n2 & 2097152;
        Boolean bl8 = bl7;
        Boolean bl9 = n11 != 0 ? paymentProcessPayload.upiSdkPresent : bl3;
        int n12 = n2 & 4194304;
        Boolean bl10 = bl9;
        Boolean bl11 = n12 != 0 ? paymentProcessPayload.isEmi : bl4;
        int n13 = n2 & 8388608;
        Boolean bl12 = bl11;
        ArrayList<Object> arrayList3 = n13 != 0 ? paymentProcessPayload.endUrls : arrayList;
        int n14 = n2 & 16777216;
        ArrayList<Object> arrayList4 = arrayList3;
        ArrayList<Object> arrayList5 = n14 != 0 ? paymentProcessPayload.allowedMethods : arrayList2;
        int n15 = n2 & 33554432;
        ArrayList<Object> arrayList6 = arrayList5;
        String string49 = n15 != 0 ? paymentProcessPayload.application : string19;
        int n16 = n2 & 67108864;
        String string50 = string49;
        String string51 = n16 != 0 ? paymentProcessPayload.walletName : string20;
        int n17 = n2 & 134217728;
        String string52 = string51;
        String string53 = n17 != 0 ? paymentProcessPayload.walletId : string21;
        int n18 = n2 & 268435456;
        String string54 = string53;
        String string55 = n18 != 0 ? paymentProcessPayload.paymentMethodType : string22;
        int n19 = n2 & 536870912;
        String string56 = string55;
        String string57 = n19 != 0 ? paymentProcessPayload.redirectUrl : string23;
        int n20 = n2 & 1073741824;
        String string58 = string57;
        String string59 = n20 != 0 ? paymentProcessPayload.authType : string24;
        String string60 = (n2 & Integer.MIN_VALUE) != 0 ? paymentProcessPayload.amount : string25;
        return paymentProcessPayload.copy(string26, string27, string28, string29, string30, string31, string32, string33, string34, string35, string36, string37, string38, string40, string42, string44, n7, string46, string48, bl6, bl8, bl10, bl12, arrayList4, arrayList6, string50, string52, string54, string56, string58, string59, string60);
    }

    public final String component1() {
        return this.action;
    }

    public final String component10() {
        return this.cardExpYear;
    }

    public final String component11() {
        return this.cardSecurityCode;
    }

    public final String component12() {
        return this.cardBin;
    }

    public final String component13() {
        return this.emiBank;
    }

    public final String component14() {
        return this.cardToken;
    }

    public final String component15() {
        return this.nameOnCard;
    }

    public final String component16() {
        return this.emiType;
    }

    public final Integer component17() {
        return this.emiTenure;
    }

    public final String component18() {
        return this.directWalletToken;
    }

    public final String component19() {
        return this.sdkPresent;
    }

    public final String component2() {
        return this.orderId;
    }

    public final Boolean component20() {
        return this.saveToLocker;
    }

    public final Boolean component21() {
        return this.showLoader;
    }

    public final Boolean component22() {
        return this.upiSdkPresent;
    }

    public final Boolean component23() {
        return this.isEmi;
    }

    public final ArrayList<Object> component24() {
        return this.endUrls;
    }

    public final ArrayList<Object> component25() {
        return this.allowedMethods;
    }

    public final String component26() {
        return this.application;
    }

    public final String component27() {
        return this.walletName;
    }

    public final String component28() {
        return this.walletId;
    }

    public final String component29() {
        return this.paymentMethodType;
    }

    public final String component3() {
        return this.custVpa;
    }

    public final String component30() {
        return this.redirectUrl;
    }

    public final String component31() {
        return this.authType;
    }

    public final String component32() {
        return this.amount;
    }

    public final String component4() {
        return this.displayNote;
    }

    public final String component5() {
        return this.clientAuthToken;
    }

    public final String component6() {
        return this.paymentMethod;
    }

    public final String component7() {
        return this.payWithApp;
    }

    public final String component8() {
        return this.cardNumber;
    }

    public final String component9() {
        return this.cardExpMonth;
    }

    public final PaymentProcessPayload copy(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10, String string11, String string12, String string13, String string14, String string15, String string16, Integer n, String string17, String string18, Boolean bl, Boolean bl2, Boolean bl3, Boolean bl4, ArrayList<Object> arrayList, ArrayList<Object> arrayList2, String string19, String string20, String string21, String string22, String string23, String string24, String string25) {
        l.g((Object)string, (String)"action");
        l.g((Object)string2, (String)"orderId");
        PaymentProcessPayload paymentProcessPayload = new PaymentProcessPayload(string, string2, string3, string4, string5, string6, string7, string8, string9, string10, string11, string12, string13, string14, string15, string16, n, string17, string18, bl, bl2, bl3, bl4, arrayList, arrayList2, string19, string20, string21, string22, string23, string24, string25);
        return paymentProcessPayload;
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PaymentProcessPayload)) break block3;
                PaymentProcessPayload paymentProcessPayload = (PaymentProcessPayload)object;
                if (l.c((Object)this.action, (Object)paymentProcessPayload.action) && l.c((Object)this.orderId, (Object)paymentProcessPayload.orderId) && l.c((Object)this.custVpa, (Object)paymentProcessPayload.custVpa) && l.c((Object)this.displayNote, (Object)paymentProcessPayload.displayNote) && l.c((Object)this.clientAuthToken, (Object)paymentProcessPayload.clientAuthToken) && l.c((Object)this.paymentMethod, (Object)paymentProcessPayload.paymentMethod) && l.c((Object)this.payWithApp, (Object)paymentProcessPayload.payWithApp) && l.c((Object)this.cardNumber, (Object)paymentProcessPayload.cardNumber) && l.c((Object)this.cardExpMonth, (Object)paymentProcessPayload.cardExpMonth) && l.c((Object)this.cardExpYear, (Object)paymentProcessPayload.cardExpYear) && l.c((Object)this.cardSecurityCode, (Object)paymentProcessPayload.cardSecurityCode) && l.c((Object)this.cardBin, (Object)paymentProcessPayload.cardBin) && l.c((Object)this.emiBank, (Object)paymentProcessPayload.emiBank) && l.c((Object)this.cardToken, (Object)paymentProcessPayload.cardToken) && l.c((Object)this.nameOnCard, (Object)paymentProcessPayload.nameOnCard) && l.c((Object)this.emiType, (Object)paymentProcessPayload.emiType) && l.c((Object)this.emiTenure, (Object)paymentProcessPayload.emiTenure) && l.c((Object)this.directWalletToken, (Object)paymentProcessPayload.directWalletToken) && l.c((Object)this.sdkPresent, (Object)paymentProcessPayload.sdkPresent) && l.c((Object)this.saveToLocker, (Object)paymentProcessPayload.saveToLocker) && l.c((Object)this.showLoader, (Object)paymentProcessPayload.showLoader) && l.c((Object)this.upiSdkPresent, (Object)paymentProcessPayload.upiSdkPresent) && l.c((Object)this.isEmi, (Object)paymentProcessPayload.isEmi) && l.c(this.endUrls, paymentProcessPayload.endUrls) && l.c(this.allowedMethods, paymentProcessPayload.allowedMethods) && l.c((Object)this.application, (Object)paymentProcessPayload.application) && l.c((Object)this.walletName, (Object)paymentProcessPayload.walletName) && l.c((Object)this.walletId, (Object)paymentProcessPayload.walletId) && l.c((Object)this.paymentMethodType, (Object)paymentProcessPayload.paymentMethodType) && l.c((Object)this.redirectUrl, (Object)paymentProcessPayload.redirectUrl) && l.c((Object)this.authType, (Object)paymentProcessPayload.authType) && l.c((Object)this.amount, (Object)paymentProcessPayload.amount)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final ArrayList<Object> getAllowedMethods() {
        return this.allowedMethods;
    }

    public final String getAmount() {
        return this.amount;
    }

    public final String getApplication() {
        return this.application;
    }

    public final String getAuthType() {
        return this.authType;
    }

    public final String getCardBin() {
        return this.cardBin;
    }

    public final String getCardExpMonth() {
        return this.cardExpMonth;
    }

    public final String getCardExpYear() {
        return this.cardExpYear;
    }

    public final String getCardNumber() {
        return this.cardNumber;
    }

    public final String getCardSecurityCode() {
        return this.cardSecurityCode;
    }

    public final String getCardToken() {
        return this.cardToken;
    }

    public final String getClientAuthToken() {
        return this.clientAuthToken;
    }

    public final String getCustVpa() {
        return this.custVpa;
    }

    public final String getDirectWalletToken() {
        return this.directWalletToken;
    }

    public final String getDisplayNote() {
        return this.displayNote;
    }

    public final String getEmiBank() {
        return this.emiBank;
    }

    public final Integer getEmiTenure() {
        return this.emiTenure;
    }

    public final String getEmiType() {
        return this.emiType;
    }

    public final ArrayList<Object> getEndUrls() {
        return this.endUrls;
    }

    public final String getNameOnCard() {
        return this.nameOnCard;
    }

    public final String getOrderId() {
        return this.orderId;
    }

    public final String getPayWithApp() {
        return this.payWithApp;
    }

    public final String getPaymentMethod() {
        return this.paymentMethod;
    }

    public final String getPaymentMethodType() {
        return this.paymentMethodType;
    }

    public final String getRedirectUrl() {
        return this.redirectUrl;
    }

    public final Boolean getSaveToLocker() {
        return this.saveToLocker;
    }

    public final String getSdkPresent() {
        return this.sdkPresent;
    }

    public final Boolean getShowLoader() {
        return this.showLoader;
    }

    public final Boolean getUpiSdkPresent() {
        return this.upiSdkPresent;
    }

    public final String getWalletId() {
        return this.walletId;
    }

    public final String getWalletName() {
        return this.walletName;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.orderId;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.custVpa;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.displayNote;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string5 = this.clientAuthToken;
        int n9 = string5 != null ? string5.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        String string6 = this.paymentMethod;
        int n11 = string6 != null ? string6.hashCode() : 0;
        int n12 = 31 * (n10 + n11);
        String string7 = this.payWithApp;
        int n13 = string7 != null ? string7.hashCode() : 0;
        int n14 = 31 * (n12 + n13);
        String string8 = this.cardNumber;
        int n15 = string8 != null ? string8.hashCode() : 0;
        int n16 = 31 * (n14 + n15);
        String string9 = this.cardExpMonth;
        int n17 = string9 != null ? string9.hashCode() : 0;
        int n18 = 31 * (n16 + n17);
        String string10 = this.cardExpYear;
        int n19 = string10 != null ? string10.hashCode() : 0;
        int n20 = 31 * (n18 + n19);
        String string11 = this.cardSecurityCode;
        int n21 = string11 != null ? string11.hashCode() : 0;
        int n22 = 31 * (n20 + n21);
        String string12 = this.cardBin;
        int n23 = string12 != null ? string12.hashCode() : 0;
        int n24 = 31 * (n22 + n23);
        String string13 = this.emiBank;
        int n25 = string13 != null ? string13.hashCode() : 0;
        int n26 = 31 * (n24 + n25);
        String string14 = this.cardToken;
        int n27 = string14 != null ? string14.hashCode() : 0;
        int n28 = 31 * (n26 + n27);
        String string15 = this.nameOnCard;
        int n29 = string15 != null ? string15.hashCode() : 0;
        int n30 = 31 * (n28 + n29);
        String string16 = this.emiType;
        int n31 = string16 != null ? string16.hashCode() : 0;
        int n32 = 31 * (n30 + n31);
        Integer n33 = this.emiTenure;
        int n34 = n33 != null ? n33.hashCode() : 0;
        int n35 = 31 * (n32 + n34);
        String string17 = this.directWalletToken;
        int n36 = string17 != null ? string17.hashCode() : 0;
        int n37 = 31 * (n35 + n36);
        String string18 = this.sdkPresent;
        int n38 = string18 != null ? string18.hashCode() : 0;
        int n39 = 31 * (n37 + n38);
        Boolean bl = this.saveToLocker;
        int n40 = bl != null ? bl.hashCode() : 0;
        int n41 = 31 * (n39 + n40);
        Boolean bl2 = this.showLoader;
        int n42 = bl2 != null ? bl2.hashCode() : 0;
        int n43 = 31 * (n41 + n42);
        Boolean bl3 = this.upiSdkPresent;
        int n44 = bl3 != null ? bl3.hashCode() : 0;
        int n45 = 31 * (n43 + n44);
        Boolean bl4 = this.isEmi;
        int n46 = bl4 != null ? bl4.hashCode() : 0;
        int n47 = 31 * (n45 + n46);
        ArrayList<Object> arrayList = this.endUrls;
        int n48 = arrayList != null ? arrayList.hashCode() : 0;
        int n49 = 31 * (n47 + n48);
        ArrayList<Object> arrayList2 = this.allowedMethods;
        int n50 = arrayList2 != null ? arrayList2.hashCode() : 0;
        int n51 = 31 * (n49 + n50);
        String string19 = this.application;
        int n52 = string19 != null ? string19.hashCode() : 0;
        int n53 = 31 * (n51 + n52);
        String string20 = this.walletName;
        int n54 = string20 != null ? string20.hashCode() : 0;
        int n55 = 31 * (n53 + n54);
        String string21 = this.walletId;
        int n56 = string21 != null ? string21.hashCode() : 0;
        int n57 = 31 * (n55 + n56);
        String string22 = this.paymentMethodType;
        int n58 = string22 != null ? string22.hashCode() : 0;
        int n59 = 31 * (n57 + n58);
        String string23 = this.redirectUrl;
        int n60 = string23 != null ? string23.hashCode() : 0;
        int n61 = 31 * (n59 + n60);
        String string24 = this.authType;
        int n62 = string24 != null ? string24.hashCode() : 0;
        int n63 = 31 * (n61 + n62);
        String string25 = this.amount;
        int n64 = 0;
        if (string25 != null) {
            n64 = string25.hashCode();
        }
        return n63 + n64;
    }

    public final Boolean isEmi() {
        return this.isEmi;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("PaymentProcessPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", orderId=");
        stringBuilder.append(this.orderId);
        stringBuilder.append(", custVpa=");
        stringBuilder.append(this.custVpa);
        stringBuilder.append(", displayNote=");
        stringBuilder.append(this.displayNote);
        stringBuilder.append(", clientAuthToken=");
        stringBuilder.append(this.clientAuthToken);
        stringBuilder.append(", paymentMethod=");
        stringBuilder.append(this.paymentMethod);
        stringBuilder.append(", payWithApp=");
        stringBuilder.append(this.payWithApp);
        stringBuilder.append(", cardNumber=");
        stringBuilder.append(this.cardNumber);
        stringBuilder.append(", cardExpMonth=");
        stringBuilder.append(this.cardExpMonth);
        stringBuilder.append(", cardExpYear=");
        stringBuilder.append(this.cardExpYear);
        stringBuilder.append(", cardSecurityCode=");
        stringBuilder.append(this.cardSecurityCode);
        stringBuilder.append(", cardBin=");
        stringBuilder.append(this.cardBin);
        stringBuilder.append(", emiBank=");
        stringBuilder.append(this.emiBank);
        stringBuilder.append(", cardToken=");
        stringBuilder.append(this.cardToken);
        stringBuilder.append(", nameOnCard=");
        stringBuilder.append(this.nameOnCard);
        stringBuilder.append(", emiType=");
        stringBuilder.append(this.emiType);
        stringBuilder.append(", emiTenure=");
        stringBuilder.append((Object)this.emiTenure);
        stringBuilder.append(", directWalletToken=");
        stringBuilder.append(this.directWalletToken);
        stringBuilder.append(", sdkPresent=");
        stringBuilder.append(this.sdkPresent);
        stringBuilder.append(", saveToLocker=");
        stringBuilder.append((Object)this.saveToLocker);
        stringBuilder.append(", showLoader=");
        stringBuilder.append((Object)this.showLoader);
        stringBuilder.append(", upiSdkPresent=");
        stringBuilder.append((Object)this.upiSdkPresent);
        stringBuilder.append(", isEmi=");
        stringBuilder.append((Object)this.isEmi);
        stringBuilder.append(", endUrls=");
        stringBuilder.append(this.endUrls);
        stringBuilder.append(", allowedMethods=");
        stringBuilder.append(this.allowedMethods);
        stringBuilder.append(", application=");
        stringBuilder.append(this.application);
        stringBuilder.append(", walletName=");
        stringBuilder.append(this.walletName);
        stringBuilder.append(", walletId=");
        stringBuilder.append(this.walletId);
        stringBuilder.append(", paymentMethodType=");
        stringBuilder.append(this.paymentMethodType);
        stringBuilder.append(", redirectUrl=");
        stringBuilder.append(this.redirectUrl);
        stringBuilder.append(", authType=");
        stringBuilder.append(this.authType);
        stringBuilder.append(", amount=");
        stringBuilder.append(this.amount);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

