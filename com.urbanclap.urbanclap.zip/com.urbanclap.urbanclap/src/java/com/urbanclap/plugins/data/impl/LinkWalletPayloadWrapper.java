/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.LinkWalletPayload;
import i2.a0.d.l;

@Keep
public final class LinkWalletPayloadWrapper {
    private final LinkWalletPayload payload;
    private final String requestId;
    private final String service;

    public LinkWalletPayloadWrapper(String string, String string2, LinkWalletPayload linkWalletPayload) {
        l.g((Object)linkWalletPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.payload = linkWalletPayload;
    }

    public static /* synthetic */ LinkWalletPayloadWrapper copy$default(LinkWalletPayloadWrapper linkWalletPayloadWrapper, String string, String string2, LinkWalletPayload linkWalletPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = linkWalletPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = linkWalletPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            linkWalletPayload = linkWalletPayloadWrapper.payload;
        }
        return linkWalletPayloadWrapper.copy(string, string2, linkWalletPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final LinkWalletPayload component3() {
        return this.payload;
    }

    public final LinkWalletPayloadWrapper copy(String string, String string2, LinkWalletPayload linkWalletPayload) {
        l.g((Object)linkWalletPayload, (String)"payload");
        return new LinkWalletPayloadWrapper(string, string2, linkWalletPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof LinkWalletPayloadWrapper)) break block3;
                LinkWalletPayloadWrapper linkWalletPayloadWrapper = (LinkWalletPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)linkWalletPayloadWrapper.requestId) && l.c((Object)this.service, (Object)linkWalletPayloadWrapper.service) && l.c((Object)this.payload, (Object)linkWalletPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final LinkWalletPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        LinkWalletPayload linkWalletPayload = this.payload;
        int n5 = 0;
        if (linkWalletPayload != null) {
            n5 = linkWalletPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("LinkWalletPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

