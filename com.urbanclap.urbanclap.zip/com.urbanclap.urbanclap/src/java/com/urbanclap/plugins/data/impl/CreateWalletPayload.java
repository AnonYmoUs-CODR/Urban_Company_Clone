/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class CreateWalletPayload {
    private final String action;
    private final String clientAuthToken;
    private final String walletName;

    public CreateWalletPayload(String string, String string2, String string3) {
        this.action = string;
        this.walletName = string2;
        this.clientAuthToken = string3;
    }

    public static /* synthetic */ CreateWalletPayload copy$default(CreateWalletPayload createWalletPayload, String string, String string2, String string3, int n, Object object) {
        if ((n & 1) != 0) {
            string = createWalletPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = createWalletPayload.walletName;
        }
        if ((n & 4) != 0) {
            string3 = createWalletPayload.clientAuthToken;
        }
        return createWalletPayload.copy(string, string2, string3);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.walletName;
    }

    public final String component3() {
        return this.clientAuthToken;
    }

    public final CreateWalletPayload copy(String string, String string2, String string3) {
        return new CreateWalletPayload(string, string2, string3);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CreateWalletPayload)) break block3;
                CreateWalletPayload createWalletPayload = (CreateWalletPayload)object;
                if (l.c((Object)this.action, (Object)createWalletPayload.action) && l.c((Object)this.walletName, (Object)createWalletPayload.walletName) && l.c((Object)this.clientAuthToken, (Object)createWalletPayload.clientAuthToken)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getClientAuthToken() {
        return this.clientAuthToken;
    }

    public final String getWalletName() {
        return this.walletName;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.walletName;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.clientAuthToken;
        int n5 = 0;
        if (string3 != null) {
            n5 = string3.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CreateWalletPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", walletName=");
        stringBuilder.append(this.walletName);
        stringBuilder.append(", clientAuthToken=");
        stringBuilder.append(this.clientAuthToken);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

