/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class GetWalletPayload {
    private final String action;
    private final String clientAuthToken;
    private final String walletId;
    private final String walletName;

    public GetWalletPayload(String string, String string2, String string3, String string4) {
        this.action = string;
        this.walletName = string2;
        this.clientAuthToken = string3;
        this.walletId = string4;
    }

    public static /* synthetic */ GetWalletPayload copy$default(GetWalletPayload getWalletPayload, String string, String string2, String string3, String string4, int n, Object object) {
        if ((n & 1) != 0) {
            string = getWalletPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = getWalletPayload.walletName;
        }
        if ((n & 4) != 0) {
            string3 = getWalletPayload.clientAuthToken;
        }
        if ((n & 8) != 0) {
            string4 = getWalletPayload.walletId;
        }
        return getWalletPayload.copy(string, string2, string3, string4);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.walletName;
    }

    public final String component3() {
        return this.clientAuthToken;
    }

    public final String component4() {
        return this.walletId;
    }

    public final GetWalletPayload copy(String string, String string2, String string3, String string4) {
        return new GetWalletPayload(string, string2, string3, string4);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof GetWalletPayload)) break block3;
                GetWalletPayload getWalletPayload = (GetWalletPayload)object;
                if (l.c((Object)this.action, (Object)getWalletPayload.action) && l.c((Object)this.walletName, (Object)getWalletPayload.walletName) && l.c((Object)this.clientAuthToken, (Object)getWalletPayload.clientAuthToken) && l.c((Object)this.walletId, (Object)getWalletPayload.walletId)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getClientAuthToken() {
        return this.clientAuthToken;
    }

    public final String getWalletId() {
        return this.walletId;
    }

    public final String getWalletName() {
        return this.walletName;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.walletName;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.clientAuthToken;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.walletId;
        int n7 = 0;
        if (string4 != null) {
            n7 = string4.hashCode();
        }
        return n6 + n7;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("GetWalletPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", walletName=");
        stringBuilder.append(this.walletName);
        stringBuilder.append(", clientAuthToken=");
        stringBuilder.append(this.clientAuthToken);
        stringBuilder.append(", walletId=");
        stringBuilder.append(this.walletId);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

