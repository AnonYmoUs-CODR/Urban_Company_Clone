/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.CheckEligibilityData;
import i2.a0.d.l;

@Keep
public final class CheckEligibilityPayload {
    private final String action;
    private final String amount;
    private final String clientAuthToken;
    private final CheckEligibilityData data;

    public CheckEligibilityPayload(String string, String string2, String string3, CheckEligibilityData checkEligibilityData) {
        this.action = string;
        this.amount = string2;
        this.clientAuthToken = string3;
        this.data = checkEligibilityData;
    }

    public static /* synthetic */ CheckEligibilityPayload copy$default(CheckEligibilityPayload checkEligibilityPayload, String string, String string2, String string3, CheckEligibilityData checkEligibilityData, int n, Object object) {
        if ((n & 1) != 0) {
            string = checkEligibilityPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = checkEligibilityPayload.amount;
        }
        if ((n & 4) != 0) {
            string3 = checkEligibilityPayload.clientAuthToken;
        }
        if ((n & 8) != 0) {
            checkEligibilityData = checkEligibilityPayload.data;
        }
        return checkEligibilityPayload.copy(string, string2, string3, checkEligibilityData);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.amount;
    }

    public final String component3() {
        return this.clientAuthToken;
    }

    public final CheckEligibilityData component4() {
        return this.data;
    }

    public final CheckEligibilityPayload copy(String string, String string2, String string3, CheckEligibilityData checkEligibilityData) {
        return new CheckEligibilityPayload(string, string2, string3, checkEligibilityData);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityPayload)) break block3;
                CheckEligibilityPayload checkEligibilityPayload = (CheckEligibilityPayload)object;
                if (l.c((Object)this.action, (Object)checkEligibilityPayload.action) && l.c((Object)this.amount, (Object)checkEligibilityPayload.amount) && l.c((Object)this.clientAuthToken, (Object)checkEligibilityPayload.clientAuthToken) && l.c((Object)this.data, (Object)checkEligibilityPayload.data)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getAmount() {
        return this.amount;
    }

    public final String getClientAuthToken() {
        return this.clientAuthToken;
    }

    public final CheckEligibilityData getData() {
        return this.data;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.amount;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.clientAuthToken;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        CheckEligibilityData checkEligibilityData = this.data;
        int n7 = 0;
        if (checkEligibilityData != null) {
            n7 = checkEligibilityData.hashCode();
        }
        return n6 + n7;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", amount=");
        stringBuilder.append(this.amount);
        stringBuilder.append(", clientAuthToken=");
        stringBuilder.append(this.clientAuthToken);
        stringBuilder.append(", data=");
        stringBuilder.append((Object)this.data);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

