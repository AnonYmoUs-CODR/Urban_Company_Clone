/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.CheckEligibilityForInAppPaymentPayload;
import i2.a0.d.l;

@Keep
public final class CheckEligibilityForInAppPaymentPayloadWrapper {
    private final CheckEligibilityForInAppPaymentPayload payload;
    private final String requestId;
    private final String service;

    public CheckEligibilityForInAppPaymentPayloadWrapper(String string, String string2, CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload) {
        l.g((Object)checkEligibilityForInAppPaymentPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.payload = checkEligibilityForInAppPaymentPayload;
    }

    public static /* synthetic */ CheckEligibilityForInAppPaymentPayloadWrapper copy$default(CheckEligibilityForInAppPaymentPayloadWrapper checkEligibilityForInAppPaymentPayloadWrapper, String string, String string2, CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = checkEligibilityForInAppPaymentPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = checkEligibilityForInAppPaymentPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            checkEligibilityForInAppPaymentPayload = checkEligibilityForInAppPaymentPayloadWrapper.payload;
        }
        return checkEligibilityForInAppPaymentPayloadWrapper.copy(string, string2, checkEligibilityForInAppPaymentPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final CheckEligibilityForInAppPaymentPayload component3() {
        return this.payload;
    }

    public final CheckEligibilityForInAppPaymentPayloadWrapper copy(String string, String string2, CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload) {
        l.g((Object)checkEligibilityForInAppPaymentPayload, (String)"payload");
        return new CheckEligibilityForInAppPaymentPayloadWrapper(string, string2, checkEligibilityForInAppPaymentPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityForInAppPaymentPayloadWrapper)) break block3;
                CheckEligibilityForInAppPaymentPayloadWrapper checkEligibilityForInAppPaymentPayloadWrapper = (CheckEligibilityForInAppPaymentPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)checkEligibilityForInAppPaymentPayloadWrapper.requestId) && l.c((Object)this.service, (Object)checkEligibilityForInAppPaymentPayloadWrapper.service) && l.c((Object)this.payload, (Object)checkEligibilityForInAppPaymentPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final CheckEligibilityForInAppPaymentPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload = this.payload;
        int n5 = 0;
        if (checkEligibilityForInAppPaymentPayload != null) {
            n5 = checkEligibilityForInAppPaymentPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityForInAppPaymentPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

