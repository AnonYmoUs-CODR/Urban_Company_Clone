/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.InitiateSDKPayload;
import i2.a0.d.l;

@Keep
public final class InitiateSDKPayloadWrapper {
    private final InitiateSDKPayload payload;
    private final String requestId;
    private final String service;

    public InitiateSDKPayloadWrapper(String string, String string2, InitiateSDKPayload initiateSDKPayload) {
        l.g((Object)initiateSDKPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.payload = initiateSDKPayload;
    }

    public static /* synthetic */ InitiateSDKPayloadWrapper copy$default(InitiateSDKPayloadWrapper initiateSDKPayloadWrapper, String string, String string2, InitiateSDKPayload initiateSDKPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = initiateSDKPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = initiateSDKPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            initiateSDKPayload = initiateSDKPayloadWrapper.payload;
        }
        return initiateSDKPayloadWrapper.copy(string, string2, initiateSDKPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final InitiateSDKPayload component3() {
        return this.payload;
    }

    public final InitiateSDKPayloadWrapper copy(String string, String string2, InitiateSDKPayload initiateSDKPayload) {
        l.g((Object)initiateSDKPayload, (String)"payload");
        return new InitiateSDKPayloadWrapper(string, string2, initiateSDKPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof InitiateSDKPayloadWrapper)) break block3;
                InitiateSDKPayloadWrapper initiateSDKPayloadWrapper = (InitiateSDKPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)initiateSDKPayloadWrapper.requestId) && l.c((Object)this.service, (Object)initiateSDKPayloadWrapper.service) && l.c((Object)this.payload, (Object)initiateSDKPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final InitiateSDKPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        InitiateSDKPayload initiateSDKPayload = this.payload;
        int n5 = 0;
        if (initiateSDKPayload != null) {
            n5 = initiateSDKPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("InitiateSDKPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

