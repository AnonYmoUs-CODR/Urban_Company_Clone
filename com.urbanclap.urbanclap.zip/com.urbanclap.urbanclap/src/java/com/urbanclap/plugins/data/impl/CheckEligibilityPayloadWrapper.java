/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.CheckEligibilityPayload;
import i2.a0.d.l;

@Keep
public final class CheckEligibilityPayloadWrapper {
    private final CheckEligibilityPayload payload;
    private final String requestId;
    private final String service;

    public CheckEligibilityPayloadWrapper(String string, String string2, CheckEligibilityPayload checkEligibilityPayload) {
        l.g((Object)checkEligibilityPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.payload = checkEligibilityPayload;
    }

    public static /* synthetic */ CheckEligibilityPayloadWrapper copy$default(CheckEligibilityPayloadWrapper checkEligibilityPayloadWrapper, String string, String string2, CheckEligibilityPayload checkEligibilityPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = checkEligibilityPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = checkEligibilityPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            checkEligibilityPayload = checkEligibilityPayloadWrapper.payload;
        }
        return checkEligibilityPayloadWrapper.copy(string, string2, checkEligibilityPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final CheckEligibilityPayload component3() {
        return this.payload;
    }

    public final CheckEligibilityPayloadWrapper copy(String string, String string2, CheckEligibilityPayload checkEligibilityPayload) {
        l.g((Object)checkEligibilityPayload, (String)"payload");
        return new CheckEligibilityPayloadWrapper(string, string2, checkEligibilityPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityPayloadWrapper)) break block3;
                CheckEligibilityPayloadWrapper checkEligibilityPayloadWrapper = (CheckEligibilityPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)checkEligibilityPayloadWrapper.requestId) && l.c((Object)this.service, (Object)checkEligibilityPayloadWrapper.service) && l.c((Object)this.payload, (Object)checkEligibilityPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final CheckEligibilityPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        CheckEligibilityPayload checkEligibilityPayload = this.payload;
        int n5 = 0;
        if (checkEligibilityPayload != null) {
            n5 = checkEligibilityPayload.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

