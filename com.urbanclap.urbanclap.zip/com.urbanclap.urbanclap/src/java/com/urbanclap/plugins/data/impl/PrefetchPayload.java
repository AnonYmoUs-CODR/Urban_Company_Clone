/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class PrefetchPayload {
    private final String clientId;

    public PrefetchPayload(String string) {
        this.clientId = string;
    }

    public static /* synthetic */ PrefetchPayload copy$default(PrefetchPayload prefetchPayload, String string, int n, Object object) {
        if ((n & 1) != 0) {
            string = prefetchPayload.clientId;
        }
        return prefetchPayload.copy(string);
    }

    public final String component1() {
        return this.clientId;
    }

    public final PrefetchPayload copy(String string) {
        return new PrefetchPayload(string);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof PrefetchPayload)) break block3;
                PrefetchPayload prefetchPayload = (PrefetchPayload)object;
                if (l.c((Object)this.clientId, (Object)prefetchPayload.clientId)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getClientId() {
        return this.clientId;
    }

    public final int hashCode() {
        String string = this.clientId;
        if (string != null) {
            return string.hashCode();
        }
        return 0;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("PrefetchPayload(clientId=");
        stringBuilder.append(this.clientId);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

