/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class LinkWalletPayload {
    private final String action;
    private final String clientAuthToken;
    private final String otp;
    private final String walletId;
    private final String walletName;

    public LinkWalletPayload(String string, String string2, String string3, String string4, String string5) {
        this.action = string;
        this.walletName = string2;
        this.clientAuthToken = string3;
        this.otp = string4;
        this.walletId = string5;
    }

    public static /* synthetic */ LinkWalletPayload copy$default(LinkWalletPayload linkWalletPayload, String string, String string2, String string3, String string4, String string5, int n, Object object) {
        if ((n & 1) != 0) {
            string = linkWalletPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = linkWalletPayload.walletName;
        }
        String string6 = string2;
        if ((n & 4) != 0) {
            string3 = linkWalletPayload.clientAuthToken;
        }
        String string7 = string3;
        if ((n & 8) != 0) {
            string4 = linkWalletPayload.otp;
        }
        String string8 = string4;
        if ((n & 16) != 0) {
            string5 = linkWalletPayload.walletId;
        }
        String string9 = string5;
        return linkWalletPayload.copy(string, string6, string7, string8, string9);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.walletName;
    }

    public final String component3() {
        return this.clientAuthToken;
    }

    public final String component4() {
        return this.otp;
    }

    public final String component5() {
        return this.walletId;
    }

    public final LinkWalletPayload copy(String string, String string2, String string3, String string4, String string5) {
        LinkWalletPayload linkWalletPayload = new LinkWalletPayload(string, string2, string3, string4, string5);
        return linkWalletPayload;
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof LinkWalletPayload)) break block3;
                LinkWalletPayload linkWalletPayload = (LinkWalletPayload)object;
                if (l.c((Object)this.action, (Object)linkWalletPayload.action) && l.c((Object)this.walletName, (Object)linkWalletPayload.walletName) && l.c((Object)this.clientAuthToken, (Object)linkWalletPayload.clientAuthToken) && l.c((Object)this.otp, (Object)linkWalletPayload.otp) && l.c((Object)this.walletId, (Object)linkWalletPayload.walletId)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getClientAuthToken() {
        return this.clientAuthToken;
    }

    public final String getOtp() {
        return this.otp;
    }

    public final String getWalletId() {
        return this.walletId;
    }

    public final String getWalletName() {
        return this.walletName;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.walletName;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.clientAuthToken;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.otp;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string5 = this.walletId;
        int n9 = 0;
        if (string5 != null) {
            n9 = string5.hashCode();
        }
        return n8 + n9;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("LinkWalletPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", walletName=");
        stringBuilder.append(this.walletName);
        stringBuilder.append(", clientAuthToken=");
        stringBuilder.append(this.clientAuthToken);
        stringBuilder.append(", otp=");
        stringBuilder.append(this.otp);
        stringBuilder.append(", walletId=");
        stringBuilder.append(this.walletId);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

