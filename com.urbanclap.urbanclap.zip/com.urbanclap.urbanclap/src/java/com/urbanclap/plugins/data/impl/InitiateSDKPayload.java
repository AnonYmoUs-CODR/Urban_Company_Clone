/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class InitiateSDKPayload {
    private final String action;
    private final String clientId;
    private final String customerId;
    private final Boolean eligibilityInInitiate;
    private final String environment;
    private final String merchantId;

    public InitiateSDKPayload(String string, String string2, String string3, String string4, String string5, Boolean bl) {
        this.action = string;
        this.merchantId = string2;
        this.clientId = string3;
        this.customerId = string4;
        this.environment = string5;
        this.eligibilityInInitiate = bl;
    }

    public static /* synthetic */ InitiateSDKPayload copy$default(InitiateSDKPayload initiateSDKPayload, String string, String string2, String string3, String string4, String string5, Boolean bl, int n, Object object) {
        if ((n & 1) != 0) {
            string = initiateSDKPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = initiateSDKPayload.merchantId;
        }
        String string6 = string2;
        if ((n & 4) != 0) {
            string3 = initiateSDKPayload.clientId;
        }
        String string7 = string3;
        if ((n & 8) != 0) {
            string4 = initiateSDKPayload.customerId;
        }
        String string8 = string4;
        if ((n & 16) != 0) {
            string5 = initiateSDKPayload.environment;
        }
        String string9 = string5;
        if ((n & 32) != 0) {
            bl = initiateSDKPayload.eligibilityInInitiate;
        }
        Boolean bl2 = bl;
        return initiateSDKPayload.copy(string, string6, string7, string8, string9, bl2);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.merchantId;
    }

    public final String component3() {
        return this.clientId;
    }

    public final String component4() {
        return this.customerId;
    }

    public final String component5() {
        return this.environment;
    }

    public final Boolean component6() {
        return this.eligibilityInInitiate;
    }

    public final InitiateSDKPayload copy(String string, String string2, String string3, String string4, String string5, Boolean bl) {
        InitiateSDKPayload initiateSDKPayload = new InitiateSDKPayload(string, string2, string3, string4, string5, bl);
        return initiateSDKPayload;
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof InitiateSDKPayload)) break block3;
                InitiateSDKPayload initiateSDKPayload = (InitiateSDKPayload)object;
                if (l.c((Object)this.action, (Object)initiateSDKPayload.action) && l.c((Object)this.merchantId, (Object)initiateSDKPayload.merchantId) && l.c((Object)this.clientId, (Object)initiateSDKPayload.clientId) && l.c((Object)this.customerId, (Object)initiateSDKPayload.customerId) && l.c((Object)this.environment, (Object)initiateSDKPayload.environment) && l.c((Object)this.eligibilityInInitiate, (Object)initiateSDKPayload.eligibilityInInitiate)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getClientId() {
        return this.clientId;
    }

    public final String getCustomerId() {
        return this.customerId;
    }

    public final Boolean getEligibilityInInitiate() {
        return this.eligibilityInInitiate;
    }

    public final String getEnvironment() {
        return this.environment;
    }

    public final String getMerchantId() {
        return this.merchantId;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.merchantId;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string3 = this.clientId;
        int n5 = string3 != null ? string3.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        String string4 = this.customerId;
        int n7 = string4 != null ? string4.hashCode() : 0;
        int n8 = 31 * (n6 + n7);
        String string5 = this.environment;
        int n9 = string5 != null ? string5.hashCode() : 0;
        int n10 = 31 * (n8 + n9);
        Boolean bl = this.eligibilityInInitiate;
        int n11 = 0;
        if (bl != null) {
            n11 = bl.hashCode();
        }
        return n10 + n11;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("InitiateSDKPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", merchantId=");
        stringBuilder.append(this.merchantId);
        stringBuilder.append(", clientId=");
        stringBuilder.append(this.clientId);
        stringBuilder.append(", customerId=");
        stringBuilder.append(this.customerId);
        stringBuilder.append(", environment=");
        stringBuilder.append(this.environment);
        stringBuilder.append(", eligibilityInInitiate=");
        stringBuilder.append((Object)this.eligibilityInInitiate);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

