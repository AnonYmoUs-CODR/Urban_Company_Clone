/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.InitiateSDKPayload;
import com.urbanclap.plugins.data.impl.PaymentProcessPayload;
import i2.a0.d.g;
import i2.a0.d.l;

@Keep
public final class ProcessPaymentPayloadWrapper {
    private final InitiateSDKPayload initPayload;
    private final PaymentProcessPayload payload;
    private final String requestId;
    private final String service;

    public ProcessPaymentPayloadWrapper(String string, String string2, InitiateSDKPayload initiateSDKPayload, PaymentProcessPayload paymentProcessPayload) {
        l.g((Object)paymentProcessPayload, (String)"payload");
        this.requestId = string;
        this.service = string2;
        this.initPayload = initiateSDKPayload;
        this.payload = paymentProcessPayload;
    }

    public /* synthetic */ ProcessPaymentPayloadWrapper(String string, String string2, InitiateSDKPayload initiateSDKPayload, PaymentProcessPayload paymentProcessPayload, int n, g g2) {
        if ((n & 4) != 0) {
            initiateSDKPayload = null;
        }
        this(string, string2, initiateSDKPayload, paymentProcessPayload);
    }

    public static /* synthetic */ ProcessPaymentPayloadWrapper copy$default(ProcessPaymentPayloadWrapper processPaymentPayloadWrapper, String string, String string2, InitiateSDKPayload initiateSDKPayload, PaymentProcessPayload paymentProcessPayload, int n, Object object) {
        if ((n & 1) != 0) {
            string = processPaymentPayloadWrapper.requestId;
        }
        if ((n & 2) != 0) {
            string2 = processPaymentPayloadWrapper.service;
        }
        if ((n & 4) != 0) {
            initiateSDKPayload = processPaymentPayloadWrapper.initPayload;
        }
        if ((n & 8) != 0) {
            paymentProcessPayload = processPaymentPayloadWrapper.payload;
        }
        return processPaymentPayloadWrapper.copy(string, string2, initiateSDKPayload, paymentProcessPayload);
    }

    public final String component1() {
        return this.requestId;
    }

    public final String component2() {
        return this.service;
    }

    public final InitiateSDKPayload component3() {
        return this.initPayload;
    }

    public final PaymentProcessPayload component4() {
        return this.payload;
    }

    public final ProcessPaymentPayloadWrapper copy(String string, String string2, InitiateSDKPayload initiateSDKPayload, PaymentProcessPayload paymentProcessPayload) {
        l.g((Object)paymentProcessPayload, (String)"payload");
        return new ProcessPaymentPayloadWrapper(string, string2, initiateSDKPayload, paymentProcessPayload);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ProcessPaymentPayloadWrapper)) break block3;
                ProcessPaymentPayloadWrapper processPaymentPayloadWrapper = (ProcessPaymentPayloadWrapper)object;
                if (l.c((Object)this.requestId, (Object)processPaymentPayloadWrapper.requestId) && l.c((Object)this.service, (Object)processPaymentPayloadWrapper.service) && l.c((Object)this.initPayload, (Object)processPaymentPayloadWrapper.initPayload) && l.c((Object)this.payload, (Object)processPaymentPayloadWrapper.payload)) break block2;
            }
            return false;
        }
        return true;
    }

    public final InitiateSDKPayload getInitPayload() {
        return this.initPayload;
    }

    public final PaymentProcessPayload getPayload() {
        return this.payload;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getService() {
        return this.service;
    }

    public final int hashCode() {
        String string = this.requestId;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.service;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        InitiateSDKPayload initiateSDKPayload = this.initPayload;
        int n5 = initiateSDKPayload != null ? initiateSDKPayload.hashCode() : 0;
        int n6 = 31 * (n4 + n5);
        PaymentProcessPayload paymentProcessPayload = this.payload;
        int n7 = 0;
        if (paymentProcessPayload != null) {
            n7 = paymentProcessPayload.hashCode();
        }
        return n6 + n7;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("ProcessPaymentPayloadWrapper(requestId=");
        stringBuilder.append(this.requestId);
        stringBuilder.append(", service=");
        stringBuilder.append(this.service);
        stringBuilder.append(", initPayload=");
        stringBuilder.append((Object)this.initPayload);
        stringBuilder.append(", payload=");
        stringBuilder.append((Object)this.payload);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

