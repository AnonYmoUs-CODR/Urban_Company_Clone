/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.l;

@Keep
public final class CheckEligibilityForInAppPaymentPayload {
    private final String action;
    private final String sdkPresent;

    public CheckEligibilityForInAppPaymentPayload(String string, String string2) {
        this.action = string;
        this.sdkPresent = string2;
    }

    public static /* synthetic */ CheckEligibilityForInAppPaymentPayload copy$default(CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload, String string, String string2, int n, Object object) {
        if ((n & 1) != 0) {
            string = checkEligibilityForInAppPaymentPayload.action;
        }
        if ((n & 2) != 0) {
            string2 = checkEligibilityForInAppPaymentPayload.sdkPresent;
        }
        return checkEligibilityForInAppPaymentPayload.copy(string, string2);
    }

    public final String component1() {
        return this.action;
    }

    public final String component2() {
        return this.sdkPresent;
    }

    public final CheckEligibilityForInAppPaymentPayload copy(String string, String string2) {
        return new CheckEligibilityForInAppPaymentPayload(string, string2);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityForInAppPaymentPayload)) break block3;
                CheckEligibilityForInAppPaymentPayload checkEligibilityForInAppPaymentPayload = (CheckEligibilityForInAppPaymentPayload)object;
                if (l.c((Object)this.action, (Object)checkEligibilityForInAppPaymentPayload.action) && l.c((Object)this.sdkPresent, (Object)checkEligibilityForInAppPaymentPayload.sdkPresent)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getAction() {
        return this.action;
    }

    public final String getSdkPresent() {
        return this.sdkPresent;
    }

    public final int hashCode() {
        String string = this.action;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.sdkPresent;
        int n3 = 0;
        if (string2 != null) {
            n3 = string2.hashCode();
        }
        return n2 + n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityForInAppPaymentPayload(action=");
        stringBuilder.append(this.action);
        stringBuilder.append(", sdkPresent=");
        stringBuilder.append(this.sdkPresent);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

