/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;

@Keep
public final class CheckEligibilityApps {
    private final ArrayList<String> checkType;
    private final String mobile;

    public CheckEligibilityApps(ArrayList<String> arrayList, String string) {
        this.checkType = arrayList;
        this.mobile = string;
    }

    public /* synthetic */ CheckEligibilityApps(ArrayList arrayList, String string, int n, g g2) {
        if ((n & 1) != 0) {
            arrayList = null;
        }
        this((ArrayList<String>)arrayList, string);
    }

    public static /* synthetic */ CheckEligibilityApps copy$default(CheckEligibilityApps checkEligibilityApps, ArrayList arrayList, String string, int n, Object object) {
        if ((n & 1) != 0) {
            arrayList = checkEligibilityApps.checkType;
        }
        if ((n & 2) != 0) {
            string = checkEligibilityApps.mobile;
        }
        return checkEligibilityApps.copy(arrayList, string);
    }

    public final ArrayList<String> component1() {
        return this.checkType;
    }

    public final String component2() {
        return this.mobile;
    }

    public final CheckEligibilityApps copy(ArrayList<String> arrayList, String string) {
        return new CheckEligibilityApps(arrayList, string);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityApps)) break block3;
                CheckEligibilityApps checkEligibilityApps = (CheckEligibilityApps)object;
                if (l.c(this.checkType, checkEligibilityApps.checkType) && l.c((Object)this.mobile, (Object)checkEligibilityApps.mobile)) break block2;
            }
            return false;
        }
        return true;
    }

    public final ArrayList<String> getCheckType() {
        return this.checkType;
    }

    public final String getMobile() {
        return this.mobile;
    }

    public final int hashCode() {
        ArrayList<String> arrayList = this.checkType;
        int n = arrayList != null ? arrayList.hashCode() : 0;
        int n2 = n * 31;
        String string = this.mobile;
        int n3 = 0;
        if (string != null) {
            n3 = string.hashCode();
        }
        return n2 + n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityApps(checkType=");
        stringBuilder.append(this.checkType);
        stringBuilder.append(", mobile=");
        stringBuilder.append(this.mobile);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

