/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;

@Keep
public final class CheckEligibilityCards {
    private final String cardAlias;
    private final String cardBin;
    private final ArrayList<String> checkType;

    public CheckEligibilityCards(ArrayList<String> arrayList, String string, String string2) {
        this.checkType = arrayList;
        this.cardAlias = string;
        this.cardBin = string2;
    }

    public /* synthetic */ CheckEligibilityCards(ArrayList arrayList, String string, String string2, int n, g g2) {
        if ((n & 1) != 0) {
            arrayList = null;
        }
        this((ArrayList<String>)arrayList, string, string2);
    }

    public static /* synthetic */ CheckEligibilityCards copy$default(CheckEligibilityCards checkEligibilityCards, ArrayList arrayList, String string, String string2, int n, Object object) {
        if ((n & 1) != 0) {
            arrayList = checkEligibilityCards.checkType;
        }
        if ((n & 2) != 0) {
            string = checkEligibilityCards.cardAlias;
        }
        if ((n & 4) != 0) {
            string2 = checkEligibilityCards.cardBin;
        }
        return checkEligibilityCards.copy(arrayList, string, string2);
    }

    public final ArrayList<String> component1() {
        return this.checkType;
    }

    public final String component2() {
        return this.cardAlias;
    }

    public final String component3() {
        return this.cardBin;
    }

    public final CheckEligibilityCards copy(ArrayList<String> arrayList, String string, String string2) {
        return new CheckEligibilityCards(arrayList, string, string2);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityCards)) break block3;
                CheckEligibilityCards checkEligibilityCards = (CheckEligibilityCards)object;
                if (l.c(this.checkType, checkEligibilityCards.checkType) && l.c((Object)this.cardAlias, (Object)checkEligibilityCards.cardAlias) && l.c((Object)this.cardBin, (Object)checkEligibilityCards.cardBin)) break block2;
            }
            return false;
        }
        return true;
    }

    public final String getCardAlias() {
        return this.cardAlias;
    }

    public final String getCardBin() {
        return this.cardBin;
    }

    public final ArrayList<String> getCheckType() {
        return this.checkType;
    }

    public final int hashCode() {
        ArrayList<String> arrayList = this.checkType;
        int n = arrayList != null ? arrayList.hashCode() : 0;
        int n2 = n * 31;
        String string = this.cardAlias;
        int n3 = string != null ? string.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        String string2 = this.cardBin;
        int n5 = 0;
        if (string2 != null) {
            n5 = string2.hashCode();
        }
        return n4 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityCards(checkType=");
        stringBuilder.append(this.checkType);
        stringBuilder.append(", cardAlias=");
        stringBuilder.append(this.cardAlias);
        stringBuilder.append(", cardBin=");
        stringBuilder.append(this.cardBin);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

