/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.urbanclap.plugins.data.impl;

import androidx.annotation.Keep;
import com.urbanclap.plugins.data.impl.CheckEligibilityApps;
import com.urbanclap.plugins.data.impl.CheckEligibilityCards;
import i2.a0.d.g;
import i2.a0.d.l;
import java.util.ArrayList;

@Keep
public final class CheckEligibilityData {
    private final ArrayList<CheckEligibilityApps> apps;
    private final ArrayList<CheckEligibilityCards> cards;

    public CheckEligibilityData() {
        this(null, null, 3, null);
    }

    public CheckEligibilityData(ArrayList<CheckEligibilityApps> arrayList, ArrayList<CheckEligibilityCards> arrayList2) {
        this.apps = arrayList;
        this.cards = arrayList2;
    }

    public /* synthetic */ CheckEligibilityData(ArrayList arrayList, ArrayList arrayList2, int n, g g2) {
        if ((n & 1) != 0) {
            arrayList = null;
        }
        if ((n & 2) != 0) {
            arrayList2 = null;
        }
        this((ArrayList<CheckEligibilityApps>)arrayList, (ArrayList<CheckEligibilityCards>)arrayList2);
    }

    public static /* synthetic */ CheckEligibilityData copy$default(CheckEligibilityData checkEligibilityData, ArrayList arrayList, ArrayList arrayList2, int n, Object object) {
        if ((n & 1) != 0) {
            arrayList = checkEligibilityData.apps;
        }
        if ((n & 2) != 0) {
            arrayList2 = checkEligibilityData.cards;
        }
        return checkEligibilityData.copy(arrayList, arrayList2);
    }

    public final ArrayList<CheckEligibilityApps> component1() {
        return this.apps;
    }

    public final ArrayList<CheckEligibilityCards> component2() {
        return this.cards;
    }

    public final CheckEligibilityData copy(ArrayList<CheckEligibilityApps> arrayList, ArrayList<CheckEligibilityCards> arrayList2) {
        return new CheckEligibilityData(arrayList, arrayList2);
    }

    public final boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof CheckEligibilityData)) break block3;
                CheckEligibilityData checkEligibilityData = (CheckEligibilityData)object;
                if (l.c(this.apps, checkEligibilityData.apps) && l.c(this.cards, checkEligibilityData.cards)) break block2;
            }
            return false;
        }
        return true;
    }

    public final ArrayList<CheckEligibilityApps> getApps() {
        return this.apps;
    }

    public final ArrayList<CheckEligibilityCards> getCards() {
        return this.cards;
    }

    public final int hashCode() {
        ArrayList<CheckEligibilityApps> arrayList = this.apps;
        int n = arrayList != null ? arrayList.hashCode() : 0;
        int n2 = n * 31;
        ArrayList<CheckEligibilityCards> arrayList2 = this.cards;
        int n3 = 0;
        if (arrayList2 != null) {
            n3 = arrayList2.hashCode();
        }
        return n2 + n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CheckEligibilityData(apps=");
        stringBuilder.append(this.apps);
        stringBuilder.append(", cards=");
        stringBuilder.append(this.cards);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

