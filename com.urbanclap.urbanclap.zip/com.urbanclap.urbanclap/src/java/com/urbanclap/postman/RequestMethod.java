/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.postman.RequestMethod$GET
 *  com.urbanclap.postman.RequestMethod$POST
 *  com.urbanclap.postman.RequestMethod$PUT
 *  i2.a0.d.g
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postman;

import com.urbanclap.postman.RequestMethod;
import i2.a0.d.g;

/*
 * Exception performing whole class analysis.
 */
public abstract class RequestMethod
extends Enum<RequestMethod> {
    private static final /* synthetic */ RequestMethod[] $VALUES;
    public static final /* enum */ RequestMethod GET;
    public static final /* enum */ RequestMethod POST;
    public static final /* enum */ RequestMethod PUT;

    public static {
        RequestMethod[] arrrequestMethod = new RequestMethod[3];
        GET gET = new /* Unavailable Anonymous Inner Class!! */;
        GET = gET;
        arrrequestMethod[0] = gET;
        PUT pUT = new /* Unavailable Anonymous Inner Class!! */;
        PUT = pUT;
        arrrequestMethod[1] = pUT;
        POST pOST = new /* Unavailable Anonymous Inner Class!! */;
        POST = pOST;
        arrrequestMethod[2] = pOST;
        $VALUES = arrrequestMethod;
    }

    private RequestMethod() {
    }

    public /* synthetic */ RequestMethod(String string, int n, g g2) {
        this();
    }

    public static RequestMethod valueOf(String string) {
        return (RequestMethod)Enum.valueOf(RequestMethod.class, (String)string);
    }

    public static RequestMethod[] values() {
        return (RequestMethod[])$VALUES.clone();
    }

    public abstract int getVolleyRequestMethod();
}

