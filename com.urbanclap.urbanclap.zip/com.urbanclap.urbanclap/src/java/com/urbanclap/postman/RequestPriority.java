/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.postman.RequestPriority$HIGH
 *  com.urbanclap.postman.RequestPriority$IMMEDIATE
 *  com.urbanclap.postman.RequestPriority$LOW
 *  com.urbanclap.postman.RequestPriority$NORMAL
 *  i2.a0.d.g
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postman;

import com.urbanclap.postman.RequestPriority;
import i2.a0.d.g;

/*
 * Exception performing whole class analysis.
 */
public abstract class RequestPriority
extends Enum<RequestPriority> {
    private static final /* synthetic */ RequestPriority[] $VALUES;
    public static final /* enum */ RequestPriority HIGH;
    public static final /* enum */ RequestPriority IMMEDIATE;
    public static final /* enum */ RequestPriority LOW;
    public static final /* enum */ RequestPriority NORMAL;

    public static {
        RequestPriority[] arrrequestPriority = new RequestPriority[4];
        LOW lOW = new /* Unavailable Anonymous Inner Class!! */;
        LOW = lOW;
        arrrequestPriority[0] = lOW;
        NORMAL nORMAL = new /* Unavailable Anonymous Inner Class!! */;
        NORMAL = nORMAL;
        arrrequestPriority[1] = nORMAL;
        HIGH hIGH = new /* Unavailable Anonymous Inner Class!! */;
        HIGH = hIGH;
        arrrequestPriority[2] = hIGH;
        IMMEDIATE iMMEDIATE = new /* Unavailable Anonymous Inner Class!! */;
        IMMEDIATE = iMMEDIATE;
        arrrequestPriority[3] = iMMEDIATE;
        $VALUES = arrrequestPriority;
    }

    private RequestPriority() {
    }

    public /* synthetic */ RequestPriority(String string, int n, g g2) {
        this();
    }

    public static RequestPriority valueOf(String string) {
        return (RequestPriority)Enum.valueOf(RequestPriority.class, (String)string);
    }

    public static RequestPriority[] values() {
        return (RequestPriority[])$VALUES.clone();
    }

    public abstract int getVolleyPriority();
}

