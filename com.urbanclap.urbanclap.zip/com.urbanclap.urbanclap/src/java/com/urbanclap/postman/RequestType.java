/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.postman;

public final class RequestType
extends Enum<RequestType> {
    private static final /* synthetic */ RequestType[] $VALUES;
    public static final /* enum */ RequestType ASYNCHRONOUS;
    public static final /* enum */ RequestType MULTI_PART;
    public static final /* enum */ RequestType SYNCHRONOUS;

    public static {
        RequestType requestType;
        RequestType requestType2;
        RequestType requestType3;
        RequestType[] arrrequestType = new RequestType[3];
        SYNCHRONOUS = requestType2 = new RequestType();
        arrrequestType[0] = requestType2;
        ASYNCHRONOUS = requestType = new RequestType();
        arrrequestType[1] = requestType;
        MULTI_PART = requestType3 = new RequestType();
        arrrequestType[2] = requestType3;
        $VALUES = arrrequestType;
    }

    public static RequestType valueOf(String string) {
        return (RequestType)Enum.valueOf(RequestType.class, (String)string);
    }

    public static RequestType[] values() {
        return (RequestType[])$VALUES.clone();
    }
}

