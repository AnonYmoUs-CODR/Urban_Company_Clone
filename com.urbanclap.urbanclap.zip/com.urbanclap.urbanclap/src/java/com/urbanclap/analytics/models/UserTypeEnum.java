/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.analytics.models;

public final class UserTypeEnum
extends Enum<UserTypeEnum> {
    private static final /* synthetic */ UserTypeEnum[] $VALUES;
    public static final /* enum */ UserTypeEnum UserTypeCustomer;
    public static final /* enum */ UserTypeEnum UserTypeProvider;
    private String userType;

    public static {
        UserTypeEnum userTypeEnum;
        UserTypeEnum userTypeEnum2;
        UserTypeProvider = userTypeEnum = new UserTypeEnum("provider");
        UserTypeCustomer = userTypeEnum2 = new UserTypeEnum("customer");
        $VALUES = new UserTypeEnum[]{userTypeEnum, userTypeEnum2};
    }

    private UserTypeEnum(String string2) {
        this.userType = string2;
    }

    public static UserTypeEnum valueOf(String string) {
        return (UserTypeEnum)Enum.valueOf(UserTypeEnum.class, (String)string);
    }

    public static UserTypeEnum[] values() {
        return (UserTypeEnum[])$VALUES.clone();
    }

    public String toString() {
        return this.userType;
    }
}

