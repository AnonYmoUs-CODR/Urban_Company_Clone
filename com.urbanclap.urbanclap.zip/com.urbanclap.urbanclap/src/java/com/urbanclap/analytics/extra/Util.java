/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.util.Log
 *  com.urbanclap.analytics.extra.Util$CONNECTION_TYPE
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.analytics.extra;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import com.urbanclap.analytics.extra.Util;

public class Util {
    public static SharedPreferences a;

    public static long a(Context context) {
        long l = Util.c(context).getLong("CLIENT_OFFSET", 0L);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Getting Client Offset as ");
        stringBuilder.append(l);
        Log.d((String)"ANALYTICS_UC", (String)stringBuilder.toString());
        return l;
    }

    public static CONNECTION_TYPE b(Context context) {
        NetworkInfo networkInfo = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            if (networkInfo.getType() == 1) {
                return CONNECTION_TYPE.WIFI;
            }
            if (networkInfo.getType() == 0) {
                switch (networkInfo.getSubtype()) {
                    default: {
                        return CONNECTION_TYPE.UNKNOWN;
                    }
                    case 13: {
                        return CONNECTION_TYPE.GGGG;
                    }
                    case 3: 
                    case 5: 
                    case 6: 
                    case 8: 
                    case 9: 
                    case 10: 
                    case 12: 
                    case 14: 
                    case 15: {
                        return CONNECTION_TYPE.GGG;
                    }
                    case 1: 
                    case 2: 
                    case 4: 
                    case 7: 
                    case 11: 
                }
                return CONNECTION_TYPE.GG;
            }
            return CONNECTION_TYPE.UNKNOWN;
        }
        return CONNECTION_TYPE.NONE;
    }

    public static SharedPreferences c(Context context) {
        if (a == null) {
            a = context.getSharedPreferences("ANALYTICS_UC", 0);
        }
        return a;
    }

    public static boolean d(Context context) {
        return Util.c(context).contains("CLIENT_OFFSET");
    }

    public static void e(long l, Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Saving Client Offset as ");
        stringBuilder.append(l);
        Log.d((String)"ANALYTICS_UC", (String)stringBuilder.toString());
        Util.c(context).edit().putLong("CLIENT_OFFSET", l).apply();
    }
}

