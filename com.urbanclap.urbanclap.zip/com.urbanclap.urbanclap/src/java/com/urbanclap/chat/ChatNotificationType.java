/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.urbanclap.chat;

public final class ChatNotificationType
extends Enum<ChatNotificationType> {
    private static final /* synthetic */ ChatNotificationType[] $VALUES;
    public static final /* enum */ ChatNotificationType CHAT_MESSAGE;
    public static final /* enum */ ChatNotificationType CHAT_SILENT;
    private final String notificationType;

    public static {
        ChatNotificationType chatNotificationType;
        ChatNotificationType chatNotificationType2;
        ChatNotificationType[] arrchatNotificationType = new ChatNotificationType[2];
        CHAT_SILENT = chatNotificationType2 = new ChatNotificationType("chat_silent");
        arrchatNotificationType[0] = chatNotificationType2;
        CHAT_MESSAGE = chatNotificationType = new ChatNotificationType("chat_message");
        arrchatNotificationType[1] = chatNotificationType;
        $VALUES = arrchatNotificationType;
    }

    private ChatNotificationType(String string2) {
        this.notificationType = string2;
    }

    public static ChatNotificationType valueOf(String string) {
        return (ChatNotificationType)Enum.valueOf(ChatNotificationType.class, (String)string);
    }

    public static ChatNotificationType[] values() {
        return (ChatNotificationType[])$VALUES.clone();
    }

    public final String getNotificationType() {
        return this.notificationType;
    }
}

