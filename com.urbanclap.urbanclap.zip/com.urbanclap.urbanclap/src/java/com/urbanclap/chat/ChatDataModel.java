/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  com.google.gson.annotations.SerializedName
 *  i2.a0.d.g
 *  i2.a0.d.l
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.urbanclap.chat;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import i2.a0.d.g;
import i2.a0.d.l;

public final class ChatDataModel
implements Parcelable {
    public static final a CREATOR = new a(null);
    @SerializedName(value="url")
    private final String a;
    @SerializedName(value="channel_id")
    private final String b;
    @SerializedName(value="unseen_message_count")
    private final Integer c;
    @SerializedName(value="unseen_last_message_timestamp")
    private final String d;

    public ChatDataModel(Parcel parcel) {
        l.h((Object)parcel, (String)"parcel");
        this(parcel.readString(), parcel.readString(), parcel.readInt(), parcel.readString());
    }

    public ChatDataModel(String string, String string2, Integer n, String string3) {
        this.a = string;
        this.b = string2;
        this.c = n;
        this.d = string3;
    }

    public final String a() {
        return this.b;
    }

    public final String b() {
        return this.a;
    }

    public final String c() {
        return this.d;
    }

    public final Integer d() {
        return this.c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object object) {
        block2 : {
            block3 : {
                if (this == object) break block2;
                if (!(object instanceof ChatDataModel)) break block3;
                ChatDataModel chatDataModel = (ChatDataModel)object;
                if (l.c((Object)this.a, (Object)chatDataModel.a) && l.c((Object)this.b, (Object)chatDataModel.b) && l.c((Object)this.c, (Object)chatDataModel.c) && l.c((Object)this.d, (Object)chatDataModel.d)) break block2;
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        String string = this.a;
        int n = string != null ? string.hashCode() : 0;
        int n2 = n * 31;
        String string2 = this.b;
        int n3 = string2 != null ? string2.hashCode() : 0;
        int n4 = 31 * (n2 + n3);
        Integer n5 = this.c;
        int n6 = n5 != null ? n5.hashCode() : 0;
        int n7 = 31 * (n4 + n6);
        String string3 = this.d;
        int n8 = 0;
        if (string3 != null) {
            n8 = string3.hashCode();
        }
        return n7 + n8;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ChatDataModel(chatUrl=");
        stringBuilder.append(this.a);
        stringBuilder.append(", channelId=");
        stringBuilder.append(this.b);
        stringBuilder.append(", unseenMessageCount=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", unseenLastMessageTimestamp=");
        stringBuilder.append(this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        l.h((Object)parcel, (String)"parcel");
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        Integer n2 = this.c;
        int n3 = n2 != null ? n2 : 0;
        parcel.writeInt(n3);
        parcel.writeString(this.d);
    }

    public static final class a
    implements Parcelable.Creator<ChatDataModel> {
        public a() {
        }

        public /* synthetic */ a(g g2) {
            this();
        }

        public ChatDataModel a(Parcel parcel) {
            l.h((Object)parcel, (String)"parcel");
            return new ChatDataModel(parcel);
        }

        public ChatDataModel[] b(int n) {
            return new ChatDataModel[n];
        }
    }

}

