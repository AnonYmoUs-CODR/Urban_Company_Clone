/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.uimanager.SimpleViewManager
 *  com.facebook.react.uimanager.ThemedReactContext
 *  com.facebook.react.uimanager.annotations.ReactProp
 *  java.lang.String
 *  t1.a.a.b
 */
package com.BV.LinearGradient;

import android.content.Context;
import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;
import t1.a.a.b;

public class LinearGradientManager
extends SimpleViewManager<b> {
    public static final String PROP_ANGLE = "angle";
    public static final String PROP_ANGLE_CENTER = "angleCenter";
    public static final String PROP_BORDER_RADII = "borderRadii";
    public static final String PROP_COLORS = "colors";
    public static final String PROP_END_POS = "endPoint";
    public static final String PROP_LOCATIONS = "locations";
    public static final String PROP_START_POS = "startPoint";
    public static final String PROP_USE_ANGLE = "useAngle";
    public static final String REACT_CLASS = "BVLinearGradient";

    public b createViewInstance(ThemedReactContext themedReactContext) {
        return new b((Context)themedReactContext);
    }

    public String getName() {
        return REACT_CLASS;
    }

    @ReactProp(defaultFloat=45.0f, name="angle")
    public void setAngle(b b2, float f) {
        b2.setAngle(f);
    }

    @ReactProp(name="angleCenter")
    public void setAngleCenter(b b2, ReadableArray readableArray) {
        b2.setAngleCenter(readableArray);
    }

    @ReactProp(name="borderRadii")
    public void setBorderRadii(b b2, ReadableArray readableArray) {
        b2.setBorderRadii(readableArray);
    }

    @ReactProp(name="colors")
    public void setColors(b b2, ReadableArray readableArray) {
        b2.setColors(readableArray);
    }

    @ReactProp(name="endPoint")
    public void setEndPosition(b b2, ReadableArray readableArray) {
        b2.setEndPosition(readableArray);
    }

    @ReactProp(name="locations")
    public void setLocations(b b2, ReadableArray readableArray) {
        if (readableArray != null) {
            b2.setLocations(readableArray);
        }
    }

    @ReactProp(name="startPoint")
    public void setStartPosition(b b2, ReadableArray readableArray) {
        b2.setStartPosition(readableArray);
    }

    @ReactProp(defaultBoolean=false, name="useAngle")
    public void setUseAngle(b b2, boolean bl) {
        b2.setUseAngle(bl);
    }
}

