/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  org.json.JSONException
 *  org.json.JSONObject
 *  t1.r.a.c.a
 *  t1.r.a.h.a
 *  t1.r.a.h.b
 *  t1.r.b.c.a
 *  t1.r.c.b
 *  t1.r.c.e
 *  t1.r.c.f
 *  t1.r.c.g
 */
package t1.r.b.c;

import android.content.Context;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;
import t1.r.b.c.a;
import t1.r.b.c.m.b;
import t1.r.c.e;
import t1.r.c.f;
import t1.r.c.g;

public class j {
    public static boolean a;
    public static b b;
    public static volatile boolean c;
    public static a d;

    public static t1.r.a.c.a a(Context context) {
        return t1.r.a.c.a.g((Context)context.getApplicationContext());
    }

    public static t1.r.a.h.a b(Context context) {
        return t1.r.a.h.b.j((Context)context.getApplicationContext());
    }

    public static void c(HashMap<String, e> hashMap, HashMap<String, HashMap<String, f>> hashMap2, Context context, boolean bl, boolean bl2, b b10) {
        a = bl2;
        t1.r.c.b.d(hashMap, hashMap2, (Context)context, (boolean)bl, (boolean)bl2);
        b = b10;
        c = true;
    }

    public static void d(AnalyticsTriggers analyticsTriggers, HashMap hashMap) {
        if (hashMap == null) {
            j.e(analyticsTriggers, new JSONObject());
            return;
        }
        try {
            Object object = g.a((Object)hashMap);
            if (object instanceof JSONObject) {
                j.e(analyticsTriggers, (JSONObject)object);
                return;
            }
            throw new JSONException("Not of type JSON Object");
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    public static void e(AnalyticsTriggers analyticsTriggers, JSONObject jSONObject) {
        t1.r.c.b.g((String)analyticsTriggers.toString(), (JSONObject)jSONObject);
    }
}

