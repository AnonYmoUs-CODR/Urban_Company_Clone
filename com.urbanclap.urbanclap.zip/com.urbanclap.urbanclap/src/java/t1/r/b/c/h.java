/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  t1.r.b.c.f
 */
package t1.r.b.c;

import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import i2.a0.d.l;
import java.util.HashMap;
import t1.r.b.c.f;
import t1.r.b.c.j;

public abstract class h {
    public final void a(AnalyticsTriggers analyticsTriggers, f f10) {
        l.g((Object)analyticsTriggers, (String)"analyticsTriggers");
        l.g((Object)f10, (String)"analyticsProps");
        j.d(analyticsTriggers, (HashMap)f10);
    }
}

