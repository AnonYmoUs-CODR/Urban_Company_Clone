/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.analytics_client.ucanalytics.EventPages
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 */
package t1.r.b.c;

import com.urbanclap.analytics_client.ucanalytics.EventPages;
import i2.a0.d.l;

public final class k {
    public static EventPages a = EventPages.HOMESCREEN;

    public static final EventPages a() {
        return a;
    }

    public static final void b(EventPages eventPages) {
        l.g((Object)eventPages, (String)"<set-?>");
        a = eventPages;
    }
}

