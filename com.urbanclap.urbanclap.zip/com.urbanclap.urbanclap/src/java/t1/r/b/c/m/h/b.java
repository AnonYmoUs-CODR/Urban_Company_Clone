/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsChannels
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  org.json.JSONObject
 *  t1.r.c.a
 *  t1.r.c.e
 */
package t1.r.b.c.m.h;

import android.content.Context;
import com.urbanclap.analytics_client.ucanalytics.AnalyticsChannels;
import java.util.HashMap;
import org.json.JSONObject;
import t1.r.b.c.i;
import t1.r.c.a;
import t1.r.c.e;

public class b
implements a {
    public void a(Context context) {
    }

    public void b(JSONObject jSONObject) {
        ((e)i.e.get((Object)AnalyticsChannels.UCServer.toString())).a().b(jSONObject);
    }
}

