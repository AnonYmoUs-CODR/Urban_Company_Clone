/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package t1.r.b.c.m;

public interface b {
    public String a();

    public String b();

    public float d();

    public float e();

    public String f();

    public String getVersion();

    public String i();
}

