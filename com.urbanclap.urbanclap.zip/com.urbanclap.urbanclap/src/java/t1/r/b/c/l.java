/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  java.lang.Object
 *  t1.r.b.c.f
 */
package t1.r.b.c;

import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import t1.r.b.c.f;

public interface l {
    public void D0(AnalyticsTriggers var1, f var2);

    public void E0(AnalyticsTriggers var1);
}

