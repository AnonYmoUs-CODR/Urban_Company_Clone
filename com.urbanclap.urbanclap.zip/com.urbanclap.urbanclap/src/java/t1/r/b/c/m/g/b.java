/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  t1.r.a.f.d
 *  t1.r.b.c.m.g.a
 *  t1.r.k.n.o0.c
 */
package t1.r.b.c.m.g;

import com.urbanclap.analytics_client.ucanalytics.AnalyticsTriggers;
import java.util.HashMap;
import java.util.Map;
import t1.r.a.f.d;
import t1.r.b.c.j;
import t1.r.b.c.m.g.a;
import t1.r.k.n.o0.c;

public class b
implements d {
    public a a;

    public b(a a6) {
        this.a = a6;
    }

    public void a(int n6, String string, long l6, HashMap<String, String> hashMap) {
        AnalyticsTriggers analyticsTriggers = AnalyticsTriggers.valueOf((String)string);
        HashMap hashMap2 = new HashMap();
        Object[] arrobject = new Object[]{string, l6};
        c.h((Object)this, (String)"trigger -> %s time -> %d", (Object[])arrobject);
        hashMap2.put((Object)"latence_ms", (Object)String.valueOf((long)l6));
        hashMap2.putAll(hashMap);
        if (l6 <= 0L) {
            c.h((Object)this, (String)"discarding the trigger -> %s", (Object[])new Object[]{string});
            return;
        }
        j.d(analyticsTriggers, hashMap2);
    }
}

