/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.urbanclap.analytics_client.ucanalytics.AnalyticsChannels
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  t1.r.b.a
 *  t1.r.b.c.m.e.a
 *  t1.r.b.c.m.f.a
 *  t1.r.b.c.m.h.a
 *  t1.r.b.c.m.h.b
 *  t1.r.c.a
 *  t1.r.c.e
 */
package t1.r.b.c;

import com.urbanclap.analytics_client.ucanalytics.AnalyticsChannels;
import java.util.HashMap;
import t1.r.b.c.m.h.b;
import t1.r.c.e;

public class i {
    public static final t1.r.b.c.m.h.a a = new t1.r.b.c.m.h.a();
    public static final b b = new b();
    public static final t1.r.b.c.m.f.a c = new t1.r.b.c.m.f.a();
    public static final t1.r.b.c.m.e.a d = new t1.r.b.c.m.e.a();
    public static final HashMap<String, e> e = new HashMap<String, e>(){
        {
            this.put((Object)AnalyticsChannels.UCServer.toString(), (Object)new e(Integer.valueOf((int)t1.r.b.a.c), (t1.r.c.a)a));
            this.put((Object)AnalyticsChannels.CleverTap.toString(), (Object)new e(Integer.valueOf((int)t1.r.b.a.b), (t1.r.c.a)c));
            this.put((Object)AnalyticsChannels.AppsFlyr.toString(), (Object)new e(Integer.valueOf((int)t1.r.b.a.a), (t1.r.c.a)d));
            this.put((Object)AnalyticsChannels.UCServerV2.toString(), (Object)new e(Integer.valueOf((int)t1.r.b.a.d), (t1.r.c.a)b));
        }
    };

    public static void e() {
        a.c();
    }

}

