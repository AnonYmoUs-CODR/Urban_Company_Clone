/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.clevertap.android.sdk.CleverTapAPI
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package t1.r.b.c.m.f;

import android.content.Context;
import com.clevertap.android.sdk.CleverTapAPI;
import java.util.HashMap;
import java.util.Map;

public class c {
    public static void a(Context context, double d10, String string, String string2) {
        CleverTapAPI cleverTapAPI = CleverTapAPI.v2((Context)context.getApplicationContext());
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"Amount", (Object)d10);
        if (string == null) {
            string = "NA";
        }
        hashMap.put((Object)"Charged ID", (Object)string);
        if (string2 == null) {
            string2 = "NA";
        }
        hashMap.put((Object)"Product category", (Object)string2);
        cleverTapAPI.K4("Charged", (Map)hashMap);
    }
}

