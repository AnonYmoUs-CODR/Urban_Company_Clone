/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.urbanclap.analytics_client.ucanalytics.Environment
 *  com.urbanclap.analytics_client.ucanalytics.EventType
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONObject
 *  t1.r.a.b.a
 *  t1.r.a.b.b
 *  t1.r.a.b.b$c
 *  t1.r.a.c.a
 *  t1.r.a.e.a
 *  t1.r.a.e.b
 *  t1.r.a.e.c
 *  t1.r.a.h.a
 *  t1.r.b.c.b
 *  t1.r.b.c.m.a
 *  t1.r.b.c.m.c
 *  t1.r.c.a
 *  t1.r.k.n.o0.c
 *  t1.r.k.n.q0.y.a
 *  t1.s.d.a.a
 */
package t1.r.b.c.m.h;

import android.content.Context;
import com.urbanclap.analytics_client.ucanalytics.Environment;
import com.urbanclap.analytics_client.ucanalytics.EventType;
import org.json.JSONObject;
import t1.r.a.b.b;
import t1.r.b.c.b;
import t1.r.b.c.j;
import t1.r.b.c.m.c;
import t1.r.b.c.m.d;

public class a
implements t1.r.c.a {
    public t1.r.a.b.b b;

    public static {
        new t1.r.k.n.q0.y.a();
    }

    public void a(Context context) {
        new t1.s.d.a.a(context);
        c c6 = new c(context);
        d d6 = new d(context);
        t1.r.b.c.m.a a6 = new t1.r.b.c.m.a(context);
        Environment environment = j.a ? Environment.DEV : Environment.PROD;
        b b6 = new b(environment, EventType.UCSERVER);
        b.c c7 = new b.c(context);
        c7.c((t1.r.a.e.b)c6);
        c7.f(d6.e());
        c7.e((t1.r.a.b.a)b6);
        c7.g(j.b(context));
        c7.d(j.a(context));
        c7.b((t1.r.a.e.a)a6);
        this.b = c7.a();
    }

    public void b(JSONObject jSONObject) {
        t1.r.a.b.b b6 = this.b;
        if (b6 == null) {
            t1.r.k.n.o0.c.e((Object)this, (String)"UCServerChannelClient", (Object[])new Object[]{"analytics client not initialized"});
            return;
        }
        b6.onEvent(jSONObject);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("AnalyticsClientEvent : ");
        stringBuilder.append(jSONObject.toString());
        t1.r.k.n.o0.c.b((Object)this, (String)stringBuilder.toString());
    }

    public void c() {
        t1.r.a.b.b b6 = this.b;
        if (b6 == null) {
            t1.r.k.n.o0.c.e((Object)this, (String)"UCServerChannelClient", (Object[])new Object[]{"analytics client not initialized"});
            return;
        }
        b6.w();
    }
}

