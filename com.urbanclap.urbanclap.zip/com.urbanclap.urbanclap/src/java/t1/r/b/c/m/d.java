/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  t1.r.a.e.c
 *  t1.r.b.c.m.d$a
 */
package t1.r.b.c.m;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import t1.r.a.e.c;
import t1.r.b.c.m.d;

public class d {
    public SharedPreferences a;

    public d(Context context) {
        this.a = context.getSharedPreferences("REF", 0);
    }

    public static /* synthetic */ SharedPreferences a(d d10) {
        return d10.a;
    }

    public String b() {
        return this.a.getString("install_af_click_time", "_N_A");
    }

    public String c() {
        return this.a.getString("install_af_campaign_id", "_N_A");
    }

    public String d() {
        return this.a.getString("install_af_install_time", "_N_A");
    }

    public c e() {
        return new a(this);
    }

    public String f() {
        return this.a.getString("utm_campaign", "_N_A");
    }

    public String g() {
        return this.a.getString("utm_content", "_N_A");
    }

    public String h() {
        return this.a.getString("utm_medium", "_N_A");
    }

    public String i() {
        return this.a.getString("utm_source", "_N_A");
    }

    public String j() {
        return this.a.getString("utm_term", "_N_A");
    }

    public void k(String string) {
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.a.edit().remove("install_af_campaign").apply();
            return;
        }
        this.a.edit().putString("install_af_campaign", string).apply();
    }

    public void l(String string) {
        this.a.edit().putString("install_af_click_time", string).apply();
    }

    public void m(String string) {
        this.a.edit().putString("install_af_campaign_id", string).apply();
    }

    public void n(String string) {
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.a.edit().remove("install_af_channel").apply();
            return;
        }
        this.a.edit().putString("install_af_channel", string).apply();
    }

    public void o(String string) {
        this.a.edit().putString("install_af_install_time", string).apply();
    }

    public void p(String string) {
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.a.edit().remove("install_af_pid").apply();
            return;
        }
        this.a.edit().putString("install_af_pid", string).apply();
    }

    public void q(String string) {
        this.a.edit().putString("creation_source", string).apply();
    }

    public void r(String string) {
        this.a.edit().putString("utm_campaign", string).apply();
    }

    public void s(String string) {
        this.a.edit().putString("utm_content", string).apply();
    }

    public void t(String string) {
        this.a.edit().putString("utm_medium", string).apply();
    }

    public void u(String string) {
        this.a.edit().putString("utm_source", string).apply();
    }

    public void v(String string) {
        this.a.edit().putString("utm_term", string).apply();
    }
}

