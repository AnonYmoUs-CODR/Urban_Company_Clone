/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package t1.r.b.c.m.e;

public interface c {
    public static final a a = a.a;

    public static final class a {
        public static final /* synthetic */ a a;

        public static {
            a = new a();
        }

        public final String a() {
            return "category_key";
        }

        public final String b() {
            return "event_name";
        }

        public final String c() {
            return "event_value";
        }

        public final String d() {
            return "gender";
        }

        public final String e() {
            return "user_type";
        }
    }

}

