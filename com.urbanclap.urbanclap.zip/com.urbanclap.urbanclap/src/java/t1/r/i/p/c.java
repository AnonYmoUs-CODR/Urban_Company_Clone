/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  com.urbanclap.reactnative.views.UcReactActivity
 *  i2.a0.d.l
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  org.json.JSONObject
 *  t1.r.f.h.d
 *  t1.r.f.h.w
 *  t1.r.i.h.a
 *  t1.r.i.h.a$a
 *  t1.r.i.o.r
 */
package t1.r.i.p;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.urbanclap.reactnative.views.UcReactActivity;
import i2.a0.d.l;
import java.io.Serializable;
import org.json.JSONObject;
import t1.r.f.h.d;
import t1.r.f.h.w;
import t1.r.i.h.a;
import t1.r.i.o.r;

public final class c {
    public static final Bundle a(String string, Bundle bundle) {
        l.g((Object)string, (String)"route");
        Bundle bundle2 = new Bundle();
        a.a a2 = a.p;
        w w2 = ((a)a2.a()).G();
        d d2 = ((a)a2.a()).e();
        bundle2.putString("route", string);
        bundle2.putInt("bridgeVersion", 8);
        bundle2.putString("userId", w2.e());
        bundle2.putString("cityKey", w2.b());
        bundle2.putString("locale", "en");
        bundle2.putString("countryKey", w2.c());
        bundle2.putLong("timestamp", System.currentTimeMillis());
        if (d2.l() != null && d2.m() != null) {
            Float f2 = d2.l();
            l.e((Object)f2);
            bundle2.putFloat("latitude", f2.floatValue());
            Float f3 = d2.m();
            l.e((Object)f3);
            bundle2.putFloat("longitude", f3.floatValue());
        }
        bundle2.putBundle("initData", bundle);
        return bundle2;
    }

    public static final Bundle b(String string, String string2, String string3, String string4, Bundle bundle) {
        l.g((Object)string, (String)"route");
        l.g((Object)string2, (String)"userId");
        l.g((Object)string3, (String)"cityKey");
        l.g((Object)string4, (String)"countryKey");
        Bundle bundle2 = new Bundle();
        d d2 = ((a)a.p.a()).e();
        bundle2.putString("route", string);
        bundle2.putInt("bridgeVersion", 8);
        bundle2.putString("userId", string2);
        bundle2.putString("cityKey", string3);
        bundle2.putString("locale", "en");
        bundle2.putString("countryKey", string4);
        bundle2.putLong("timestamp", System.currentTimeMillis());
        if (d2.l() != null && d2.m() != null) {
            Float f2 = d2.l();
            l.e((Object)f2);
            bundle2.putFloat("latitude", f2.floatValue());
            Float f3 = d2.m();
            l.e((Object)f3);
            bundle2.putFloat("longitude", f3.floatValue());
        }
        bundle2.putBundle("initData", bundle);
        return bundle2;
    }

    public static final Intent c(Activity activity, String string, String string2, String string3, String string4, JSONObject jSONObject) {
        l.g((Object)activity, (String)"context");
        l.g((Object)string, (String)"route");
        l.g((Object)string2, (String)"userId");
        l.g((Object)string3, (String)"cityKey");
        l.g((Object)string4, (String)"countryKey");
        l.g((Object)jSONObject, (String)"initData");
        Intent intent = new Intent((Context)activity, UcReactActivity.class);
        intent.putExtra("bundle", c.b(string, string2, string3, string4, r.e((JSONObject)jSONObject)));
        return intent;
    }

    public static final Intent d(Context context, String string, String string2, String string3, String string4, Bundle bundle, Boolean bl) {
        l.g((Object)context, (String)"context");
        l.g((Object)string, (String)"route");
        l.g((Object)string2, (String)"userId");
        l.g((Object)string3, (String)"cityKey");
        l.g((Object)string4, (String)"countryKey");
        Intent intent = new Intent(context, UcReactActivity.class);
        intent.putExtra("bundle", c.b(string, string2, string3, string4, bundle));
        intent.putExtra("fromCreateRequest", (Serializable)bl);
        if (l.c((Object)bl, (Object)Boolean.TRUE)) {
            intent.addFlags(32768);
        }
        return intent;
    }

    public static /* synthetic */ Intent e(Context context, String string, String string2, String string3, String string4, Bundle bundle, Boolean bl, int n, Object object) {
        if ((n & 32) != 0) {
            bundle = null;
        }
        Bundle bundle2 = bundle;
        if ((n & 64) != 0) {
            bl = Boolean.FALSE;
        }
        return c.d(context, string, string2, string3, string4, bundle2, bl);
    }

    public static final void f(Context context, String string, Bundle bundle) {
        l.g((Object)context, (String)"context");
        l.g((Object)string, (String)"route");
        w w2 = ((a)a.p.a()).G();
        String string2 = w2.e();
        String string3 = string2 != null ? string2 : "";
        String string4 = w2.b();
        String string5 = string4 != null ? string4 : "";
        String string6 = w2.c();
        String string7 = string6 != null ? string6 : "";
        context.startActivity(c.e(context, string, string3, string5, string7, bundle, null, 64, null));
    }

    public static final void g(Context context, String string, String string2, String string3, String string4, Bundle bundle) {
        l.g((Object)context, (String)"context");
        l.g((Object)string, (String)"route");
        l.g((Object)string2, (String)"userId");
        l.g((Object)string3, (String)"cityKey");
        l.g((Object)string4, (String)"countryKey");
        context.startActivity(c.e(context, string, string2, string3, string4, bundle, null, 64, null));
    }

    public static /* synthetic */ void h(Context context, String string, Bundle bundle, int n, Object object) {
        if ((n & 4) != 0) {
            bundle = null;
        }
        c.f(context, string, bundle);
    }

    public static final void i(Activity activity, String string, Bundle bundle, int n) {
        l.g((Object)activity, (String)"context");
        l.g((Object)string, (String)"route");
        Intent intent = new Intent((Context)activity, UcReactActivity.class);
        intent.putExtra("bundle", c.a(string, bundle));
        activity.startActivityForResult(intent, n);
    }

    public static final void j(Activity activity, String string, String string2, String string3, String string4, Bundle bundle, int n) {
        l.g((Object)activity, (String)"context");
        l.g((Object)string, (String)"route");
        l.g((Object)string2, (String)"userId");
        l.g((Object)string3, (String)"cityKey");
        l.g((Object)string4, (String)"countryKey");
        Intent intent = new Intent((Context)activity, UcReactActivity.class);
        intent.putExtra("bundle", c.b(string, string2, string3, string4, bundle));
        activity.startActivityForResult(intent, n);
    }
}

