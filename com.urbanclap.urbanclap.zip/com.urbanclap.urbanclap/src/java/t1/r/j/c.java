/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  androidx.fragment.app.FragmentActivity
 *  i2.a0.c.a
 *  i2.a0.d.l
 *  i2.f
 *  i2.h
 *  i2.h0.s
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Objects
 *  org.json.JSONObject
 *  t1.r.f.b
 *  t1.r.f.f.b.s
 *  t1.r.f.h.k
 *  t1.r.j.c$a
 */
package t1.r.j;

import android.app.Activity;
import android.content.Intent;
import androidx.fragment.app.FragmentActivity;
import i2.a0.d.l;
import i2.f;
import i2.h;
import java.util.HashMap;
import java.util.Objects;
import org.json.JSONObject;
import t1.r.f.f.b.s;
import t1.r.f.h.k;
import t1.r.j.c;
import t1.r.j.e.b;

public final class c {
    public HashMap<String, b> a = new HashMap();
    public final f b = h.b((i2.a0.c.a)a.a);

    public final k a() {
        return (k)this.b.getValue();
    }

    public final String b(String string) {
        if (i2.h0.s.M((CharSequence)string, (CharSequence)"+", (boolean)false, (int)2, null)) {
            int n = i2.h0.s.X((CharSequence)string, (String)"+", (int)0, (boolean)false, (int)6, null);
            Objects.requireNonNull((Object)string, (String)"null cannot be cast to non-null type java.lang.String");
            string = string.substring(0, n);
            l.f((Object)string, (String)"(this as java.lang.Strin\u2026ing(startIndex, endIndex)");
        }
        return string;
    }

    public final void c(String string, FragmentActivity fragmentActivity, s s2, t1.r.f.b<HashMap<Object, Object>, Object> b2) {
        l.g((Object)fragmentActivity, (String)"activity");
        l.g((Object)s2, (String)"screenPluginData");
        l.g(b2, (String)"iPluginCapabilityListener");
        t1.r.j.b b3 = t1.r.j.b.f;
        HashMap<String, t1.r.j.d.a> hashMap = b3.e();
        String string2 = string != null ? this.b(string) : null;
        t1.r.j.d.a a2 = (t1.r.j.d.a)hashMap.get((Object)string2);
        b b4 = new b(b2, b3.c());
        b4.c(s2.b());
        if (string != null) {
            b4.g(string);
        }
        if (a2 != null) {
            a2.d(b4);
        }
        this.a.put((Object)string, (Object)b4);
        if (a2 != null) {
            a2.c(s2.a(), (Activity)fragmentActivity);
        }
    }

    public final void d(Activity activity, int n, int n2, Intent intent) {
        l.g((Object)activity, (String)"activity");
        t1.r.j.b b2 = t1.r.j.b.f;
        String string = this.b(b2.b().c(n));
        this.a().b((Object)this, "SailorManager {propogateResult} registryScreenName = ".concat(String.valueOf((Object)string)), new Object[0]);
        if (b2.e().containsKey((Object)string)) {
            b b3 = (b)this.a.get((Object)b2.b().c(n));
            t1.r.j.d.a a2 = (t1.r.j.d.a)b2.e().get((Object)string);
            if (b3 != null && a2 != null) {
                a2.d(b3);
            }
            k k2 = this.a();
            StringBuilder stringBuilder = new StringBuilder("SailorManager {propogateResult}: screenHandlerResgisty contains screenName sailorHelper = ");
            stringBuilder.append((Object)b3);
            stringBuilder.append(" baseSailorScreenHandler = ");
            stringBuilder.append((Object)a2);
            k2.b((Object)this, stringBuilder.toString(), new Object[0]);
            if (a2 != null) {
                a2.f(n, n2, intent, a2.e());
            }
        }
    }
}

