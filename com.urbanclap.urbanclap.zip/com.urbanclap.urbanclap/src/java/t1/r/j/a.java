/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package t1.r.j;

public final class a {
    public static final int a = 2130772005;
    public static final int b = 2130772008;
}

