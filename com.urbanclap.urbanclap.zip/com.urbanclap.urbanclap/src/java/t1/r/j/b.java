/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  i2.a0.d.l
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  t1.r.f.h.k
 *  t1.r.j.e.d
 */
package t1.r.j;

import i2.a0.d.l;
import java.util.HashMap;
import t1.r.f.h.k;
import t1.r.j.d.a;
import t1.r.j.e.c;
import t1.r.j.e.d;

public final class b {
    public static HashMap<String, a> a;
    public static t1.r.j.f.a b;
    public static t1.r.j.e.a c;
    public static c d;
    public static k e;
    public static final b f;

    public static {
        f = new b();
    }

    public final k a() {
        k k2 = e;
        if (k2 != null) {
            return k2;
        }
        l.v((String)"loggerPlugin");
        throw null;
    }

    public final t1.r.j.f.a b() {
        t1.r.j.f.a a2 = b;
        if (a2 != null) {
            return a2;
        }
        l.v((String)"requestCodeGenerator");
        throw null;
    }

    public final c c() {
        c c2 = d;
        if (c2 != null) {
            return c2;
        }
        l.v((String)"sailorIntentHelper");
        throw null;
    }

    public final t1.r.j.e.a d() {
        t1.r.j.e.a a2 = c;
        if (a2 != null) {
            return a2;
        }
        l.v((String)"sailorTransactionHelper");
        throw null;
    }

    public final HashMap<String, a> e() {
        HashMap<String, a> hashMap = a;
        if (hashMap != null) {
            return hashMap;
        }
        l.v((String)"screenHandlerRegistry");
        throw null;
    }

    public final void f(HashMap<String, a> hashMap, k k2, c c2) {
        l.g(hashMap, (String)"screenHandlerRegistry");
        l.g((Object)k2, (String)"loggerPlugin");
        l.g((Object)c2, (String)"sailorIntentHelper");
        a = hashMap;
        b = new t1.r.j.f.a(hashMap);
        c = new d();
        e = k2;
        d = c2;
    }

    public final t1.r.j.c g() {
        return new t1.r.j.c();
    }
}

