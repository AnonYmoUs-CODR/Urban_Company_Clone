/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package amazonpay.silentpay;

import android.graphics.Color;

public final class c {
    public static final int a = Color.parseColor((String)"#000000");
    public static final int b = Color.parseColor((String)"#FFFFFF");

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a;
        public static final /* enum */ a b;
        public static final /* enum */ a c;
        public static final /* enum */ a d;
        private static final /* synthetic */ a[] e;

        public static {
            a a2;
            a a3;
            a a4;
            a a5;
            a = a3 = new a();
            b = a2 = new a();
            c = a4 = new a();
            d = a5 = new a();
            e = new a[]{a3, a2, a4, a5};
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])e.clone();
        }
    }

}

