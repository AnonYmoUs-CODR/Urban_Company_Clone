/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  java.io.Serializable
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  r.a.c
 *  r.a.e
 */
package amazonpay.silentpay;

import amazonpay.silentpay.d;
import android.content.Intent;
import android.os.Bundle;
import com.amazon.identity.auth.device.AuthError;
import java.io.Serializable;
import r.a.c;
import r.a.e;

public class APayError
extends Exception {
    public ErrorType a;
    public AuthError b;

    public APayError(ErrorType errorType, AuthError authError) {
        this.a = errorType;
        this.b = authError;
    }

    public APayError(ErrorType errorType, String string) {
        super(string);
        this.a = errorType;
    }

    public APayError(ErrorType errorType, String string, Throwable throwable) {
        super(string, throwable);
        this.a = errorType;
    }

    public static AuthError a(Intent intent) {
        if (intent.getExtras().containsKey("ERROR_CAUSE")) {
            return new AuthError(intent.getExtras().getString("ERROR_MESSAGE"), (Throwable)intent.getExtras().getSerializable("ERROR_CAUSE"), (AuthError.ERROR_TYPE)intent.getExtras().getSerializable("AUTH_ERROR_TYPE"));
        }
        return new AuthError(intent.getExtras().getString("ERROR_MESSAGE"), (AuthError.ERROR_TYPE)intent.getExtras().getSerializable("AUTH_ERROR_TYPE"));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static APayError b(Intent intent) {
        if (intent == null) return null;
        try {
            if (intent.getExtras() == null) return null;
            ErrorType[] arrerrorType = ErrorType.values();
            int n = arrerrorType.length;
            int n2 = 0;
            while (n2 < n) {
                ErrorType errorType = arrerrorType[n2];
                if (intent.getExtras().containsKey(errorType.name())) {
                    ErrorType errorType2 = ErrorType.AUTH_ERROR;
                    if (errorType == errorType2 && intent.getExtras().containsKey("AUTH_ERROR_TYPE")) {
                        return new APayError(errorType2, APayError.a(intent));
                    }
                    if (intent.getExtras().containsKey("ERROR_MESSAGE") && intent.getExtras().containsKey("ERROR_CAUSE")) {
                        return new APayError(errorType, intent.getExtras().getString("ERROR_MESSAGE"), (Throwable)intent.getExtras().getSerializable("ERROR_CAUSE"));
                    }
                    if (intent.getExtras().containsKey("ERROR_MESSAGE")) {
                        return new APayError(errorType, intent.getExtras().getString("ERROR_MESSAGE"));
                    }
                }
                ++n2;
            }
            return null;
        }
        catch (Exception exception) {
            c.e((String)"APayError", (String)"Error parsing Apay Error", (Throwable)exception);
            e.d((d.a)d.a.k);
            return new APayError(ErrorType.APAY_ERROR, "Error parsing Apay Error", exception);
        }
    }

    public AuthError c() {
        return this.b;
    }

    public ErrorType d() {
        return this.a;
    }

    public static final class ErrorType
    extends Enum<ErrorType> {
        public static final /* enum */ ErrorType APAY_ERROR;
        public static final /* enum */ ErrorType AUTH_ERROR;
        public static final /* enum */ ErrorType LOW_MEMORY;
        private static final /* synthetic */ ErrorType[] a;

        public static {
            ErrorType errorType;
            ErrorType errorType2;
            ErrorType errorType3;
            AUTH_ERROR = errorType3 = new ErrorType();
            APAY_ERROR = errorType = new ErrorType();
            LOW_MEMORY = errorType2 = new ErrorType();
            a = new ErrorType[]{errorType3, errorType, errorType2};
        }

        public static ErrorType valueOf(String string) {
            return (ErrorType)Enum.valueOf(ErrorType.class, (String)string);
        }

        public static ErrorType[] values() {
            return (ErrorType[])a.clone();
        }
    }

}

