/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.Class
 */
package amazonpay.silentpay;

import amazonpay.silentpay.APayActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class RedirectUriReceiverActivity
extends Activity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = new Intent((Context)this, APayActivity.class);
        intent.setData(this.getIntent().getData());
        intent.addFlags(603979776);
        this.finish();
        this.startActivity(intent);
    }
}

