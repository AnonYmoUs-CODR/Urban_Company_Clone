/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  amazonpay.silentpay.APayActivity$b
 *  android.app.Activity
 *  android.app.PendingIntent
 *  android.app.PendingIntent$CanceledException
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.util.Pair
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  androidx.browser.customtabs.CustomTabsIntent
 *  com.amazon.identity.auth.device.AuthError
 *  com.amazon.identity.auth.device.AuthError$ERROR_TYPE
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeRequest
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeRequest$GrantType
 *  com.amazon.identity.auth.device.api.authorization.AuthorizeRequest$a
 *  com.amazon.identity.auth.device.api.authorization.Region
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.List
 *  r.a.a
 *  r.a.c
 *  r.a.d
 *  r.a.e
 *  t1.d.a.a.a.a.b.a
 *  t1.d.a.a.a.a.b.e
 *  t1.d.a.a.a.a.c.a
 *  t1.d.a.a.a.b.b
 *  t1.d.a.a.b.a
 */
package amazonpay.silentpay;

import amazonpay.silentpay.APayActivity;
import amazonpay.silentpay.APayError;
import amazonpay.silentpay.c;
import amazonpay.silentpay.d;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.browser.customtabs.CustomTabsIntent;
import com.amazon.identity.auth.device.AuthError;
import com.amazon.identity.auth.device.api.authorization.AuthorizeRequest;
import com.amazon.identity.auth.device.api.authorization.Region;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import t1.d.a.a.a.a.b.e;

/*
 * Exception performing whole class analysis.
 */
public final class APayActivity
extends Activity {
    public t1.d.a.a.a.a.c.a a;
    public PendingIntent b;
    public PendingIntent c;
    public boolean d;
    public String e;
    public String f;

    public APayActivity() {
        this.d = false;
    }

    public static /* synthetic */ void d(APayActivity aPayActivity, APayError.ErrorType errorType, Exception exception) {
        aPayActivity.f(errorType, exception);
    }

    public static /* synthetic */ void e(APayActivity aPayActivity, Intent intent) {
        aPayActivity.k(intent);
    }

    public final ProgressBar a(List<Pair<Integer, Integer>> list) {
        ProgressBar progressBar = new ProgressBar((Context)this, null, 16842871);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        if (!list.isEmpty()) {
            for (Pair pair : list) {
                if (pair.second != null) {
                    layoutParams.addRule(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
                    continue;
                }
                layoutParams.addRule(((Integer)pair.first).intValue());
            }
        }
        progressBar.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        return progressBar;
    }

    public final RelativeLayout b() {
        APayActivity aPayActivity = this;
        synchronized (aPayActivity) {
            RelativeLayout relativeLayout = new RelativeLayout((Context)this);
            TextView textView = this.c(r.a.a.b.b(), r.a.a.b.e(), Float.valueOf((float)r.a.a.b.i()));
            textView.setGravity(17);
            textView.setId(1);
            relativeLayout.addView((View)textView);
            Object[] arrobject = new Pair[]{new Pair((Object)14, null), new Pair((Object)12, null), new Pair((Object)3, (Object)textView.getId())};
            relativeLayout.addView((View)this.a((List<Pair<Integer, Integer>>)Arrays.asList((Object[])arrobject)));
            return relativeLayout;
        }
    }

    public final TextView c(String string, Integer n, Float f2) {
        TextView textView = new TextView((Context)this);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(13);
        textView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        if (n != null) {
            textView.setTextColor(n.intValue());
        }
        if (f2 != null) {
            textView.setTextSize(f2.floatValue());
        }
        textView.setText((CharSequence)string);
        return textView;
    }

    public final void f(APayError.ErrorType errorType, Exception exception) {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        try {
            bundle.putString(errorType.name(), null);
            if (exception.getMessage() != null) {
                bundle.putString("ERROR_MESSAGE", exception.getMessage());
            }
            if (exception.getCause() != null) {
                bundle.putSerializable("ERROR_CAUSE", (Serializable)exception.getCause());
            }
            if (errorType == APayError.ErrorType.AUTH_ERROR) {
                bundle.putSerializable("AUTH_ERROR_TYPE", (Serializable)((AuthError)exception).m1());
            }
            intent.putExtras(bundle);
            this.k(intent);
            this.finish();
            return;
        }
        catch (Exception exception2) {
            r.a.c.b((String)"APayActivity", (String)"Exception during error serialization", (Throwable)exception2);
            bundle.putString(APayError.ErrorType.AUTH_ERROR.name(), null);
            if (exception.getMessage() != null) {
                bundle.putString("ERROR_MESSAGE", exception.getMessage());
            }
            intent.putExtras(bundle);
            this.k(intent);
            this.finish();
            return;
        }
    }

    public void g(Activity activity, Intent intent, CustomTabsIntent customTabsIntent) {
        t1.d.a.a.a.a.c.a a2;
        r.a.c.a((String)"APayActivity", (String)"init authorize called");
        this.a = a2 = t1.d.a.a.a.a.c.a.f((Activity)activity, (Intent)intent, (CustomTabsIntent)customTabsIntent);
        a2.o((t1.d.a.a.a.b.b)new /* Unavailable Anonymous Inner Class!! */);
        AuthorizeRequest.a a3 = new AuthorizeRequest.a(this.a);
        a3.a(r.a.a.b.p());
        a3.d(r.a.a.b.q());
        a3.c(AuthorizeRequest.GrantType.AUTHORIZATION_CODE);
        a3.e(this.f, "S256");
        AuthorizeRequest authorizeRequest = a3.b();
        t1.d.a.a.a.a.b.a.d((Context)this, (Region)r.a.a.b.o());
        t1.d.a.a.a.a.b.a.a((AuthorizeRequest)authorizeRequest);
    }

    public final void h(Intent intent) {
        r.a.c.a((String)"APayActivity", (String)"handleOperationCancelled called");
        PendingIntent pendingIntent = this.c;
        if (pendingIntent != null) {
            try {
                pendingIntent.send((Context)this, 0, intent);
                return;
            }
            catch (PendingIntent.CanceledException canceledException) {
                r.a.c.e((String)"APayActivity", (String)"Unable to start cancelIntent", (Throwable)canceledException);
                this.finish();
                return;
            }
        }
        this.setResult(0, intent);
    }

    public final void i(Bundle bundle) {
        if (bundle != null) {
            this.b = (PendingIntent)bundle.getParcelable("COMPLETION_INTENT");
            this.c = (PendingIntent)bundle.getParcelable("CANCEL_INTENT");
            this.d = bundle.getBoolean("HAS_OPERATION_STARTED", false);
            this.f = bundle.getString("CODE_CHALLENGE");
            if (bundle.containsKey("OPERATION")) {
                r.a.a.c = (c.a)bundle.getSerializable("OPERATION");
                r.a.a.b = r.a.d.a((Context)this);
            }
            if (bundle.containsKey("PAY_URL")) {
                this.e = bundle.getString("PAY_URL");
            }
        }
    }

    public void j(Activity activity, Intent intent, CustomTabsIntent customTabsIntent) {
        r.a.c.a((String)"APayActivity", (String)"init charge called");
        this.a = t1.d.a.a.a.a.c.a.f((Activity)activity, (Intent)intent, (CustomTabsIntent)customTabsIntent);
        try {
            t1.d.a.a.b.a.a((Context)this).b(this.a, this.e);
            return;
        }
        catch (AuthError authError) {
            r.a.e.d((d.a)d.a.h);
            this.f(APayError.ErrorType.AUTH_ERROR, (Exception)((Object)authError));
            this.finish();
            return;
        }
    }

    public final void k(Intent intent) {
        r.a.c.a((String)"APayActivity", (String)"handleOperationCompleted called");
        this.d = false;
        if (this.b != null) {
            try {
                r.a.e.c((c.a)r.a.a.c);
                this.b.send((Context)this, -1, intent);
                return;
            }
            catch (PendingIntent.CanceledException canceledException) {
                r.a.c.e((String)"APayActivity", (String)"Unable to start completionIntent", (Throwable)canceledException);
                this.finish();
                return;
            }
        }
        r.a.e.c((c.a)r.a.a.c);
        this.setResult(-1, intent);
    }

    public void onCreate(Bundle bundle) {
        block12 : {
            super.onCreate(bundle);
            if (bundle != null) {
                r.a.c.a((String)"APayActivity", (String)"Low memory flow triggered");
                this.i(bundle);
            } else {
                r.a.c.a((String)"APayActivity", (String)"Normal memory flow triggered");
                this.i(this.getIntent().getExtras());
            }
            try {
                this.setContentView((View)this.b());
            }
            catch (Exception exception) {
                r.a.c.e((String)"APayActivity", (String)"Exception while setting up layout", (Throwable)exception);
                r.a.e.d((d.a)d.a.n);
                this.f(APayError.ErrorType.APAY_ERROR, exception);
            }
            if (!this.d) {
                try {
                    if (r.a.a.b.s()) {
                        r.a.c.a((String)"APayActivity", (String)"proceeding in custom tab");
                        r.a.e.d((d.a)d.a.d);
                        if (r.a.a.c != c.a.b && r.a.a.c != c.a.a) {
                            if (r.a.a.c == c.a.c || r.a.a.c == c.a.d) {
                                this.j(this, this.getIntent(), r.a.a.a);
                                return;
                            }
                            break block12;
                        }
                        this.g(this, this.getIntent(), r.a.a.a);
                        return;
                    }
                    r.a.c.a((String)"APayActivity", (String)"proceeding in browser");
                    r.a.e.d((d.a)d.a.e);
                    if (r.a.a.c != c.a.b && r.a.a.c != c.a.a) {
                        if (r.a.a.c == c.a.c) {
                            this.j(this, this.getIntent(), r.a.a.a);
                            return;
                        }
                        break block12;
                    }
                    this.g(this, this.getIntent(), null);
                    return;
                }
                catch (Exception exception) {
                    r.a.c.e((String)"APayActivity", (String)"Error while initializing activity", (Throwable)exception);
                    r.a.e.d((d.a)d.a.m);
                    this.f(APayError.ErrorType.APAY_ERROR, exception);
                }
            }
        }
    }

    public void onDestroy() {
        r.a.c.a((String)"APayActivity", (String)"on destroy called");
        this.d = false;
        super.onDestroy();
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getData() != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("in on new intent with data:");
            stringBuilder.append(String.valueOf((Object)intent.getData().toString()));
            r.a.c.a((String)"APayActivity", (String)stringBuilder.toString());
            this.k(intent);
            this.finish();
        }
        this.d = false;
    }

    public void onResume() {
        super.onResume();
        if (this.d) {
            r.a.c.a((String)"APayActivity", (String)"resume existing operation");
            Intent intent = new Intent();
            intent.putExtras(new Bundle());
            this.h(intent);
            this.finish();
            return;
        }
        if (this.a != null) {
            r.a.c.a((String)"APayActivity", (String)"sending redirect info to auth sdk");
            this.a.l();
            this.d = true;
            return;
        }
        r.a.c.f((String)"APayActivity", (String)"Unable to continue with authorization. Returning.");
        this.f(APayError.ErrorType.LOW_MEMORY, (Exception)((Object)new RuntimeException("insufficient memory to complete authorize operation")));
        this.finish();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        r.a.c.a((String)"APayActivity", (String)"onSaveInstantState called");
        bundle.putBoolean("HAS_OPERATION_STARTED", this.d);
        bundle.putParcelable("COMPLETION_INTENT", (Parcelable)this.b);
        bundle.putParcelable("CANCEL_INTENT", (Parcelable)this.c);
        bundle.putSerializable("OPERATION", (Serializable)r.a.a.c);
        bundle.putSerializable("CODE_CHALLENGE", (Serializable)this.f);
        String string = this.e;
        if (string != null) {
            bundle.putSerializable("PAY_URL", (Serializable)string);
        }
    }

}

