/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.os.AsyncTask
 *  android.util.Base64
 *  android.util.Log
 *  com.google.firebase.perf.network.FirebasePerfUrlConnection
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.ref.WeakReference
 *  java.net.HttpURLConnection
 *  java.net.MalformedURLException
 *  java.net.URL
 *  java.net.URLConnection
 *  java.net.URLEncoder
 *  java.util.zip.GZIPOutputStream
 *  javax.net.ssl.HttpsURLConnection
 *  org.json.JSONArray
 *  org.json.JSONObject
 *  r.a.a
 *  r.a.d
 *  r.a.f
 *  r.a.g
 */
package amazonpay.silentpay;

import amazonpay.silentpay.c;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;
import r.a.f;
import r.a.g;

public final class d {
    public static f a;
    public static WeakReference<d> b;
    public static String c;

    public static {
        b = new WeakReference(null);
    }

    public d(Context context) {
        a = new f(context.getSharedPreferences("RECORDS_PREFS", 0));
        c = context.getPackageName();
        if (!a.g("PUBLISH_IN_MS")) {
            a.c("PUBLISH_IN_MS", System.currentTimeMillis() + r.a.a.b.j());
        }
    }

    public static d a(Context context) {
        if (b.get() == null) {
            b = new WeakReference((Object)new d(context));
        }
        return (d)b.get();
    }

    public static void m() {
        a.b();
    }

    public final JSONObject b(c.a a2, a a3) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("op", (Object)a2);
        jSONObject.put("event", (Object)a3.a());
        jSONObject.put("count", (Object)Integer.toString((int)1));
        return jSONObject;
    }

    public final JSONObject c(String string) {
        JSONObject jSONObject = new JSONObject(string);
        String string2 = jSONObject.get("count").toString();
        jSONObject.remove("count");
        jSONObject.put("count", (Object)Integer.toString((int)(1 + Integer.valueOf((String)string2))));
        return jSONObject;
    }

    public final JSONObject d(String string, String string2, String string3, Throwable throwable) {
        JSONObject jSONObject = new JSONObject();
        if (throwable != null) {
            Object[] arrobject = new Object[]{string, string2, string3, throwable.toString()};
            jSONObject.put("logs", (Object)String.format((String)"%s|%s : %s %s", (Object[])arrobject));
            return jSONObject;
        }
        jSONObject.put("logs", (Object)String.format((String)"%s|%s : %s", (Object[])new Object[]{string, string2, string3}));
        return jSONObject;
    }

    /*
     * Exception decompiling
     */
    public void f(long var1, long var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl75 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public void g(a var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl58 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public void h(String var1, String var2, Throwable var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl64 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public final String j(String string) {
        if (string != null) {
            return string.substring(1, -2 + string.length()).replaceFirst("\"logs\":\"", "");
        }
        return "";
    }

    public final JSONObject k(String string, String string2, Throwable throwable) {
        JSONObject jSONObject = new JSONObject();
        if (throwable != null) {
            Object[] arrobject = new Object[]{string, string2, throwable.toString()};
            jSONObject.put("logs", (Object)String.format((String)"%s : %s %s", (Object[])arrobject));
            return jSONObject;
        }
        jSONObject.put("logs", (Object)String.format((String)"%s : %s", (Object[])new Object[]{string, string2}));
        return jSONObject;
    }

    public final boolean n() {
        boolean bl;
        block5 : {
            block4 : {
                long l;
                long l2;
                try {
                    if (a.e() > r.a.a.b.k()) break block4;
                    l = a.f("PUBLISH_IN_MS");
                    l2 = System.currentTimeMillis();
                }
                catch (Exception exception) {
                    Log.w((String)"RecordAggregator", (String)"error while fetching records size");
                    d.m();
                    return false;
                }
                long l3 = l LCMP l2;
                bl = false;
                if (l3 > 0) break block5;
            }
            bl = true;
        }
        return bl;
    }

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a A;
        public static final /* enum */ a B;
        public static final /* enum */ a C;
        public static final /* enum */ a D;
        public static final /* enum */ a E;
        public static final /* enum */ a F;
        public static final /* enum */ a G;
        public static final /* enum */ a H;
        private static final /* synthetic */ a[] J;
        public static final /* enum */ a a;
        public static final /* enum */ a b;
        public static final /* enum */ a c;
        public static final /* enum */ a d;
        public static final /* enum */ a e;
        public static final /* enum */ a f;
        public static final /* enum */ a g;
        public static final /* enum */ a h;
        public static final /* enum */ a i;
        public static final /* enum */ a j;
        public static final /* enum */ a k;
        public static final /* enum */ a l;
        public static final /* enum */ a m;
        public static final /* enum */ a n;
        public static final /* enum */ a o;
        public static final /* enum */ a p;
        public static final /* enum */ a q;
        public static final /* enum */ a r;
        public static final /* enum */ a s;
        public static final /* enum */ a t;
        public static final /* enum */ a u;
        public static final /* enum */ a v;
        public static final /* enum */ a w;
        public static final /* enum */ a x;
        public static final /* enum */ a y;
        public static final /* enum */ a z;
        private String I;

        public static {
            a a2;
            a a3;
            a a4;
            a a5;
            a a6;
            a a7;
            a a8;
            a a9;
            a a10;
            a a11;
            a a12;
            a a13;
            a a14;
            a a15;
            a a16;
            a a17;
            a a18;
            a a19;
            a a20;
            a a21;
            a a22;
            a a23;
            a a24;
            a a25;
            a a26;
            a a27;
            a a28;
            a a29;
            a a30;
            a a31;
            a a32;
            a a33;
            a a34;
            a a35;
            a = a23 = new a("810");
            b = a8 = new a("811");
            c = a7 = new a("812");
            d = a20 = new a("820");
            e = a32 = new a("830");
            f = a6 = new a("840");
            g = a17 = new a("841");
            h = a28 = new a("842");
            i = a11 = new a("843");
            j = a15 = new a("844");
            k = a31 = new a("845");
            l = a16 = new a("850");
            m = a21 = new a("851");
            n = a14 = new a("852");
            o = a29 = new a("860");
            p = a24 = new a("861");
            q = a2 = new a("862");
            r = a33 = new a("863");
            s = a12 = new a("864");
            t = a5 = new a("865");
            u = a34 = new a("866");
            v = a18 = new a("867");
            w = a4 = new a("868");
            x = a26 = new a("870");
            y = a9 = new a("871");
            z = a30 = new a("890");
            A = a19 = new a("891");
            B = a3 = new a("892");
            C = a22 = new a("893");
            D = a27 = new a("894");
            E = a35 = new a("895");
            F = a13 = new a("900");
            G = a25 = new a("901");
            H = a10 = new a("902");
            J = new a[]{a23, a8, a7, a20, a32, a6, a17, a28, a11, a15, a31, a16, a21, a14, a29, a24, a2, a33, a12, a5, a34, a18, a4, a26, a9, a30, a19, a3, a22, a27, a35, a13, a25, a10};
        }

        private a(String string2) {
            this.I = string2;
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])J.clone();
        }

        public String a() {
            return this.I;
        }
    }

    public static class c
    extends AsyncTask<Void, Void, String> {
        public static int a;

        public c() {
        }

        public /* synthetic */ c(b b2) {
            this();
        }

        /*
         * Exception decompiling
         */
        public final String a() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl55 : ACONST_NULL : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public /* varargs */ String b(Void ... arrvoid) {
            if (this.isCancelled()) return null;
            String string = this.a();
            if (string == null) return null;
            try {
                if (string.length() <= 0) return null;
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection)((URLConnection)FirebasePerfUrlConnection.instrument((Object)new URL(r.a.a.b.m()).openConnection()));
                g.e((HttpURLConnection)httpsURLConnection, (byte[])string.getBytes(), (String)"application/x-www-form-urlencoded");
                if (httpsURLConnection.getResponseCode() == 200) {
                    return g.c((InputStream)httpsURLConnection.getInputStream());
                }
                a = 1 + a;
                Log.w((String)"RecordPublisher", (String)"Record publishing failed.");
                return null;
            }
            catch (Exception exception) {
                a = 1 + a;
                d.m();
                Log.w((String)"RecordPublisher", (String)"Something went wrong while publishing records", (Throwable)exception);
                return null;
            }
            catch (IOException iOException) {
                a = 1 + a;
                Log.w((String)"RecordPublisher", (String)"IOException while publishing logs", (Throwable)iOException);
                d.m();
                return null;
            }
            catch (MalformedURLException malformedURLException) {
                a = 1 + a;
                d.m();
                Log.w((String)"RecordPublisher", (String)"MalformedURL while publishing records", (Throwable)malformedURLException);
            }
            return null;
        }

        public final JSONObject c(JSONObject jSONObject) {
            JSONObject jSONObject2 = new JSONObject();
            if (jSONObject != null) {
                if (jSONObject.toString().getBytes().length >= 860) {
                    jSONObject2.put("payload", (Object)URLEncoder.encode((String)this.f(jSONObject.toString()), (String)"UTF-8"));
                    jSONObject2.put("isCompressed", (Object)"true");
                    jSONObject = jSONObject2;
                } else {
                    jSONObject.put("isCompressed", (Object)"false");
                }
                jSONObject.put("sdkType", (Object)"android");
                jSONObject.put("appId", (Object)c);
                return jSONObject;
            }
            throw new IllegalArgumentException("appended records were null");
        }

        public void d(String string) {
            super.onPostExecute((Object)string);
            if (!this.isCancelled() && string != null && string.length() > 0) {
                try {
                    JSONObject jSONObject = new JSONObject(string);
                    if (jSONObject.has("status") && jSONObject.getString("status").equalsIgnoreCase("success")) {
                        a = 0;
                        d.m();
                        a.c("PUBLISH_IN_MS", System.currentTimeMillis() + r.a.a.b.j());
                        return;
                    }
                    a = 1 + a;
                    Log.w((String)"RecordPublisher", (String)"Record publishing failed.");
                    return;
                }
                catch (Exception exception) {
                    Log.w((String)"RecordPublisher", (String)"Error while serializing response", (Throwable)exception);
                    d.m();
                }
            }
        }

        public /* synthetic */ Object doInBackground(Object[] arrobject) {
            return this.b((Void[])arrobject);
        }

        public final void e(String string, JSONObject jSONObject) {
            if (a.a(string) != null) {
                if (jSONObject.has("payload")) {
                    JSONObject jSONObject2 = new JSONObject(jSONObject.getString("payload"));
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(jSONObject2.toString());
                    stringBuilder.append(a.a(string));
                    jSONObject.put("payload", (Object)new JSONObject(stringBuilder.toString().replaceAll("\\}\\{", ",")));
                    return;
                }
                jSONObject.put("payload", (Object)a.a(string));
            }
        }

        public String f(String string) {
            if (string != null && string.length() > 0) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(string.length());
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream((OutputStream)byteArrayOutputStream);
                gZIPOutputStream.write(string.getBytes("UTF-8"));
                gZIPOutputStream.close();
                byte[] arrby = byteArrayOutputStream.toByteArray();
                byteArrayOutputStream.close();
                return Base64.encodeToString((byte[])arrby, (int)2);
            }
            return null;
        }

        public final JSONObject g() {
            JSONObject jSONObject = new JSONObject();
            this.h(jSONObject);
            if (a.g("TIME_RECORDS")) {
                this.e("TIME_RECORDS", jSONObject);
            }
            if (a.g("LOG_RECORDS")) {
                this.e("LOG_RECORDS", jSONObject);
            }
            return jSONObject;
        }

        public final void h(JSONObject jSONObject) {
            JSONArray jSONArray = new JSONArray();
            JSONObject jSONObject2 = new JSONObject();
            for (a a2 : a.values()) {
                if (!a.g(a2.name())) continue;
                jSONArray.put((Object)new JSONObject(a.a(a2.name())));
            }
            if (jSONArray.length() > 0) {
                jSONObject2.put("events", (Object)jSONArray);
                jSONObject.put("payload", (Object)jSONObject2);
            }
        }

        public /* synthetic */ void onPostExecute(Object object) {
            this.d((String)object);
        }

        public void onPreExecute() {
            super.onPreExecute();
            if (a > r.a.a.b.l()) {
                this.cancel(true);
                Log.w((String)"RecordPublisher", (String)"Attempts to publish records exceeded");
                d.m();
                a.c("PUBLISH_IN_MS", System.currentTimeMillis() + r.a.a.b.j());
            }
        }
    }

}

