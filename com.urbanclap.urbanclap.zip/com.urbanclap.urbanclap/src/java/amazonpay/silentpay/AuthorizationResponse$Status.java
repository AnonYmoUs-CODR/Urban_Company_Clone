/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package amazonpay.silentpay;

public final class AuthorizationResponse$Status
extends Enum<AuthorizationResponse$Status> {
    public static final /* enum */ AuthorizationResponse$Status DENIED;
    public static final /* enum */ AuthorizationResponse$Status GRANTED;
    private static final /* synthetic */ AuthorizationResponse$Status[] a;

    public static {
        AuthorizationResponse$Status authorizationResponse$Status;
        AuthorizationResponse$Status authorizationResponse$Status2;
        GRANTED = authorizationResponse$Status2 = new AuthorizationResponse$Status();
        DENIED = authorizationResponse$Status = new AuthorizationResponse$Status();
        a = new AuthorizationResponse$Status[]{authorizationResponse$Status2, authorizationResponse$Status};
    }

    public static AuthorizationResponse$Status valueOf(String string) {
        return (AuthorizationResponse$Status)Enum.valueOf(AuthorizationResponse$Status.class, (String)string);
    }

    public static AuthorizationResponse$Status[] values() {
        return (AuthorizationResponse$Status[])a.clone();
    }
}

